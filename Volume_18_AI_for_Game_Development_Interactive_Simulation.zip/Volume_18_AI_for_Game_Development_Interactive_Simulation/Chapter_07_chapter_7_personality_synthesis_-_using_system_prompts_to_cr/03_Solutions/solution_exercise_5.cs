
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

// 1. Global World State
public class GlobalWorldState
{
    public List<string> Facts { get; } = new List<string>();
    private readonly SemaphoreSlim _lock = new SemaphoreSlim(1, 1);

    public async Task AddFactAsync(string fact)
    {
        await _lock.WaitAsync();
        try
        {
            if (!Facts.Contains(fact))
            {
                Facts.Add(fact);
                Debug.Log($"[Director] New Fact Added: {fact}");
            }
        }
        finally
        {
            _lock.Release();
        }
    }

    public async Task<List<string>> GetFactsAsync()
    {
        await _lock.WaitAsync();
        try
        {
            return new List<string>(Facts); // Return copy
        }
        finally
        {
            _lock.Release();
        }
    }
}

// 2. Director Class
public class NarrativeDirector : MonoBehaviour
{
    public static NarrativeDirector Instance { get; private set; }
    public GlobalWorldState WorldState { get; private set; } = new GlobalWorldState();

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    // 2. Context Generation
    public async Task<string> GenerateSceneContext(string currentSceneDescription)
    {
        var facts = await WorldState.GetFactsAsync();
        string factsStr = string.Join("\n", facts);

        // Construct prompt for LLM
        string prompt = $"Generate a scene briefing based on these world facts:\n{factsStr}\n\nScene: {currentSceneDescription}\n\nBriefing (3-5 bullet points):";

        // Mock LLM Call
        await Task.Delay(200); 
        return $"[Director Context]\n- The air is tense.\n- {currentSceneDescription} is active.\n- Watch for contradictions.";
    }

    // 4. Conflict Resolution
    public async Task CheckForContradiction(string newFact)
    {
        var existingFacts = await WorldState.GetFactsAsync();
        
        // Simple keyword contradiction logic
        foreach (var fact in existingFacts)
        {
            if (fact.Contains("Safe") && newFact.Contains("Dangerous") && fact.Split(' ').Intersect(newFact.Split(' ')).Count() > 1)
            {
                Debug.LogWarning($"[Director] CONTRADICTION DETECTED: '{fact}' vs '{newFact}'");
                
                // Attempt to Retcon
                string retcon = "The area was previously thought safe but is now known to be dangerous.";
                await WorldState.AddFactAsync(retcon);
                return;
            }
        }
        
        // If no contradiction, add the fact
        await WorldState.AddFactAsync(newFact);
    }

    // 3. Injection Helper
    public string InjectDirectorContext(string basePrompt, string directorContext)
    {
        return $"{directorContext}\n\n{basePrompt}";
    }
}

// 3. & 5. Parallel Processing in DialogueManager
public class ParallelDialogueManager : MonoBehaviour
{
    public async Task<List<string>> GetResponsesForScene(List<string> playerInputs, CharacterState state)
    {
        // 1. Get Director Context (Awaited first)
        string sceneContext = await NarrativeDirector.Instance.GenerateSceneContext("A busy tavern");

        // 2. Fire off concurrent tasks
        var tasks = playerInputs.Select(input => 
            GetSingleCharacterResponse(input, state, sceneContext)
        ).ToList();

        // Wait for all to complete
        string[] results = await Task.WhenAll(tasks);

        // 3. Process results and update world state (Parallel)
        var updateTasks = results.Select(r => 
            NarrativeDirector.Instance.CheckForContradiction(r)
        );
        
        await Task.WhenAll(updateTasks);

        return results.ToList();
    }

    private async Task<string> GetSingleCharacterResponse(string input, CharacterState state, string context)
    {
        // Simulate LLM processing time (random)
        await Task.Delay(UnityEngine.Random.Range(500, 1500));
        
        // Mock response generation
        string response = $"Response to '{input}' in state {state}.";
        
        // Randomly introduce a fact for the Director to check
        if (UnityEngine.Random.value > 0.5f) response += " The tavern is safe.";
        else response += " The tavern is dangerous.";

        return response;
    }
}
