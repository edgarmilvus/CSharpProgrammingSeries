
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// 1. ScriptableObject Definition
[System.Serializable]
public struct Trait
{
    public string Name;
    [Range(0f, 1f)] public float Weight;
}

[CreateAssetMenu(fileName = "NewPersonality", menuName = "Personality/Profile")]
public class PersonalityProfile : ScriptableObject
{
    public string CharacterName;
    public AnimationCurve MoodCurve; // Time (0-1) maps to Tone intensity
    public List<Trait> Traits = new List<Trait>();
}

// 2. Prompt Compiler
public static class PersonalityCompiler
{
    public static string Compile(PersonalityProfile profile, float currentStressLevel)
    {
        var sb = new StringBuilder();

        sb.AppendLine($"Character Name: {profile.CharacterName}");

        // Evaluate MoodCurve (0 to 1 stress)
        float toneIntensity = profile.MoodCurve.Evaluate(currentStressLevel);
        string toneDescription = toneIntensity > 0.5f ? "Intense" : "Calm";
        sb.AppendLine($"Current Tone: {toneDescription} (Intensity: {toneIntensity:F2})");

        sb.AppendLine("Core Traits:");
        foreach (var trait in profile.Traits)
        {
            // Convert weight to descriptive adverb
            string intensity = trait.Weight > 0.7f ? "highly" : (trait.Weight > 0.3f ? "moderately" : "slightly");
            sb.AppendLine($"- {intensity} {trait.Name} ({trait.Weight:F2})");
        }

        return sb.ToString();
    }

    // 4. Interactive Challenge: Personality Drift
    public static void UpdatePersonalityProfile(PersonalityProfile profile, float interactionImpact)
    {
        // Modify traits based on impact (e.g., positive interaction increases 'Kindness')
        // For simplicity, we assume interactionImpact > 0 increases the first trait, 
        // < 0 increases the second (or a designated 'Aggression' trait).
        
        // NOTE: Modifying ScriptableObjects at runtime modifies the asset file.
        // In a real production environment, we would clone the SO or use a runtime data container.
        
        foreach (var trait in profile.Traits)
        {
            // Simple drift logic: Shift weight towards the impact direction
            // Clamping between 0 and 1
            trait.Weight = Mathf.Clamp01(trait.Weight + (interactionImpact * 0.1f));
        }

        // Mark the asset as dirty to save changes (Editor only usually, but requested for exercise)
        #if UNITY_EDITOR
        UnityEditor.EditorUtility.SetDirty(profile);
        #endif
    }
}

// 3. Dynamic System Prompt Integration (Modifying Exercise 1 Factory)
public static class PromptFactoryV2
{
    public static string GenerateDynamicPrompt(CharacterArchetype archetype, PersonalityProfile profile, float stressLevel)
    {
        // Compile personality
        string personalityDesc = PersonalityCompiler.Compile(profile, stressLevel);

        var sb = new StringBuilder();
        sb.AppendLine("SYSTEM PROMPT:");
        sb.AppendLine($"Archetype: {archetype.ArchetypeName}");
        sb.AppendLine("--- Dynamic Personality ---");
        sb.AppendLine(personalityDesc);
        sb.AppendLine("---------------------------");
        sb.AppendLine("Output Format: JSON");

        return sb.ToString();
    }
}
