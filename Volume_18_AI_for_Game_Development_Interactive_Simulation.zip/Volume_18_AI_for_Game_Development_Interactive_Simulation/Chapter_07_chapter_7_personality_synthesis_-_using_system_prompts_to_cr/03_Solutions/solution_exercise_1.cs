
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// 1. Data Structure: CharacterArchetype
// Using a record struct for lightweight, immutable data storage.
public record struct CharacterArchetype(
    string ArchetypeName,
    string Tone,
    string KnowledgeDomain,
    float Temperature,
    List<string> CoreMemories
);

public static class PromptFactory
{
    // 2. Prompt Factory: GenerateSystemPrompt
    public static string GenerateSystemPrompt(CharacterArchetype archetype)
    {
        // Construct the detailed system prompt
        var sb = new StringBuilder();
        
        sb.AppendLine("You are a character in a simulation. Adhere strictly to the following profile.");
        sb.AppendLine($"Archetype: {archetype.ArchetypeName}");
        sb.AppendLine($"Tone: {archetype.Tone}");
        sb.AppendLine($"Knowledge Domain: {archetype.KnowledgeDomain}");
        sb.AppendLine($"Temperature (Creativity): {archetype.Temperature}");
        
        sb.AppendLine("\nCore Memories (Reference these when relevant):");
        foreach (var memory in archetype.CoreMemories)
        {
            sb.AppendLine($"- {memory}");
        }

        sb.AppendLine("\nCRITICAL OUTPUT INSTRUCTIONS:");
        sb.AppendLine("You MUST respond ONLY with a valid JSON object.");
        sb.AppendLine("Format: { \"response\": \"string\", \"emotion\": \"enum\", \"action\": \"string\" }");
        sb.AppendLine("Do not include any text before or after the JSON object.");

        string prompt = sb.ToString();

        // 3. Token Estimation & 4. Validation
        int estimatedTokens = EstimateTokenCount(prompt);
        if (estimatedTokens > 4096)
        {
            throw new ArgumentOutOfRangeException(nameof(archetype), 
                $"Generated prompt exceeds token limit (Est: {estimatedTokens}). " +
                $"Suggestion: Trim 'CoreMemories' or 'ArchetypeName' to reduce length.");
        }

        return prompt;
    }

    // 3. Token Estimation Heuristic
    public static int EstimateTokenCount(string prompt)
    {
        // Heuristic: 1 token ~= 4 characters
        return (int)Math.Ceiling(prompt.Length / 4.0);
    }

    // Interactive Challenge: Dynamic Context Injection
    public static string GenerateContextualPrompt(CharacterArchetype archetype, string recentPlayerAction)
    {
        // Start with base prompt
        var basePrompt = GenerateSystemPrompt(archetype);
        var baseTokens = EstimateTokenCount(basePrompt);
        
        // Estimate action tokens
        var actionTokens = EstimateTokenCount(recentPlayerAction);
        var totalTokens = baseTokens + actionTokens;

        // If exceeding limit, truncate CoreMemories (oldest first)
        if (totalTokens > 4096)
        {
            // Calculate how many tokens we need to save
            int excess = totalTokens - 4096;
            
            // Create a mutable list to modify
            var mutableMemories = new List<string>(archetype.CoreMemories);
            
            while (excess > 0 && mutableMemories.Count > 0)
            {
                // Remove oldest (index 0)
                int removedTokens = EstimateTokenCount(mutableMemories[0]);
                mutableMemories.RemoveAt(0);
                excess -= removedTokens;
            }

            // Reconstruct archetype with truncated memories
            var trimmedArchetype = archetype with { CoreMemories = mutableMemories };
            basePrompt = GenerateSystemPrompt(trimmedArchetype);
        }

        // Append the player action context
        return $"{basePrompt}\n\nRecent Player Action: {recentPlayerAction}";
    }
}
