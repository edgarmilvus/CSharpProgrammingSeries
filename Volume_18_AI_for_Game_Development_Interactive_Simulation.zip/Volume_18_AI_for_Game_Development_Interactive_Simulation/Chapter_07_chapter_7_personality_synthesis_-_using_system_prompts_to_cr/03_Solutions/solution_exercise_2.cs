
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using TMPro;

// 1. State Machine Enum
public enum CharacterState { Idle, Inquiry, Trading, Combat }

// Mock interface for the LLM client
public interface IChatClient
{
    IAsyncEnumerable<string> GetStreamingResponseAsync(string prompt);
}

public class DialogueManager : MonoBehaviour
{
    public TextMeshProUGUI dialogueTextUI;
    private IChatClient _chatClient; // Injected via Inspector or DI
    
    // Buffer for streaming text
    private readonly Queue<string> _responseBuffer = new Queue<string>();
    private bool _isProcessing = false;

    // 2. Async Implementation & 4. UI Integration
    public async Task GetResponseAsync(string playerInput, CharacterState currentState)
    {
        if (_isProcessing) return;
        _isProcessing = true;

        // Construct prompt with state context
        string prompt = $"Current State: {currentState}\nPlayer: {playerInput}\nResponse:";

        // Clear previous UI text
        dialogueTextUI.text = "";

        // 5. Refactor: Streaming Responses via IAsyncEnumerable
        // We assume _chatClient returns an async stream of tokens
        await foreach (var token in _chatClient.GetStreamingResponseAsync(prompt))
        {
            // Enqueue the token (chunk) for the UI coroutine to process
            _responseBuffer.Enqueue(token);
            
            // If the UI processor isn't running, start it
            if (!_isProcessing) StartCoroutine(ProcessBuffer());
        }

        _isProcessing = false;
    }

    // 4. & 5. UI Coroutine for Typing Effect
    private IEnumerator ProcessBuffer()
    {
        while (_responseBuffer.Count > 0)
        {
            string chunk = _responseBuffer.Dequeue();
            dialogueTextUI.text += chunk;

            // Simulate typing speed (e.g., 50 chars per second)
            // Calculate delay based on chunk length to maintain speed
            float delay = chunk.Length / 50f; 
            yield return new WaitForSeconds(delay);
        }
    }

    // 3. State Transition Logic (Mock Analysis)
    private CharacterState AnalyzeResponseForTransition(string response, CharacterState currentState)
    {
        // Simple keyword analysis for state transition
        if (response.Contains("buy") || response.Contains("sell"))
        {
            return CharacterState.Trading;
        }
        if (response.Contains("attack") || response.Contains("defend"))
        {
            return CharacterState.Combat;
        }
        return currentState; // Default no change
    }
}

// Mock Implementation of IChatClient for Exercise purposes
public class MockChatClient : IChatClient
{
    public async IAsyncEnumerable<string> GetStreamingResponseAsync(string prompt)
    {
        // Simulate network delay
        await Task.Delay(UnityEngine.Random.Range(1000, 3000));

        string mockResponse = "I see you are interested in trading. Let us discuss prices.";
        
        // Simulate streaming tokens (words)
        string[] tokens = mockResponse.Split(' ');
        foreach (var token in tokens)
        {
            yield return token + " ";
            await Task.Delay(100); // Simulate token arrival rate
        }
    }
}
