
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// 1. Memory Structures
public class ConversationTurn
{
    public string PlayerInput { get; set; }
    public string AiResponse { get; set; }
}

public class CharacterMemory
{
    public List<ConversationTurn> History { get; set; } = new List<ConversationTurn>();
    public List<string> WorldStateFlags { get; set; } = new List<string>();
}

// Interface for World State updates
public interface IWorldStateObserver
{
    void UpdateWorldState(string flag);
}

// 2. Context Builder & 4. Interactive Challenge (Forgetfulness)
public static class ContextBuilder
{
    private const int HISTORY_TOKEN_LIMIT = 1000;
    private const int CHARS_PER_TOKEN = 4;

    public static string BuildContextPrompt(CharacterMemory memory, string currentPlayerInput)
    {
        var sb = new StringBuilder();

        // World State
        if (memory.WorldStateFlags.Any())
        {
            sb.AppendLine("World State Flags:");
            foreach (var flag in memory.WorldStateFlags)
            {
                sb.AppendLine($"- {flag}");
            }
        }

        // History with Relevance Scoring
        if (memory.History.Any())
        {
            sb.AppendLine("Conversation History:");
            
            // Calculate relevance for each turn based on keyword overlap
            var scoredHistory = memory.History
                .Select(turn => new 
                { 
                    Turn = turn, 
                    Score = CalculateRelevance(turn, currentPlayerInput) 
                })
                .OrderByDescending(x => x.Score) // Most relevant first
                .ToList();

            string historyBlock = "";
            int currentTokenCount = 0;

            foreach (var item in scoredHistory)
            {
                string turnText = $"Player: {item.Turn.PlayerInput} | NPC: {item.Turn.AiResponse}";
                int turnTokens = turnText.Length / CHARS_PER_TOKEN;

                // If adding this exceeds limit, summarize or skip
                if (currentTokenCount + turnTokens > HISTORY_TOKEN_LIMIT)
                {
                    // Interactive Challenge: Summarization Strategy
                    // Instead of hard truncation, we append a summary note
                    if (!sb.ToString().Contains("[Previous context summarized]"))
                    {
                        sb.AppendLine("[Previous context summarized due to length]");
                    }
                    break; 
                }

                historyBlock += turnText + "\n";
                currentTokenCount += turnTokens;
            }
            
            sb.Append(historyBlock);
        }

        return sb.ToString();
    }

    // Approximate semantic similarity via keyword overlap
    private static float CalculateRelevance(ConversationTurn turn, string currentInput)
    {
        var inputWords = currentInput.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var historyWords = (turn.PlayerInput + " " + turn.AiResponse).Split(' ', StringSplitOptions.RemoveEmptyEntries);
        
        int matches = inputWords.Intersect(historyWords, StringComparer.OrdinalIgnoreCase).Count();
        
        // Normalize by input length to get a score between 0 and 1
        return (float)matches / inputWords.Length;
    }
}

// 3. Integration into DialogueManager
public class DialogueManagerWithMemory : MonoBehaviour, IWorldStateObserver
{
    public CharacterMemory Memory { get; private set; } = new CharacterMemory();

    // Called by other systems (QuestManager, etc.)
    public void UpdateWorldState(string flag)
    {
        if (!Memory.WorldStateFlags.Contains(flag))
        {
            Memory.WorldStateFlags.Add(flag);
        }
    }

    public async Task<string> GetResponseWithMemory(string playerInput, CharacterState state)
    {
        // 1. Build Context
        string context = ContextBuilder.BuildContextPrompt(Memory, playerInput);
        
        // 2. Construct Full Prompt
        string fullPrompt = $"{context}\nCurrent State: {state}\nPlayer: {playerInput}";

        // 3. Call LLM (Mocked)
        string aiResponse = await MockLLMCall(fullPrompt);

        // 4. Update History
        Memory.History.Add(new ConversationTurn 
        { 
            PlayerInput = playerInput, 
            AiResponse = aiResponse 
        });

        // Keep history manageable (optional, though context builder handles token limits)
        if (Memory.History.Count > 20) Memory.History.RemoveAt(0);

        return aiResponse;
    }

    private async Task<string> MockLLMCall(string prompt)
    {
        await Task.Delay(500);
        return "I remember what you said. The world feels different now.";
    }
}
