
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

using System.Collections.Generic;
using UnityEngine;

namespace AI.GameDev.Personality
{
    // Interface from Book 12: Design Patterns for AI
    // Defines the contract for any LLM provider to handle personality synthesis.
    public interface IPersonalityEngine
    {
        // The core method that takes the Triad components and constructs the prompt.
        // Returns a formatted string ready for the specific model's API.
        string ConstructPrompt(
            string archetype, 
            string backstory, 
            EmotionalState currentEmotion, 
            List<string> interactionHistory
        );

        // Validates if the constructed prompt fits within the model's token limit.
        bool ValidateTokenLimit(string prompt, int maxTokens);
    }

    // Example of the Emotional State struct used in the Triad
    public struct EmotionalState
    {
        public float Joy;
        public float Anger;
        public float Fear;
        public float Trust;
        
        public override string ToString()
        {
            // Converts float values to descriptive strings for the LLM
            return $"Emotion(Joy:{Joy:F2}, Anger:{Anger:F2})";
        }
    }
}
