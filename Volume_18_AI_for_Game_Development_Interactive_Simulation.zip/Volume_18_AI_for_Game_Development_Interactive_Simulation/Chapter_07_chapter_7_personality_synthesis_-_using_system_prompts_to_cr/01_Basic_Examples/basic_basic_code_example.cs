
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// A self-contained example demonstrating how to generate a unique character 
/// personality using a System Prompt and an LLM API call, then use that 
/// personality to drive dialogue in a Unity scene.
/// 
/// Context: You are building a small RPG. You need an NPC (Non-Player Character) 
/// named "Elara" who is a cynical, ancient librarian. Instead of hard-coding 
/// thousands of lines of dialogue, you define her "soul" via a system prompt 
/// and let an LLM generate her responses dynamically based on player input.
/// </summary>
public class PersonalitySynthesisExample : MonoBehaviour
{
    // --- Configuration ---
    
    [Header("Personality Definition")]
    [Tooltip("The System Prompt defines the character's soul, constraints, and voice.")]
    [TextArea(10, 20)]
    public string systemPrompt = "You are Elara, an ancient librarian in a fantasy world. " +
                                 "You are cynical, sarcastic, and speak in short, clipped sentences. " +
                                 "You value knowledge above all else. " +
                                 "If the user asks for something trivial, scold them. " +
                                 "Do not break character. Keep responses under 50 words.";

    [Header("Simulation Settings")]
    public string playerName = "Adventurer";
    
    // Mock API URL (In a real scenario, this would be your LLM provider's endpoint)
    private const string MockApiUrl = "https://api.mock-llm.com/v1/chat/completions";

    // --- Unity Lifecycle ---

    private async void Start()
    {
        // 1. Initialize the dialogue system
        Debug.Log("Starting Personality Synthesis Demo...");
        
        // 2. Simulate a player interaction
        string playerInput = "Hello! I need to find the ancient tome of power.";
        
        // 3. Generate the NPC response using the defined personality
        string npcResponse = await GetNpcResponse(playerInput);
        
        // 4. Display the result
        DisplayDialogue(npcResponse);
    }

    // --- Core Logic ---

    /// <summary>
    /// Orchestrates the generation of a response by constructing the prompt 
    /// and simulating an API call.
    /// </summary>
    private async Task<string> GetNpcResponse(string playerMessage)
    {
        // Construct the full conversation history for the LLM
        // In a real game, you would maintain a List<ChatMessage> history.
        string prompt = BuildPrompt(playerMessage);

        // Simulate network latency
        await Task.Delay(500); 

        // SIMULATED API CALL:
        // In a production environment, you would use UnityWebRequest or a dedicated SDK.
        // Here, we mock the LLM's response based on the prompt's intent.
        string llmOutput = MockLlmResponse(playerMessage);

        return llmOutput;
    }

    /// <summary>
    /// Constructs the prompt by combining the System Persona and the User Input.
    /// </summary>
    private string BuildPrompt(string userMessage)
    {
        // Using StringBuilder for efficient string concatenation
        StringBuilder sb = new StringBuilder();
        
        sb.AppendLine($"System: {systemPrompt}");
        sb.AppendLine($"User ({playerName}): {userMessage}");
        sb.AppendLine("Elara:"); // We prime the model to start speaking immediately
        
        return sb.ToString();
    }

    /// <summary>
    /// A deterministic mock function that simulates an LLM response.
    /// This ensures the code example runs without an actual API key.
    /// </summary>
    private string MockLlmResponse(string input)
    {
        // Simple keyword matching to simulate "personality" logic
        // An LLM would do this via semantic understanding, but for this example,
        // we simulate the output based on the System Prompt rules.
        
        if (input.ToLower().Contains("hello") || input.ToLower().Contains("hi"))
        {
            return "Hmph. Greetings. State your business, mortal.";
        }
        
        if (input.ToLower().Contains("tome") || input.ToLower().Contains("power"))
        {
            return "The Tome of Power? Dangerous knowledge. Are you sure you can handle it?";
        }

        if (input.ToLower().Contains("please"))
        {
            return "Politeness won't help you here. What do you want?";
        }

        return "I have no time for such trivialities.";
    }

    /// <summary>
    /// Handles the visual representation of the dialogue in the Unity Console.
    /// </summary>
    private void DisplayDialogue(string text)
    {
        // In a real game, this would update a UI TextMeshPro component.
        // For this example, we log to the console.
        Debug.Log($"<color=#FFD700>[Elara]</color>: {text}");
    }
}
