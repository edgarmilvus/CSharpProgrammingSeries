
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalitySynthesisEngine
{
    // CORE CONCEPT 1: The System Prompt Template
    // In Chapter 7, we learned that a System Prompt is the "DNA" of an AI character.
    // It defines the immutable traits: Archetype, Backstory, and Emotional Range.
    // We use C# string interpolation to dynamically inject context (like the player's name)
    // into the static DNA, creating a unique instance of the character.
    public class CharacterSystemPrompt
    {
        public string Archetype { get; set; }
        public string Backstory { get; set; }
        public string EmotionalRange { get; set; }
        public string PlayerName { get; set; }

        // This method constructs the final prompt string sent to the LLM.
        // It adheres to the "Context Injection" technique discussed in the chapter.
        public string GeneratePrompt()
        {
            // We use a StringBuilder for efficient string manipulation, a best practice
            // for handling potentially long prompt strings in C#.
            StringBuilder promptBuilder = new StringBuilder();

            promptBuilder.AppendLine("SYSTEM INSTRUCTIONS:");
            promptBuilder.AppendLine("You are an AI character in a simulation. Maintain strict consistency.");
            promptBuilder.AppendLine($"ARCHETYPE: {Archetype}");
            promptBuilder.AppendLine($"BACKSTORY: {Backstory}");
            promptBuilder.AppendLine($"EMOTIONAL RANGE: {EmotionalRange}");
            promptBuilder.AppendLine($"INTERACTION CONTEXT: You are speaking to {PlayerName}.");
            promptBuilder.AppendLine("RULES:");
            promptBuilder.AppendLine("1. Respond in character.");
            promptBuilder.AppendLine("2. Keep responses under 100 words.");
            promptBuilder.AppendLine("3. Do not break the fourth wall.");

            return promptBuilder.ToString();
        }
    }

    // CORE CONCEPT 2: Token Management & Context Windows
    // Chapter 7 emphasizes the technical limitation of LLMs: Token Limits.
    // A "Token" is roughly 4 characters of text. LLMs have a finite context window (e.g., 4096 tokens).
    // If a conversation exceeds this limit, the earliest context is dropped ("forgotten").
    // This class simulates the logic required to manage this window in a real-time Unity simulation.
    public class DialogueHistoryManager
    {
        // Simulating a token limit (e.g., 4096 tokens).
        // In a real LLM, 1 token ~= 4 chars. We simulate this by character count.
        private const int MAX_TOKEN_LIMIT = 4000; 
        private const int CHARS_PER_TOKEN = 4;
        private const int MAX_CHARS = MAX_TOKEN_LIMIT * CHARS_PER_TOKEN;

        // We store the conversation as a list of strings (turns).
        private List<string> history = new List<string>();

        // Adds a new exchange to the history and checks if we exceed the limit.
        public void AddExchange(string userInput, string aiResponse)
        {
            string exchange = $"User: {userInput} | AI: {aiResponse}";
            history.Add(exchange);

            // Calculate current total length.
            int currentLength = 0;
            foreach (string turn in history)
            {
                currentLength += turn.Length;
            }

            // If we exceed the limit, we must prune the history.
            // Chapter 7 discusses "Truncation Strategies". 
            // The simplest strategy is First-In-First-Out (FIFO).
            while (currentLength > MAX_CHARS && history.Count > 0)
            {
                string removedTurn = history[0];
                history.RemoveAt(0);
                currentLength -= removedTurn.Length;

                Console.WriteLine($"[TOKEN MANAGER] Pruning old context: '{removedTurn.Substring(0, Math.Min(30, removedTurn.Length))}...'");
            }
        }

        // Retrieves the history formatted for the LLM prompt.
        public string GetFormattedHistory()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CONVERSATION HISTORY:");
            foreach (string turn in history)
            {
                sb.AppendLine(turn);
            }
            return sb.ToString();
        }
    }

    // CORE CONCEPT 3: The Personality Synthesis Engine
    // This class acts as the bridge between the static data (System Prompts) 
    // and the dynamic runtime (Game Loop).
    public class PersonalitySynthesisEngine
    {
        // In a real application, this would be an API call to an LLM provider (e.g., OpenAI, Azure).
        // For this console simulation, we mock the LLM response logic.
        // We use basic control flow (if/else) to demonstrate how different archetypes react differently
        // to the same input, simulating the LLM's generation based on the System Prompt.
        public string GenerateResponse(string systemPrompt, string userInput, string historyContext)
        {
            // Simulating the "Context Window" concatenation.
            // The LLM receives: System Prompt + History + Current Input.
            string fullContext = systemPrompt + "\n" + historyContext + "\nCurrent Input: " + userInput;

            // Analyze the System Prompt to determine the Archetype (Simple parsing).
            // This mimics how the LLM weights its internal parameters based on the instructions.
            string archetype = "Unknown";
            if (fullContext.Contains("Wise Mentor")) archetype = "Wise Mentor";
            else if (fullContext.Contains("Aggressive Mercenary")) archetype = "Aggressive Mercenary";

            // Simulating generation based on Archetype logic.
            // In a real LLM, this is probabilistic token generation.
            // Here, we use deterministic logic to prove the concept.
            switch (archetype)
            {
                case "Wise Mentor":
                    return GenerateWiseMentorResponse(userInput);
                case "Aggressive Mercenary":
                    return GenerateAggressiveMercenaryResponse(userInput);
                default:
                    return "I do not know who I am.";
            }
        }

        private string GenerateWiseMentorResponse(string input)
        {
            // Logic: Look for keywords and respond with patience and guidance.
            if (input.ToLower().Contains("help")) return "Patience, young one. The path is difficult, but clarity comes with stillness.";
            if (input.ToLower().Contains("danger")) return "Danger is merely an opportunity for growth. Observe, then act.";
            return "I listen to your words. Speak your mind.";
        }

        private string GenerateAggressiveMercenaryResponse(string input)
        {
            // Logic: Look for keywords and respond with hostility or directness.
            if (input.ToLower().Contains("help")) return "Help costs gold. What are you paying?";
            if (input.ToLower().Contains("danger")) return "Danger? Good. I was getting bored. Draw your weapon.";
            return "Stop wasting my time. State your business.";
        }
    }

    // MAIN APPLICATION
    // This Console Application simulates a "Game Loop" where the player interacts with
    // two distinct AI characters. It demonstrates the full pipeline:
    // 1. Defining System Prompts (Personality Synthesis)
    // 2. Managing Conversation History (Token Management)
    // 3. Generating Context-Aware Responses (LLM Simulation)
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== PERSONALITY SYNTHESIS ENGINE SIMULATION ===");
            Console.WriteLine("Based on Chapter 7: AI for Game Development\n");

            // Initialize the Engine and History Manager
            PersonalitySynthesisEngine engine = new PersonalitySynthesisEngine();
            DialogueHistoryManager historyManager = new DialogueHistoryManager();

            // Define Player
            string playerName = "Hero";

            // --- CHARACTER 1: THE WISE MENTOR ---
            CharacterSystemPrompt mentorPrompt = new CharacterSystemPrompt
            {
                Archetype = "Wise Mentor",
                Backstory = "A former wizard who lost his sight but gained inner vision.",
                EmotionalRange = "Calm, Patient, Reflective",
                PlayerName = playerName
            };

            // --- CHARACTER 2: THE AGGRESSIVE MERCENARY ---
            CharacterSystemPrompt mercenaryPrompt = new CharacterSystemPrompt
            {
                Archetype = "Aggressive Mercenary",
                Backstory = "A veteran of countless wars, scarred and cynical.",
                EmotionalRange = "Hostile, Direct, Greedy",
                PlayerName = playerName
            };

            // Simulation Loop
            string[] playerInputs = {
                "Greetings.",
                "I need help.",
                "There is danger ahead."
            };

            // Process interactions for Mentor
            Console.WriteLine("\n--- INTERACTION 1: WISE MENTOR ---");
            ProcessCharacterInteraction(engine, historyManager, mentorPrompt, playerInputs);

            // Reset history for the second character to simulate separate instances
            historyManager = new DialogueHistoryManager(); 

            // Process interactions for Mercenary
            Console.WriteLine("\n--- INTERACTION 2: AGGRESSIVE MERCENARY ---");
            ProcessCharacterInteraction(engine, historyManager, mercenaryPrompt, playerInputs);

            Console.WriteLine("\n=== SIMULATION COMPLETE ===");
        }

        // Helper method to run the loop
        static void ProcessCharacterInteraction(PersonalitySynthesisEngine engine, DialogueHistoryManager history, CharacterSystemPrompt prompt, string[] inputs)
        {
            foreach (string input in inputs)
            {
                // 1. Generate the System Prompt
                string sysPrompt = prompt.GeneratePrompt();

                // 2. Get History Context
                string historyContext = history.GetFormattedHistory();

                // 3. Ask Engine for Response
                string response = engine.GenerateResponse(sysPrompt, input, historyContext);

                // 4. Output Result
                Console.WriteLine($"Player: {input}");
                Console.WriteLine($"Character: {response}");

                // 5. Update History (Token Management)
                history.AddExchange(input, response);
            }
        }
    }
}
