
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace GameBalanceMCTS
{
    // Represents a single unit type in the game (e.g., Knight, Archer).
    // We are balancing the 'Damage' stat for these units.
    public class UnitType
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int Damage { get; set; } // This is the parameter we are balancing.

        public UnitType(string name, int health, int damage)
        {
            Name = name;
            Health = health;
            Damage = damage;
        }

        // Creates a deep copy for simulation isolation.
        public UnitType Clone()
        {
            return new UnitType(Name, Health, Damage);
        }
    }

    // Represents the state of a single battle simulation.
    public class BattleState
    {
        public UnitType PlayerUnit { get; set; }
        public UnitType EnemyUnit { get; set; }
        public int TurnCount { get; set; }
        public bool IsTerminal { get; set; } // True if the battle is over.
        public int Winner; // 1 for Player, -1 for Enemy, 0 for Draw.

        public BattleState(UnitType player, UnitType enemy)
        {
            PlayerUnit = player.Clone();
            EnemyUnit = enemy.Clone();
            TurnCount = 0;
            IsTerminal = false;
            Winner = 0;
        }

        // Simulates one turn of the battle (Player attacks, then Enemy attacks).
        public void SimulateTurn()
        {
            if (IsTerminal) return;

            TurnCount++;

            // Player attacks Enemy
            EnemyUnit.Health -= PlayerUnit.Damage;
            if (EnemyUnit.Health <= 0)
            {
                IsTerminal = true;
                Winner = 1; // Player wins
                return;
            }

            // Enemy attacks Player
            PlayerUnit.Health -= EnemyUnit.Damage;
            if (PlayerUnit.Health <= 0)
            {
                IsTerminal = true;
                Winner = -1; // Enemy wins
                return;
            }

            // Safety break to prevent infinite loops in simulations
            if (TurnCount > 100)
            {
                IsTerminal = true;
                Winner = 0; // Draw
            }
        }
    }

    // The Monte Carlo Tree Search Node.
    // Represents a specific state in the simulation tree.
    public class MCTSNode
    {
        public BattleState State { get; set; }
        public MCTSNode Parent { get; set; }
        public int VisitCount { get; set; }
        public double TotalScore { get; set; } // Accumulated wins.
        public MCTSNode[] Children { get; set; } // In this simple case, we only expand one child (sequential turns).

        public MCTSNode(BattleState state, MCTSNode parent)
        {
            State = state;
            Parent = parent;
            VisitCount = 0;
            TotalScore = 0;
            Children = null;
        }
    }

    public class MCTSBalancer
    {
        private const int SIMULATIONS_PER_NODE = 50; // Number of rollouts to perform per node.
        private const int MAX_DEPTH = 20; // Maximum turns to simulate.

        // The core MCTS algorithm: Selection, Expansion, Simulation, Backpropagation.
        public MCTSNode RunMCTS(UnitType playerUnit, UnitType enemyUnit, int iterations)
        {
            MCTSNode rootNode = new MCTSNode(new BattleState(playerUnit, enemyUnit), null);

            for (int i = 0; i < iterations; i++)
            {
                MCTSNode node = rootNode;

                // 1. SELECTION: Traverse down the tree using UCB1 until we find a node we can expand.
                // We stop if the node is terminal or has unvisited children.
                while (node.Children != null && node.Children.Length > 0 && !node.State.IsTerminal)
                {
                    node = SelectBestChild(node);
                }

                // 2. EXPANSION: If the node is not terminal and hasn't been expanded, create children.
                if (!node.State.IsTerminal && node.VisitCount > 0)
                {
                    // In this battle simulation, there is only one logical "action": simulate the next turn.
                    // So we expand to a single child state.
                    BattleState nextState = new BattleState(node.State.PlayerUnit, node.State.EnemyUnit);
                    nextState.SimulateTurn();
                    
                    node.Children = new MCTSNode[] { new MCTSNode(nextState, node) };
                    node = node.Children[0];
                }

                // 3. SIMULATION (Rollout): Play out the game randomly from the current state.
                int simulationResult = SimulateRandomGame(node.State);

                // 4. BACKPROPAGATION: Update statistics up the tree.
                while (node != null)
                {
                    node.VisitCount++;
                    // We track score from the perspective of the root player (PlayerUnit).
                    // If simulation result is 1 (Player Win), add 1. If -1 (Player Loss), add 0.
                    if (simulationResult == 1) node.TotalScore += 1;
                    else if (simulationResult == 0) node.TotalScore += 0.5; // Draw is half a win
                    
                    node = node.Parent;
                }
            }

            return rootNode;
        }

        // UCB1 Formula: Balances exploration vs exploitation.
        // UCT = (Wins / Visits) + C * sqrt(ln(ParentVisits) / Visits)
        private MCTSNode SelectBestChild(MCTSNode node)
        {
            MCTSNode bestChild = null;
            double bestUCB = -1;

            foreach (var child in node.Children)
            {
                if (child.VisitCount == 0) return child; // Always visit unvisited nodes first.

                double exploitation = (double)child.TotalScore / child.VisitCount;
                double exploration = Math.Sqrt(2.0 * Math.Log(node.VisitCount) / child.VisitCount);
                double ucbScore = exploitation + exploration;

                if (ucbScore > bestUCB)
                {
                    bestUCB = ucbScore;
                    bestChild = child;
                }
            }
            return bestChild;
        }

        // Runs a random simulation from a specific state to terminal.
        private int SimulateRandomGame(BattleState startState)
        {
            BattleState simState = new BattleState(startState.PlayerUnit, startState.EnemyUnit);
            
            // Random generator for simulation randomness (if we had multiple actions).
            // In this deterministic turn-based setup, it's just a loop.
            while (!simState.IsTerminal)
            {
                simState.SimulateTurn();
            }
            return simState.Winner;
        }
    }

    // The Analysis Engine: Evaluates data and suggests balancing changes.
    public class BalanceAnalyzer
    {
        public void AnalyzeAndSuggest(MCTSNode root, UnitType playerUnit, UnitType enemyUnit)
        {
            Console.WriteLine("--- Balance Analysis Report ---");
            Console.WriteLine($"Current Player Unit: {playerUnit.Name} (Dmg: {playerUnit.Damage})");
            Console.WriteLine($"Current Enemy Unit: {enemyUnit.Name} (Dmg: {enemyUnit.Damage})");
            Console.WriteLine($"Total Simulations: {root.VisitCount}");
            Console.WriteLine($"Player Win Rate: {((double)root.TotalScore / root.VisitCount * 100):F2}%");
            Console.WriteLine();

            // Heuristic for balancing:
            // If Win Rate > 55%, Player is too strong. Reduce Player Damage or Increase Enemy Damage.
            // If Win Rate < 45%, Player is too weak. Increase Player Damage or Decrease Enemy Damage.
            
            double winRate = (double)root.TotalScore / root.VisitCount;

            if (winRate > 0.55)
            {
                Console.WriteLine("Result: Player Unit is OVERPOWERED.");
                Console.WriteLine($"Suggestion: Decrease {playerUnit.Name} Damage by 1 (New: {playerUnit.Damage - 1})");
                Console.WriteLine("OR Increase Enemy Damage by 1.");
            }
            else if (winRate < 0.45)
            {
                Console.WriteLine("Result: Player Unit is UNDERPOWERED.");
                Console.WriteLine($"Suggestion: Increase {playerUnit.Name} Damage by 1 (New: {playerUnit.Damage + 1})");
                Console.WriteLine("OR Decrease Enemy Damage by 1.");
            }
            else
            {
                Console.WriteLine("Result: Game is BALANCED.");
                Console.WriteLine("Suggestion: No changes needed.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // 1. Setup: Define current game parameters (The "Design" we are testing).
            // Scenario: A Knight vs a Goblin.
            // Current stats: Knight (10 HP, 3 Dmg), Goblin (12 HP, 3 Dmg).
            // Intuition: Goblin has more HP, so Knight might lose.
            UnitType knight = new UnitType("Knight", 10, 3);
            UnitType goblin = new UnitType("Goblin", 12, 3);

            Console.WriteLine("Initializing MCTS Balance Simulation...");
            Console.WriteLine("Problem: Determine if the Knight vs Goblin matchup is fair.");
            Console.WriteLine();

            // 2. Execution: Run MCTS to simulate thousands of battles.
            MCTSBalancer balancer = new MCTSBalancer();
            
            // We run 1000 iterations of the MCTS algorithm.
            // In a real engine, this would be 10,000+ and run in a background thread.
            MCTSNode resultNode = balancer.RunMCTS(knight, goblin, 1000);

            // 3. Analysis: Interpret the simulation data.
            BalanceAnalyzer analyzer = new BalanceAnalyzer();
            analyzer.AnalyzeAndSuggest(resultNode, knight, goblin);

            Console.WriteLine("\n--- Iterative Adjustment Example ---");
            Console.WriteLine("Applying suggestion: Increasing Knight Damage to 4...");
            
            // 4. Iteration: Update parameters and re-run (Simulating the loop).
            knight.Damage = 4;
            MCTSNode adjustedNode = balancer.RunMCTS(knight, goblin, 1000);
            analyzer.AnalyzeAndSuggest(adjustedNode, knight, goblin);
        }
    }
}
