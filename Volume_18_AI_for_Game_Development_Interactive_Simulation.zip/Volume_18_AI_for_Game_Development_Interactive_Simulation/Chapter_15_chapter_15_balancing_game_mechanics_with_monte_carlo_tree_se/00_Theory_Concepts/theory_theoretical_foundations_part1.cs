
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

// Using a generic interface allows the MCTS algorithm to work with any game state.
// This is a powerful abstraction learned from building modular AI systems.
public interface IGameState<TAction, TScore> where TAction : notnull
{
    // Generates all possible parameter adjustments or actions from the current state.
    IEnumerable<TAction> GetPossibleActions();

    // Applies an action (e.g., a parameter change) and returns a new, immutable game state.
    // Immutability is critical for parallel simulations and deterministic backpropagation.
    IGameState<TAction, TScore> ApplyAction(TAction action);

    // Checks if the state is terminal (e.g., a match has concluded).
    bool IsTerminal();

    // Returns the score of the terminal state from a specific player's perspective.
    // This is the 'w_i' value in the UCT formula.
    TScore GetScore(int playerIndex);
}
