
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace MCTS_Basic
{
    // Represents the state of the game (the board)
    public class GameState
    {
        public char[,] Board { get; private set; } // 3x3 grid
        public char CurrentPlayer { get; private set; } // 'X' or 'O'
        public bool IsTerminal { get; private set; }
        public int Winner { get; private set; } // 1 for X, -1 for O, 0 for Draw, null if not finished

        public GameState()
        {
            Board = new char[3, 3];
            CurrentPlayer = 'X';
            IsTerminal = false;
            Winner = 0;
        }

        // Copy constructor for simulation branches
        public GameState(GameState other)
        {
            Board = (char[,])other.Board.Clone();
            CurrentPlayer = other.CurrentPlayer;
            IsTerminal = other.IsTerminal;
            Winner = other.Winner;
        }

        // Apply a move (row, col)
        public void ApplyMove(int row, int col)
        {
            if (Board[row, col] != '\0') throw new InvalidOperationException("Cell occupied");
            
            Board[row, col] = CurrentPlayer;
            
            // Check for win or draw
            CheckStatus();
            
            // Switch player
            CurrentPlayer = (CurrentPlayer == 'X') ? 'O' : 'X';
        }

        private void CheckStatus()
        {
            // Check rows, cols, diagonals
            for (int i = 0; i < 3; i++)
            {
                if (Board[i, 0] != '\0' && Board[i, 0] == Board[i, 1] && Board[i, 1] == Board[i, 2])
                    SetWinner(Board[i, 0]);
                if (Board[0, i] != '\0' && Board[0, i] == Board[1, i] && Board[1, i] == Board[2, i])
                    SetWinner(Board[0, i]);
            }
            if (Board[0, 0] != '\0' && Board[0, 0] == Board[1, 1] && Board[1, 1] == Board[2, 2])
                SetWinner(Board[0, 0]);
            if (Board[0, 2] != '\0' && Board[0, 2] == Board[1, 1] && Board[1, 1] == Board[2, 0])
                SetWinner(Board[0, 2]);

            // Check Draw
            bool full = true;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (Board[i, j] == '\0') full = false;

            if (full && Winner == 0)
            {
                IsTerminal = true;
                Winner = 0; // Draw
            }
        }

        private void SetWinner(char player)
        {
            IsTerminal = true;
            Winner = (player == 'X') ? 1 : -1;
        }

        public List<(int, int)> GetLegalMoves()
        {
            var moves = new List<(int, int)>();
            if (IsTerminal) return moves;

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (Board[i, j] == '\0') moves.Add((i, j));
            return moves;
        }

        public void PrintBoard()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    Console.Write((Board[i, j] == '\0' ? '.' : Board[i, j]) + " ");
                Console.WriteLine();
            }
        }
    }

    // MCTS Node
    public class Node
    {
        public GameState State { get; private set; }
        public Node Parent { get; private set; }
        public List<Node> Children { get; private set; }
        public (int, int) Move { get; private set; } // Move that led to this state
        public int Visits { get; set; }
        public double Wins { get; set; } // From perspective of Parent.CurrentPlayer

        public Node(GameState state, Node parent = null, (int, int) move = default)
        {
            State = state;
            Parent = parent;
            Move = move;
            Children = new List<Node>();
            Visits = 0;
            Wins = 0;
        }

        public bool IsFullyExpanded => GetUntriedMoves().Count == 0;

        public List<(int, int)> GetUntriedMoves()
        {
            var tried = Children.Select(c => c.Move).ToHashSet();
            return State.GetLegalMoves().Where(m => !tried.Contains(m)).ToList();
        }

        // Upper Confidence Bound 1 (UCB1)
        public double GetUCB1(double explorationConstant = 1.41)
        {
            if (Visits == 0) return double.MaxValue; // Should not happen in selection, but safety
            return (Wins / Visits) + explorationConstant * Math.Sqrt(Math.Log(Parent.Visits) / Visits);
        }
    }

    public class MCTS
    {
        private Node _root;
        private Random _random = new Random();

        public MCTS(GameState initialState)
        {
            _root = new Node(initialState);
        }

        public (int, int) Run(int iterations)
        {
            for (int i = 0; i < iterations; i++)
            {
                // 1. Selection
                Node node = Select(_root);

                // 2. Expansion
                if (!node.State.IsTerminal)
                {
                    node = Expand(node);
                }

                // 3. Simulation (Rollout)
                int outcome = Simulate(node.State);

                // 4. Backpropagation
                Backpropagate(node, outcome);
            }

            // Return the move with the most visits (robust child)
            return _root.Children.OrderByDescending(c => c.Visits).First().Move;
        }

        private Node Select(Node node)
        {
            while (node.Children.Any() && node.IsFullyExpanded)
            {
                node = node.Children.OrderByDescending(c => c.GetUCB1()).First();
            }
            return node;
        }

        private Node Expand(Node node)
        {
            var untried = node.GetUntriedMoves();
            var move = untried[_random.Next(untried.Count)];
            
            var newState = new GameState(node.State);
            newState.ApplyMove(move.Item1, move.Item2);
            
            var child = new Node(newState, node, move);
            node.Children.Add(child);
            return child;
        }

        private int Simulate(GameState state)
        {
            // Random playout
            var current = new GameState(state);
            while (!current.IsTerminal)
            {
                var moves = current.GetLegalMoves();
                var move = moves[_random.Next(moves.Count)];
                current.ApplyMove(move.Item1, move.Item2);
            }
            return current.Winner;
        }

        private void Backpropagate(Node node, int outcome)
        {
            // Perspective: If the node's state was X's turn, and outcome is 1 (X won), it's a win.
            // However, we need to track whose turn it was at the node.
            // Standard MCTS: Value is from perspective of the player who just moved to reach this node.
            // Or simpler: Update based on the player of the node's state.
            
            while (node != null)
            {
                node.Visits++;
                // If the state's current player (the one about to move) is the same as the winner, 
                // this node is good for the previous player (who just moved).
                // Actually, let's stick to: Was the player who made the move to get here the winner?
                // In this implementation, we track the winner of the simulation.
                // We need to invert the score if the perspective changes.
                
                // Simplified Logic:
                // If the node represents a state where 'X' is about to move, and the simulation resulted in 'X' winning (1),
                // then the previous move (by 'O') was bad.
                
                // Let's use a simpler heuristic for this example:
                // We update Wins based on the player who just moved.
                // But we don't store "player who moved here" explicitly, we can infer from Parent.
                
                if (node.Parent == null) // Root
                {
                    node.Wins += outcome; // Just aggregate raw score
                }
                else
                {
                    // If Parent's turn was 'X', and 'X' won (1), then this move was good.
                    // Parent.CurrentPlayer is the player who moved to get to 'node'.
                    if (node.Parent.State.CurrentPlayer == 'X' && outcome == 1) node.Wins += 1;
                    else if (node.Parent.State.CurrentPlayer == 'O' && outcome == -1) node.Wins += 1;
                    // If Draw (0), no change
                }
                
                node = node.Parent;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- MCTS Tic-Tac-Toe Solver ---");
            
            // Scenario: X has played center. O is deciding where to go.
            // We want MCTS to find the best move for O.
            var state = new GameState();
            state.ApplyMove(1, 1); // X plays Center
            
            Console.WriteLine("Current Board (X is Center):");
            state.PrintBoard();
            Console.WriteLine($"Current Player: {state.CurrentPlayer} (O)");

            // Run MCTS
            var mcts = new MCTS(state);
            Console.WriteLine("\nRunning MCTS (1000 iterations)...");
            var bestMove = mcts.Run(1000);

            Console.WriteLine($"Best Move for O: ({bestMove.Item1}, {bestMove.Item2})");
            
            // Apply move to show result
            state.ApplyMove(bestMove.Item1, bestMove.Item2);
            Console.WriteLine("\nBoard after O's move:");
            state.PrintBoard();
        }
    }
}
