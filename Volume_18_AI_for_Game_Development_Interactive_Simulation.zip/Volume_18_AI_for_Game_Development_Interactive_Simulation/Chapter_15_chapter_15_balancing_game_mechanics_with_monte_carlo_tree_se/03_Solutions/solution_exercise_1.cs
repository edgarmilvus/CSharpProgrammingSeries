
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace MCTS_Balancing
{
    // 1. Data Structures
    public enum UnitType { Knight, Archer }

    public struct UnitStats
    {
        public int Health;
        public int Damage;
    }

    public class GameState
    {
        public UnitStats Knight { get; set; }
        public UnitStats Archer { get; set; }
        public UnitType CurrentTurn { get; set; }

        public GameState(int knightHp, int archerHp)
        {
            Knight = new UnitStats { Health = knightHp, Damage = 10 }; // Knight: 10 dmg
            Archer = new UnitStats { Health = archerHp, Damage = 20 }; // Archer: 20 dmg
            CurrentTurn = UnitType.Knight; // Knight attacks first
        }

        // Copy constructor for state branching
        public GameState(GameState other)
        {
            Knight = other.Knight;
            Archer = other.Archer;
            CurrentTurn = other.CurrentTurn;
        }

        public bool IsTerminal()
        {
            return Knight.Health <= 0 || Archer.Health <= 0;
        }

        // Returns 1.0 if Knight wins, 0.0 if Archer wins
        public double GetResult()
        {
            if (Knight.Health > 0) return 1.0;
            return 0.0;
        }

        public void ApplyAction()
        {
            if (CurrentTurn == UnitType.Knight)
            {
                Archer.Health -= Knight.Damage;
                CurrentTurn = UnitType.Archer;
            }
            else
            {
                Knight.Health -= Archer.Damage;
                CurrentTurn = UnitType.Knight;
            }
        }
    }

    // 2. MCTS Node
    public class MCTSNode
    {
        public GameState State { get; set; }
        public MCTSNode Parent { get; set; }
        public List<MCTSNode> Children { get; set; } = new List<MCTSNode>();
        public int VisitCount { get; set; } = 0;
        public double TotalReward { get; set; } = 0.0;
        public bool IsFullyExpanded => !State.IsTerminal() && Children.Count > 0; // Simplified check
        
        // For tracking action (not strictly needed for logic but good for debugging)
        public string ActionName { get; set; }

        public MCTSNode(GameState state, MCTSNode parent, string action = "")
        {
            State = state;
            Parent = parent;
            ActionName = action;
        }
    }

    // 3. MCTS Algorithm
    public class MCTS
    {
        private Random _random = new Random();
        private double _explorationConstant = 1.414;

        public MCTSNode Search(MCTSNode root, int iterations)
        {
            for (int i = 0; i < iterations; i++)
            {
                // 1. Selection
                MCTSNode node = Select(root);

                // 2. Expansion
                if (!node.State.IsTerminal())
                {
                    node = Expand(node);
                }

                // 3. Simulation (Rollout)
                double reward = Simulate(node.State);

                // 4. Backpropagation
                Backpropagate(node, reward);
            }
            return root;
        }

        private MCTSNode Select(MCTSNode node)
        {
            while (node.Children.Any() && !node.State.IsTerminal())
            {
                // If all children are not fully expanded, we might expand here, 
                // but typically we select the best UCB child until we hit a leaf.
                node = GetBestUCBChild(node);
            }
            return node;
        }

        private MCTSNode Expand(MCTSNode node)
        {
            // In this specific game, there is only 1 possible action per turn (attack).
            // So we only generate 1 child.
            GameState nextState = new GameState(node.State);
            nextState.ApplyAction();
            
            string actionName = $"{node.State.CurrentTurn} Attacks";
            var child = new MCTSNode(nextState, node, actionName);
            node.Children.Add(child);
            return child;
        }

        private double Simulate(GameState state)
        {
            GameState simState = new GameState(state);
            while (!simState.IsTerminal())
            {
                simState.ApplyAction();
            }
            return simState.GetResult();
        }

        private void Backpropagate(MCTSNode node, double reward)
        {
            while (node != null)
            {
                node.VisitCount++;
                node.TotalReward += reward;
                node = node.Parent;
                // Invert reward for alternating turns if we were tracking specific player perspectives,
                // but here we always track Knight win probability from Root's perspective.
                // Since simulation always returns Knight win (1) or Loss (0), we don't invert.
            }
        }

        private MCTSNode GetBestUCBChild(MCTSNode node)
        {
            MCTSNode bestChild = null;
            double bestUCB = double.MinValue;

            foreach (var child in node.Children)
            {
                // UCB1 Formula: w_i/n_i + c * sqrt(ln(N) / n_i)
                // w_i = TotalReward, n_i = VisitCount, N = Parent.VisitCount
                if (child.VisitCount == 0) return child; // Unvisited node is automatically best

                double exploit = child.TotalReward / child.VisitCount;
                double explore = Math.Sqrt(Math.Log(node.VisitCount) / child.VisitCount);
                double ucb = exploit + _explorationConstant * explore;

                if (ucb > bestUCB)
                {
                    bestUCB = ucb;
                    bestChild = child;
                }
            }
            return bestChild ?? node.Children[0];
        }
    }

    // 4. Execution
    class Program
    {
        static void Main(string[] args)
        {
            // Initial State: Knight HP 100, Archer HP 60
            GameState rootState = new GameState(100, 60);
            MCTSNode rootNode = new MCTSNode(rootState, null);

            MCTS mcts = new MCTS();
            int iterations = 10000;
            
            Console.WriteLine($"Running MCTS for {iterations} iterations...");
            MCTSNode finalRoot = mcts.Search(rootNode, iterations);

            double winRate = finalRoot.TotalReward / finalRoot.VisitCount;
            Console.WriteLine($"Knight Win Rate: {winRate:P2}");
        }
    }
}
