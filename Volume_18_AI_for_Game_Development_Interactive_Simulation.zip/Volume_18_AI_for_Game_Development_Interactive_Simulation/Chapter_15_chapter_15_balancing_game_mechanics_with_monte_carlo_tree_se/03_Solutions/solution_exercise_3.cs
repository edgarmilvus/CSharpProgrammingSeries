
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MCTS_UnityIntegration
{
    // 1. Simulation State
    public class SimulationState
    {
        public float TowerDamage { get; set; }
        public float FireRate { get; set; }
        public float Time { get; set; }
        public List<Enemy> Enemies { get; set; }
        public bool BaseReached { get; set; }
        public bool AllDead { get; set; }

        public SimulationState(float damage, float rate)
        {
            TowerDamage = damage;
            FireRate = rate;
            Time = 0f;
            BaseReached = false;
            AllDead = false;
            // Initialize with 3 enemies
            Enemies = new List<Enemy>
            {
                new Enemy { Health = 100, Distance = 50, Speed = 5 },
                new Enemy { Health = 120, Distance = 60, Speed = 4 },
                new Enemy { Health = 80, Distance = 40, Speed = 6 }
            };
        }

        public SimulationState(SimulationState other)
        {
            TowerDamage = other.TowerDamage;
            FireRate = other.FireRate;
            Time = other.Time;
            BaseReached = other.BaseReached;
            AllDead = other.AllDead;
            Enemies = other.Enemies.Select(e => e.Clone()).ToList();
        }

        public bool IsTerminal() => BaseReached || AllDead || Time > 30f; // 30 sec limit

        public void Step(float dt)
        {
            Time += dt;
            
            // Tower Logic (Simplified: attacks every FireRate interval)
            // Assuming dt is small, we check if a shot occurs
            // For simulation speed, we can just iterate logic
            if (Enemies.Any())
            {
                // Simple logic: Tower attacks the closest enemy
                var target = Enemies.OrderBy(e => e.Distance).First();
                if (target.Distance <= 20) // Range check
                {
                    // Fire rate check (simplified)
                    // In a real sim, we track cooldown. Here, we assume continuous fire scaled by rate
                    // We'll just apply damage proportional to rate for simulation speed
                    target.Health -= TowerDamage * FireRate * dt;
                }
            }

            // Enemy Logic
            foreach (var enemy in Enemies.ToList())
            {
                enemy.Distance -= enemy.Speed * dt;
                if (enemy.Distance <= 0)
                {
                    BaseReached = true;
                }
                if (enemy.Health <= 0)
                {
                    Enemies.Remove(enemy);
                }
            }

            if (Enemies.Count == 0 && !BaseReached) AllDead = true;
        }
    }

    public class Enemy
    {
        public float Health { get; set; }
        public float Distance { get; set; }
        public float Speed { get; set; }
        public Enemy Clone() => new Enemy { Health = Health, Distance = Distance, Speed = Speed };
    }

    // 2. MCTS Implementation
    public class TowerMCTS
    {
        private Random _random = new Random();
        private ConcurrentQueue<string> _logQueue;

        // Discrete Parameter Space
        private static List<(float dmg, float rate)> _configs = new List<(float, float)>
        {
            (10f, 0.5f), (10f, 1.0f), (10f, 1.5f),
            (20f, 0.5f), (20f, 1.0f), (20f, 1.5f),
            (30f, 0.5f), (30f, 1.0f), (30f, 1.5f)
        };

        public TowerMCTS(ConcurrentQueue<string> logQueue)
        {
            _logQueue = logQueue;
        }

        public async Task<MCTSNode> SearchAsync(int iterations)
        {
            // Run on background thread
            return await Task.Run(() =>
            {
                var root = new MCTSNode(new SimulationState(0, 0), null); // Dummy root

                for (int i = 0; i < iterations; i++)
                {
                    if (i % 100 == 0)
                    {
                        _logQueue.Enqueue($"Iteration {i}/{iterations} complete");
                    }

                    // 1. Selection (Expand root if needed)
                    if (root.Children.Count == 0)
                    {
                        foreach (var cfg in _configs)
                        {
                            root.Children.Add(new MCTSNode(new SimulationState(cfg.dmg, cfg.rate), root));
                        }
                    }

                    MCTSNode node = GetBestUCBChild(root);

                    // 2. Simulation
                    double reward = Simulate(node.State);

                    // 3. Backpropagation
                    Backpropagate(node, reward);
                }

                return root;
            });
        }

        private double Simulate(SimulationState state)
        {
            SimulationState simState = new SimulationState(state);
            float dt = 0.1f; // Time step
            while (!simState.IsTerminal())
            {
                simState.Step(dt);
            }

            if (simState.AllDead) return 1.0;
            if (simState.BaseReached) return -1.0;
            return 0.0; // Time out
        }

        private void Backpropagate(MCTSNode node, double reward)
        {
            while (node != null)
            {
                node.VisitCount++;
                node.TotalReward += reward;
                node = node.Parent;
            }
        }

        private MCTSNode GetBestUCBChild(MCTSNode node)
        {
            MCTSNode bestChild = null;
            double bestUCB = double.MinValue;
            double exploration = 1.414;

            foreach (var child in node.Children)
            {
                if (child.VisitCount == 0) return child;

                double exploit = child.TotalReward / child.VisitCount;
                double explore = Math.Sqrt(Math.Log(node.VisitCount) / child.VisitCount);
                double ucb = exploit + exploration * explore;

                if (ucb > bestUCB)
                {
                    bestUCB = ucb;
                    bestChild = child;
                }
            }
            return bestChild;
        }
    }

    public class MCTSNode
    {
        public SimulationState State { get; set; }
        public MCTSNode Parent { get; set; }
        public List<MCTSNode> Children { get; set; } = new List<MCTSNode>();
        public int VisitCount { get; set; }
        public double TotalReward { get; set; }

        public MCTSNode(SimulationState state, MCTSNode parent)
        {
            State = state;
            Parent = parent;
        }
    }

    // 3. Unity Integration (Mock MonoBehaviour)
    public class TowerBalanceManager
    {
        // Simulating Unity's main thread context
        private ConcurrentQueue<string> _logQueue = new ConcurrentQueue<string>();
        private bool _isRunning = false;

        public void StartBalanceSimulation(int iterations)
        {
            if (_isRunning) return;
            _isRunning = true;

            var mcts = new TowerMCTS(_logQueue);
            
            // Start background task
            var task = mcts.SearchAsync(iterations);
            
            task.ContinueWith(t =>
            {
                _isRunning = false;
                if (t.IsFaulted) 
                {
                    _logQueue.Enqueue("Simulation failed: " + t.Exception);
                    return;
                }

                var root = t.Result;
                var bestNode = root.Children.OrderByDescending(c => c.TotalReward / c.VisitCount).FirstOrDefault();
                
                if (bestNode != null)
                {
                    string result = $"Best Config: DMG {bestNode.State.TowerDamage}, Rate {bestNode.State.FireRate} | Reward: {bestNode.TotalReward/bestNode.VisitCount:F2}";
                    _logQueue.Enqueue(result);
                }
            });
        }

        // Update method (called every frame in Unity)
        public void Update()
        {
            while (_logQueue.TryDequeue(out string message))
            {
                // In Unity: Debug.Log(message);
                Console.WriteLine($"[Unity Console] {message}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var manager = new TowerBalanceManager();
            manager.StartBalanceSimulation(2000);

            // Simulate Unity's Update loop
            while (true)
            {
                manager.Update();
                System.Threading.Thread.Sleep(50); // Simulate frame time
                // Break condition for console app
                // In a real app, this loop is handled by Unity
                if (!manager._isRunning) break; 
            }
        }
    }
}
