
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MCTS_Economy
{
    // 1. Economy Model
    public struct EconomyConfig
    {
        public float MiningRate;
        public int WorkerCost;

        public override string ToString() => $"[Rate: {MiningRate}, Cost: {WorkerCost}]";
    }

    public class EconomyState
    {
        public int CurrentGold { get; set; }
        public int Workers { get; set; }
        public int Ticks { get; set; }
        public EconomyConfig Config { get; set; }

        public EconomyState(int gold, int workers, int ticks, EconomyConfig config)
        {
            CurrentGold = gold;
            Workers = workers;
            Ticks = ticks;
            Config = config;
        }

        public EconomyState(EconomyState other)
        {
            CurrentGold = other.CurrentGold;
            Workers = other.Workers;
            Ticks = other.Ticks;
            Config = other.Config;
        }

        public bool IsTerminal() => Ticks >= 100 || CurrentGold < 0;

        // Actions: HireWorker or DoNothing
        public List<EconomyState> GetNextStates()
        {
            var states = new List<EconomyState>();
            
            // Action 1: Do Nothing
            var doNothingState = new EconomyState(this);
            doNothingState.SimulateTick();
            states.Add(doNothingState);

            // Action 2: Hire Worker (if affordable)
            if (CurrentGold >= Config.WorkerCost)
            {
                var hireState = new EconomyState(this);
                hireState.CurrentGold -= Config.WorkerCost;
                hireState.Workers++;
                hireState.SimulateTick();
                states.Add(hireState);
            }

            return states;
        }

        private void SimulateTick()
        {
            CurrentGold += (int)(Workers * Config.MiningRate);
            Ticks++;
        }
    }

    // 2. MCTS Node
    public class MCTSNode
    {
        public EconomyState State { get; set; }
        public MCTSNode Parent { get; set; }
        public List<MCTSNode> Children { get; set; } = new List<MCTSNode>();
        public int VisitCount { get; set; } = 0;
        public double TotalReward { get; set; } = 0.0;
        
        // For parameter search, we might track which config led here, 
        // but for simplicity, we just track the state.
        public MCTSNode(EconomyState state, MCTSNode parent)
        {
            State = state;
            Parent = parent;
        }
    }

    // 3. MCTS for Parameter Search
    public class EconomyMCTS
    {
        private Random _random = new Random();
        private double _explorationConstant = 1.414;

        // Search space definition
        public static List<EconomyConfig> PossibleConfigs = new List<EconomyConfig>
        {
            new EconomyConfig { MiningRate = 0.5f, WorkerCost = 10 },
            new EconomyConfig { MiningRate = 1.0f, WorkerCost = 20 },
            new EconomyConfig { MiningRate = 1.5f, WorkerCost = 30 }
        };

        public MCTSNode Search(MCTSNode root, int iterations)
        {
            for (int i = 0; i < iterations; i++)
            {
                MCTSNode node = Select(root);
                
                // In this specific problem, the "Action" is selecting a Configuration at the Root.
                // However, the prompt implies the tree represents the decision process over time.
                // To strictly follow "Action is selecting a specific EconomyConfig", 
                // we treat the root's children as the different configurations.
                
                if (node == root && !node.State.IsTerminal())
                {
                    // If we are at root and haven't expanded configs, do so.
                    if (node.Children.Count == 0)
                    {
                        foreach (var config in PossibleConfigs)
                        {
                            var initState = new EconomyState(100, 1, 0, config);
                            node.Children.Add(new MCTSNode(initState, node));
                        }
                    }
                    // Select one of the config children
                    node = GetBestUCBChild(node);
                }
                
                // If the node is a specific config simulation (not root)
                if (!node.State.IsTerminal() && node.Children.Count == 0)
                {
                    // Expand simulation steps (Hire vs DoNothing)
                    var nextStates = node.State.GetNextStates();
                    foreach (var s in nextStates)
                    {
                        node.Children.Add(new MCTSNode(s, node));
                    }
                }

                // Select child if we expanded, or pick the node if it's terminal
                MCTSNode leaf = node;
                if (node.Children.Any()) leaf = GetBestUCBChild(node);

                double reward = Simulate(leaf.State);
                Backpropagate(leaf, reward);
            }
            return root;
        }

        private MCTSNode Select(MCTSNode node)
        {
            // Simple selection: go down the tree using UCB
            while (node.Children.Any() && !node.State.IsTerminal())
            {
                node = GetBestUCBChild(node);
            }
            return node;
        }

        private double Simulate(EconomyState state)
        {
            EconomyState simState = new EconomyState(state);
            while (!simState.IsTerminal())
            {
                // Random policy: Hire or DoNothing
                var options = simState.GetNextStates();
                simState = options[_random.Next(options.Count)];
            }

            // Reward Function
            if (simState.CurrentGold < 0) return -10.0; // Bankruptcy penalty
            return simState.CurrentGold / 1000.0; // Normalized reward
        }

        private void Backpropagate(MCTSNode node, double reward)
        {
            while (node != null)
            {
                node.VisitCount++;
                node.TotalReward += reward;
                node = node.Parent;
            }
        }

        private MCTSNode GetBestUCBChild(MCTSNode node)
        {
            MCTSNode bestChild = null;
            double bestUCB = double.MinValue;

            foreach (var child in node.Children)
            {
                if (child.VisitCount == 0) return child;

                double exploit = child.TotalReward / child.VisitCount;
                double explore = Math.Sqrt(Math.Log(node.VisitCount) / child.VisitCount);
                double ucb = exploit + _explorationConstant * explore;

                if (ucb > bestUCB)
                {
                    bestUCB = ucb;
                    bestChild = child;
                }
            }
            return bestChild;
        }
    }

    // 4. Execution & Visualization
    class Program
    {
        static void Main(string[] args)
        {
            // Initial State: Gold 100, Workers 1
            // The root node represents the initial state before a config is chosen.
            // However, for MCTS to work here, we usually start with a root that has children (configs).
            // Let's create a dummy root.
            var rootState = new EconomyState(100, 1, 0, new EconomyConfig()); 
            var rootNode = new MCTSNode(rootState, null);

            var mcts = new EconomyMCTS();
            int iterations = 5000;

            Console.WriteLine($"Running Economy MCTS for {iterations} iterations...");
            var finalRoot = mcts.Search(rootNode, iterations);

            // Find best config
            var bestConfigNode = finalRoot.Children.OrderByDescending(c => c.TotalReward / c.VisitCount).FirstOrDefault();

            if (bestConfigNode != null)
            {
                double winRate = bestConfigNode.TotalReward / bestConfigNode.VisitCount;
                Console.WriteLine($"Optimal Config: {bestConfigNode.State.Config}");
                Console.WriteLine($"Average Reward: {winRate * 1000} (Normalized: {winRate:F4})");
            }

            // Visualization (Graphviz Output)
            Console.WriteLine("\n--- Graphviz Dot Output ---");
            GenerateGraphviz(finalRoot);
        }

        static void GenerateGraphviz(MCTSNode root)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("digraph EconomyTree {");
            sb.AppendLine("  node [shape=box];");

            Queue<MCTSNode> queue = new Queue<MCTSNode>();
            queue.Enqueue(root);

            int nodeId = 0;
            root.Id = nodeId++;

            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                string label = current.Parent == null ? "Root" : current.State.Config.ToString();
                if (current.Parent != null && current.Parent.Parent == null)
                {
                     // It's a config node
                     label += $"\nAvg Reward: {(current.TotalReward/current.VisitCount):F2}";
                }

                sb.AppendLine($"  node{current.Id} [label=\"{label}\"];");

                foreach (var child in current.Children)
                {
                    child.Id = nodeId++;
                    sb.AppendLine($"  node{current.Id} -> node{child.Id};");
                    queue.Enqueue(child);
                }
            }
            sb.AppendLine("}");
            Console.WriteLine(sb.ToString());
        }
    }

    // Helper to attach ID for Graphviz
    public static class NodeExtensions
    {
        public static int Id { get; set; }
    }
}
