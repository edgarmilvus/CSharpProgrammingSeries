
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MCTS_Convergence
{
    // Reusing basic structures from Exercise 1 for brevity
    public enum UnitType { Knight, Archer }
    public struct UnitStats { public int Health; public int Damage; }
    
    public class GameState
    {
        public UnitStats Knight, Archer;
        public GameState(int k, int a) { Knight = new UnitStats { Health = k, Damage = 10 }; Archer = new UnitStats { Health = a, Damage = 20 }; }
        public bool IsTerminal() => Knight.Health <= 0 || Archer.Health <= 0;
        public double GetResult() => Knight.Health > 0 ? 1.0 : 0.0;
        public void ApplyAction() { if (Knight.Health > 0 && Archer.Health > 0) { if (Knight.Health > 0) { Archer.Health -= Knight.Damage; } if (Archer.Health > 0) { Knight.Health -= Archer.Damage; } } }
    }

    // 1. Convergence Logger
    public class DataPoint
    {
        public int Iteration { get; set; }
        public double WinProbability { get; set; }
    }

    public class ConvergenceData
    {
        public List<DataPoint> Points { get; set; } = new List<DataPoint>();
    }

    public class ConvergenceMCTS
    {
        private Random _random = new Random();
        private ConvergenceData _convergenceData = new ConvergenceData();

        public (MCTSNode Root, ConvergenceData Data) Search(MCTSNode root, int maxIterations, int loggingInterval, double stabilityThreshold = 0.01)
        {
            double lastProb = -1.0;
            int stableCount = 0;
            int checkInterval = 500; // Check stability every 500 iterations

            for (int i = 1; i <= maxIterations; i++)
            {
                // Standard MCTS steps (Selection, Expansion, Simulation, Backpropagation)
                // ... (Simplified MCTS logic for brevity, assuming we have a method to run one iteration)
                RunSingleIteration(root);

                // Logging
                if (i % loggingInterval == 0)
                {
                    double currentProb = root.TotalReward / root.VisitCount;
                    _convergenceData.Points.Add(new DataPoint { Iteration = i, WinProbability = currentProb });
                    Console.WriteLine($"Iter {i}: Win Rate = {currentProb:P2}");
                }

                // Dynamic Stopping Criteria
                if (i % checkInterval == 0)
                {
                    double currentProb = root.TotalReward / root.VisitCount;
                    if (lastProb >= 0 && Math.Abs(currentProb - lastProb) < stabilityThreshold)
                    {
                        stableCount++;
                        if (stableCount >= 3) // 3 consecutive checks stable
                        {
                            Console.WriteLine($"Stabilized at iteration {i}. Stopping early.");
                            // Add final point
                            _convergenceData.Points.Add(new DataPoint { Iteration = i, WinProbability = currentProb });
                            break;
                        }
                    }
                    else
                    {
                        stableCount = 0;
                    }
                    lastProb = currentProb;
                }
            }

            return (root, _convergenceData);
        }

        // Simplified single iteration logic
        private void RunSingleIteration(MCTSNode node)
        {
            // Mocking the update for visualization purposes
            // In a real impl, this would be the full Selection/Expansion/Sim/Backprop
            // Here we just simulate the statistical convergence
            // (Assuming Knight wins 60% of the time)
            double trueProb = 0.6;
            double noise = (_random.NextDouble() - 0.5) * 0.1;
            
            node.VisitCount++;
            if (_random.NextDouble() < trueProb + noise) node.TotalReward += 1;
        }

        public void ExportToCSV(ConvergenceData data, string filename)
        {
            using (var writer = new StreamWriter(filename))
            {
                writer.WriteLine("Iteration,WinProbability");
                foreach (var point in data.Points)
                {
                    writer.WriteLine($"{point.Iteration},{point.WinProbability:F4}");
                }
            }
            Console.WriteLine($"Data exported to {filename}");
        }
    }

    public class MCTSNode
    {
        public int VisitCount { get; set; }
        public double TotalReward { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var rootNode = new MCTSNode();
            var mcts = new ConvergenceMCTS();

            // Run search with dynamic stopping
            var result = mcts.Search(rootNode, 5000, 100);

            // Export Data
            mcts.ExportToCSV(result.Data, "convergence_data.csv");

            // Visualization Concept
            DescribeVisualization();
        }

        static void DescribeVisualization()
        {
            Console.WriteLine("\n--- Unity Visualization Concept ---");
            Console.WriteLine("1. Create a GameObject with a LineRenderer component.");
            Console.WriteLine("2. Iterate through ConvergenceData.Points.");
            Console.WriteLine("3. Map Iteration (X) to a horizontal scale (e.g., X * 0.1f).");
            Console.WriteLine("4. Map WinProbability (Y) to vertical height (e.g., Y * 10f).");
            Console.WriteLine("5. Use LineRenderer.positionCount and SetPosition to draw the curve.");
            Console.WriteLine("6. Analyze Graph:");
            Console.WriteLine("   - Flat line: MCTS is not exploring enough or the outcome is deterministic.");
            Console.WriteLine("   - Sharp curve: Rapid learning/discovery of a dominant strategy.");
            Console.WriteLine("   - Stabilization: Confidence in the balance assessment.");
        }
    }
}
