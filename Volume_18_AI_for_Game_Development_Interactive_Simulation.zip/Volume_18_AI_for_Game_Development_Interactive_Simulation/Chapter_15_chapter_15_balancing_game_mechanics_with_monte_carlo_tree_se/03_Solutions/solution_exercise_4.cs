
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace MCTS_LLMIntegration
{
    // 1. Mock LLM Interface
    public interface ILLMProvider
    {
        Task<string> GenerateRules(string prompt);
    }

    public class MockLLMProvider : ILLMProvider
    {
        public Task<string> GenerateRules(string prompt)
        {
            // Simulating an LLM response with hardcoded JSON
            var cards = new[]
            {
                new { Name = "Fireball", Cost = 3, Damage = 5, Type = "Spell" },
                new { Name = "Goblin", Cost = 2, Damage = 3, Type = "Creature" },
                new { Name = "Dragon", Cost = 6, Damage = 10, Type = "Creature" },
                new { Name = "Heal", Cost = 4, Damage = 0, Type = "Spell" }
            };
            
            string json = JsonSerializer.Serialize(cards);
            return Task.FromResult(json);
        }
    }

    // 2. Data Parsing
    public class Card
    {
        public string Name { get; set; }
        public int Cost { get; set; }
        public int Damage { get; set; }
        public string Type { get; set; }
    }

    public class RuleEngine
    {
        public List<Card> ParseCards(string json)
        {
            var cards = JsonSerializer.Deserialize<List<Card>>(json);
            return cards;
        }

        // 3. Rule-Based Heuristic
        public double CalculateHeuristicBonus(MCTSNode node, List<Card> cards)
        {
            // Find the card associated with this node's action
            // In this simplified simulation, the action is playing a specific card
            var card = cards.FirstOrDefault(c => c.Name == node.ActionName);
            if (card == null) return 0.0;

            double bonus = 0.0;

            // Rule: "Spells with Cost > 3 are high value"
            if (card.Type == "Spell" && card.Cost > 3)
            {
                bonus += 0.5;
            }

            // Rule: "Creatures with high damage are valuable"
            if (card.Type == "Creature" && card.Damage > 5)
            {
                bonus += 0.3;
            }

            return bonus;
        }
    }

    // 4. MCTS with Rule-Based UCB
    public class MCTSNode
    {
        public string ActionName { get; set; } // e.g., Card Name
        public MCTSNode Parent { get; set; }
        public List<MCTSNode> Children { get; set; } = new List<MCTSNode>();
        public int VisitCount { get; set; }
        public double TotalReward { get; set; }
        
        // Mock state for simulation
        public bool IsTerminal { get; set; } 

        public MCTSNode(string action, MCTSNode parent)
        {
            ActionName = action;
            Parent = parent;
        }
    }

    public class RuleBasedMCTS
    {
        private Random _random = new Random();
        private RuleEngine _ruleEngine;
        private List<Card> _availableCards;

        public RuleBasedMCTS(List<Card> cards)
        {
            _availableCards = cards;
            _ruleEngine = new RuleEngine();
        }

        public MCTSNode Search(MCTSNode root, int iterations)
        {
            for (int i = 0; i < iterations; i++)
            {
                MCTSNode node = Select(root);
                if (!node.IsTerminal)
                {
                    node = Expand(node);
                }
                double reward = Simulate();
                Backpropagate(node, reward);
            }
            return root;
        }

        private MCTSNode Expand(MCTSNode node)
        {
            // Actions are playing a card
            foreach (var card in _availableCards)
            {
                node.Children.Add(new MCTSNode(card.Name, node) { IsTerminal = true }); // Terminal for simplicity
            }
            return node.Children[0]; // Return first child for simulation
        }

        private double Simulate()
        {
            // Random result for demo
            return _random.NextDouble();
        }

        private void Backpropagate(MCTSNode node, double reward)
        {
            while (node != null)
            {
                node.VisitCount++;
                node.TotalReward += reward;
                node = node.Parent;
            }
        }

        private MCTSNode Select(MCTSNode node)
        {
            if (node.Children.Count == 0) return node;
            return GetBestRuleBasedChild(node);
        }

        private MCTSNode GetBestRuleBasedChild(MCTSNode node)
        {
            MCTSNode bestChild = null;
            double bestScore = double.MinValue;
            double exploration = 1.414;

            foreach (var child in node.Children)
            {
                if (child.VisitCount == 0) return child;

                // Standard UCB
                double exploit = child.TotalReward / child.VisitCount;
                double explore = Math.Sqrt(Math.Log(node.VisitCount) / child.VisitCount);
                double ucb = exploit + exploration * explore;

                // Add Heuristic Bonus
                double heuristicBonus = _ruleEngine.CalculateHeuristicBonus(child, _availableCards);
                double finalScore = ucb + heuristicBonus;

                if (finalScore > bestScore)
                {
                    bestScore = finalScore;
                    bestChild = child;
                }
            }
            return bestChild;
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            // 1. Get Rules from LLM
            ILLMProvider llm = new MockLLMProvider();
            string jsonRules = await llm.GenerateRules("Generate card stats for a fantasy game.");
            Console.WriteLine($"LLM Output: {jsonRules}\n");

            // 2. Parse Rules
            var ruleEngine = new RuleEngine();
            var cards = ruleEngine.ParseCards(jsonRules);

            // 3. Run MCTS
            var root = new MCTSNode("Root", null);
            var mcts = new RuleBasedMCTS(cards);
            
            Console.WriteLine("Running Rule-Based MCTS...");
            mcts.Search(root, 1000);

            // 4. Compare Distributions
            Console.WriteLine("\nAction Selection Distribution:");
            foreach (var child in root.Children)
            {
                var card = cards.First(c => c.Name == child.ActionName);
                string heuristic = ruleEngine.CalculateHeuristicBonus(child, cards) > 0 ? "[High Value]" : "";
                Console.WriteLine($"{child.ActionName} (Cost: {card.Cost}, Dmg: {card.Damage}): Visits {child.VisitCount} {heuristic}");
            }
        }
    }
}
