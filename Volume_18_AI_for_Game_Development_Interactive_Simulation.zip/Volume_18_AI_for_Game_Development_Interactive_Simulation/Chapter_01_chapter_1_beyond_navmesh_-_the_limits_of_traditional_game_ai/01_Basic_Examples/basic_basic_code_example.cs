
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Demonstrates the limitations of a traditional Finite State Machine (FSM)
/// for NPC behavior, specifically highlighting the "state explosion" problem
/// and rigid logic that fails to handle dynamic player interactions.
/// 
/// Context: An NPC guard in a stealth game. The guard patrols, investigates
/// noises, and chases the player. In a traditional FSM, every possible
/// interaction requires explicit state transitions, leading to brittle code.
/// </summary>
public class TraditionalFSMGaurd : MonoBehaviour
{
    // --- 1. State Definition ---
    // Using an enum for compile-time safety and readability.
    // However, this requires modification whenever new behaviors are added.
    public enum GuardState
    {
        Patrolling,     // Moving between waypoints
        Investigating,  // Moving to a noise source
        Chasing,        // Pursuing the player
        Idle            // Standing still
    }

    // --- 2. Configuration & References ---
    [Header("Navigation Settings")]
    public Transform[] waypoints; // Array of patrol points
    public float moveSpeed = 3.5f;
    public float rotationSpeed = 5.0f;

    [Header("Detection Settings")]
    public float sightRange = 10f;
    public float fieldOfView = 90f;
    public LayerMask playerLayer;
    public LayerMask obstacleLayer;

    [Header("Investigation Settings")]
    public float investigationDuration = 5f;
    public float investigationRadius = 2f;

    // --- 3. Runtime State Variables ---
    private GuardState currentState;
    private int currentWaypointIndex = 0;
    private Vector3 investigationTarget;
    private float investigationTimer;
    private Transform playerTarget;
    private Vector3 lastKnownPlayerPosition;

    // --- 4. Unity Lifecycle Methods ---

    void Start()
    {
        // Initialize the FSM to the default state
        currentState = GuardState.Patrolling;
        playerTarget = GameObject.FindGameObjectWithTag("Player")?.transform;

        if (waypoints.Length == 0)
        {
            Debug.LogError("No waypoints assigned for the guard!");
            this.enabled = false; // Disable script to prevent errors
        }
    }

    void Update()
    {
        // The "Update" loop acts as the FSM dispatcher.
        // It checks conditions and delegates behavior to specific state handlers.
        // As complexity grows, this single method becomes bloated and hard to maintain.
        
        switch (currentState)
        {
            case GuardState.Patrolling:
                HandlePatrolling();
                CheckForPlayer();
                break;

            case GuardState.Investigating:
                HandleInvestigating();
                CheckForPlayer(); // Can spot player while investigating
                break;

            case GuardState.Chasing:
                HandleChasing();
                break;
                
            case GuardState.Idle:
                // Simple idle logic
                break;
        }
    }

    // --- 5. State Handlers ---

    private void HandlePatrolling()
    {
        if (waypoints.Length == 0) return;

        Transform targetWaypoint = waypoints[currentWaypointIndex];
        
        // Move towards the waypoint
        float distance = Vector3.Distance(transform.position, targetWaypoint.position);
        
        if (distance > 0.1f)
        {
            // Simple vector math for movement (ignoring NavMesh for this specific example to focus on logic)
            Vector3 direction = (targetWaypoint.position - transform.position).normalized;
            Quaternion lookRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);
            transform.position += transform.forward * moveSpeed * Time.deltaTime;
        }
        else
        {
            // Switch to next waypoint
            currentWaypointIndex = (currentWaypointIndex + 1) % waypoints.Length;
        }
    }

    private void HandleInvestigating()
    {
        // Move to the investigation target (e.g., a noise source)
        float distance = Vector3.Distance(transform.position, investigationTarget);

        if (distance > 0.5f)
        {
            Vector3 direction = (investigationTarget - transform.position).normalized;
            Quaternion lookRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);
            transform.position += transform.forward * moveSpeed * Time.deltaTime;
        }
        else
        {
            // Once arrived, wait for the investigation duration
            investigationTimer -= Time.deltaTime;
            
            // Rotate slowly to look around
            transform.Rotate(Vector3.up, 30f * Time.deltaTime);

            if (investigationTimer <= 0)
            {
                // Investigation complete, return to patrolling
                currentState = GuardState.Patrolling;
                Debug.Log("Investigation finished. Returning to patrol.");
            }
        }
    }

    private void HandleChasing()
    {
        if (playerTarget == null) return;

        // Chase the player relentlessly
        Vector3 direction = (playerTarget.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);
        transform.position += transform.forward * (moveSpeed * 1.5f) * Time.deltaTime; // Run faster when chasing

        // If we lose sight (e.g., player goes behind a wall), transition to investigation
        if (!CanSeePlayer())
        {
            lastKnownPlayerPosition = playerTarget.position;
            StartInvestigation(lastKnownPlayerPosition);
            Debug.Log("Lost sight of player! Investigating last known position.");
        }
    }

    // --- 6. Sensory & Logic Checks ---

    private void CheckForPlayer()
    {
        if (playerTarget == null) return;

        if (CanSeePlayer())
        {
            currentState = GuardState.Chasing;
            Debug.Log("Player detected! Switching to Chase state.");
        }
    }

    private bool CanSeePlayer()
    {
        if (playerTarget == null) return false;

        // 1. Check distance
        float distanceToPlayer = Vector3.Distance(transform.position, playerTarget.position);
        if (distanceToPlayer > sightRange) return false;

        // 2. Check Angle (Field of View)
        Vector3 directionToPlayer = (playerTarget.position - transform.position).normalized;
        float angleBetweenGuardAndPlayer = Vector3.Angle(transform.forward, directionToPlayer);
        if (angleBetweenGuardAndPlayer > fieldOfView / 2) return false;

        // 3. Check Line of Sight (Raycast)
        // We cast a ray from the guard to the player. If we hit an obstacle (wall, crate)
        // before hitting the player, the player is hidden.
        RaycastHit hit;
        if (Physics.Raycast(transform.position + Vector3.up, directionToPlayer, out hit, sightRange, obstacleLayer))
        {
            // If the ray hits something that isn't the player, we can't see the player
            if (!hit.transform.CompareTag("Player")) return false;
        }

        return true;
    }

    // --- 7. External Event Triggers ---

    // This method simulates receiving an event (e.g., a noise made by the player)
    public void HearNoise(Vector3 noisePosition)
    {
        // In a real game, this would be called by an audio system or event manager.
        // The logic here is rigid: if we hear a noise, we investigate.
        // However, what if we are currently chasing? Should we ignore the noise?
        // What if the noise is a gunshot? Should we investigate or run for cover?
        // The FSM requires explicit code for every combination of states.
        
        if (currentState != GuardState.Chasing) // Example of hard-coded priority logic
        {
            StartInvestigation(noisePosition);
        }
    }

    private void StartInvestigation(Vector3 targetPos)
    {
        currentState = GuardState.Investigating;
        investigationTarget = targetPos;
        investigationTimer = investigationDuration;
        Debug.Log($"Investigating noise at {targetPos}");
    }
}
