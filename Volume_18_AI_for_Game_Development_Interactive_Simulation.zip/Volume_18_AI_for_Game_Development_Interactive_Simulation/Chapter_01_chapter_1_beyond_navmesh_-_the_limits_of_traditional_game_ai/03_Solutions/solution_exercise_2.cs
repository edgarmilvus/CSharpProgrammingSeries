
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using UnityEngine.AI;

public class NavAgentController : MonoBehaviour
{
    [Header("Configuration")]
    public Transform destination;
    public GameObject obstaclePrefab;
    public Transform obstacleSpawnPoint;
    
    [Header("Stuck Detection")]
    public float stuckThreshold = 0.1f; // Velocity magnitude considered "stuck"
    public float stuckTimeThreshold = 3.0f;

    private NavMeshAgent agent;
    private float stuckTimer = 0f;
    private bool isPanicking = false;
    private Renderer agentRenderer;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agentRenderer = GetComponent<Renderer>();
        
        if (destination != null)
        {
            agent.SetDestination(destination.position);
        }
    }

    void Update()
    {
        // 1. Check for dynamic obstacle trigger (simulated by proximity or manual call for this exercise)
        // In a real scenario, this would be inside a Trigger Collider's OnTriggerEnter
        // For this exercise, we will assume a helper method is called externally or check distance manually to trigger the block
        CheckForObstruction();

        // 2. Monitor for "Stuck" behavior
        if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance)
        {
            // Agent thinks it arrived, but if destination isn't reached (due to obstacle), velocity might drop
            if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
            {
                // Only count as stuck if we haven't actually reached the destination
                if (Vector3.Distance(transform.position, destination.position) > agent.stoppingDistance + 1f)
                {
                    stuckTimer += Time.deltaTime;
                }
            }
        }
        else
        {
            stuckTimer = 0f; // Reset if moving
        }

        // 3. Trigger Panic State
        if (stuckTimer >= stuckTimeThreshold && !isPanicking)
        {
            EnterPanicState();
        }
    }

    // Simulate the dynamic obstacle appearing
    public void TriggerObstacleSpawn()
    {
        Instantiate(obstaclePrefab, obstacleSpawnPoint.position, Quaternion.identity);
        // Note: NavMesh does not update automatically. The agent will try to path through the new collider.
    }

    private void CheckForObstruction()
    {
        // This is a visual helper; the physics collision handles the actual blocking
        // The NavMeshAgent will push against the obstacle but fail to recalculate a path
    }

    private void EnterPanicState()
    {
        isPanicking = true;
        agent.isStopped = true; // Stop trying to move
        
        // Visual feedback
        if (agentRenderer != null) agentRenderer.material.color = Color.red;
        
        Debug.Log("Path Blocked: Logic Failure");
        
        // Note: We do NOT implement pathfinding here as per requirements. 
        // The AI simply stops and signals failure.
    }
}
