
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using System.Collections.Generic;

public class SquadLeaderAI : MonoBehaviour
{
    // State Definition
    public enum SquadState { Idle, Combat, CoverCompromised, Retreat }
    private SquadState currentState = SquadState.Idle;

    // Blackboard Data
    public bool hasCover = true;
    public float squadHealthAverage = 100f;
    public GameObject coverObject; // The pillar or wall
    
    // Simulated Squad Members
    public List<Transform> squadMembers = new List<Transform>();

    void Start()
    {
        // Subscribe to the cover destruction event
        if (coverObject != null)
        {
            CoverObject coverScript = coverObject.GetComponent<CoverObject>();
            if (coverScript != null) coverScript.OnDestroyed += HandleCoverDestroyed;
        }
    }

    void Update()
    {
        // State Machine Logic
        switch (currentState)
        {
            case SquadState.Idle:
                // Transition to Combat if player detected (simulated)
                break;

            case SquadState.Combat:
                if (!hasCover)
                {
                    // Critical Transition: Cover is gone
                    currentState = SquadState.CoverCompromised;
                    Debug.Log("Cover compromised! Re-evaluating...");
                }
                else
                {
                    // Maintain combat position
                }
                break;

            case SquadState.CoverCompromised:
                // THE IMPOSSIBLE TASK: Hard-coded logic for dynamic scenarios
                EvaluateTacticalResponse();
                break;
                
            case SquadState.Retreat:
                ExecuteRetreat();
                break;
        }
    }

    // This method demonstrates the combinatorial explosion of FSM logic
    private void EvaluateTacticalResponse()
    {
        // Scenario 1: Low health, no cover
        if (squadHealthAverage < 30f)
        {
            currentState = SquadState.Retreat;
            Debug.Log("Critical Condition: Retreating.");
            return;
        }

        // Scenario 2: High health, no cover
        if (squadHealthAverage > 70f)
        {
            // Logic: Aggressive flanking? 
            // But what if the player has a grenade? What if the terrain is open?
            // We need more variables.
            Debug.Log("Flanking maneuver initiated (Hard-coded).");
            return;
        }

        // Scenario 3: Medium health, no cover
        // We might need to check distance to player, ammo count, etc.
        // Every new variable (ammo, player weapon, terrain height) requires a NEW nested if/else.
        
        Debug.Log("Defaulting to cautious advance due to lack of specific logic.");
    }

    private void ExecuteRetreat()
    {
        // Move squad to predefined fallback point
        Debug.Log("Squad moving to fallback point.");
    }

    // Event Handler
    private void HandleCoverDestroyed()
    {
        hasCover = false;
        Debug.Log("Event Received: Cover Destroyed.");
    }
}

// Helper script for the cover object
public class CoverObject : MonoBehaviour
{
    public delegate void CoverDestroyedHandler();
    public event CoverDestroyedHandler OnDestroyed;

    void OnDestroy()
    {
        OnDestroyed?.Invoke();
    }
}
