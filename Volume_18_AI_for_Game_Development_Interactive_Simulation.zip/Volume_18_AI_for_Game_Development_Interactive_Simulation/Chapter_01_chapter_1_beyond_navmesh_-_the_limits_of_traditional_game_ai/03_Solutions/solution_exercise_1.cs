
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using System.Collections;

public class GuardAI : MonoBehaviour
{
    // State Definition
    public enum GuardState { Patrolling, Chasing }
    private GuardState currentState;

    // Inspector Configuration
    [Header("References")]
    public Transform player;
    public Transform[] waypoints;
    
    [Header("Parameters")]
    public float patrolSpeed = 3.5f;
    public float chaseSpeed = 8.0f;
    public float detectionRadius = 10f;
    public float loseRadius = 20f;
    public float waitTime = 2f;

    // Internal State Variables
    private int currentWaypointIndex = 0;
    private float waitTimer;
    private bool isWaiting = false;

    void Start()
    {
        // Initialize state
        currentState = GuardState.Patrolling;
        // Start the appropriate behavior loop
        StartCoroutine(PatrolRoutine());
    }

    void Update()
    {
        // Central state transition check
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        switch (currentState)
        {
            case GuardState.Patrolling:
                // Transition condition: Player enters detection radius
                if (distanceToPlayer < detectionRadius)
                {
                    SwitchState(GuardState.Chasing);
                }
                break;

            case GuardState.Chasing:
                // Transition condition: Player leaves lose radius
                if (distanceToPlayer > loseRadius)
                {
                    SwitchState(GuardState.Patrolling);
                }
                else
                {
                    // Continuous behavior during chase
                    ChasePlayer();
                }
                break;
        }
    }

    // Handles logic for cleaning up previous state and initializing new state
    private void SwitchState(GuardState newState)
    {
        // Stop any running coroutines specific to the previous state
        if (currentState == GuardState.Patrolling)
        {
            StopAllCoroutines(); // Stops the PatrolRoutine
        }

        currentState = newState;

        // Initialize new state
        if (currentState == GuardState.Patrolling)
        {
            // Snap back to the nearest waypoint or resume logic
            // Here we simply restart the patrol routine
            StartCoroutine(PatrolRoutine());
        }
        else if (currentState == GuardState.Chasing)
        {
            // Visual feedback or immediate logic
            Debug.Log("Switched to Chasing!");
        }
    }

    // Logic for Patrolling State
    private IEnumerator PatrolRoutine()
    {
        while (currentState == GuardState.Patrolling)
        {
            // If we are waiting at a waypoint, count down
            if (isWaiting)
            {
                waitTimer -= Time.deltaTime;
                if (waitTimer <= 0)
                {
                    isWaiting = false;
                    // Move to next waypoint index
                    currentWaypointIndex = (currentWaypointIndex + 1) % waypoints.Length;
                }
                yield return null; // Wait for next frame
                continue;
            }

            // Move towards current target waypoint
            Transform targetWaypoint = waypoints[currentWaypointIndex];
            transform.position = Vector3.MoveTowards(transform.position, targetWaypoint.position, patrolSpeed * Time.deltaTime);
            transform.LookAt(targetWaypoint);

            // Check if reached waypoint
            if (Vector3.Distance(transform.position, targetWaypoint.position) < 0.1f)
            {
                isWaiting = true;
                waitTimer = waitTime;
            }

            yield return null;
        }
    }

    // Logic for Chasing State
    private void ChasePlayer()
    {
        // Move towards player
        transform.position = Vector3.MoveTowards(transform.position, player.position, chaseSpeed * Time.deltaTime);
        transform.LookAt(player);
    }

    // Visualization for debugging
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, loseRadius);
    }
}
