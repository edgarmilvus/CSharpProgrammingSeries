
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using System.Collections.Generic;

public class DialogueManager : MonoBehaviour
{
    [Header("Configuration")]
    public bool isRaining = false; // Simulated global state

    // Hard-coded dictionary for deterministic responses
    private Dictionary<string, string> dialogueMap = new Dictionary<string, string>()
    {
        { "hello", "Greetings, traveler." },
        { "what do you sell?", "I sell swords, potions, and lies." },
        { "where is the king?", "He is in the castle, as always." },
        { "bye", "Farewell." }
    };

    // Simulate receiving input from a UI InputField or Console
    public void ProcessPlayerInput(string input)
    {
        string formattedInput = input.ToLower().Trim();
        string response;

        // 1. Context Check (The "Raining" Flag)
        // This overrides normal logic flow, demonstrating poor integration of context.
        if (isRaining)
        {
            Debug.Log("Shopkeeper: It's a gloomy day today...");
            // Note: In a rigid FSM/Script, this might return early, ignoring the player's actual question.
        }

        // 2. Dictionary Lookup (The "Hard-Coded" Logic)
        if (dialogueMap.TryGetValue(formattedInput, out response))
        {
            Debug.Log($"Shopkeeper: {response}");
        }
        else
        {
            // 3. Fallback for unknown inputs
            Debug.Log("Shopkeeper: I don't understand.");
        }
    }

    // Helper for testing
    [ContextMenu("Toggle Rain")]
    public void ToggleRain()
    {
        isRaining = !isRaining;
        Debug.Log($"Rain is now: {isRaining}");
    }
}
