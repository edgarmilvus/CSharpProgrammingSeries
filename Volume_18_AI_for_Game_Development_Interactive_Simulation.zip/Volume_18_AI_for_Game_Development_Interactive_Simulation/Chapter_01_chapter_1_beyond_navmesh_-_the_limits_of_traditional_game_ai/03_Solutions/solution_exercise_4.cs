
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;

public class SensorySystem : MonoBehaviour
{
    [Header("Vision Settings")]
    public float viewRadius = 15f;
    [Range(0, 360)] public float viewAngle = 90f;
    public LayerMask targetMask;
    public LayerMask obstacleMask;

    [Header("Hearing Settings")]
    public float hearRadius = 10f;

    [Header("References")]
    public Transform player;
    public Transform archerBody;

    // Data structure for processed sensory input
    public struct PerceivedStimulus
    {
        public Vector3 position;
        public float intensity;
        public enum StimulusType { Sight, Sound }
        public StimulusType type;
    }

    public PerceivedStimulus? currentStimulus; // Nullable struct

    void Update()
    {
        // Reset stimulus every frame (simulating constant sensory scanning)
        currentStimulus = null;

        // 1. Process Vision
        if (CanSeePlayer())
        {
            currentStimulus = new PerceivedStimulus
            {
                position = player.position,
                intensity = 1.0f,
                type = PerceivedStimulus.StimulusType.Sight
            };
        }
        // 2. Process Sound (Only if not already seeing, or prioritize based on logic)
        else if (CanHearPlayer())
        {
            currentStimulus = new PerceivedStimulus
            {
                position = player.position, // In a real system, this would be the noise source position
                intensity = 0.5f,
                type = PerceivedStimulus.StimulusType.Sound
            };
        }

        // 3. Decision Logic based on Processed Data
        if (currentStimulus.HasValue)
        {
            RespondToStimulus(currentStimulus.Value);
        }
    }

    bool CanSeePlayer()
    {
        Vector3 dirToPlayer = (player.position - transform.position).normalized;
        
        // Check angle
        if (Vector3.Angle(transform.forward, dirToPlayer) < viewAngle / 2)
        {
            float distToPlayer = Vector3.Distance(transform.position, player.position);
            if (distToPlayer < viewRadius)
            {
                // Check obstacles
                if (!Physics.Raycast(transform.position, dirToPlayer, distToPlayer, obstacleMask))
                {
                    Debug.DrawRay(transform.position, dirToPlayer * distToPlayer, Color.green);
                    return true;
                }
            }
        }
        return false;
    }

    bool CanHearPlayer()
    {
        // Simplified hearing: Check distance to player
        // In a complex system, this would check velocity of player for "noise generation"
        float distToPlayer = Vector3.Distance(transform.position, player.position);
        if (distToPlayer < hearRadius)
        {
            // Simulate noise event based on player movement (simplified)
            if (player.GetComponent<PlayerMovement>()?.IsMoving() == true)
            {
                return true;
            }
        }
        return false;
    }

    void RespondToStimulus(PerceivedStimulus stimulus)
    {
        // Visualize the decision
        if (stimulus.type == PerceivedStimulus.StimulusType.Sight)
        {
            Debug.DrawLine(transform.position, stimulus.position, Color.red);
            // Aim and Shoot logic would go here
        }
        else if (stimulus.type == PerceivedStimulus.StimulusType.Sound)
        {
            Debug.DrawLine(transform.position, stimulus.position, Color.yellow);
            // Investigate logic would go here
            archerBody.LookAt(stimulus.position);
        }
    }
    
    // Mock class for dependency
    public class PlayerMovement : MonoBehaviour {
        public bool IsMoving() => Input.GetAxis("Horizontal") != 0 || Input.GetAxis("Vertical") != 0;
    }
}
