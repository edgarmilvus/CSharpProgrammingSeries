
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace AdvancedApplicationScript
{
    // Problem: A small indie game studio is prototyping a survival game.
    // The player has a limited inventory and needs to decide which items to keep
    // when scavenging. Traditional game AI (NavMesh + FSM) is used for enemy movement,
    // but the player's decision-making process is currently hard-coded.
    // We need a system that simulates the player's thought process based on
    // current needs, item value, and inventory space, mimicking a "smart" agent
    // rather than a simple scripted sequence.

    // Context: This script simulates the logic behind a "Smart Looter" agent.
    // It does not control a 3D character directly (which would be NavMesh),
    // but rather the internal decision-making logic (which would be an FSM in traditional AI).
    // We are replacing the rigid FSM with a data-driven priority system to demonstrate
    // the shift towards adaptive behavior.

    class Program
    {
        static void Main(string[] args)
        {
            // 1. Initialization: Setup the agent's state and the environment.
            AgentState playerState = new AgentState();
            Item[] worldItems = GenerateWorldItems();

            Console.WriteLine("--- SCENARIO START: SMART LOOTER PROTOTYPE ---");
            Console.WriteLine($"Max Inventory: {playerState.MaxInventorySlots}");
            Console.WriteLine($"Current Health: {playerState.Health}/100");
            Console.WriteLine($"Current Hunger: {playerState.Hunger}/100\n");

            // 2. Perception Loop: The agent "sees" items in the environment.
            // In a real game engine, this would be a SphereCast or OnTriggerEnter.
            // Here, we iterate through an array representing the visible area.
            foreach (Item item in worldItems)
            {
                // 3. Decision Logic: Evaluate if the item is worth picking up.
                // This replaces a hard-coded FSM transition (e.g., "If see Medkit -> Go to Medkit").
                // Instead, we calculate a dynamic score based on current needs.
                int decisionScore = CalculateUtilityScore(item, playerState);

                Console.WriteLine($"Scanned Item: {item.Name} | Base Value: {item.Value} | Utility Score: {decisionScore}");

                // 4. Action Execution: If the score meets the threshold, pick it up.
                if (decisionScore >= 50) // Threshold constant
                {
                    if (playerState.CurrentInventoryCount < playerState.MaxInventorySlots)
                    {
                        playerState.AddItem(item);
                        Console.WriteLine($">>> ACTION: Picked up {item.Name}.\n");
                    }
                    else
                    {
                        // 5. Dynamic Re-evaluation: Inventory is full.
                        // This is a critical limitation of FSMs: handling complex states like "Inventory Full"
                        // often requires exponential state transitions. Here, we handle it linearly.
                        Console.WriteLine(">>> WARNING: Inventory Full. Evaluating replacement...\n");
                        HandleInventoryFull(item, playerState);
                    }
                }
                else
                {
                    Console.WriteLine(">>> DECISION: Ignoring item (Low Utility).\n");
                }
            }

            // 6. Final State Report
            Console.WriteLine("--- SCENARIO END: FINAL INVENTORY ---");
            playerState.DisplayInventory();
        }

        // --- CORE LOGIC BLOCKS ---

        // Calculates the "Utility" of an item.
        // This function represents the "Brain" of the agent.
        // It uses basic math and conditional logic to mimic value assessment.
        static int CalculateUtilityScore(Item item, AgentState state)
        {
            int score = 0;

            // Base value adds to the score (Greed factor)
            score += item.Value;

            // Need-based multiplier (Survival factor)
            if (item.Type == ItemType.Medkit && state.Health < 50)
            {
                score += 100; // High priority if injured
            }
            else if (item.Type == ItemType.Food && state.Hunger < 30)
            {
                score += 80; // High priority if starving
            }

            // Weight penalty (Carry capacity factor)
            // Heavier items are less desirable unless extremely valuable.
            if (item.Weight > 5)
            {
                score -= 20;
            }

            return score;
        }

        // Handles the logic when the agent has no space.
        // This simulates a "Compare and Replace" decision tree.
        static void HandleInventoryFull(Item newItem, AgentState state)
        {
            int lowestValueIndex = -1;
            int lowestValue = int.MaxValue;

            // Find the least valuable item currently held
            for (int i = 0; i < state.Inventory.Length; i++)
            {
                if (state.Inventory[i] != null)
                {
                    // Compare utility scores, not just base value, for a smarter swap
                    int currentItemScore = CalculateUtilityScore(state.Inventory[i], state);
                    int newItemScore = CalculateUtilityScore(newItem, state);

                    // If the new item is significantly better than what we have, mark the weak one for replacement
                    if (newItemScore > currentItemScore + 20) // Threshold for swap
                    {
                        if (state.Inventory[i].Value < lowestValue)
                        {
                            lowestValue = state.Inventory[i].Value;
                            lowestValueIndex = i;
                        }
                    }
                }
            }

            if (lowestValueIndex != -1)
            {
                Console.WriteLine($"Swapping {state.Inventory[lowestValueIndex].Name} for {newItem.Name}");
                state.Inventory[lowestValueIndex] = newItem;
            }
            else
            {
                Console.WriteLine("Current inventory items are more valuable than new item. Discarding new item.");
            }
        }

        // Helper to generate dummy data
        static Item[] GenerateWorldItems()
        {
            return new Item[]
            {
                new Item("Old Bandage", ItemType.Medkit, 1, 10),
                new Item("Canned Beans", ItemType.Food, 2, 25),
                new Item("Rusty Pistol", ItemType.Weapon, 5, 40),
                new Item("First Aid Kit", ItemType.Medkit, 3, 60),
                new Item("Water Bottle", ItemType.Food, 1, 15),
                new Item("Gold Bar", ItemType.Valuable, 4, 200) // High value, triggers inventory full logic
            };
        }
    }

    // --- DATA STRUCTURES ---

    // Enum defining item types. 
    // In a traditional FSM, these might be hard-coded strings.
    // Using an Enum provides type safety and better performance.
    public enum ItemType
    {
        Food,
        Medkit,
        Weapon,
        Valuable
    }

    // Represents an object in the game world.
    // This is a simple class (POCO) to hold data.
    public class Item
    {
        public string Name { get; set; }
        public ItemType Type { get; set; }
        public int Weight { get; set; }
        public int Value { get; set; }

        public Item(string name, ItemType type, int weight, int value)
        {
            Name = name;
            Type = type;
            Weight = weight;
            Value = value;
        }
    }

    // Represents the Agent's internal state.
    // In a complex game, this would be a component attached to a GameObject.
    public class AgentState
    {
        public int Health { get; set; } = 100;
        public int Hunger { get; set; } = 100;
        public int MaxInventorySlots { get; set; } = 4;
        public int CurrentInventoryCount { get; set; } = 0;
        
        // Using a fixed-size array to simulate memory constraints.
        // This forces the agent to make decisions about resource management.
        public Item[] Inventory { get; set; }

        public AgentState()
        {
            Inventory = new Item[MaxInventorySlots];
        }

        public void AddItem(Item item)
        {
            for (int i = 0; i < Inventory.Length; i++)
            {
                if (Inventory[i] == null)
                {
                    Inventory[i] = item;
                    CurrentInventoryCount++;
                    return;
                }
            }
        }

        public void DisplayInventory()
        {
            for (int i = 0; i < Inventory.Length; i++)
            {
                if (Inventory[i] != null)
                {
                    Console.WriteLine($"Slot {i + 1}: {Inventory[i].Name} (Val: {Inventory[i].Value})");
                }
                else
                {
                    Console.WriteLine($"Slot {i + 1}: Empty");
                }
            }
        }
    }
}
