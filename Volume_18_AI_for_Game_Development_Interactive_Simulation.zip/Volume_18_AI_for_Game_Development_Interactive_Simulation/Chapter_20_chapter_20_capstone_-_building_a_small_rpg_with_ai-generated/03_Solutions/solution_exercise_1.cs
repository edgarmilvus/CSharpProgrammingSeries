
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

// 1. Define the LLM Interface
public interface IDialogueLLM
{
    Task<string> GenerateResponseAsync(string prompt, CancellationToken ct);
}

// Mock implementation for demonstration purposes
public class MockLLM : IDialogueLLM
{
    public async Task<string> GenerateResponseAsync(string prompt, CancellationToken ct)
    {
        // Simulate network latency
        await Task.Delay(1000, ct);
        
        // Simulate response generation
        ct.ThrowIfCancellationRequested();
        return "This is a generated response based on: " + prompt.Substring(0, Mathf.Min(prompt.Length, 20)) + "...";
    }
}

public enum DialogueState
{
    AwaitingPlayerInput,
    GeneratingResponse,
    DisplayingText,
    Inactive
}

public class DialogueManager : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private IDialogueLLM _llm;
    [SerializeField] private Text _uiText; // The text box to display dialogue
    [SerializeField] private GameObject _thinkingIndicator; // Loading spinner

    [Header("Configuration")]
    [SerializeField] private string _npcPersonality = "Wise, cryptic, and helpful.";
    [SerializeField] private int _maxHistoryLength = 3;
    
    // State Management
    private DialogueState _currentState = DialogueState.Inactive;
    private CancellationTokenSource _generationCts;
    private readonly List<(string user, string npc)> _conversationHistory = new();
    
    // Streaming
    private StringBuilder _currentTextBuilder = new StringBuilder();
    private bool _isStreaming = false;
    private string _targetFullText;
    private float _typeSpeed = 0.04f; // Seconds per character

    private void Start()
    {
        // Dependency injection for the mock (in a real app, use a proper DI container)
        if (_llm == null) _llm = new MockLLM();
        
        if (_thinkingIndicator != null) _thinkingIndicator.SetActive(false);
    }

    private void Update()
    {
        // Handle text streaming in Update loop for simplicity
        if (_isStreaming && !string.IsNullOrEmpty(_targetFullText))
        {
            StreamTextTick();
        }
    }

    // Public API to start a conversation turn
    public async void RequestPlayerInput(string playerInput)
    {
        if (_currentState == DialogueState.GeneratingResponse) return; // Prevent spamming

        // 1. Transition State
        _currentState = DialogueState.GeneratingResponse;
        
        // 2. Update History
        _conversationHistory.Add((playerInput, "")); // NPC response pending

        // 3. UI Feedback
        if (_thinkingIndicator != null) _thinkingIndicator.SetActive(true);
        _uiText.text = "...";

        // 4. Prepare Cancellation
        _generationCts?.Cancel();
        _generationCts = new CancellationTokenSource();

        try
        {
            // 5. Construct Prompt
            string prompt = ConstructPrompt(playerInput);

            // 6. Async Generation
            string response = await _llm.GenerateResponseAsync(prompt, _generationCts.Token);

            // 7. Update History with result
            if (_conversationHistory.Count > 0)
            {
                _conversationHistory[^1] = (_conversationHistory[^1].user, response);
            }

            // 8. Transition to Display
            _currentState = DialogueState.DisplayingText;
            if (_thinkingIndicator != null) _thinkingIndicator.SetActive(false);
            
            StartTextStreaming(response);
        }
        catch (OperationCanceledException)
        {
            Debug.Log("Dialogue generation cancelled.");
            ResetState();
        }
        catch (Exception e)
        {
            Debug.LogError($"Dialogue generation failed: {e.Message}");
            // Fallback
            StartTextStreaming("I seem to have lost my train of thought...");
        }
    }

    private string ConstructPrompt(string currentPlayerInput)
    {
        // Build context from history (last N exchanges)
        var historyContext = _conversationHistory
            .Skip(Mathf.Max(0, _conversationHistory.Count - _maxHistoryLength))
            .Select(h => $"Player: {h.user}\nNPC: {h.npc}")
            .Aggregate((a, b) => $"{a}\n{b}");

        return $"NPC Personality: {_npcPersonality}\n" +
               $"Quest Context: Active Quest Discussion\n" +
               $"Conversation History:\n{historyContext}\n" +
               $"Player Input: {currentPlayerInput}\n" +
               $"NPC Response:";
    }

    private void StartTextStreaming(string fullText)
    {
        _targetFullText = fullText;
        _currentTextBuilder.Clear();
        _isStreaming = true;
        _uiText.text = "";
    }

    private void StreamTextTick()
    {
        // Simple character-by-character simulation
        // In a real scenario, you might use coroutines or a more precise timer
        if (string.IsNullOrEmpty(_targetFullText)) return;

        // Append one character
        if (_currentTextBuilder.Length < _targetFullText.Length)
        {
            _currentTextBuilder.Append(_targetFullText[_currentTextBuilder.Length]);
            _uiText.text = _currentTextBuilder.ToString();
        }
        else
        {
            // Streaming finished
            _isStreaming = false;
            _currentState = DialogueState.AwaitingPlayerInput;
        }
    }

    // Called when UI closes or player cancels
    public void CancelDialogue()
    {
        _generationCts?.Cancel();
        ResetState();
    }

    private void ResetState()
    {
        _isStreaming = false;
        _currentState = DialogueState.Inactive;
        if (_thinkingIndicator != null) _thinkingIndicator.SetActive(false);
    }

    private void OnDestroy()
    {
        _generationCts?.Cancel();
        _generationCts?.Dispose();
    }
}
