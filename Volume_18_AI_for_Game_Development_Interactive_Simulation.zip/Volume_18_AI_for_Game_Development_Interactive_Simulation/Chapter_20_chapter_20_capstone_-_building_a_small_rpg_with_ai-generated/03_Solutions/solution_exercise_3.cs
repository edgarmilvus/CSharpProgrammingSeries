
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public static class AssetGenerator
{
    // Cache dictionary to store textures by prompt hash
    private static Dictionary<string, Texture2D> _cache = new Dictionary<string, Texture2D>();

    public static async Task<Texture2D> GenerateTextureAsync(string prompt)
    {
        // 1. Check Cache
        string key = prompt.GetHashCode().ToString();
        if (_cache.TryGetValue(key, out Texture2D cachedTex))
        {
            return cachedTex;
        }

        // 2. Create Mock URL (In reality, this would be an API endpoint)
        // Using a placeholder image service for demonstration
        string url = $"https://via.placeholder.com/256x256.png?text={UnityWebRequest.EscapeURL(prompt)}";

        // 3. Async Web Request
        using (UnityWebRequest uwr = UnityWebRequestTexture.GetTexture(url))
        {
            var asyncOp = uwr.SendWebRequest();

            // Wait for completion without blocking main thread
            while (!asyncOp.isDone) 
            {
                await Task.Yield(); 
            }

            if (uwr.result == UnityWebRequest.Result.ConnectionError || uwr.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError($"Image download failed: {uwr.error}");
                return null;
            }

            // 4. Get Texture and Cache
            Texture2D texture = DownloadHandlerTexture.GetContent(uwr);
            texture.name = prompt; // Name the texture for debugging
            
            // IMPORTANT: Mark texture as non-readable to save memory if it's just for UI display
            // Note: DownloadHandlerTexture creates readable textures by default. 
            // In production, you might blit this to a non-readable texture or use AssetDatabase.
            
            _cache.Add(key, texture);
            return texture;
        }
    }

    public static void UnloadTexture(string prompt)
    {
        string key = prompt.GetHashCode().ToString();
        if (_cache.TryGetValue(key, out Texture2D tex))
        {
            UnityEngine.Object.Destroy(tex);
            _cache.Remove(key);
            
            // Trigger garbage collection for unused assets
            Resources.UnloadUnusedAssets();
        }
    }
}

public class DynamicQuestIcon : MonoBehaviour
{
    [SerializeField] private Image targetImage;
    [SerializeField] private Text descriptionText; // Optional: Input field to test

    // Example usage trigger
    public async void GenerateAndApplyIcon(string description)
    {
        if (targetImage == null) return;

        string prompt = $"RPG icon style, minimalistic, {description}";
        
        // Show loading state
        targetImage.color = Color.gray;

        Texture2D tex = await AssetGenerator.GenerateTextureAsync(prompt);

        if (tex != null)
        {
            // Convert Texture2D to Sprite
            Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
            targetImage.sprite = sprite;
            targetImage.color = Color.white;
        }
    }

    private void OnDestroy()
    {
        // Cleanup logic if specific textures need to be unloaded per instance
        // AssetGenerator.UnloadTexture(prompt); 
    }
}
