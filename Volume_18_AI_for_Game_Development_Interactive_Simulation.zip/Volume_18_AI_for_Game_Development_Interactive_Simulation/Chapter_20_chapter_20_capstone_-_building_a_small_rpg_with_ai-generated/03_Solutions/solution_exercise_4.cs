
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets; // Assuming addressables for spawning

public struct PlayerActionEvent
{
    public string ActionDescription;
    public Vector3 PlayerPosition;
}

public class AIWorldBuilder : MonoBehaviour
{
    // Thread-safe queue for player actions
    private ConcurrentQueue<PlayerActionEvent> _eventQueue = new ConcurrentQueue<PlayerActionEvent>();
    private CancellationTokenSource _processingCts;
    
    // Dependencies
    [SerializeField] private IDialogueLLM _llm; // Injected or Mocked
    [SerializeField] private QuestGenerator _questGenerator; 

    private void Start()
    {
        _processingCts = new CancellationTokenSource();
        StartEventProcessingLoop();
    }

    private void StartEventProcessingLoop()
    {
        // Run background task
        Task.Run(async () =>
        {
            while (!_processingCts.Token.IsCancellationRequested)
            {
                if (_eventQueue.TryDequeue(out PlayerActionEvent evt))
                {
                    await ProcessEventAsync(evt);
                }
                else
                {
                    // Prevent CPU spinning
                    await Task.Delay(100, _processingCts.Token);
                }
            }
        });
    }

    // Public method to be called by Player Interaction scripts
    public void QueuePlayerAction(string description, Vector3 pos)
    {
        _eventQueue.Enqueue(new PlayerActionEvent 
        { 
            ActionDescription = description, 
            PlayerPosition = pos 
        });
    }

    private async Task ProcessEventAsync(PlayerActionEvent evt)
    {
        try
        {
            // 1. Interpret Event (LLM -> Structured JSON)
            string jsonPrompt = $"Analyze action: '{evt.ActionDescription}'. Output ONLY valid JSON: {{ \"affected_area\": string, \"change_type\": string (destruction/creation/modification), \"severity\": float (0.0-1.0) }}";
            
            string jsonResponse = await _llm.GenerateResponseAsync(jsonPrompt, _processingCts.Token);
            
            // Parse JSON (Using a simple parser or Unity's JsonUtility for this example)
            EnvironmentalChange change = ParseEnvironmentalChange(jsonResponse);

            // 2. Apply Changes to Scene (Must use Main Thread)
            await MainThreadDispatcher.RunOnMainThread(() => 
            {
                ApplyVisualChanges(change, evt.PlayerPosition);
            });

            // 3. Generate Remediation Quest
            if (_questGenerator != null)
            {
                string questPrompt = $"Fix {change.change_type} in {change.affected_area} with severity {change.severity}";
                Quest remediationQuest = await _questGenerator.GenerateQuestAsync(questPrompt);
                
                // Fire event or update UI
                Debug.Log($"New Remediation Quest: {remediationQuest.Title}");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to process event: {e.Message}");
        }
    }

    private EnvironmentalChange ParseEnvironmentalChange(string json)
    {
        // Mock parsing logic
        // In production, use Newtonsoft.Json or Unity's JsonUtility
        return new EnvironmentalChange 
        { 
            affected_area = "Forest_01", 
            change_type = "destruction", 
            severity = 0.8f 
        };
    }

    private void ApplyVisualChanges(EnvironmentalChange change, Vector3 pos)
    {
        // Example: Change material or spawn particles
        // This runs on the Main Thread
        Debug.Log($"Applying {change.change_type} to {change.affected_area} at {pos}");
        
        // Visual feedback (e.g., instantiate smoke)
        // GameObject smoke = Instantiate(smokePrefab, pos, Quaternion.identity);
    }

    private void OnDestroy()
    {
        _processingCts?.Cancel();
    }
}

// Helper struct for JSON mapping
[Serializable]
public struct EnvironmentalChange
{
    public string affected_area;
    public string change_type;
    public float severity;
}

// Main Thread Dispatcher Helper (Essential for Background Tasks modifying Unity Objects)
public static class MainThreadDispatcher
{
    private static readonly ConcurrentQueue<Action> _executionQueue = new ConcurrentQueue<Action>();

    public static void Enqueue(Action action)
    {
        _executionQueue.Enqueue(action);
    }

    // Call this from a MonoBehaviour Update loop
    public static void Update()
    {
        while (_executionQueue.TryDequeue(out Action action))
        {
            action?.Invoke();
        }
    }

    public static Task RunOnMainThread(Action action)
    {
        var tcs = new TaskCompletionSource<bool>();
        Enqueue(() =>
        {
            try
            {
                action();
                tcs.SetResult(true);
            }
            catch (Exception ex)
            {
                tcs.SetException(ex);
            }
        });
        return tcs.Task;
    }
}

// Attach this script to a GameObject in the scene
public class DispatcherComponent : MonoBehaviour
{
    private void Update() => MainThreadDispatcher.Update();
}
