
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Mono.Data.Sqlite;
using UnityEngine;

public record DialogueHistoryEntry(int Id, string NpcId, string PlayerInput, string NpcResponse, DateTime Timestamp);

public class DialogueRepository
{
    private readonly string _dbPath;

    public DialogueRepository(string dbName = "DialogueHistory.db")
    {
        // Ensure directory exists
        string directory = Path.Combine(Application.persistentDataPath, "Databases");
        if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
        
        _dbPath = Path.Combine(directory, dbName);
        InitializeDatabase();
    }

    private void InitializeDatabase()
    {
        using (var connection = new SqliteConnection(_dbPath))
        {
            connection.Open();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS DialogueHistory (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        NpcId TEXT NOT NULL,
                        PlayerInput TEXT,
                        NpcResponse TEXT,
                        Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )";
                command.ExecuteNonQuery();
            }
            connection.Close();
        }
    }

    public async Task SaveDialogueAsync(string npcId, string playerInput, string npcResponse)
    {
        await Task.Run(() =>
        {
            using (var connection = new SqliteConnection(_dbPath))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "INSERT INTO DialogueHistory (NpcId, PlayerInput, NpcResponse) VALUES (@npc, @input, @response)";
                    command.Parameters.AddWithValue("@npc", npcId);
                    command.Parameters.AddWithValue("@input", playerInput);
                    command.Parameters.AddWithValue("@response", npcResponse);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        });
    }

    public async Task<List<DialogueHistoryEntry>> GetRecentDialogueAsync(string npcId, int limit)
    {
        return await Task.Run(() =>
        {
            var entries = new List<DialogueHistoryEntry>();
            using (var connection = new SqliteConnection(_dbPath))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT Id, NpcId, PlayerInput, NpcResponse, Timestamp FROM DialogueHistory WHERE NpcId = @npc ORDER BY Timestamp DESC LIMIT @limit";
                    command.Parameters.AddWithValue("@npc", npcId);
                    command.Parameters.AddWithValue("@limit", limit);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            entries.Add(new DialogueHistoryEntry(
                                reader.GetInt32(0),
                                reader.GetString(1),
                                reader.GetString(2),
                                reader.GetString(3),
                                reader.GetDateTime(4)
                            ));
                        }
                    }
                }
                connection.Close();
            }
            // Reverse to chronological order
            entries.Reverse();
            return entries;
        });
    }
}

// Integration with DialogueManager (Conceptual addition to Exercise 1)
public class DialogueManagerWithMemory : DialogueManager // Inheriting for brevity
{
    private DialogueRepository _repo;
    private const string _npcId = "Unique_NPC_01";

    protected override void Start()
    {
        base.Start();
        _repo = new DialogueRepository();
    }

    // Override prompt construction to include memory
    private async Task<string> ConstructPromptWithMemory(string currentPlayerInput)
    {
        // Fetch history
        var history = await _repo.GetRecentDialogueAsync(_npcId, 5);
        
        // Pruning Logic (Context Window Limit)
        string memoryContext = "";
        int estimatedTokenCount = 0;
        const int MAX_TOKENS = 200; // Rough estimation for demo

        foreach (var entry in history)
        {
            string entryText = $"[Memory: {entry.Timestamp}] Player: {entry.PlayerInput} NPC: {entry.NpcResponse}\n";
            if (estimatedTokenCount + entryText.Length > MAX_TOKENS)
            {
                // Stop adding raw history, trigger summary logic
                await SummarizeAndStoreHistory(history);
                break; 
            }
            memoryContext += entryText;
            estimatedTokenCount += entryText.Length;
        }

        return $"System: You are an NPC with memory.\nMemory:\n{memoryContext}\nCurrent Input: {currentPlayerInput}";
    }

    private async Task SummarizeAndStoreHistory(List<DialogueHistoryEntry> oldEntries)
    {
        // 1. Generate summary via LLM (Mocked here)
        string summaryPrompt = $"Summarize these conversation snippets: {JsonUtility.ToJson(oldEntries)}";
        // string summary = await _llm.GenerateResponseAsync(summaryPrompt, ...);
        string summary = "[Summary of previous adventures...]";

        // 2. Delete old entries
        // (Implementation of Delete logic in Repository omitted for brevity)

        // 3. Insert summary as a new entry
        await _repo.SaveDialogueAsync(_npcId, "[System]", summary);
    }
}
