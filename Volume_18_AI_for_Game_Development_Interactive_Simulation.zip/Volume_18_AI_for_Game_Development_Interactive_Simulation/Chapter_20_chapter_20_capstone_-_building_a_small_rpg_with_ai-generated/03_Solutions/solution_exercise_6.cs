
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

using System;
using System.Collections.Concurrent;
using UnityEngine;
using UnityEngine.Events;

public enum GameState { Idle, InDialogue, QuestActive, QuestComplete }

[System.Serializable]
public class UnityEventQuest : UnityEvent<Quest> { }

public class GameLoopOrchestrator : MonoBehaviour
{
    public static GameLoopOrchestrator Instance { get; private set; }
    
    // Events for decoupling
    public UnityEventQuest OnQuestGenerated;
    public UnityEvent OnQuestCompleted;
    public UnityEvent OnDialogueStarted;

    [SerializeField] private GameState _currentState = GameState.Idle;
    
    // Request Queue to prevent spamming/race conditions
    private ConcurrentQueue<Action> _requestQueue = new ConcurrentQueue<Action>();
    private bool _isProcessing = false;

    private void Awake()
    {
        // Thread-safe Singleton initialization
        if (Instance != null && Instance != this)
        {
            Destroy(this);
            return;
        }
        Instance = this;
    }

    private void Update()
    {
        // Process queued requests sequentially
        if (!_isProcessing && _requestQueue.TryDequeue(out Action action))
        {
            _isProcessing = true;
            action.Invoke();
        }

        // State Validation
        ValidateState();
    }

    // Public API for external systems to request state changes
    public void RequestDialogue()
    {
        _requestQueue.Enqueue(async () =>
        {
            if (_currentState != GameState.Idle) return;

            ChangeState(GameState.InDialogue);
            OnDialogueStarted?.Invoke();
            
            // Simulate dialogue flow
            await Task.Delay(1000); // Placeholder for actual dialogue logic
            
            // Example: Dialogue ends, request quest generation
            RequestQuestGeneration("Player asked for help");
        });
    }

    public void RequestQuestGeneration(string context)
    {
        // This would be called by DialogueManager event
        if (_currentState != GameState.InDialogue && _currentState != GameState.Idle) return;

        // Logic to generate quest (calling Exercise 2 system)
        Quest newQuest = new Quest { Title = "New Orchestrated Quest" };
        
        OnQuestGenerated?.Invoke(newQuest);
        ChangeState(GameState.QuestActive);
        
        _isProcessing = false; // Release lock
    }

    public void CompleteQuest()
    {
        if (_currentState != GameState.QuestActive) return;

        ChangeState(GameState.QuestComplete);
        OnQuestCompleted?.Invoke();
        
        // Return to idle after a delay
        Invoke(nameof(ResetToIdle), 2.0f);
    }

    private void ResetToIdle()
    {
        ChangeState(GameState.Idle);
    }

    private void ChangeState(GameState newState)
    {
        // Transition logic
        Debug.Log($"Orchestrator State Change: {_currentState} -> {newState}");
        _currentState = newState;
    }

    private void ValidateState()
    {
        // Example Validation: If we are InDialogue but the DialogueManager is inactive, force reset
        if (_currentState == GameState.InDialogue && FindObjectOfType<DialogueManager>() == null)
        {
            Debug.LogWarning("State Mismatch: Dialogue state active but no manager found. Resetting.");
            ChangeState(GameState.Idle);
            _isProcessing = false;
        }
    }
}
