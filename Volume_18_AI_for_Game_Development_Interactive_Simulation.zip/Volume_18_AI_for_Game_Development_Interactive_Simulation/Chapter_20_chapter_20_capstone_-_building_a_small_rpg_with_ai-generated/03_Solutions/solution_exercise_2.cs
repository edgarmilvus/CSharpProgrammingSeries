
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

// 1. Data Structures
public record struct WorldKnowledge(string Id, string Content, Vector<float> Embedding);

public class Quest
{
    public string Title;
    public string Description;
    public string Objective;
}

// 2. Vector Store Simulation
public class VectorStore
{
    private List<WorldKnowledge> _store = new();

    public void AddKnowledge(WorldKnowledge knowledge) => _store.Add(knowledge);

    // Simulates vector search using Cosine Similarity
    public List<WorldKnowledge> RetrieveRelevantContext(string query, int k)
    {
        // In a real app, we would embed the query first. 
        // Here we simulate an embedding based on string length to mock similarity.
        var queryEmbedding = SimulateEmbedding(query);

        return _store
            .Select(item => new 
            { 
                Item = item, 
                Score = CalculateCosineSimilarity(queryEmbedding, item.Embedding) 
            })
            .OrderByDescending(x => x.Score)
            .Take(k)
            .Select(x => x.Item)
            .ToList();
    }

    private Vector<float> SimulateEmbedding(string text)
    {
        // Dummy embedding: Vector based on text length for demonstration
        float val = text.Length % 100; 
        return new Vector<float>(new float[] { val, val * 0.5f, val * 0.2f });
    }

    private float CalculateCosineSimilarity(Vector<float> a, Vector<float> b)
    {
        // Simplified calculation for the example
        if (a.Count != b.Count) return 0;
        float dot = 0;
        for (int i = 0; i < a.Count; i++) dot += a[i] * b[i];
        return dot; // Not normalizing for simplicity in this mock
    }
}

// 3. Quest Generator Logic
public class QuestGenerator
{
    private readonly VectorStore _vectorStore;
    private readonly IDialogueLLM _llm; // Reusing the interface from Ex 1

    public QuestGenerator(VectorStore store, IDialogueLLM llm)
    {
        _vectorStore = store;
        _llm = llm;
    }

    public async Task<Quest> GenerateQuestAsync(string playerAction)
    {
        // Step 1: Retrieve Context
        var contextItems = _vectorStore.RetrieveRelevantContext(playerAction, 2);
        
        // Step 2: Construct RAG Prompt
        string contextString = contextItems.Count > 0 
            ? string.Join("\n- ", contextItems.Select(x => x.Content)) 
            : null;

        string prompt = $"[World Context]\n";
        
        if (!string.IsNullOrEmpty(contextString))
        {
            prompt += $"{contextString}\n";
        }
        else
        {
            // Hallucination Prevention: Explicit warning if no context found
            prompt += "WARNING: No specific lore found. Ensure the quest is generic and fits a standard fantasy setting.\n";
        }

        prompt += $"\n[Player Action]\n{playerAction}\n" +
                  $"[Task]\nGenerate a Quest object (Title, Description, Objective) that logically follows the context.";

        // Step 3: Call LLM
        // Note: In a real scenario, we would need a parser to convert LLM text to Quest object.
        // Here we simulate the generation.
        string response = await _llm.GenerateResponseAsync(prompt, CancellationToken.None);

        // Step 4: Parse/Construct Quest (Mocking the parsing for this exercise)
        return new Quest
        {
            Title = "Generated Quest from Context",
            Description = $"Based on: {playerAction}. Context: {contextString ?? "None"}",
            Objective = "Complete the generated task."
        };
    }
}
