
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace AI_RPG_Quest_Generator
{
    // Core Data Structures for the RPG System
    // These represent the fundamental building blocks of our game world.
    // We use simple classes and structs to hold state, mimicking the components in Unity.
    public class Quest
    {
        public string Title;
        public string Description;
        public string TargetNPC;
        public int RewardGold;
        public bool IsCompleted;

        public Quest(string title, string description, string targetNPC, int rewardGold)
        {
            Title = title;
            Description = description;
            TargetNPC = targetNPC;
            RewardGold = rewardGold;
            IsCompleted = false;
        }
    }

    public class Player
    {
        public string Name;
        public int Gold;
        public List<Quest> ActiveQuests;

        public Player(string name)
        {
            Name = name;
            Gold = 0;
            ActiveQuests = new List<Quest>();
        }
    }

    public class NPC
    {
        public string Name;
        public string DialogueContext; // Simulates a knowledge base for RAG
        public string[] QuestPool;     // A pool of potential quests this NPC can give

        public NPC(string name, string context, string[] quests)
        {
            Name = name;
            DialogueContext = context;
            QuestPool = quests;
        }
    }

    // Simulated AI Services
    // In a real application, these would call external APIs (OpenAI, HuggingFace, etc.)
    // Here, we simulate the behavior to demonstrate the architecture without needing API keys.
    public static class AI_QuestGenerator
    {
        // Simulates an LLM prompt: "Given NPC context: [context], generate a quest title and description."
        public static Quest GenerateQuest(NPC npc)
        {
            // Logic: We simulate the AI generating a quest based on the NPC's specific context.
            // This mimics "Dynamic World Building" where the world reacts to the state.
            Random rnd = new Random();
            int questIndex = rnd.Next(0, npc.QuestPool.Length);
            string questType = npc.QuestPool[questIndex];

            string title = $"The {questType} of {npc.Name}";
            string description = $"Assist {npc.Name} with the ongoing {questType.ToLower()}. " +
                                 $"Based on local rumors ({npc.DialogueContext.Substring(0, Math.Min(20, npc.DialogueContext.Length))}...), " +
                                 $"this requires immediate attention.";
            
            int reward = 10 + (questType.Length * 2); // Arbitrary reward calculation

            return new Quest(title, description, npc.Name, reward);
        }
    }

    public static class AI_DialogueSystem
    {
        // Simulates RAG (Retrieval-Augmented Generation).
        // Instead of sending the whole history, we retrieve relevant context (NPC memory)
        // and inject it into the prompt for the LLM.
        public static string GenerateResponse(Player player, NPC npc, string playerInput)
        {
            // 1. Retrieval Step: Fetch relevant memory/context
            string memoryContext = npc.DialogueContext;

            // 2. Augmentation Step: Combine memory with current input
            // In a real scenario, this is where vector databases would be queried.
            string promptContext = $"Context: {memoryContext}\nPlayer says: {playerInput}";

            // 3. Generation Step: Simulate LLM output
            // We use basic string manipulation to simulate a "smart" response based on keywords.
            string response = "";
            if (playerInput.ToLower().Contains("quest") || playerInput.ToLower().Contains("job"))
            {
                response = $"{npc.Name}: 'Ah, you seek work? I have a task related to my duties...'";
            }
            else if (playerInput.ToLower().Contains("hello") || playerInput.Contains("hi"))
            {
                response = $"{npc.Name}: 'Greetings, traveler. I am {npc.Name}. {memoryContext}'";
            }
            else
            {
                response = $"{npc.Name}: 'I see... (based on context: {memoryContext})'";
            }

            return response;
        }
    }

    public static class AI_TextureGenerator
    {
        // Simulates a Diffusion Model generating a UI asset.
        // In Unity, this would return a Texture2D. Here, we return a string representation.
        public static string GenerateQuestIcon(string questTitle)
        {
            // Logic: Analyze keywords in the title to determine the visual style.
            // This mimics prompt engineering for image generation.
            string style = "Fantasy";
            string subject = "Generic";
            
            if (questTitle.Contains("Forest")) subject = "Oak Tree";
            if (questTitle.Contains("Mine")) subject = "Pickaxe";
            if (questTitle.Contains("Dragon")) subject = "Dragon Scale";

            // Simulating the generation delay and output
            Console.WriteLine($"[AI Texture Service]: Generating diffusion model for '{subject}'...");
            System.Threading.Thread.Sleep(500); // Simulate processing time
            
            return $"[Icon Generated: {style} style {subject} with gold border]";
        }
    }

    // Main Application Logic
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- AI-Driven RPG Prototype Initialized ---");
            Console.WriteLine("System: Loading Local LLM Modules and Diffusion Models...\n");

            // 1. Initialize Game World
            Player player = new Player("Hero");
            
            // Define NPCs with specific contexts (simulating RAG knowledge bases)
            string[] elaraQuests = { "Forest", "Herbs", "Lost Child" };
            NPC elara = new NPC("Elara", "Elara is a herbalist worried about the darkening forest.", elaraQuests);

            string[] borinQuests = { "Mine", "Ore", "Tunnel" };
            NPC borin = new NPC("Borin", "Borin is a gruff miner complaining about cave-ins.", borinQuests);

            // 2. Gameplay Loop Simulation
            bool isRunning = true;
            while (isRunning)
            {
                Console.WriteLine("\n========================================");
                Console.WriteLine($"Player: {player.Name} | Gold: {player.Gold} | Active Quests: {player.ActiveQuests.Count}");
                Console.WriteLine("========================================");
                Console.WriteLine("Available NPCs: Elara, Borin");
                Console.WriteLine("Actions: [Talk <Name>], [Quest <Name>], [Complete], [Exit]");
                Console.Write("Input: ");
                
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input)) continue;

                string[] parts = input.Split(' ');
                string command = parts[0].ToLower();
                string targetName = parts.Length > 1 ? parts[1] : "";

                // --- Logic Block: Dialogue System (RAG) ---
                if (command == "talk")
                {
                    NPC target = GetNPC(targetName, elara, borin);
                    if (target != null)
                    {
                        // Simulate Player Input for the LLM
                        string playerDialogue = $"Hello {target.Name}, tell me about yourself.";
                        Console.WriteLine($"\n[Player]: {playerDialogue}");
                        
                        // Call AI Dialogue System (RAG)
                        string response = AI_DialogueSystem.GenerateResponse(player, target, playerDialogue);
                        Console.WriteLine(response);
                    }
                    else
                    {
                        Console.WriteLine("NPC not found.");
                    }
                }
                // --- Logic Block: Quest Generation (Dynamic Content) ---
                else if (command == "quest")
                {
                    NPC target = GetNPC(targetName, elara, borin);
                    if (target != null)
                    {
                        Console.WriteLine($"\n[System]: Querying AI Quest Generator for {target.Name}...");
                        
                        // Call AI Quest Generator
                        Quest newQuest = AI_QuestGenerator.GenerateQuest(target);
                        
                        Console.WriteLine($"[Generated Quest]: {newQuest.Title}");
                        Console.WriteLine($"   Desc: {newQuest.Description}");
                        Console.WriteLine($"   Reward: {newQuest.RewardGold} Gold");

                        // Add to player's log
                        player.ActiveQuests.Add(newQuest);
                        
                        // Call AI Texture Generator for UI Asset
                        string iconData = AI_TextureGenerator.GenerateQuestIcon(newQuest.Title);
                        Console.WriteLine($"   UI Asset: {iconData}");
                    }
                }
                // --- Logic Block: Quest Completion (Game Loop) ---
                else if (command == "complete")
                {
                    if (player.ActiveQuests.Count > 0)
                    {
                        // Complete the first quest in the list (simplified logic)
                        Quest quest = player.ActiveQuests[0];
                        quest.IsCompleted = true;
                        player.Gold += quest.RewardGold;
                        player.ActiveQuests.RemoveAt(0);
                        
                        Console.WriteLine($"\n[System]: Quest '{quest.Title}' completed!");
                        Console.WriteLine($"[System]: Received {quest.RewardGold} Gold.");
                        
                        // Dynamic World Update: The NPC context might change after a quest
                        UpdateWorldState(quest.TargetNPC);
                    }
                    else
                    {
                        Console.WriteLine("\n[System]: No active quests to complete.");
                    }
                }
                // --- Logic Block: Exit ---
                else if (command == "exit")
                {
                    isRunning = false;
                    Console.WriteLine("Shutting down AI systems...");
                }
                else
                {
                    Console.WriteLine("Unknown command.");
                }
            }
        }

        // Helper method to retrieve NPCs
        static NPC GetNPC(string name, NPC elara, NPC borin)
        {
            if (name.Equals("Elara", StringComparison.OrdinalIgnoreCase)) return elara;
            if (name.Equals("Borin", StringComparison.OrdinalIgnoreCase)) return borin;
            return null;
        }

        // Simulates the dynamic world state change
        static void UpdateWorldState(string npcName)
        {
            Console.WriteLine($"[World State]: Updating knowledge base for {npcName}...");
            // In a real RAG system, this would update the vector database or text file.
        }
    }
}
