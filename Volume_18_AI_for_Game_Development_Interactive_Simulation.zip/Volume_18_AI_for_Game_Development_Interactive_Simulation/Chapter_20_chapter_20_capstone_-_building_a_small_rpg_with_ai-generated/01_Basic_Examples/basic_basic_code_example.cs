
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

// A simple mock interface for an LLM (Large Language Model) provider.
// In a real application, this would be replaced by an API call to OpenAI, Anthropic, or a local model.
public interface ILLMProvider
{
    Task<string> GenerateResponseAsync(string prompt);
}

// A concrete implementation simulating a local LLM response.
// This allows the code to run without an internet connection or API keys for this example.
public class LocalMockLLM : ILLMProvider
{
    public async Task<string> GenerateResponseAsync(string prompt)
    {
        // Simulate network latency
        await Task.Delay(500); 

        // Simple keyword matching to simulate intelligent behavior
        if (prompt.Contains("quest"))
        {
            return "I have a task for you. The forest to the north is plagued by goblins. Clear them out, and I shall reward you with 50 gold.";
        }
        if (prompt.Contains("goblin"))
        {
            return "They are weak to fire magic but resistant to physical attacks. Be careful, traveler.";
        }
        
        return "Greetings, traveler. I am a humble merchant. How can I assist you today?";
    }
}

// The core logic for managing the NPC's "brain" and memory.
// This utilizes a simplified pattern of Retrieval-Augmented Generation (RAG) to maintain context.
public class NPCBrain
{
    private readonly ILLMProvider _llm;
    private readonly List<string> _memory;
    private readonly string _systemPrompt;

    public NPCBrain(ILLMProvider llm, string npcName, string role)
    {
        _llm = llm;
        _memory = new List<string>();
        // System prompts define the persona and constraints of the AI.
        _systemPrompt = $"You are {npcName}, a {role}. Keep your responses concise and in character.";
    }

    // Generates a response based on player input and internal memory.
    public async Task<string> InteractAsync(string playerInput)
    {
        // 1. Update Memory
        _memory.Add($"Player: {playerInput}");

        // 2. Construct Prompt (RAG Context)
        // We retrieve recent memory to provide context to the LLM.
        string context = string.Join("\n", _memory.TakeLast(4)); // Look at last 4 exchanges
        string fullPrompt = $"{_systemPrompt}\n\nRecent Context:\n{context}\n\nResponse:";

        // 3. Generate
        string response = await _llm.GenerateResponseAsync(fullPrompt);

        // 4. Store Response
        _memory.Add($"NPC: {response}");

        return response;
    }
}

// Unity Component to bridge the AI logic with the Game UI.
public class AIChatInterface : MonoBehaviour
{
    [Header("UI References")]
    public InputField playerInputField;
    public Button sendButton;
    public Text npcResponseText;
    public ScrollRect chatScroll;

    [Header("AI Configuration")]
    public string npcName = "Elder";
    public string npcRole = "Village Elder";

    // Dependency Injection: We inject the LLM provider into the brain.
    private NPCBrain _npcBrain;

    void Start()
    {
        // Initialize dependencies
        ILLMProvider llmProvider = new LocalMockLLM();
        _npcBrain = new NPCBrain(llmProvider, npcName, npcRole);

        // Hook up UI events
        sendButton.onClick.AddListener(OnSendClicked);
        playerInputField.onEndEdit.AddListener(HandleEnterKey);
        
        // Initial greeting
        DisplayMessage("System", $"{npcName} is ready to talk.");
    }

    private void HandleEnterKey(string text)
    {
        if (Input.GetKey(KeyCode.Return) || Input.GetKey(KeyCode.KeypadEnter))
        {
            OnSendClicked();
        }
    }

    private async void OnSendClicked()
    {
        string input = playerInputField.text;
        if (string.IsNullOrWhiteSpace(input)) return;

        // UI Update: Show player message immediately
        DisplayMessage("Player", input);
        playerInputField.text = "";
        sendButton.interactable = false; // Prevent spamming

        try
        {
            // AI Processing
            string npcResponse = await _npcBrain.InteractAsync(input);

            // UI Update: Show AI response
            DisplayMessage(npcName, npcResponse);
        }
        catch (Exception e)
        {
            DisplayMessage("Error", $"Something went wrong: {e.Message}");
        }
        finally
        {
            sendButton.interactable = true;
        }
    }

    private void DisplayMessage(string sender, string message)
    {
        // Append text to the chat window
        npcResponseText.text += $"\n<b>{sender}:</b> {message}";
        
        // Force layout rebuild to ensure scroll works correctly
        Canvas.ForceUpdateCanvases();
        chatScroll.verticalNormalizedPosition = 0f;
    }
}
