
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.cs
// Description: Theoretical Foundations
// ==========================================

using System.Collections.Generic;
using System.Linq;

// Records are ideal for data transfer objects in AI pipelines
// because they are immutable by default, preventing accidental state mutation
// during the complex flow of retrieval and generation.
public record MemoryItem(string Id, string Content, float[] Embedding);

public interface IMemoryStore
{
    // IAsyncEnumerable allows streaming results as they are retrieved,
    // which is vital for low-latency gameplay when querying large databases.
    IAsyncEnumerable<MemoryItem> RetrieveSimilarAsync(float[] queryEmbedding, int k);
}

public class NarrativeController
{
    private readonly IMemoryStore _memoryStore;
    private readonly ILanguageModel _llm;

    public async Task<string> GetNPCResponse(string playerInput, string npcId)
    {
        // 1. Embed the player's input (requires a separate embedding model)
        float[] inputEmbedding = await EmbedTextAsync(playerInput);

        // 2. Retrieve relevant memories
        // We use 'await foreach' to handle the stream efficiently.
        var relevantMemories = new List<MemoryItem>();
        await foreach (var memory in _memoryStore.RetrieveSimilarAsync(inputEmbedding, k: 3))
        {
            relevantMemories.Add(memory);
        }

        // 3. Construct the RAG-augmented prompt
        string context = string.Join("\n", relevantMemories.Select(m => m.Content));
        string prompt = $"""
            Context:
            {context}
            
            Player says: {playerInput}
            
            Respond as the NPC:
            """;

        // 4. Generate
        return await _llm.GenerateAsync(prompt, new GenerationParameters());
    }
}
