
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

using System.Threading.Tasks;
using UnityEngine;

public class TextureGenerator : MonoBehaviour
{
    // Using a ConcurrentQueue ensures thread safety when
    // multiple game systems request assets simultaneously.
    private System.Collections.Concurrent.ConcurrentQueue<TextureRequest> _requestQueue;

    async void Start()
    {
        // Process queue on a background thread to avoid frame drops
        await ProcessQueueAsync();
    }

    private async Task ProcessQueueAsync()
    {
        while (true)
        {
            if (_requestQueue.TryDequeue(out var request))
            {
                // ConfigureAwait(false) releases the Unity context back to the main thread
                // This is critical to prevent freezing the game loop.
                var result = await GenerateImageAsync(request.Prompt).ConfigureAwait(false);
                
                // We must return to the Unity Main Thread to apply the texture to a Material
                await UnityMainThreadDispatcher.Instance.EnqueueAsync(() => 
                {
                    request.TargetMaterial.mainTexture = result;
                });
            }
            await Task.Yield();
        }
    }
}
