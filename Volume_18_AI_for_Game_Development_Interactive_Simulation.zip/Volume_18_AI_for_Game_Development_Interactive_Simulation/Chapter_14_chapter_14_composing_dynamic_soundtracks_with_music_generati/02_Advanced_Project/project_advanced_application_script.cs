
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace DynamicSoundtrackSimulator
{
    // Represents the different intensity levels of gameplay.
    // In a real game, this would be driven by enemy count, player health, or narrative tension.
    public enum GameplayIntensity
    {
        Low,    // Exploration, safe zones
        Medium, // Minor skirmishes, puzzle solving
        High    // Combat, boss fights, chase sequences
    }

    // Represents the narrative context or "Biome" of the current scene.
    public enum NarrativeContext
    {
        Wilderness,
        Urban,
        Mystical
    }

    // Simulates an external AI Music API (like AIVA, Soundraw, or Mubert).
    // In a real implementation, this would make HTTP requests to a REST API.
    public class AiMusicApi
    {
        // Simulates an asynchronous API call to generate a music track.
        // Returns a string representing the track ID or file path.
        public async Task<string> GenerateTrackAsync(GameplayIntensity intensity, NarrativeContext context)
        {
            // Simulate network latency (500ms - 1500ms)
            int latency = new Random().Next(500, 1500);
            await Task.Delay(latency);

            // Generate a unique identifier for the track
            string trackId = $"track_{context}_{intensity}_{DateTime.Now.Ticks}";
            
            Console.WriteLine($"[API LOG] Generated {trackId} (Intensity: {intensity}, Context: {context})");
            return trackId;
        }

        // Simulates fetching audio stems (layers) for dynamic mixing.
        // Real APIs often provide separate stems (Drums, Bass, Melody, Ambience).
        public string[] GetStems(string trackId)
        {
            Console.WriteLine($"[API LOG] Fetching stems for {trackId}...");
            return new string[] { 
                $"{trackId}_drums.wav", 
                $"{trackId}_bass.wav", 
                $"{trackId}_melody.wav", 
                $"{trackId}_ambience.wav" 
            };
        }
    }

    // Manages the audio playback state and transitions.
    // Handles the logic for cross-fading between tracks to ensure seamless audio.
    public class AudioMixer
    {
        private string _currentTrackId;
        private string _pendingTrackId;
        private string[] _currentStems;
        private bool _isTransitioning;
        private float _masterVolume = 1.0f;

        // Simulates playing a track by managing internal state.
        public void PlayTrack(string trackId, string[] stems)
        {
            if (_isTransitioning)
            {
                Console.WriteLine("[Mixer] Cannot play new track: Transition in progress.");
                return;
            }

            if (_currentTrackId == null)
            {
                // First track, instant play
                _currentTrackId = trackId;
                _currentStems = stems;
                Console.WriteLine($"[Mixer] Started playback: {trackId}");
                StartStemPlayback(stems);
            }
            else
            {
                // Trigger cross-fade
                Console.WriteLine($"[Mixer] Initiating cross-fade from {_currentTrackId} to {trackId}");
                StartCrossFade(trackId, stems);
            }
        }

        // Handles the logic for fading out the old track and fading in the new one.
        private void StartCrossFade(string newTrackId, string[] newStems)
        {
            _pendingTrackId = newTrackId;
            _isTransitioning = true;

            // Run transition logic in a separate thread to not block the main game loop
            Task.Run(() =>
            {
                float fadeDuration = 2.0f; // seconds
                int steps = 50;
                float stepTime = fadeDuration / steps;

                for (int i = 0; i <= steps; i++)
                {
                    float ratio = i / (float)steps;
                    
                    // Simulate volume mixing
                    float oldVol = 1.0f - ratio;
                    float newVol = ratio;

                    // In a real engine (Unity), we would set AudioSource.volume here.
                    // For this console app, we just log the state.
                    if (i % 10 == 0) 
                        Console.WriteLine($"[Mixer] Cross-fading... Old: {oldVol:P0} | New: {newVol:P0}");

                    Thread.Sleep((int)(stepTime * 1000));
                }

                // Finalize transition
                _currentTrackId = _pendingTrackId;
                _currentStems = newStems;
                _pendingTrackId = null;
                _isTransitioning = false;
                Console.WriteLine($"[Mixer] Transition complete. Now playing: {_currentTrackId}");
            });
        }

        private void StartStemPlayback(string[] stems)
        {
            foreach (var stem in stems)
            {
                Console.WriteLine($"   -> Layer Active: {stem}");
            }
        }

        // Simulates dynamic mixing based on intensity.
        // In a real scenario, this adjusts the volume of specific stems (e.g., drums get louder).
        public void UpdateMixIntensity(GameplayIntensity intensity)
        {
            if (_currentStems == null) return;

            Console.WriteLine($"[Mixer] Adjusting mix layers for intensity: {intensity}");
            // Logic to boost specific stems would go here
        }
    }

    // The core controller that bridges gameplay events to the audio system.
    public class DynamicSoundtrackController
    {
        private readonly AiMusicApi _musicApi;
        private readonly AudioMixer _audioMixer;
        
        // Cache to prevent re-generating tracks for the same context/intensity immediately
        private readonly Dictionary<string, string> _trackCache;

        public DynamicSoundtrackController()
        {
            _musicApi = new AiMusicApi();
            _audioMixer = new AudioMixer();
            _trackCache = new Dictionary<string, string>();
        }

        // Entry point for handling a gameplay event.
        // This would be hooked into Unity's event system (e.g., OnEnemySpawn, OnPlayerEnterSafeZone).
        public async void OnGameplayStateChanged(GameplayIntensity intensity, NarrativeContext context)
        {
            Console.WriteLine($"\n--- Event Detected: {context} | {intensity} ---");

            // 1. Check Cache
            string cacheKey = $"{context}_{intensity}";
            if (_trackCache.TryGetValue(cacheKey, out string cachedTrackId))
            {
                Console.WriteLine($"[Controller] Found cached track: {cachedTrackId}");
                _audioMixer.PlayTrack(cachedTrackId, new string[] { /* cached stems */ });
                _audioMixer.UpdateMixIntensity(intensity);
                return;
            }

            // 2. Generate New Track via API
            try
            {
                string newTrackId = await _musicApi.GenerateTrackAsync(intensity, context);
                string[] stems = _musicApi.GetStems(newTrackId);

                // 3. Update Cache
                _trackCache[cacheKey] = newTrackId;

                // 4. Trigger Audio Mixer
                _audioMixer.PlayTrack(newTrackId, stems);
                _audioMixer.UpdateMixIntensity(intensity);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Error] Failed to generate music: {ex.Message}");
                // Fallback logic (e.g., play pre-recorded static music) would go here
            }
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            // Initialize the system
            var controller = new DynamicSoundtrackController();

            Console.WriteLine("=== Dynamic AI Soundtrack Simulator Started ===\n");

            // Simulate a gameplay session
            // 1. Player enters the Wilderness (Low Intensity)
            controller.OnGameplayStateChanged(GameplayIntensity.Low, NarrativeContext.Wilderness);
            await Task.Delay(1000); // Wait for async processing

            // 2. Player spots enemies (Intensity rises to Medium)
            controller.OnGameplayStateChanged(GameplayIntensity.Medium, NarrativeContext.Wilderness);
            await Task.Delay(1000);

            // 3. Player enters combat (High Intensity)
            controller.OnGameplayStateChanged(GameplayIntensity.High, NarrativeContext.Wilderness);
            await Task.Delay(1000);

            // 4. Player moves to Urban area (Context Change)
            controller.OnGameplayStateChanged(GameplayIntensity.Medium, NarrativeContext.Urban);
            await Task.Delay(1000);

            // 5. Player returns to Low intensity in Urban (Should hit cache)
            controller.OnGameplayStateChanged(GameplayIntensity.Low, NarrativeContext.Urban);
            
            // Keep console open to observe async transitions
            Console.WriteLine("\n=== Simulation Finished. Press any key to exit ===");
            Console.ReadKey();
        }
    }
}
