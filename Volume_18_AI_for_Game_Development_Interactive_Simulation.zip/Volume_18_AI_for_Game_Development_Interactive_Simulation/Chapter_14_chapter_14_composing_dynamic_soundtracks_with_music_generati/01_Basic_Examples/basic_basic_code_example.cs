
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks; // Requires UniTask package
using UnityEngine.Networking;

/// <summary>
/// A self-contained example demonstrating how to fetch and play a dynamically generated
/// music track based on gameplay intensity. This simulates a call to a music generation API
/// (like Mubert or Aiva) where the "intensity" parameter alters the musical output.
/// 
/// Real-World Context:
/// Imagine an Action RPG where the player is exploring a calm forest (Low Intensity).
/// Suddenly, enemies appear. The music seamlessly transitions to a tense combat theme (High Intensity)
/// without hard cuts or obvious loops. This script handles the logic to request a new segment
/// of music that matches the current game state and fades it in smoothly.
/// </summary>
public class DynamicMusicGenerator : MonoBehaviour
{
    [Header("Audio Configuration")]
    [Tooltip("The AudioSource component used to play the generated music.")]
    [SerializeField] private AudioSource _musicSource;

    [Header("API Simulation Settings")]
    [Tooltip("Base URL for the music generation API. For this example, we simulate a response.")]
    [SerializeField] private string _apiEndpoint = "https://api.example-music-gen.com/v1/generate";
    
    [Tooltip("API Key (mocked for this example). In production, store this securely.")]
    [SerializeField] private string _apiKey = "YOUR_API_KEY_HERE";

    [Header("Dynamic Parameters")]
    [Tooltip("Current gameplay intensity (0.0 to 1.0). Driven by game logic.")]
    [Range(0f, 1f)]
    [SerializeField] private float _currentIntensity = 0.0f;

    // Internal state tracking
    private float _targetIntensity = 0.0f;
    private Coroutine _musicTransitionRoutine;
    private bool _isGenerating = false;

    // A simple enum to represent the musical mood derived from intensity
    public enum MusicMood { Calm, Tense, Aggressive }

    private void Start()
    {
        if (_musicSource == null)
            _musicSource = GetComponent<AudioSource>();

        // Initialize target intensity
        _targetIntensity = _currentIntensity;
        
        // Start the background music loop
        RequestNewTrack(_currentIntensity);
    }

    private void Update()
    {
        // Simulate gameplay changing intensity (e.g., enemies spawning)
        // In a real game, this would be driven by an EnemyManager or GameState
        if (Input.GetKeyDown(KeyCode.Space))
        {
            _targetIntensity = _targetIntensity > 0.5f ? 0.1f : 0.9f;
            Debug.Log($"Intensity target changed to: {_targetIntensity}");
        }

        // Smoothly interpolate current intensity towards target
        // This prevents jittery audio changes if target updates rapidly
        _currentIntensity = Mathf.Lerp(_currentIntensity, _targetIntensity, Time.deltaTime * 2f);

        // Check if we need to trigger a music change
        // We only trigger a new generation if we aren't already generating
        // and if the intensity shift is significant enough to warrant a new mood
        if (!_isGenerating && Mathf.Abs(_currentIntensity - _targetIntensity) > 0.1f)
        {
            // Determine the mood based on the current interpolated intensity
            MusicMood mood = DetermineMood(_currentIntensity);
            
            // Trigger the async generation process
            RequestNewTrack(_currentIntensity);
        }
    }

    /// <summary>
    /// Maps a float intensity value to a discrete musical mood.
    /// </summary>
    private MusicMood DetermineMood(float intensity)
    {
        if (intensity < 0.3f) return MusicMood.Calm;
        if (intensity < 0.7f) return MusicMood.Tense;
        return MusicMood.Aggressive;
    }

    /// <summary>
    /// Orchestrates the process of requesting a new track and transitioning to it.
    /// </summary>
    private void RequestNewTrack(float intensity)
    {
        // Prevent overlapping requests
        if (_isGenerating) return;
        
        // Start the async UniTask routine
        GenerateAndPlayTrack(intensity).Forget();
    }

    /// <summary>
    /// Core async logic: Generate -> Download -> Crossfade.
    /// </summary>
    private async UniTaskVoid GenerateAndPlayTrack(float intensity)
    {
        _isGenerating = true;
        MusicMood mood = DetermineMood(intensity);

        Debug.Log($"Generating new track for Mood: {mood} (Intensity: {intensity:F2})...");

        // 1. Simulate API Call to generate music
        // In a real scenario, this sends parameters (bpm, key, intensity) to an endpoint
        // and receives a URL to an audio file (e.g., .mp3 or .wav)
        string audioUrl = await SimulateMusicGenerationAPI(intensity, mood);

        // 2. Download the audio clip
        AudioClip newClip = await DownloadAudioClip(audioUrl);

        if (newClip == null)
        {
            Debug.LogError("Failed to download audio clip.");
            _isGenerating = false;
            return;
        }

        // 3. Perform the crossfade transition
        Debug.Log($"Track received. Beginning crossfade to {mood} music.");
        await CrossfadeMusic(newClip, 2.0f); // 2-second fade

        _isGenerating = false;
    }

    /// <summary>
    /// Simulates a call to an external Music Generation API.
    /// Returns a URL string pointing to the generated audio file.
    /// </summary>
    private async UniTask<string> SimulateMusicGenerationAPI(float intensity, MusicMood mood)
    {
        // Simulate network latency (500ms - 1500ms)
        int latency = UnityEngine.Random.Range(500, 1500);
        await UniTask.Delay(latency);

        // Mock URL generation based on mood
        // In reality, this would be a unique ID returned by the API
        return $"https://api.example-music-gen.com/assets/{mood}_{intensity.GetHashCode()}.mp3";
    }

    /// <summary>
    /// Downloads the audio file from the provided URL and decodes it into an AudioClip.
    /// </summary>
    private async UniTask<AudioClip> DownloadAudioClip(string url)
    {
        // Use UnityWebRequest to fetch the audio data
        using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url, AudioType.MPEG))
        {
            // Send the request and wait for completion
            var operation = www.SendWebRequest();
            
            while (!operation.isDone) 
                await UniTask.Yield();

            if (www.result == UnityWebRequest.Result.ConnectionError || www.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError($"Error downloading audio: {www.error}");
                return null;
            }

            // Retrieve the clip
            return DownloadHandlerAudioClip.GetContent(www);
        }
    }

    /// <summary>
    /// Handles the smooth transition between the current playing clip and the new clip.
    /// Uses a coroutine-like async pattern to fade volumes.
    /// </summary>
    private async UniTask CrossfadeMusic(AudioClip newClip, float fadeDuration)
    {
        // Create a temporary AudioSource to play the new track
        // This allows us to mix the old and new tracks together
        GameObject tempObj = new GameObject("TempMusicSource");
        AudioSource newSource = tempObj.AddComponent<AudioSource>();
        newSource.clip = newClip;
        newSource.loop = true;
        newSource.volume = 0f;
        newSource.Play();

        // Calculate fade speed
        float fadeSpeed = 1f / fadeDuration;

        // Fade In (New) & Fade Out (Old)
        while (newSource.volume < 1f || _musicSource.volume > 0f)
        {
            // Smoothly adjust volumes
            newSource.volume = Mathf.MoveTowards(newSource.volume, 1f, fadeSpeed * Time.deltaTime);
            _musicSource.volume = Mathf.MoveTowards(_musicSource.volume, 0f, fadeSpeed * Time.deltaTime);
            
            await UniTask.Yield();
        }

        // Cleanup: Stop and destroy the old source
        _musicSource.Stop();
        _musicSource.clip = newClip; // Assign new clip to main source
        _musicSource.volume = 1f;    // Reset volume
        _musicSource.Play();

        // Destroy the temporary object
        Destroy(tempObj);
    }
}
