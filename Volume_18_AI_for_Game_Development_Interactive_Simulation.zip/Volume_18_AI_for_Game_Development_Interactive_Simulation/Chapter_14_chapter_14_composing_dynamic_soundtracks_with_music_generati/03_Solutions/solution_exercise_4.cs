
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;

[System.Serializable]
public class AudioLayer
{
    public string Key; // e.g., "Melee"
    public AudioSource Source;
    public float Priority = 1.0f; // Higher = more important
    public float SmoothTime = 0.5f; // Damping
    private float _currentVelocity;

    public void UpdateVolume(float targetIntensity, float dampTime)
    {
        // SmoothDamp creates the "flutter-free" transition
        float newVol = Mathf.SmoothDamp(Source.volume, targetIntensity, ref _currentVelocity, dampTime);
        Source.volume = newVol;
    }
}

public class MusicMixer : MonoBehaviour
{
    public List<AudioLayer> Layers = new List<AudioLayer>();
    public float DampTime = 0.5f;

    // 1. Multi-Dimensional Input
    public void UpdateMix(Dictionary<string, float> intensityInputs)
    {
        // 2. Crossfading Logic: Calculate raw target volumes first
        foreach (var layer in Layers)
        {
            if (intensityInputs.TryGetValue(layer.Key, out float input))
            {
                layer.UpdateVolume(input, DampTime);
            }
            else
            {
                layer.UpdateVolume(0f, DampTime);
            }
        }

        // 3. Priority System: Normalize if clipping
        float totalVolume = Layers.Sum(l => l.Source.volume);
        
        if (totalVolume > 1.0f)
        {
            // Calculate scaling factor based on priority
            // We want to reduce volume of low priority layers more than high priority
            // This is a simplified "Ducking" logic
            
            // Sort by priority (ascending, so we scale low priority first)
            var sortedLayers = Layers.OrderBy(l => l.Priority).ToList();
            
            float excess = totalVolume - 1.0f;
            
            foreach (var layer in sortedLayers)
            {
                if (excess <= 0) break;
                
                float availableReduction = layer.Source.volume;
                float reduction = Mathf.Min(availableReduction, excess);
                
                layer.Source.volume -= reduction;
                excess -= reduction;
            }
        }
    }
}
