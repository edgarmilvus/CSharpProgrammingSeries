
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;

// 1. Architecture: MusicStemProfile ScriptableObject
[CreateAssetMenu(fileName = "NewStemProfile", menuName = "Audio/MusicStemProfile")]
public class MusicStemProfile : ScriptableObject
{
    public string StemIdentifier;
    public AudioClip StemClip;
    public AnimationCurve VolumeCurve; // Maps 0-1 intensity to 0-1 volume
}

// 2. Manager Logic: AudioIntensityManager
public class AudioIntensityManager : MonoBehaviour
{
    [System.Serializable]
    public class StemChannel
    {
        public MusicStemProfile Profile;
        public AudioSource Source; // Assigned via Inspector
    }

    public List<StemChannel> Stems = new List<StemChannel>();
    
    // 4. Event Integration
    public UnityEvent<float> OnIntensityChange;

    private float _currentIntensity = 0f;

    // 3. Intensity Processing
    public void UpdateMix(float globalIntensity)
    {
        // 5. Edge Case Handling: Clamp intensity
        globalIntensity = Mathf.Clamp01(globalIntensity);
        
        if (Mathf.Approximately(globalIntensity, _currentIntensity)) return;

        _currentIntensity = globalIntensity;
        
        foreach (var stem in Stems)
        {
            if (stem.Source == null)
            {
                Debug.LogWarning($"Missing AudioSource for Stem: {stem.Profile.StemIdentifier}");
                continue;
            }

            // Evaluate the curve directly for complex shapes
            float targetVolume = stem.Profile.VolumeCurve.Evaluate(globalIntensity);
            
            // Smoothly apply volume change (using frame-rate independent smoothing if desired, 
            // here we set directly or could use Mathf.SmoothDamp)
            stem.Source.volume = targetVolume;

            // Optimization: Ensure audio source is playing if volume > 0, stop if 0
            if (targetVolume > 0.01f && !stem.Source.isPlaying) stem.Source.Play();
            if (targetVolume <= 0.01f && stem.Source.isPlaying) stem.Source.Stop();
        }

        // Trigger external events
        OnIntensityChange?.Invoke(globalIntensity);
    }
}
