
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using System.Collections.Generic;

public enum TransitionType { Fade, Stinger, TempoSync }

// 1. Node-Based Architecture
[System.Serializable]
public class MusicNode
{
    public string Name;
    public MusicStemProfile Profile;
    public float TempoModifier = 1.0f; // e.g., 1.1 for 10% faster

    // 5. Runtime Modification
    public void ModifyTempo(float modifier)
    {
        TempoModifier = Mathf.Clamp(modifier, 0.5f, 2.0f);
    }
}

[System.Serializable]
public class MusicEdge
{
    public MusicNode From;
    public MusicNode To;
    public TransitionType Type;
    public float Duration;
}

public class AudioContextGraph : MonoBehaviour
{
    public List<MusicNode> Nodes = new List<MusicNode>();
    public List<MusicEdge> Edges = new List<MusicEdge>();
    
    private MusicNode _currentNode;

    // 3. Pathfinding for Audio (Simplified for linear musical coherence)
    public List<MusicEdge> CalculateTransitionPath(MusicNode current, MusicNode target)
    {
        // In a real graph, we might need intermediate nodes (e.g. Alert).
        // Here we find the direct edge, or simulate a "Stop -> Start" if no edge exists.
        
        List<MusicEdge> path = new List<MusicEdge>();
        
        // Check for direct connection
        var directEdge = Edges.Find(e => e.From == current && e.To == target);
        if (directEdge != null)
        {
            path.Add(directEdge);
        }
        else
        {
            // No direct path. Find intermediate if necessary (e.g. Exploration -> Alert -> Boss)
            // For this exercise, we simulate a fallback "Stop/Start" transition
            Debug.LogWarning($"No direct edge found from {current.Name} to {target.Name}. Using fallback.");
            path.Add(new MusicEdge { From = current, To = target, Type = TransitionType.Fade, Duration = 1.0f });
        }
        
        return path;
    }

    public void TransitionTo(MusicNode target)
    {
        if (_currentNode == null) _currentNode = Nodes[0]; // Default start

        var path = CalculateTransitionPath(_currentNode, target);
        
        foreach (var edge in path)
        {
            StartCoroutine(ExecuteTransition(edge));
        }
    }

    private IEnumerator ExecuteTransition(MusicEdge edge)
    {
        Debug.Log($"Transitioning from {edge.From.Name} to {edge.To.Name} via {edge.Type} over {edge.Duration}s");
        
        // Apply Node Runtime Modifications
        Debug.Log($"Applying Tempo Modifier: {edge.To.TempoModifier}");

        // Simulate transition delay
        yield return new WaitForSeconds(edge.Duration);
        
        _currentNode = edge.To;
    }

    // 5. Debugging Visualization (Editor Only)
    void OnDrawGizmos()
    {
        #if UNITY_EDITOR
        foreach (var node in Nodes)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawSphere(node.Name == "Boss" ? Vector3.right * 5 : Vector3.zero, 0.2f);
            UnityEditor.Handles.Label(node.Name == "Boss" ? Vector3.right * 5 : Vector3.zero, node.Name);
        }
        
        foreach (var edge in Edges)
        {
            Gizmos.color = Color.yellow;
            Vector3 start = edge.From.Name == "Boss" ? Vector3.right * 5 : Vector3.zero;
            Vector3 end = edge.To.Name == "Boss" ? Vector3.right * 5 : Vector3.zero;
            Gizmos.DrawLine(start, end);
        }
        #endif
    }
}
