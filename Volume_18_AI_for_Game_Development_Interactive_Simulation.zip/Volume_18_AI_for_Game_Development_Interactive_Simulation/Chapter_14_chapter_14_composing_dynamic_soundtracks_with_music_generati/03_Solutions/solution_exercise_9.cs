
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.cs
// Description: Solution for Exercise 9
// ==========================================

using UnityEngine;
using UnityEngine.Audio;

[CreateAssetMenu(fileName = "NewAudioProfile", menuName = "Audio/AccessibilityProfile")]
public class AudioAccessibilityProfile : ScriptableObject
{
    [Range(0f, 2f)] public float DialogueBoost = 1.0f;
    [Range(0f, 1f)] public float SFXVolume = 1.0f;
    [Range(0f, 1f)] public float MusicClarity = 1.0f; // 1 = Full High Freq, 0 = Low Pass
    public bool ForceMono = false;
}

public class AccessibilityMixer : MonoBehaviour
{
    public AudioAccessibilityProfile Profile;
    public AudioMixer Mixer; // The main Audio Mixer
    public AudioSource MusicSource;
    public AudioSource DialogueSource;

    // 2. Dynamic Mixing
    public void ApplyProfile()
    {
        // Music Clarity -> Low Pass Filter
        // Map 0-1 clarity to 2000Hz-22000Hz cutoff
        float cutoff = Mathf.Lerp(2000f, 22000f, Profile.MusicClarity);
        Mixer.SetFloat("MusicCutoff", cutoff);

        // 3. Spatial Audio Mapping / Ducking
        // If Dialogue is playing, lower music volume based on DialogueBoost
        if (DialogueSource.isPlaying)
        {
            // Duck music by 50% if dialogue is loud, scaled by boost
            float targetMusicVol = 1.0f - (0.5f * Profile.DialogueBoost);
            // Apply to Mixer or Source directly
            MusicSource.volume = targetMusicVol * Profile.SFXVolume; 
        }
        else
        {
            MusicSource.volume = Profile.SFXVolume;
        }

        // 4. Runtime Adjustment for Dialogue
        DialogueSource.volume = Profile.DialogueBoost;

        // 5. Mono Compatibility
        if (Profile.ForceMono)
        {
            // Check if already mono to avoid overhead
            if (MusicSource.spatialBlend > 0f)
            {
                MusicSource.spatialBlend = 0f; // 2D
                // If using AudioMixer, we might route to a Mono Group
                Debug.Log("Forced Audio to Mono Mode");
            }
        }
    }

    void Update()
    {
        // Listen for changes (in a real app, this would be event-driven)
        if (Profile != null) ApplyProfile();
    }
}
