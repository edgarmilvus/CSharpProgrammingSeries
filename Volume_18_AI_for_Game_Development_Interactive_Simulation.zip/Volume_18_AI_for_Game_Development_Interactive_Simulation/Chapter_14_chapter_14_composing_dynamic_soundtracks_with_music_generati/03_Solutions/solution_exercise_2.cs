
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

public enum RequestState { Idle, Requesting, Cooldown, Error }

[System.Serializable]
public struct MusicGenerationRequest
{
    public int BPM;
    public string Genre;
    public float Intensity;
}

public class MusicRequestQueue : MonoBehaviour
{
    private Queue<MusicGenerationRequest> _requestQueue = new Queue<MusicGenerationRequest>();
    private RequestState _currentState = RequestState.Idle;
    private float _lastRequestTime;
    private const float COOLDOWN_DURATION = 2.0f;
    private const string MOCK_API_URL = "https://example.com/generate-music";

    // Expose state
    public RequestState CurrentState => _currentState;

    public void QueueRequest(MusicGenerationRequest request)
    {
        _requestQueue.Enqueue(request);
        if (_currentState == RequestState.Idle)
        {
            StartCoroutine(ProcessQueue());
        }
    }

    private IEnumerator ProcessQueue()
    {
        while (_requestQueue.Count > 0)
        {
            // 3. Rate Limiting
            float timeSinceLast = Time.time - _lastRequestTime;
            if (timeSinceLast < COOLDOWN_DURATION)
            {
                _currentState = RequestState.Cooldown;
                yield return new WaitForSeconds(COOLDOWN_DURATION - timeSinceLast);
            }

            _currentState = RequestState.Requesting;
            var request = _requestQueue.Dequeue();

            // 2. Async/await Pattern (using Coroutine for Unity WebRequest compatibility)
            yield return StartCoroutine(SendApiRequest(request));
            
            _lastRequestTime = Time.time;
        }

        _currentState = RequestState.Idle;
    }

    private IEnumerator SendApiRequest(MusicGenerationRequest request)
    {
        // Simulate payload
        string json = JsonUtility.ToJson(request);
        byte[] rawPayload = Encoding.UTF8.GetBytes(json);

        using (UnityWebRequest www = new UnityWebRequest(MOCK_API_URL, "POST"))
        {
            www.uploadHandler = new UploadHandlerRaw(rawPayload);
            www.downloadHandler = new DownloadHandlerBuffer();
            www.SetRequestHeader("Content-Type", "application/json");

            yield return www.SendWebRequest();

            // 5. Error Handling & Retry Logic
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"API Error: {www.error}");
                
                // Re-queue logic (simulated retry)
                if (request.BPM > 0) // Simple check to prevent infinite loops in this example
                {
                    // In a real scenario, we'd track retry count per request
                    Debug.LogWarning("Retrying request...");
                    _requestQueue.Enqueue(request); 
                }
                else
                {
                    _currentState = RequestState.Error;
                }
            }
            else
            {
                Debug.Log($"Received Audio Data: {www.downloadHandler.text}");
                // Process audio data here...
            }
        }
    }
}
