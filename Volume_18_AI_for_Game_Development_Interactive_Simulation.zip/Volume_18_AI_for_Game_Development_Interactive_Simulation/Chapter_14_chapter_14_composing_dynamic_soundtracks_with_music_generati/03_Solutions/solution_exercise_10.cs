
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_10.cs
// Description: Solution for Exercise 10
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

[System.Serializable]
public struct PlayerState
{
    public int ID;
    public Vector3 Position;
    public float Health;
    public bool IsInCombat;
}

public class NetworkedMusicAggregator : MonoBehaviour
{
    // 1. Data Aggregation
    private List<PlayerState> _playerStates = new List<PlayerState>();
    
    // 4. Latency Compensation
    private float _smoothedTeamIntensity = 0f;
    private float _intensityVelocity = 0f;
    private const float SMOOTH_TIME = 0.5f;

    // 5. Fallback for Offline
    private bool _isNetworkActive = false;

    // Called by Network Manager when data arrives
    public void ReceivePlayerState(PlayerState state)
    {
        _isNetworkActive = true;
        var existing = _playerStates.FindIndex(p => p.ID == state.ID);
        if (existing >= 0) _playerStates[existing] = state;
        else _playerStates.Add(state);
    }

    void Update()
    {
        if (!_isNetworkActive)
        {
            // 5. Fallback: Use local player state
            // Simulate single player
            return; 
        }

        // 2. Spatial Blending & Aggregation
        float rawIntensity = CalculateTeamMetrics();
        
        // 4. Latency Compensation (Moving Average / SmoothDamp)
        _smoothedTeamIntensity = Mathf.SmoothDamp(_smoothedTeamIntensity, rawIntensity, ref _intensityVelocity, SMOOTH_TIME);

        // Pass to Audio Manager
        // AudioIntensityManager.Instance.UpdateMix(_smoothedTeamIntensity);
    }

    private float CalculateTeamMetrics()
    {
        if (_playerStates.Count == 0) return 0f;

        // A. Aggregate Intensity (Combat/Health)
        float avgHealth = _playerStates.Average(p => p.Health);
        float combatWeight = _playerStates.Count(p => p.IsInCombat) / (float)_playerStates.Count;
        
        // Base intensity: More combat = higher intensity
        float intensity = combatWeight * 1.0f; 

        // B. Team Cohesion (Spatial)
        // Calculate average position
        Vector3 center = Vector3.zero;
        foreach (var p in _playerStates) center += p.Position;
        center /= _playerStates.Count;

        // Calculate average distance from center
        float totalDist = 0;
        foreach (var p in _playerStates) totalDist += Vector3.Distance(p.Position, center);
        float avgDist = totalDist / _playerStates.Count;

        // Logic: High Cohesion (Low Dist) -> Harmonious. Low Cohesion (High Dist) -> Chaotic.
        // We can map this to a "Dissonance" parameter or Stereo Width.
        
        if (avgDist > 20f) 
        {
            // Players are scattered: Increase "Chaos" (e.g., add dissonant layer)
            intensity += 0.2f; 
            Debug.Log("Team Scattered: Adding Chaos Layer");
        }

        return Mathf.Clamp01(intensity);
    }

    // 3. Network Serialization (Mock)
    public byte[] SerializeState(PlayerState state)
    {
        // Simple binary writer simulation
        using (var stream = new System.IO.MemoryStream())
        using (var writer = new System.IO.BinaryWriter(stream))
        {
            writer.Write(state.ID);
            writer.Write(state.Position.x);
            writer.Write(state.Position.y);
            writer.Write(state.Position.z);
            writer.Write(state.Health);
            writer.Write(state.IsInCombat);
            return stream.ToArray();
        }
    }
}
