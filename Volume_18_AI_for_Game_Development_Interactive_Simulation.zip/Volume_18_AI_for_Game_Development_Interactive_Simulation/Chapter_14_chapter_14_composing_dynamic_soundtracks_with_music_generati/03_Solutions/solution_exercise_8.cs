
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_8.cs
// Description: Solution for Exercise 8
// ==========================================

using UnityEngine;
using System.Collections;

public class VerticalRemixer : MonoBehaviour
{
    [System.Serializable]
    public class StemChannel
    {
        public AudioSource CurrentSource;
        public string StemName;
    }

    public List<StemChannel> ActiveStems = new List<StemChannel>();

    // 1. Phase-Locked Switching & 2. Crossfade
    public void SwapStem(string stemName, AudioClip newClip, float crossfadeDuration = 2.0f)
    {
        var channel = ActiveStems.Find(s => s.StemName == stemName);
        if (channel == null) return;

        StartCoroutine(SwapRoutine(channel, newClip, crossfadeDuration));
    }

    private IEnumerator SwapRoutine(StemChannel channel, AudioClip newClip, float duration)
    {
        AudioSource oldSource = channel.CurrentSource;
        
        // Create new Audio Source for the swap
        GameObject newObj = new GameObject($"Swapping_{channel.StemName}");
        newObj.transform.SetParent(transform);
        AudioSource newSource = newObj.AddComponent<AudioSource>();
        
        // 4. State Preservation (Copy Mixer Group)
        newSource.outputAudioMixerGroup = oldSource.outputAudioMixerGroup;

        // 3. Key Matching / Pitch Check (Simulation)
        // In a real scenario, we'd analyze metadata. Here we assume if clips differ in sample rate/pitch.
        if (oldSource.clip != null && newClip != null)
        {
            if (Mathf.Abs(oldSource.pitch - 1.0f) > 0.1f)
            {
                Debug.LogWarning($"Pitch mismatch detected. Applying compensation.");
                newSource.pitch = oldSource.pitch;
            }
        }

        // 1. Phase Locking: Get exact sample position
        // We calculate time based on samples to ensure precision
        int samplesPlayed = (int)(oldSource.timeSamples);
        
        newSource.clip = newClip;
        newSource.timeSamples = samplesPlayed; // Lock phase
        newSource.volume = 0f;
        newSource.Play();

        // 2. Crossfade
        float timer = 0f;
        while (timer < duration)
        {
            timer += Time.deltaTime;
            float t = timer / duration;

            oldSource.volume = 1f - t;
            newSource.volume = t;

            yield return null;
        }

        // Cleanup
        oldSource.Stop();
        oldSource.volume = 1f; // Reset for next use
        channel.CurrentSource = newSource; // Update reference
        
        Destroy(oldSource.gameObject); // Remove old
    }
}
