
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.cs
// Description: Solution for Exercise 7
// ==========================================

using UnityEngine;
using UnityEngine.Events;
using System.Threading.Tasks;

public class AudioAnalyzer : MonoBehaviour
{
    public AudioSource Source; // The music output
    public int SampleSize = 1024; // Power of 2 for FFT
    
    // 3. Peak Detection
    public float KickThreshold = 0.5f; 
    public UnityEvent OnBeat;

    private float[] _samples;
    private float[] _spectrum;
    private float _beatTimer = 0f;
    private bool _isBeatPending = false;

    // 5. Performance Optimization: Throttling
    private const float ANALYSIS_INTERVAL = 0.1f; // 100ms
    private float _lastAnalysisTime;

    void Start()
    {
        _samples = new float[SampleSize];
        _spectrum = new float[SampleSize];
    }

    void Update()
    {
        if (Time.time - _lastAnalysisTime < ANALYSIS_INTERVAL) return;
        _lastAnalysisTime = Time.time;

        // Run heavy analysis on separate thread where possible, 
        // but GetOutputData must run on main thread.
        Source.GetOutputData(_samples, 0);
        
        // Run FFT calculation asynchronously
        Task.Run(() => AnalyzeSpectrum());
    }

    // 1. FFT Analysis & 2. Frequency Band Detection
    private void AnalyzeSpectrum()
    {
        // GetSpectrumData must be called on main thread, so we simulate the calculation
        // or use a main-thread dispatch if using a library. 
        // For this example, we analyze the raw samples (Time Domain) for peaks 
        // or assume we populated _spectrum via GetSpectrumData in a main-thread call.
        
        // To be strictly correct with Unity API, we must call GetSpectrumData in Update.
        // Let's adjust to do the heavy logic in Update but throttled.
        
        // Re-implementation for strict Unity API compliance:
        Source.GetSpectrumData(_spectrum, 0, FFTWindow.BlackmanHarris);

        // Calculate bands
        float lowBand = 0;
        float midBand = 0;
        float highBand = 0;

        // Simple bin division
        for (int i = 0; i < SampleSize; i++)
        {
            if (i < SampleSize / 3) lowBand += _spectrum[i];
            else if (i < (SampleSize * 2) / 3) midBand += _spectrum[i];
            else highBand += _spectrum[i];
        }

        // Normalize
        lowBand /= (SampleSize / 3);

        // 4. Peak Detection (Kick Drum)
        if (lowBand > KickThreshold && _beatTimer <= 0)
        {
            _beatTimer = 0.5f; // Cooldown
            // Trigger on main thread
            UnityMainThreadDispatcher.Instance().Enqueue(() => OnBeat?.Invoke());
        }

        if (_beatTimer > 0) _beatTimer -= ANALYSIS_INTERVAL;
    }
}

// Helper class to dispatch events back to Main Thread if running async
public class UnityMainThreadDispatcher : MonoBehaviour
{
    private static UnityMainThreadDispatcher _instance;
    private readonly System.Collections.Generic.Queue<System.Action> _executionQueue = new System.Collections.Generic.Queue<System.Action>();

    public static UnityMainThreadDispatcher Instance()
    {
        if (_instance == null)
        {
            var obj = new GameObject("MainThreadDispatcher");
            _instance = obj.AddComponent<UnityMainThreadDispatcher>();
            DontDestroyOnLoad(obj);
        }
        return _instance;
    }

    public void Enqueue(System.Action action)
    {
        lock (_executionQueue)
        {
            _executionQueue.Enqueue(action);
        }
    }

    void Update()
    {
        lock (_executionQueue)
        {
            while (_executionQueue.Count > 0)
            {
                _executionQueue.Dequeue().Invoke();
            }
        }
    }
}
