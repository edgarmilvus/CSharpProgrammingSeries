
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using System.Collections;

public class DynamicMusicConductor : MonoBehaviour
{
    public AudioSource MainLoopSource;
    public AudioClip ResolutionClip; // Outro for peace
    public AudioClip[] StingerClips; // Random dramatic hits

    private bool _isInterrupted = false;
    private Coroutine _activeRoutine;
    private float _savedLoopTime = 0f;

    // 1. Stinger Injection
    public void PlayStinger()
    {
        if (_isInterrupted) return; // Don't stack interruptions

        var stinger = StingerClips[Random.Range(0, StingerClips.Length)];
        if (stinger == null) return;

        // Start the interruption routine
        if (_activeRoutine != null) StopCoroutine(_activeRoutine);
        _activeRoutine = StartCoroutine(StingerRoutine(stinger));
    }

    private IEnumerator StingerRoutine(AudioClip stinger)
    {
        _isInterrupted = true;
        
        // Save current loop position
        _savedLoopTime = MainLoopSource.time;
        
        // Play stinger
        MainLoopSource.PlayOneShot(stinger);
        
        // Wait for stinger duration
        yield return new WaitForSeconds(stinger.length);

        // Resume loop exactly where it left off
        MainLoopSource.time = _savedLoopTime;
        MainLoopSource.Play(); // Ensure it's playing
        _isInterrupted = false;
    }

    // 2. Harmonic Resolution
    public void RequestStateChange(bool isPeaceful)
    {
        if (_isInterrupted) 
        {
            // 3. Thread Safety / Race Condition Handling
            // If a resolution is already playing, ignore the new request or queue it.
            // Here we simply ignore to prevent chaos.
            Debug.Log("System busy resolving. Request ignored.");
            return;
        }

        if (isPeaceful)
        {
            // Instant switch requested, but we need resolution
            _activeRoutine = StartCoroutine(PlayResolutionAndSwitch());
        }
        else
        {
            // Switch immediately to combat
            MainLoopSource.clip = null; // Stop current
            // Logic to start combat loop...
            Debug.Log("Switching to Combat Loop");
        }
    }

    private IEnumerator PlayResolutionAndSwitch()
    {
        _isInterrupted = true;
        
        // Stop main loop
        MainLoopSource.Stop();
        
        // Play resolution clip
        MainLoopSource.PlayOneShot(ResolutionClip);
        
        // Wait for resolution to finish
        yield return new WaitForSeconds(ResolutionClip.length);

        // Now switch to Peace stems
        Debug.Log("Switched to Peace Loop (After Resolution)");
        _isInterrupted = false;
    }

    // 4. Visualization (Simplified)
    void OnDrawGizmos()
    {
        if (MainLoopSource == null) return;
        Gizmos.color = _isInterrupted ? Color.red : Color.green;
        Gizmos.DrawWireSphere(transform.position, 1f);
        
        // Visualize queue status in Editor
        #if UNITY_EDITOR
        UnityEditor.Handles.Label(transform.position + Vector3.up, 
            _isInterrupted ? "Status: Interrupted" : "Status: Playing Loop");
        #endif
    }
}
