
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

using UnityEngine;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public static class ProceduralAudioBridge
{
    // 1. JS Interop Wrapper
    // DllImport is ignored if not compiling for WebGL, preventing errors in Editor
    [DllImport("__Internal")]
    private static extern void GenerateSynthTone(float frequency, float duration, string waveformType);

    [DllImport("__Internal")]
    private static extern float[] GetSynthData(); // Hypothetical JS return

    public static void RequestSynthTone(float freq, float duration, string wave)
    {
        #if UNITY_WEBGL && !UNITY_EDITOR
        GenerateSynthTone(freq, duration, wave);
        #else
        Debug.Log($"[WebGL Mock] Requested {wave} tone at {freq}Hz");
        #endif
    }
}

public class AudioSynthesisManager : MonoBehaviour
{
    // 4. Object Pooling
    private Queue<AudioSource> _audioClipPool = new Queue<AudioSource>();
    private const int POOL_SIZE = 5;

    void Start()
    {
        // Pre-populate pool
        for (int i = 0; i < POOL_SIZE; i++)
        {
            CreatePooledSource();
        }
    }

    private AudioSource CreatePooledSource()
    {
        var go = new GameObject("PooledSynth");
        go.transform.SetParent(transform);
        var source = go.AddComponent<AudioSource>();
        _audioClipPool.Enqueue(source);
        return source;
    }

    // 3. Dynamic Parameter Mapping
    public void PlaySoundForVelocity(float velocity)
    {
        // Map velocity (0-20) to Frequency (200-800Hz)
        float freq = Mathf.Lerp(200, 800, velocity / 20f);
        
        #if UNITY_WEBGL && !UNITY_EDITOR
        // Real JS call
        ProceduralAudioBridge.RequestSynthTone(freq, 0.5f, "sawtooth");
        #else
        // 5. Fallback for Editor
        PlayFallbackNoise(freq);
        #endif
    }

    // Fallback: Simple noise burst using Unity Audio
    private void PlayFallbackNoise(float freq)
    {
        if (_audioClipPool.Count == 0) CreatePooledSource();
        
        var source = _audioClipPool.Dequeue();
        
        // Generate a simple noise clip at runtime (expensive, but fine for fallback/editor)
        AudioClip clip = GenerateNoiseClip(1.0f); 
        source.clip = clip;
        source.pitch = freq / 440f; // Pitch shift to simulate frequency
        source.Play();
        
        // Return to pool after play
        StartCoroutine(ReturnToPool(source, 1.0f));
    }

    private IEnumerator ReturnToPool(AudioSource source, float delay)
    {
        yield return new WaitForSeconds(delay);
        _audioClipPool.Enqueue(source);
    }

    // 2. AudioClip Generation (Simulated)
    private AudioClip GenerateNoiseClip(float length)
    {
        int sampleRate = 44100;
        int samples = Mathf.FloorToInt(sampleRate * length);
        float[] data = new float[samples];
        for (int i = 0; i < samples; i++)
        {
            data[i] = Random.Range(-1f, 1f);
        }
        return AudioClip.Create("GeneratedNoise", samples, 1, sampleRate, false);
    }
    
    // Method to be called by JS Bridge (via Application.ExternalCall or similar in real scenario)
    public void OnJsDataReceived(float[] samples)
    {
        // Create actual clip from JS data
        AudioClip clip = AudioClip.Create("SynthTone", samples.Length, 1, 44100, false);
        clip.SetData(samples, 0);
        
        // Play immediately or pool
        var source = gameObject.AddComponent<AudioSource>();
        source.PlayOneShot(clip);
    }
}
