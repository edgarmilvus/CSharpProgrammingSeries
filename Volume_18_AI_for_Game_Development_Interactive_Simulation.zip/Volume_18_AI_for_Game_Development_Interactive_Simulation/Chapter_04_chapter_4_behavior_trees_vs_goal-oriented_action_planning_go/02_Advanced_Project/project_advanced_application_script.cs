
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

namespace GOAPSimulation
{
    // ---------------------------------------------------------
    // 1. DATA MODELS & ENUMS
    // ---------------------------------------------------------

    // Represents the atomic state of the world for our agent.
    // In a real Unity project, this would be a ScriptableObject or a struct.
    public enum WorldState
    {
        HasAxe,
        HasWood,
        IsAtTree,
        IsAtWorkshop,
        TreeChopped,
        WoodInStorage,
        HasTool
    }

    // Represents possible actions an agent can perform.
    public enum ActionType
    {
        MoveToTree,
        ChopTree,
        MoveToWorkshop,
        CraftTool,
        StoreWood
    }

    // ---------------------------------------------------------
    // 2. GOAP CORE CLASSES
    // ---------------------------------------------------------

    /// <summary>
    /// Represents a node in the planning graph. 
    /// Contains the current state of the world and the path taken to get there.
    /// </summary>
    public class PlanNode
    {
        public Dictionary<WorldState, bool> State { get; set; }
        public ActionType? Action { get; set; } // The action that led to this state
        public PlanNode Parent { get; set; }    // For backtracking the path
        public int Cost { get; set; }           // g-score in A* terms

        public PlanNode(Dictionary<WorldState, bool> state, ActionType? action, PlanNode parent, int cost)
        {
            State = new Dictionary<WorldState, bool>(state);
            Action = action;
            Parent = parent;
            Cost = cost;
        }
    }

    /// <summary>
    /// Defines an action an agent can take. 
    /// Contains Preconditions (must be true to execute) and Effects (changes in world state).
    /// </summary>
    public class ActionDefinition
    {
        public ActionType Type { get; set; }
        public Dictionary<WorldState, bool> Preconditions { get; set; }
        public Dictionary<WorldState, bool> Effects { get; set; }
        public int BaseCost { get; set; }

        public ActionDefinition(ActionType type, int cost)
        {
            Type = type;
            BaseCost = cost;
            Preconditions = new Dictionary<WorldState, bool>();
            Effects = new Dictionary<WorldState, bool>();
        }

        public ActionDefinition AddPrecondition(WorldState key, bool value)
        {
            Preconditions[key] = value;
            return this;
        }

        public ActionDefinition AddEffect(WorldState key, bool value)
        {
            Effects[key] = value;
            return this;
        }

        // Checks if the action can be performed in the given world state
        public bool CanExecute(Dictionary<WorldState, bool> worldState)
        {
            foreach (var pre in Preconditions)
            {
                if (!worldState.ContainsKey(pre.Key) || worldState[pre.Key] != pre.Value)
                {
                    return false;
                }
            }
            return true;
        }

        // Returns the new world state after executing this action
        public Dictionary<WorldState, bool> ApplyEffects(Dictionary<WorldState, bool> worldState)
        {
            var newState = new Dictionary<WorldState, bool>(worldState);
            foreach (var eff in Effects)
            {
                newState[eff.Key] = eff.Value;
            }
            return newState;
        }
    }

    /// <summary>
    /// The Planner class. Uses a simplified A* search to find a sequence of actions.
    /// </summary>
    public class GOAPPlanner
    {
        private List<ActionDefinition> _availableActions;

        public GOAPPlanner()
        {
            _availableActions = new List<ActionDefinition>();
            InitializeActions();
        }

        // Define the logic for our specific scenario (Woodcutter)
        private void InitializeActions()
        {
            // Action: Move to Tree
            _availableActions.Add(new ActionDefinition(ActionType.MoveToTree, 1)
                .AddPrecondition(WorldState.HasTool, true) // Need a tool to chop
                .AddEffect(WorldState.IsAtTree, true));

            // Action: Chop Tree
            _availableActions.Add(new ActionDefinition(ActionType.ChopTree, 3)
                .AddPrecondition(WorldState.IsAtTree, true)
                .AddPrecondition(WorldState.HasTool, true)
                .AddEffect(WorldState.TreeChopped, true)
                .AddEffect(WorldState.HasWood, true));

            // Action: Move to Workshop
            _availableActions.Add(new ActionDefinition(ActionType.MoveToWorkshop, 2)
                .AddEffect(WorldState.IsAtWorkshop, true));

            // Action: Craft Tool (if broken/missing)
            _availableActions.Add(new ActionDefinition(ActionType.CraftTool, 5)
                .AddPrecondition(WorldState.IsAtWorkshop, true)
                .AddEffect(WorldState.HasTool, true));

            // Action: Store Wood
            _availableActions.Add(new ActionDefinition(ActionType.StoreWood, 1)
                .AddPrecondition(WorldState.HasWood, true)
                .AddEffect(WorldState.WoodInStorage, true)
                .AddEffect(WorldState.HasWood, false)); // Consumes the wood in hand
        }

        /// <summary>
        /// Finds a plan (sequence of actions) to reach the goal state.
        /// </summary>
        /// <param name="startState">Current world state</param>
        /// <param name="goalState">Desired world state</param>
        /// <returns>List of actions to perform, or null if no plan found</returns>
        public List<ActionType> Plan(Dictionary<WorldState, bool> startState, Dictionary<WorldState, bool> goalState)
        {
            // Open list for A* (nodes to explore)
            List<PlanNode> openList = new List<PlanNode>();
            
            // Closed list (visited nodes) to prevent cycles
            List<Dictionary<WorldState, bool>> closedList = new List<Dictionary<WorldState, bool>>();

            // Initialize with start state
            openList.Add(new PlanNode(startState, null, null, 0));

            while (openList.Count > 0)
            {
                // Sort by Cost (g-score) - simple priority queue simulation
                openList.Sort((a, b) => a.Cost.CompareTo(b.Cost));
                PlanNode current = openList[0];
                openList.RemoveAt(0);

                // Check if we reached the goal
                if (IsGoalMet(current.State, goalState))
                {
                    return ReconstructPath(current);
                }

                closedList.Add(current.State);

                // Expand neighbors (valid actions)
                foreach (var action in _availableActions)
                {
                    if (action.CanExecute(current.State))
                    {
                        Dictionary<WorldState, bool> newState = action.ApplyEffects(current.State);

                        // Skip if already visited
                        if (IsStateInList(newState, closedList)) continue;

                        int newCost = current.Cost + action.BaseCost;
                        PlanNode newNode = new PlanNode(newState, action.Type, current, newCost);

                        // Add to open list if not already there with a lower cost
                        if (!IsStateInListWithLowerCost(newState, newCost, openList))
                        {
                            openList.Add(newNode);
                        }
                    }
                }
            }

            return null; // No plan found
        }

        private bool IsGoalMet(Dictionary<WorldState, bool> current, Dictionary<WorldState, bool> goal)
        {
            foreach (var g in goal)
            {
                if (!current.ContainsKey(g.Key) || current[g.Key] != g.Value)
                    return false;
            }
            return true;
        }

        private List<ActionType> ReconstructPath(PlanNode node)
        {
            List<ActionType> path = new List<ActionType>();
            while (node.Parent != null)
            {
                path.Add(node.Action.Value);
                node = node.Parent;
            }
            path.Reverse();
            return path;
        }

        private bool IsStateInList(Dictionary<WorldState, bool> state, List<Dictionary<WorldState, bool>> list)
        {
            foreach (var s in list)
            {
                if (StatesEqual(state, s)) return true;
            }
            return false;
        }

        private bool IsStateInListWithLowerCost(Dictionary<WorldState, bool> state, int cost, List<PlanNode> list)
        {
            foreach (var node in list)
            {
                if (StatesEqual(state, node.State))
                {
                    if (node.Cost <= cost) return true; // Found a better/cheaper way
                }
            }
            return false;
        }

        private bool StatesEqual(Dictionary<WorldState, bool> a, Dictionary<WorldState, bool> b)
        {
            if (a.Count != b.Count) return false;
            foreach (var kvp in a)
            {
                if (!b.ContainsKey(kvp.Key) || b[kvp.Key] != kvp.Value) return false;
            }
            return true;
        }
    }

    // ---------------------------------------------------------
    // 3. BEHAVIOR TREE CORE CLASSES
    // ---------------------------------------------------------

    /// <summary>
    /// Base class for all BT nodes.
    /// </summary>
    public abstract class BTNode
    {
        public abstract BTNodeState Evaluate(AgentContext context);
    }

    public enum BTNodeState { Success, Failure, Running }

    /// <summary>
    /// A Sequence node executes children in order. 
    /// If any child fails, the sequence fails immediately.
    /// </summary>
    public class SequenceNode : BTNode
    {
        private BTNode[] _children;

        public SequenceNode(params BTNode[] children)
        {
            _children = children;
        }

        public override BTNodeState Evaluate(AgentContext context)
        {
            foreach (var child in _children)
            {
                var result = child.Evaluate(context);
                if (result != BTNodeState.Success)
                {
                    return result; // Return Failure or Running immediately
                }
            }
            return BTNodeState.Success;
        }
    }

    /// <summary>
    /// A Selector node executes children in order until one succeeds.
    /// If all fail, the selector fails.
    /// </summary>
    public class SelectorNode : BTNode
    {
        private BTNode[] _children;

        public SelectorNode(params BTNode[] children)
        {
            _children = children;
        }

        public override BTNodeState Evaluate(AgentContext context)
        {
            foreach (var child in _children)
            {
                var result = child.Evaluate(context);
                if (result != BTNodeState.Failure)
                {
                    return result; // Return Success or Running
                }
            }
            return BTNodeState.Failure;
        }
    }

    /// <summary>
    /// A Leaf node that performs an actual action (e.g., "Chop").
    /// </summary>
    public class ActionNode : BTNode
    {
        private ActionType _actionType;
        private string _description;

        public ActionNode(ActionType actionType, string description)
        {
            _actionType = actionType;
            _description = description;
        }

        public override BTNodeState Evaluate(AgentContext context)
        {
            // In a real game, this would move the agent, play animation, etc.
            // Here, we simulate execution time.
            
            if (!context.IsActionInProgress)
            {
                Console.WriteLine($"[BT] Starting Action: {_description}");
                context.CurrentAction = _actionType;
                context.IsActionInProgress = true;
                context.ActionTimer = 0; // Reset timer
                return BTNodeState.Running;
            }
            else
            {
                // Simulate progress
                context.ActionTimer++;
                if (context.ActionTimer >= 2) // Arbitrary time units
                {
                    Console.WriteLine($"[BT] Completed Action: {_description}");
                    context.IsActionInProgress = false;
                    
                    // Apply effect to world state immediately after action
                    ApplyWorldStateChange(context);
                    
                    return BTNodeState.Success;
                }
                else
                {
                    Console.WriteLine($"[BT] ...Running {_description} ({context.ActionTimer}/2)");
                    return BTNodeState.Running;
                }
            }
        }

        private void ApplyWorldStateChange(AgentContext context)
        {
            // Hardcoded effects based on action type for this simulation
            switch (_actionType)
            {
                case ActionType.MoveToTree:
                    context.WorldState[WorldState.IsAtTree] = true;
                    context.WorldState[WorldState.IsAtWorkshop] = false;
                    break;
                case ActionType.ChopTree:
                    context.WorldState[WorldState.HasWood] = true;
                    context.WorldState[WorldState.TreeChopped] = true;
                    break;
                case ActionType.MoveToWorkshop:
                    context.WorldState[WorldState.IsAtWorkshop] = true;
                    context.WorldState[WorldState.IsAtTree] = false;
                    break;
                case ActionType.CraftTool:
                    context.WorldState[WorldState.HasTool] = true;
                    break;
                case ActionType.StoreWood:
                    context.WorldState[WorldState.HasWood] = false;
                    context.WorldState[WorldState.WoodInStorage] = true;
                    break;
            }
        }
    }

    /// <summary>
    /// A Leaf node that checks a condition in the world state.
    /// </summary>
    public class ConditionNode : BTNode
    {
        private WorldState _key;
        private bool _requiredValue;

        public ConditionNode(WorldState key, bool requiredValue)
        {
            _key = key;
            _requiredValue = requiredValue;
        }

        public override BTNodeState Evaluate(AgentContext context)
        {
            if (context.WorldState.ContainsKey(_key) && context.WorldState[_key] == _requiredValue)
            {
                return BTNodeState.Success;
            }
            return BTNodeState.Failure;
        }
    }

    // ---------------------------------------------------------
    // 4. CONTEXT & SIMULATION SETUP
    // ---------------------------------------------------------

    /// <summary>
    /// Holds the agent's current knowledge and execution state.
    /// </summary>
    public class AgentContext
    {
        public Dictionary<WorldState, bool> WorldState { get; set; }
        public List<ActionType> CurrentPlan { get; set; }
        public int PlanStepIndex { get; set; }
        
        // Execution state for Action Nodes
        public bool IsActionInProgress { get; set; }
        public ActionType CurrentAction { get; set; }
        public int ActionTimer { get; set; }

        public AgentContext()
        {
            WorldState = new Dictionary<WorldState, bool>();
            CurrentPlan = new List<ActionType>();
            PlanStepIndex = 0;
        }
    }

    // ---------------------------------------------------------
    // 5. MAIN PROGRAM (HYBRID ARCHITECTURE)
    // ---------------------------------------------------------

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== GOAP & BT Hybrid Simulation: Woodcutter Agent ===\n");

            // 1. Initialize Agent Context (Start State)
            // The agent is at the workshop, has a tool, but needs wood.
            var context = new AgentContext();
            context.WorldState[WorldState.IsAtWorkshop] = true;
            context.WorldState[WorldState.HasTool] = true;
            context.WorldState[WorldState.HasWood] = false;
            context.WorldState[WorldState.WoodInStorage] = false;
            context.WorldState[WorldState.TreeChopped] = false;
            context.WorldState[WorldState.IsAtTree] = false;

            // 2. Define the Goal
            // Goal: Have wood in storage.
            var goalState = new Dictionary<WorldState, bool>
            {
                { WorldState.WoodInStorage, true }
            };

            // 3. Initialize GOAP Planner
            var planner = new GOAPPlanner();

            // 4. Generate Plan using GOAP
            Console.WriteLine("--- Phase 1: Planning (GOAP) ---");
            var plan = planner.Plan(context.WorldState, goalState);

            if (plan == null)
            {
                Console.WriteLine("GOAP Planner: No plan found to achieve goal.");
                return;
            }

            Console.WriteLine("GOAP Planner: Plan generated successfully.");
            Console.WriteLine("Plan Sequence:");
            foreach (var step in plan)
            {
                Console.WriteLine($" -> {step}");
            }
            Console.WriteLine();

            // Assign plan to context for the BT to execute
            context.CurrentPlan = plan;
            context.PlanStepIndex = 0;

            // 5. Build Behavior Tree
            // The BT is not hardcoded with logic. It dynamically reads the 'CurrentPlan' from the context.
            // This is a "Dynamic BT" that acts as an executor for the GOAP plan.
            Console.WriteLine("--- Phase 2: Execution (Behavior Tree) ---");
            
            // We construct a dynamic sequence node based on the plan.
            // In a real engine, this would be done via a "BT Service" that updates the tree structure.
            BTNode root = BuildDynamicBTExecutor(context.CurrentPlan);

            // 6. Run Simulation Loop
            int maxTicks = 20; // Safety break
            int tick = 0;

            while (tick < maxTicks)
            {
                Console.WriteLine($"\n--- Tick {tick + 1} ---");
                
                // Evaluate the BT
                BTNodeState result = root.Evaluate(context);

                if (result == BTNodeState.Success)
                {
                    Console.WriteLine("\n[SUCCESS] Goal Achieved: Wood is in storage.");
                    break;
                }
                else if (result == BTNodeState.Failure)
                {
                    Console.WriteLine("\n[FAILURE] The BT encountered an error or a condition failed.");
                    break;
                }
                // If Running, the loop continues to simulate the next frame/tick

                tick++;
            }

            if (tick >= maxTicks)
            {
                Console.WriteLine("\n[TIMEOUT] Simulation stopped due to max ticks.");
            }
        }

        /// <summary>
        /// Helper to convert a list of Actions into a Behavior Tree Sequence.
        /// </summary>
        static BTNode BuildDynamicBTExecutor(List<ActionType> plan)
        {
            // We will build a Sequence node containing nodes for each action in the plan.
            // Each action in the plan will be wrapped in a Sequence:
            // 1. Check if we are at the correct location/state (Condition)
            // 2. Perform the action (Action Node)
            
            List<BTNode> sequenceNodes = new List<BTNode>();

            foreach (var action in plan)
            {
                // Create a sub-sequence for this specific action: [Check -> Do]
                // Note: In a complex BT, we might have move logic that handles pathfinding.
                // Here we abstract "Move" as a single action node for simplicity.
                
                BTNode actionNode = null;

                // Map ActionTypes to specific BT Nodes
                switch (action)
                {
                    case ActionType.MoveToTree:
                        actionNode = new SequenceNode(
                            new ConditionNode(WorldState.HasTool, true), // Pre-check
                            new ActionNode(ActionType.MoveToTree, "Walking to Tree")
                        );
                        break;
                    case ActionType.ChopTree:
                        actionNode = new SequenceNode(
                            new ConditionNode(WorldState.IsAtTree, true),
                            new ActionNode(ActionType.ChopTree, "Chopping Tree")
                        );
                        break;
                    case ActionType.MoveToWorkshop:
                        actionNode = new SequenceNode(
                            new ActionNode(ActionType.MoveToWorkshop, "Walking to Workshop")
                        );
                        break;
                    case ActionType.CraftTool:
                        actionNode = new SequenceNode(
                            new ConditionNode(WorldState.IsAtWorkshop, true),
                            new ActionNode(ActionType.CraftTool, "Crafting Tool")
                        );
                        break;
                    case ActionType.StoreWood:
                        actionNode = new SequenceNode(
                            new ConditionNode(WorldState.HasWood, true),
                            new ActionNode(ActionType.StoreWood, "Storing Wood")
                        );
                        break;
                }

                if (actionNode != null)
                {
                    sequenceNodes.Add(actionNode);
                }
            }

            // The root of the BT is a sequence of all planned actions
            return new SequenceNode(sequenceNodes.ToArray());
        }
    }
}
