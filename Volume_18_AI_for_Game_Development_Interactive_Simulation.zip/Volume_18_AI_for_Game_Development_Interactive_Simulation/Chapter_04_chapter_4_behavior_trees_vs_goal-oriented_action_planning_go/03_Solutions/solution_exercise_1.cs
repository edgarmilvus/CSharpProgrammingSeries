
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine; // Assumed Unity context for Vector3

// 1. Core Enums and Base Node
public enum NodeState { Running, Success, Failure }

public abstract class Node
{
    public abstract NodeState Evaluate();
}

// 2. Blackboard (Shared State)
public record Blackboard
{
    public List<Vector3> PatrolPoints { get; init; } = new();
    public bool IsEnemyDetected { get; set; }
    public Vector3 LastKnownEnemyPosition { get; set; }
    public int CurrentPatrolIndex { get; set; }
}

// 3. Composite Nodes
public class Selector : Node
{
    private readonly List<Node> _children;
    public Selector(List<Node> children) => _children = children;

    public override NodeState Evaluate()
    {
        foreach (var child in _children)
        {
            var childState = child.Evaluate();
            if (childState != NodeState.Failure) return childState;
        }
        return NodeState.Failure;
    }
}

public class Sequence : Node
{
    private readonly List<Node> _children;
    public Sequence(List<Node> children) => _children = children;

    public override NodeState Evaluate()
    {
        foreach (var child in _children)
        {
            var childState = child.Evaluate();
            if (childState != NodeState.Success) return childState;
        }
        return NodeState.Success;
    }
}

// 4. Decorator/Condition Node
public class Conditional : Node
{
    private readonly Func<bool> _condition;
    public Conditional(Func<bool> condition) => _condition = condition;

    public override NodeState Evaluate() => _condition() ? NodeState.Success : NodeState.Failure;
}

// 5. Action Node (Async capable)
public class ActionNode : Node
{
    private readonly Func<Task<NodeState>> _action;
    public ActionNode(Func<Task<NodeState>> action) => _action = action;

    public override NodeState Evaluate()
    {
        // Note: In a real Unity Update loop, we can't await directly.
        // We would typically use a 'Tick' system or a custom 'AsyncNode' wrapper.
        // For this exercise, we assume the tree is ticked by an async context 
        // or we return Running and handle the task externally.
        // Here, we simulate the execution.
        var task = _action();
        task.Wait(); // Blocking for simplicity in this specific exercise structure
        return task.Result;
    }
}

// 6. Service Node (Async Polling)
public class ServiceNode : Node
{
    private readonly Blackboard _blackboard;
    private readonly float _interval;
    private DateTime _lastRun;
    private readonly Func<Vector3> _pollingLogic; // Simulates Physics.OverlapSphere

    public ServiceNode(Blackboard blackboard, float interval, Func<Vector3> pollingLogic)
    {
        _blackboard = blackboard;
        _interval = interval;
        _pollingLogic = pollingLogic;
        _lastRun = DateTime.MinValue;
    }

    public override NodeState Evaluate()
    {
        // Check if enough time has passed to poll
        if ((DateTime.Now - _lastRun).TotalSeconds >= _interval)
        {
            var detectedPos = _pollingLogic();
            _blackboard.IsEnemyDetected = detectedPos != Vector3.zero;
            if (_blackboard.IsEnemyDetected) _blackboard.LastKnownEnemyPosition = detectedPos;
            _lastRun = DateTime.Now;
        }
        
        // Service nodes usually run continuously and never return Failure
        return NodeState.Success; 
    }
}

// 7. Concrete Implementation
public class DroneAgent : MonoBehaviour
{
    private Blackboard _blackboard;
    private Node _rootNode;
    private CancellationTokenSource _cts;

    private void Start()
    {
        _blackboard = new Blackboard
        {
            PatrolPoints = new List<Vector3> { new(0, 0, 0), new(10, 0, 10), new(20, 0, 0) }
        };

        // Constructing the Tree
        // Branch 1: Combat
        var combatBranch = new Sequence(new List<Node>
        {
            new Conditional(() => _blackboard.IsEnemyDetected),
            new ActionNode(async () => 
            {
                Debug.Log($"Chasing target at {_blackboard.LastKnownEnemyPosition}");
                await Task.Delay(1000); // Simulate movement time
                return NodeState.Success;
            }),
            new ActionNode(async () => 
            {
                Debug.Log("Attacking!");
                await Task.Delay(500);
                return NodeState.Success;
            })
        });

        // Branch 2: Patrol
        var patrolBranch = new Sequence(new List<Node>
        {
            new ActionNode(async () => 
            {
                if (_blackboard.CurrentPatrolIndex >= _blackboard.PatrolPoints.Count) 
                    _blackboard.CurrentPatrolIndex = 0;
                
                var target = _blackboard.PatrolPoints[_blackboard.CurrentPatrolIndex];
                Debug.Log($"Moving to waypoint {_blackboard.CurrentPatrolIndex}");
                await Task.Delay(1000); // Simulate movement
                return NodeState.Success;
            }),
            new ActionNode(async () => 
            {
                Debug.Log("Waiting 3 seconds...");
                // Using async/await inside the node logic
                await Task.Delay(3000); 
                _blackboard.CurrentPatrolIndex++;
                return NodeState.Success;
            })
        });

        // Root: Selector (Prioritizes Combat over Patrol)
        _rootNode = new Selector(new List<Node> { combatBranch, patrolBranch });

        // Start the Service Loop
        StartServiceLoop();
    }

    private void StartServiceLoop()
    {
        _cts = new CancellationTokenSource();
        Task.Run(async () =>
        {
            // Service Node Logic running in background
            while (!_cts.Token.IsCancellationRequested)
            {
                // Polling logic (e.g., Physics check)
                // Simulating a random detection
                Vector3 detected = UnityEngine.Random.Range(0, 10) == 0 ? Vector3.one : Vector3.zero;
                
                if (detected != Vector3.zero)
                {
                    _blackboard.IsEnemyDetected = true;
                    _blackboard.LastKnownEnemyPosition = detected;
                }
                else if (!_blackboard.IsEnemyDetected) // Keep state if already true until resolved
                {
                    _blackboard.IsEnemyDetected = false;
                }

                await Task.Delay(500); // Polling frequency
            }
        }, _cts.Token);
    }

    private void Update()
    {
        // Tick the Behavior Tree
        _rootNode.Evaluate();
    }

    private void OnDestroy()
    {
        _cts?.Cancel();
    }
}
