
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

// 1. Domain Models
public class LLMResponse
{
    public string GoalName { get; set; }
    public Dictionary<string, bool> TargetState { get; set; }
    public Dictionary<string, float> CostModifiers { get; set; } // Key: ActionName, Value: Multiplier
}

public class GoalGenerator
{
    // Simulated LLM API delay
    private const int API_DELAY_MS = 200;

    public async Task<GoapGoal> GenerateGoalAsync(string contextPrompt, List<GoapAction> availableActions)
    {
        Console.WriteLine($"[LLM] Sending Prompt:\n{contextPrompt}");
        
        // Simulate network latency
        await Task.Delay(API_DELAY_MS);

        // SIMULATION LOGIC (Mimicking LLM behavior based on prompt content)
        LLMResponse simulatedResponse = SimulateLLMBrain(contextPrompt);

        // Deserialize/Map to GoapGoal
        var goal = new GoapGoal
        {
            Name = simulatedResponse.GoalName,
            TargetState = new WorldState { States = simulatedResponse.TargetState }
        };

        // Apply Personality Cost Modifiers to the global action list (or return them to be applied)
        if (simulatedResponse.CostModifiers != null)
        {
            foreach (var action in availableActions)
            {
                if (simulatedResponse.CostModifiers.TryGetValue(action.Name, out float multiplier))
                {
                    action.Cost *= multiplier;
                    Console.WriteLine($"[Personality] Action '{action.Name}' cost modified by {multiplier}. New Cost: {action.Cost}");
                }
            }
        }

        return goal;
    }

    private LLMResponse SimulateLLMBrain(string prompt)
    {
        // Simple rule-based simulation of an LLM
        if (prompt.Contains("Hungry: True") && prompt.Contains("Greedy"))
        {
            return new LLMResponse
            {
                GoalName = "Hoard Food",
                TargetState = new Dictionary<string, bool> { { "HasFood", true }, { "IsFull", true } },
                CostModifiers = new Dictionary<string, float> { { "BuyFood", 0.5f }, { "StealFood", 0.8f } } // Greedy likes buying cheap
            };
        }
        else if (prompt.Contains("Hungry: True"))
        {
            return new LLMResponse
            {
                GoalName = "Eat Meal",
                TargetState = new Dictionary<string, bool> { { "IsFull", true } },
                CostModifiers = new Dictionary<string, float> { { "Cook", 1.0f }, { "BuyFood", 1.0f } }
            };
        }
        else if (prompt.Contains("UnderAttack: True") && prompt.Contains("Cowardly"))
        {
            return new LLMResponse
            {
                GoalName = "Survive",
                TargetState = new Dictionary<string, bool> { { "IsSafe", true } },
                CostModifiers = new Dictionary<string, float> { { "Attack", 5.0f }, { "RunAway", 0.2f } }
            };
        }

        return new LLMResponse
        {
            GoalName = "Wait",
            TargetState = new Dictionary<string, bool> { { "TimePassed", true } },
            CostModifiers = new Dictionary<string, float>()
        };
    }
}

// Integration Example
public class TownspersonAgent
{
    private readonly GoalGenerator _generator = new();
    private List<GoapAction> _actions;
    private string _personality = "Greedy"; // Can change dynamically

    public async Task ReevaluateGoal(WorldState currentState)
    {
        // Construct Context Prompt
        string context = $"Personality: {_personality}\nCurrent State: ";
        foreach (var state in currentState.States)
        {
            context += $"{state.Key}: {state.Value}, ";
        }
        
        // Generate Goal
        GoapGoal newGoal = await _generator.GenerateGoalAsync(context, _actions);
        
        // Now we would pass this goal to the GoapPlanner (Exercise 2)
        // var planner = new GoapPlanner();
        // var plan = planner.Plan(currentState, _actions, newGoal);
        Console.WriteLine($"[Agent] New Goal Generated: {newGoal.Name}");
    }
}
