
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

// 1. Priority Enum
public enum Priority { Low, Medium, High, Critical }

// 2. Event System
public static class GlobalEvents
{
    public static event Action<string, Priority> OnEmergency;
    
    public static void TriggerEmergency(string type, Priority priority)
    {
        OnEmergency?.Invoke(type, priority);
    }
}

// 3. Interrupt Controller
public class InterruptController
{
    private readonly HybridAgent _agent;
    private Priority _currentPriority = Priority.Low;
    private CancellationTokenSource _planningCts;

    public InterruptController(HybridAgent agent)
    {
        _agent = agent;
        GlobalEvents.OnEmergency += HandleEmergency;
    }

    private async void HandleEmergency(string type, Priority incomingPriority)
    {
        if (incomingPriority < _currentPriority) return; // Lower priority ignored

        Console.WriteLine($"[Interrupt] Emergency detected: {type} (Priority: {incomingPriority})");

        // 1. Cancel any ongoing planning
        _planningCts?.Cancel();
        _planningCts = new CancellationTokenSource();

        // 2. Clear current plan
        _agent.CurrentPlan?.Clear();
        _agent.NeedsReplan = true;
        _currentPriority = incomingPriority;

        // 3. Generate Emergency Goal via LLM (Simulated)
        var llmGenerator = new GoalGenerator();
        string prompt = $"Emergency! {type} is happening. Immediate survival goal?";
        
        // We pass a cancellation token to the async generation
        try 
        {
            // Note: Modify GoalGenerator to accept CancellationToken if strictly necessary, 
            // but Task.Delay inside it is the main cancellation point.
            var emergencyGoal = await llmGenerator.GenerateGoalAsync(prompt, new List<GoapAction>());
            
            // 4. Inject Emergency Goal into Agent
            // In a real system, we'd swap the agent's current goal reference.
            // For this exercise, we assume the agent's planner uses the latest goal provided.
            Console.WriteLine($"[Interrupt] New Emergency Goal: {emergencyGoal.Name}");
            
            // Reset priority after handling (simplified)
            _currentPriority = Priority.Low;
        }
        catch (TaskCanceledException)
        {
            Console.WriteLine("[Interrupt] Planning was cancelled due to higher priority event.");
        }
    }

    public void ReleaseInterrupt()
    {
        _currentPriority = Priority.Low;
    }
}

// 4. Updated Agent to handle Cancellation
public class ResilientHybridAgent : HybridAgent
{
    public ResilientHybridAgent(List<GoapAction> actions, GoapGoal goal) : base(actions, goal) { }

    // Override Plan method to support Cancellation
    public async Task<Queue<GoapAction>> PlanWithCancellation(CancellationToken token)
    {
        Console.WriteLine("[Planner] Starting A* search...");
        
        // Simulate heavy computation
        for (int i = 0; i < 5; i++)
        {
            token.ThrowIfCancellationRequested();
            await Task.Delay(500, token); // Wait here throws if cancelled
        }

        // Return a dummy plan
        return new Queue<GoapAction>(new[] { new GoapAction { Name = "EmergencyAction" } });
    }
}

// 5. BT Root with Emergency Handling
public class InterruptibleBT
{
    private readonly ResilientHybridAgent _agent;

    public InterruptibleBT(ResilientHybridAgent agent) => _agent = agent;

    public NodeState Tick()
    {
        // Check for Emergency Flag (Set by InterruptController)
        if (_agent.Blackboard.IsEnemyDetected) // Assuming this is set by an event/sensor
        {
            // Execute Emergency Sub-Tree
            return ExecuteEmergencyBehavior();
        }
        
        // Standard Plan Execution
        return ExecuteStandardPlan();
    }

    private NodeState ExecuteEmergencyBehavior()
    {
        // Logic: Run, Hide, or Shoot based on personality
        Console.WriteLine("[BT] Handling Emergency: Firing weapon / Taking Cover");
        return NodeState.Success; // Action taken
    }

    private NodeState ExecuteStandardPlan()
    {
        // Standard execution logic from Exercise 4
        return NodeState.Success;
    }
}
