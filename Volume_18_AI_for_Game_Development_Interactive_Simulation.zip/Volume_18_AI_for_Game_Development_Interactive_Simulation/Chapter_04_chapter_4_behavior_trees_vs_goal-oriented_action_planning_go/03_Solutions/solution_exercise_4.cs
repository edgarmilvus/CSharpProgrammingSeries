
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

// 1. The Hybrid Controller
public class HybridAgent
{
    public Blackboard Blackboard { get; } = new();
    public Queue<GoapAction> CurrentPlan { get; private set; }
    public GoapAction CurrentAction => CurrentPlan?.Peek();
    public bool NeedsReplan { get; set; }

    private readonly GoapPlanner _planner = new();
    private readonly List<GoapAction> _availableActions;
    private readonly GoapGoal _currentGoal;
    private readonly BehaviorTreeExecutor _btExecutor;

    public HybridAgent(List<GoapAction> actions, GoapGoal goal)
    {
        _availableActions = actions;
        _currentGoal = goal;
        _btExecutor = new BehaviorTreeExecutor(this);
    }

    public async Task UpdateLoop()
    {
        while (true)
        {
            if (NeedsReplan || CurrentPlan == null || CurrentPlan.Count == 0)
            {
                Console.WriteLine("[Hybrid] Triggering Re-plan...");
                NeedsReplan = false;
                CurrentPlan = _planner.Plan(Blackboard, _availableActions, _currentGoal);
                
                if (CurrentPlan == null)
                {
                    Console.WriteLine("[Hybrid] No plan possible. Waiting.");
                    await Task.Delay(1000);
                    continue;
                }
            }

            // Execute the BT for one tick
            var result = _btExecutor.Tick();

            if (result == NodeState.Failure)
            {
                NeedsReplan = true;
            }
            else if (result == NodeState.Success)
            {
                // Action finished successfully, pop it
                CurrentPlan.Dequeue();
            }

            await Task.Delay(100); // Simulate frame tick
        }
    }
}

// 2. The Behavior Tree Executor
public class BehaviorTreeExecutor
{
    private readonly HybridAgent _agent;
    private Node _root;

    public BehaviorTreeExecutor(HybridAgent agent)
    {
        _agent = agent;
        BuildTree();
    }

    private void BuildTree()
    {
        // Root: Selector
        // 1. Replan Check (Decorator)
        // 2. Execute Plan Sequence
        
        var replanNode = new Conditional(() => _agent.NeedsReplan);
        
        // Note: In a real scenario, the Replan action would trigger the async planner.
        // Here we just return Failure to stop execution if replan is needed.
        
        var executeNode = new ExecutePlanNode(_agent);

        // If NeedsReplan is true, the Selector fails the first branch and tries the second (if any),
        // or we structure it to prioritize the Replan logic.
        // For this architecture, if NeedsReplan is true, we want to interrupt current execution.
        // We can handle this by checking NeedsReplan at the very top of the Tick.
        
        _root = new Sequence(new List<Node> { executeNode });
    }

    public NodeState Tick()
    {
        // Global Interrupt Check
        if (_agent.NeedsReplan) return NodeState.Failure;

        return _root.Evaluate();
    }
}

// 3. The "ExecutePlan" Node (The Glue)
public class ExecutePlanNode : Node
{
    private readonly HybridAgent _agent;
    private Node _currentActionNode;

    public ExecutePlanNode(HybridAgent agent) => _agent = agent;

    public override NodeState Evaluate()
    {
        if (_agent.CurrentAction == null) return NodeState.Failure;

        // Lazy initialization of the concrete BT node for the current action
        if (_currentActionNode == null || _currentActionNode is not ActionNode)
        {
            _currentActionNode = MapActionToBT(_agent.CurrentAction);
        }

        // Monitor Preconditions (The "Stuck" or "Invalid" check)
        if (!_agent.CurrentAction.IsPreconditionMet(_agent.Blackboard))
        {
            Console.WriteLine($"[Monitor] Precondition failed for {_agent.CurrentAction.Name}");
            return NodeState.Failure; // Triggers Replan
        }

        // Execute the concrete BT node
        var result = _currentActionNode.Evaluate();

        // If action finished, reset for next action in queue
        if (result == NodeState.Success)
        {
            _currentActionNode = null;
        }

        return result;
    }

    private Node MapActionToBT(GoapAction action)
    {
        // Factory pattern to convert abstract GOAP action to concrete BT nodes
        return action.Name switch
        {
            "MoveTo" => new ActionNode(async () => 
            {
                // Simulate MoveTo with a stuck check
                Console.WriteLine("Moving to target...");
                await Task.Delay(2000);
                
                // Simulate random obstacle
                if (new Random().Next(0, 10) == 0) 
                {
                    Console.WriteLine("Obstacle detected! Path blocked.");
                    return NodeState.Failure; 
                }
                return NodeState.Success;
            }),
            "Attack" => new ActionNode(async () => 
            {
                Console.WriteLine("Attacking target...");
                await Task.Delay(500);
                return NodeState.Success;
            }),
            _ => new ActionNode(async () => { await Task.Delay(100); return NodeState.Success; })
        };
    }
}
