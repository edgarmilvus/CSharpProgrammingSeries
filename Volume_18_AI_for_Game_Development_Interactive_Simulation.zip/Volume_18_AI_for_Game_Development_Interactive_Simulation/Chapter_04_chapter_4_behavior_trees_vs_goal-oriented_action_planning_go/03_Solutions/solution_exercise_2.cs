
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Generic; // For PriorityQueue

// 1. Data Structures
public class WorldState
{
    public Dictionary<string, bool> States { get; set; } = new();
    
    public WorldState Clone() => new() { States = new Dictionary<string, bool>(States) };
    
    public int DistanceTo(WorldState other)
    {
        // Heuristic: Count of keys that differ in value
        int diff = 0;
        foreach (var kvp in other.States)
        {
            if (!States.TryGetValue(kvp.Key, out bool val) || val != kvp.Value) diff++;
        }
        return diff;
    }
}

public class GoapAction
{
    public string Name { get; set; }
    public float Cost { get; set; }
    public Dictionary<string, bool> Preconditions { get; set; } = new();
    public Dictionary<string, bool> Effects { get; set; } = new();

    public bool IsPreconditionMet(WorldState state)
    {
        foreach (var pre in Preconditions)
        {
            if (!state.States.TryGetValue(pre.Key, out bool val) || val != pre.Value) 
                return false;
        }
        return true;
    }
}

public class GoapGoal
{
    public string Name { get; set; }
    public WorldState TargetState { get; set; }
}

// 2. Node for A* Search
public class PlanNode
{
    public WorldState State { get; set; }
    public float GCost { get; set; } // Cost from start
    public float HCost { get; set; } // Heuristic to goal
    public float FCost => GCost + HCost;
    public GoapAction Action { get; set; } // Action that led here
    public PlanNode Parent { get; set; }
}

// 3. The Planner
public class GoapPlanner
{
    public Queue<GoapAction> Plan(WorldState current, List<GoapAction> availableActions, GoapGoal goal)
    {
        // Reset actions
        foreach (var action in availableActions) action.Cost = action.Cost; // Reset potential modifiers

        // Priority Queue (Min-Heap) for A*
        // Element: PlanNode, Priority: FCost
        var openSet = new PriorityQueue<PlanNode, float>();
        
        // Track visited states to prevent loops
        var visited = new HashSet<string>();

        var startNode = new PlanNode 
        { 
            State = current.Clone(), 
            GCost = 0, 
            HCost = current.DistanceTo(goal.TargetState),
            Parent = null,
            Action = null
        };

        openSet.Enqueue(startNode, startNode.FCost);

        while (openSet.Count > 0)
        {
            var currentPlanNode = openSet.Dequeue();
            
            // Check if goal is reached
            if (currentPlanNode.State.DistanceTo(goal.TargetState) == 0)
            {
                return ReconstructPath(currentPlanNode);
            }

            // Mark state as visited (using a simplified hash of state)
            string stateHash = GetStateHash(currentPlanNode.State);
            if (visited.Contains(stateHash)) continue;
            visited.Add(stateHash);

            // Expand neighbors (Available Actions)
            foreach (var action in availableActions)
            {
                if (action.IsPreconditionMet(currentPlanNode.State))
                {
                    var newState = currentPlanNode.State.Clone();
                    
                    // Apply Effects
                    foreach (var effect in action.Effects)
                    {
                        newState.States[effect.Key] = effect.Value;
                    }

                    // Calculate Costs
                    float newG = currentPlanNode.GCost + action.Cost;
                    float newH = newState.DistanceTo(goal.TargetState);
                    
                    // Check if this path is better
                    // (In a full implementation, we check if we found a shorter path to this state)
                    var neighborNode = new PlanNode
                    {
                        State = newState,
                        GCost = newG,
                        HCost = newH,
                        Action = action,
                        Parent = currentPlanNode
                    };

                    openSet.Enqueue(neighborNode, neighborNode.FCost);
                }
            }
        }

        return null; // No plan found
    }

    private Queue<GoapAction> ReconstructPath(PlanNode node)
    {
        var path = new Stack<GoapAction>();
        while (node.Parent != null)
        {
            path.Push(node.Action);
            node = node.Parent;
        }
        return new Queue<GoapAction>(path);
    }

    private string GetStateHash(WorldState state)
    {
        // Simple hash for visited check
        return string.Join(",", state.States.OrderBy(x => x.Key).Select(x => $"{x.Key}:{x.Value}"));
    }
}
