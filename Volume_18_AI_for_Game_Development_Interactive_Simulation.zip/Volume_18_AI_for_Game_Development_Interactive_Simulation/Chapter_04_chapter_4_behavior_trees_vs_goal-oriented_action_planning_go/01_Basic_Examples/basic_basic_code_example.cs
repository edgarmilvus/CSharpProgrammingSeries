
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

// A simple "Hello World" for GOAP: A worker agent needs to gather wood to build a shelter.
// This example demonstrates the core components: Goals, Actions, Preconditions, Effects, and a simple Planner.

// 1. The World State: Represented by a set of boolean facts.
// We use a HashSet for efficient lookups. In a real Unity game, this might be a more complex data structure,
// but for this example, strings are sufficient to demonstrate the concept.
public class WorldState
{
    private readonly HashSet<string> _facts;

    public WorldState() => _facts = new HashSet<string>();

    private WorldState(HashSet<string> facts) => _facts = new HashSet<string>(facts);

    public void SetFact(string fact, bool value)
    {
        if (value) _facts.Add(fact);
        else _facts.Remove(fact);
    }

    public bool HasFact(string fact) => _facts.Contains(fact);

    public WorldState Clone() => new WorldState(_facts);

    public override string ToString() => $"[{string.Join(", ", _facts.OrderBy(f => f))}]";
}

// 2. The GOAP Action: Represents something an agent can do.
// Each action has:
//   - Cost: How "expensive" the action is (used by the planner to find the best path).
//   - Preconditions: Facts that must be true in the world for the action to be executable.
//   - Effects: Facts that become true (or false) after the action is executed.
public abstract class GoapAction
{
    public string Name { get; protected set; }
    public float Cost { get; protected set; } = 1.0f;
    public Dictionary<string, bool> Preconditions { get; protected set; } = new();
    public Dictionary<string, bool> Effects { get; protected set; } = new();

    // A simple method to check if the action's preconditions are met by the current world state.
    public bool ArePreconditionsMet(WorldState state)
    {
        foreach (var precond in Preconditions)
        {
            if (state.HasFact(precond.Key) != precond.Value) return false;
        }
        return true;
    }

    // In a real game, this would contain the logic to execute the action (e.g., move to a tree, play an animation).
    // Here, we just simulate it by returning a new WorldState with the effects applied.
    public virtual WorldState ApplyEffects(WorldState state)
    {
        var newState = state.Clone();
        foreach (var effect in Effects)
        {
            newState.SetFact(effect.Key, effect.Value);
        }
        return newState;
    }

    public override string ToString() => Name;
}

// --- Concrete Actions for our Wood Gathering Scenario ---

public class GatherWoodAction : GoapAction
{
    public GatherWoodAction()
    {
        Name = "Gather Wood";
        Cost = 2.0f;
        // Precondition: Must have an axe to gather wood efficiently (or at all).
        Preconditions["HasAxe"] = true;
        // Effect: After gathering, the agent has wood.
        Effects["HasWood"] = true;
    }
}

public class CraftAxeAction : GoapAction
{
    public CraftAxeAction()
    {
        Name = "Craft Axe";
        Cost = 3.0f;
        // Precondition: Needs some wood to craft an axe.
        Preconditions["HasWood"] = true;
        // Effect: After crafting, the agent has an axe.
        Effects["HasAxe"] = true;
    }
}

public class FindAxeAction : GoapAction
{
    public FindAxeAction()
    {
        Name = "Find Axe";
        Cost = 1.0f;
        // No preconditions: The agent can always try to find an axe on the ground.
        // Effect: The agent now has an axe.
        Effects["HasAxe"] = true;
    }
}

// 3. The GOAP Goal: Represents a desired state of the world.
// A goal is simply a set of facts that the agent wants to be true.
public class GoapGoal
{
    public string Name { get; }
    public Dictionary<string, bool> DesiredState { get; }

    public GoapGoal(string name, Dictionary<string, bool> desiredState)
    {
        Name = name;
        DesiredState = desiredState;
    }

    // Check if this goal is satisfied by the current world state.
    public bool IsSatisfied(WorldState state)
    {
        foreach (var fact in DesiredState)
        {
            if (state.HasFact(fact.Key) != fact.Value) return false;
        }
        return true;
    }
}

// 4. The Planner: The core of GOAP. It finds a sequence of actions to achieve a goal.
// This implementation uses a simple A* search algorithm.
public class GoapPlanner
{
    // A node in the search tree.
    private class Node
    {
        public WorldState State { get; }
        public Node Parent { get; }
        public GoapAction Action { get; }
        public float Cost { get; }

        public Node(WorldState state, Node parent, GoapAction action, float cost)
        {
            State = state;
            Parent = parent;
            Action = action;
            Cost = cost;
        }
    }

    // Plans a path from the current state to the goal using the available actions.
    // Returns a queue of actions to execute, or null if no plan is found.
    public Queue<GoapAction> Plan(WorldState currentState, GoapGoal goal, List<GoapAction> availableActions)
    {
        // Reset actions for a new plan (in case they have state).
        foreach (var action in availableActions) { /* Reset action state if needed */ }

        // The open set for A* search, prioritized by cost (f = g + h).
        var openSet = new PriorityQueue<Node, float>();
        var startNode = new Node(currentState.Clone(), null, null, 0);
        openSet.Enqueue(startNode, 0);

        // Keep track of visited states to avoid cycles and redundant paths.
        var visited = new HashSet<WorldState>(new WorldStateComparer());

        while (openSet.Count > 0)
        {
            var current = openSet.Dequeue();

            // Goal Check: If the current state satisfies the goal, we've found a plan.
            if (goal.IsSatisfied(current.State))
            {
                return ReconstructPath(current);
            }

            // Mark this state as visited.
            visited.Add(current.State);

            // Explore neighbors (possible actions).
            foreach (var action in availableActions)
            {
                if (action.ArePreconditionsMet(current.State))
                {
                    var nextState = action.ApplyEffects(current.State);

                    // If we've already visited this state, skip it.
                    if (visited.Contains(nextState)) continue;

                    // Calculate the new cost (g) and heuristic (h).
                    var newCost = current.Cost + action.Cost;
                    var heuristic = CalculateHeuristic(nextState, goal);

                    // Create a new node and add it to the open set.
                    var newNode = new Node(nextState, current, action, newCost);
                    openSet.Enqueue(newNode, newCost + heuristic);
                }
            }
        }

        // No plan found.
        return null;
    }

    // Heuristic: Estimates how far we are from the goal.
    // A simple heuristic: count the number of unsatisfied goal facts.
    private float CalculateHeuristic(WorldState state, GoapGoal goal)
    {
        int unsatisfiedCount = 0;
        foreach (var fact in goal.DesiredState)
        {
            if (state.HasFact(fact.Key) != fact.Value) unsatisfiedCount++;
        }
        return unsatisfiedCount;
    }

    // Backtracks from the goal node to the start node to build the action sequence.
    private Queue<GoapAction> ReconstructPath(Node node)
    {
        var path = new Stack<GoapAction>();
        while (node.Parent != null)
        {
            path.Push(node.Action);
            node = node.Parent;
        }
        return new Queue<GoapAction>(path);
    }

    // Helper comparer for WorldState to be used in HashSet.
    private class WorldStateComparer : IEqualityComparer<WorldState>
    {
        public bool Equals(WorldState x, WorldState y)
        {
            if (ReferenceEquals(x, y)) return true;
            if (x == null || y == null) return false;
            return x.ToString() == y.ToString(); // Simple string comparison for this example.
        }

        public int GetHashCode(WorldState obj) => obj.ToString().GetHashCode();
    }
}

// 5. The Agent: This class uses the planner to get a plan and then executes it.
// In a real game, this would be a MonoBehaviour in Unity.
public class Agent
{
    public WorldState CurrentState { get; private set; }
    private Queue<GoapAction> _currentPlan;
    private List<GoapAction> _availableActions;
    private List<GoapGoal> _goals;

    public Agent()
    {
        CurrentState = new WorldState();
        _availableActions = new List<GoapAction>();
        _goals = new List<GoapGoal>();
    }

    public void AddAction(GoapAction action) => _availableActions.Add(action);
    public void AddGoal(GoapGoal goal) => _goals.Add(goal);

    // In a real game loop, this would be called every frame or at a specific interval.
    public void Update()
    {
        // If we have a plan, execute the next action.
        if (_currentPlan != null && _currentPlan.Count > 0)
        {
            var action = _currentPlan.Peek();
            Console.WriteLine($"Executing action: {action.Name}");
            // Simulate action execution by applying its effects to the current state.
            CurrentState = action.ApplyEffects(CurrentState);
            Console.WriteLine($"New State: {CurrentState}");
            _currentPlan.Dequeue();
        }
        // If the plan is empty or null, find a new plan.
        else
        {
            Console.WriteLine("No current plan. Finding a new goal and plan...");
            _currentPlan = null;

            // Find a goal that is not already satisfied.
            foreach (var goal in _goals)
            {
                if (!goal.IsSatisfied(CurrentState))
                {
                    Console.WriteLine($"Selected Goal: {goal.Name}");
                    var planner = new GoapPlanner();
                    _currentPlan = planner.Plan(CurrentState, goal, _availableActions);

                    if (_currentPlan != null)
                    {
                        Console.WriteLine($"Plan found with {_currentPlan.Count} actions.");
                        break; // Found a plan, stop searching for goals.
                    }
                    else
                    {
                        Console.WriteLine($"Could not find a plan for goal: {goal.Name}");
                    }
                }
            }

            if (_currentPlan == null)
            {
                Console.WriteLine("All goals are satisfied or no plan can be found. Idling.");
            }
        }
    }
}

// 6. Main Program: Demonstrates the system in action.
public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("--- GOAP 'Hello World' Simulation ---");

        // Create an agent.
        var worker = new Agent();

        // Add available actions to the agent's knowledge base.
        worker.AddAction(new FindAxeAction());
        worker.AddAction(new CraftAxeAction());
        worker.AddAction(new GatherWoodAction());

        // Define the agent's goals.
        // Goal 1: Have wood (for building).
        var gatherWoodGoal = new GoapGoal("Gather Wood", new Dictionary<string, bool> { { "HasWood", true } });
        worker.AddGoal(gatherWoodGoal);

        // Goal 2: Have an axe (for future gathering).
        var haveAxeGoal = new GoapGoal("Have Axe", new Dictionary<string, bool> { { "HasAxe", true } });
        worker.AddGoal(haveAxeGoal);

        // --- Simulation Loop ---
        // The agent starts with nothing.
        // The planner will determine the best sequence of actions to satisfy the highest priority goal.
        // In this case, "Gather Wood" is the first goal added, so it will be prioritized.
        // To gather wood, the agent needs an axe. The planner will find a plan to get an axe first.
        // It can either "Find Axe" (cost 1) or "Craft Axe" (cost 3, but requires wood, which it doesn't have).
        // The planner will choose "Find Axe" because it's cheaper and its preconditions are met.
        // After finding the axe, the agent can execute "Gather Wood".

        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"\n--- Tick {i + 1} ---");
            worker.Update();
            if (worker.CurrentState.HasFact("HasWood") && worker.CurrentState.HasFact("HasAxe"))
            {
                Console.WriteLine("\nAgent has achieved both goals. Simulation complete.");
                break;
            }
        }
    }
}

// Helper class for PriorityQueue (available in .NET 6+)
// If using an older version, you would need to implement this or use a SortedList.
public class PriorityQueue<TElement, TPriority>
{
    private readonly SortedList<TPriority, Queue<TElement>> _sortedList = new();

    public int Count { get; private set; }

    public void Enqueue(TElement element, TPriority priority)
    {
        if (!_sortedList.TryGetValue(priority, out var queue))
        {
            queue = new Queue<TElement>();
            _sortedList[priority] = queue;
        }
        queue.Enqueue(element);
        Count++;
    }

    public TElement Dequeue()
    {
        if (Count == 0) throw new InvalidOperationException("Queue is empty");

        var firstPriority = _sortedList.Keys[0];
        var queue = _sortedList[firstPriority];
        var element = queue.Dequeue();
        Count--;

        if (queue.Count == 0)
        {
            _sortedList.RemoveAt(0);
        }

        return element;
    }
}

// Custom comparer for WorldState to be used in HashSet
public class WorldStateComparer : IEqualityComparer<WorldState>
{
    public bool Equals(WorldState x, WorldState y)
    {
        if (ReferenceEquals(x, y)) return true;
        if (x == null || y == null) return false;
        return x.ToString() == y.ToString(); // Simple string comparison for this example.
    }

    public int GetHashCode(WorldState obj) => obj.ToString().GetHashCode();
}
