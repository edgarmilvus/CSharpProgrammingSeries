
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

// REAL-WORLD CONTEXT:
// In a narrative-driven game, characters must react emotionally to player dialogue choices.
// This system simulates an "AI Animation Director" that processes dialogue text and generates
// corresponding body language cues (e.g., head movement, hand gestures, posture shifts).
// The goal is to bridge the gap between LLM-generated text and Unity's animation system
// by calculating "Animation Intensity" scores for different body parts.

namespace AIDrivenAnimation
{
    // Represents a single animation instruction sent to Unity's Animator or IK system.
    public struct AnimationCue
    {
        public string BodyPart; // e.g., "Head", "Hands", "Torso"
        public string Trigger;  // e.g., "Nod", "Shrug", "LeanForward"
        public float Intensity; // 0.0 to 1.0, driving blend trees or IK weight
    }

    // Simulates an external LLM service that analyzes text for sentiment and intent.
    // In a real Unity project, this would call an API (e.g., OpenAI, Azure AI).
    public class DialogueAnalyzer
    {
        // A mock database of keywords to simulate NLP analysis without external dependencies.
        private string[] _positiveKeywords = { "happy", "great", "yes", "good", "excited" };
        private string[] _negativeKeywords = { "sad", "no", "bad", "angry", "disappointed" };
        private string[] _emphaticKeywords = { "really", "very", "absolutely", "never" };

        public AnalysisResult Analyze(string dialogueText)
        {
            AnalysisResult result = new AnalysisResult();
            string lowerText = dialogueText.ToLower();

            // 1. Determine Sentiment
            foreach (string word in _positiveKeywords)
            {
                if (lowerText.Contains(word))
                {
                    result.SentimentScore += 1;
                    result.Sentiment = "Positive";
                }
            }

            foreach (string word in _negativeKeywords)
            {
                if (lowerText.Contains(word))
                {
                    result.SentimentScore -= 1;
                    result.Sentiment = "Negative";
                }
            }

            // 2. Determine Intensity (based on emphatic words)
            foreach (string word in _emphaticKeywords)
            {
                if (lowerText.Contains(word))
                {
                    result.IntensityMultiplier = 1.5f; // Boost intensity
                    break;
                }
            }

            // 3. Determine Intent (Simple heuristic based on sentence structure)
            if (lowerText.Contains("?"))
            {
                result.Intent = "Question";
            }
            else if (lowerText.Contains("!"))
            {
                result.Intent = "Exclamation";
            }
            else
            {
                result.Intent = "Statement";
            }

            return result;
        }
    }

    public struct AnalysisResult
    {
        public int SentimentScore; // -10 to 10
        public string Sentiment;   // "Positive", "Negative", "Neutral"
        public float IntensityMultiplier; // 1.0 is default
        public string Intent;      // "Question", "Exclamation", "Statement"
    }

    // The core logic engine that maps analysis results to specific animation cues.
    // This mimics the "Body Language Manager" described in the chapter.
    public class BodyLanguageMapper
    {
        // Maps sentiment scores to specific non-verbal behaviors.
        public List<AnimationCue> GenerateCues(AnalysisResult analysis)
        {
            List<AnimationCue> cues = new List<AnimationCue>();
            float intensity = CalculateBaseIntensity(analysis);

            // LOGIC BLOCK 1: Head Movement based on Sentiment
            if (analysis.Sentiment == "Positive")
            {
                cues.Add(new AnimationCue
                {
                    BodyPart = "Head",
                    Trigger = "Nod",
                    Intensity = intensity * 0.8f // Cap head movement intensity
                });
            }
            else if (analysis.Sentiment == "Negative")
            {
                cues.Add(new AnimationCue
                {
                    BodyPart = "Head",
                    Trigger = "Shake",
                    Intensity = intensity * 0.8f
                });
            }

            // LOGIC BLOCK 2: Torso Posture based on Intent
            if (analysis.Intent == "Question")
            {
                cues.Add(new AnimationCue
                {
                    BodyPart = "Torso",
                    Trigger = "LeanForward",
                    Intensity = intensity * 0.6f
                });
            }
            else if (analysis.Intent == "Exclamation")
            {
                cues.Add(new AnimationCue
                {
                    BodyPart = "Torso",
                    Trigger = "LeanBack",
                    Intensity = intensity * 0.9f
                });
            }

            // LOGIC BLOCK 3: Hand Gestures based on Intensity Multiplier
            if (analysis.IntensityMultiplier > 1.0f)
            {
                cues.Add(new AnimationCue
                {
                    BodyPart = "Hands",
                    Trigger = "Gesticulate",
                    Intensity = intensity * analysis.IntensityMultiplier
                });
            }
            else if (analysis.SentimentScore < 0)
            {
                cues.Add(new AnimationCue
                {
                    BodyPart = "Hands",
                    Trigger = "Clasp",
                    Intensity = 0.5f // Low intensity, defensive posture
                });
            }

            return cues;
        }

        // Helper to normalize intensity between 0 and 1 based on raw sentiment score.
        private float CalculateBaseIntensity(AnalysisResult analysis)
        {
            float rawScore = Math.Abs(analysis.SentimentScore);
            // Normalize roughly to 0-1 range, clamping at 5 for max intensity
            float normalized = rawScore / 5.0f;
            if (normalized > 1.0f) normalized = 1.0f;
            
            return normalized * analysis.IntensityMultiplier;
        }
    }

    // Simulates the Unity Animation Controller.
    // In a real implementation, this would interface with Animator.SetFloat(), 
    // Unity's Animation Rigging package (IK), or a Blend Tree.
    public class AnimationController
    {
        public void ExecuteAnimation(List<AnimationCue> cues)
        {
            Console.WriteLine("--- [Unity Animation System] ---");
            Console.WriteLine("Processing Animation Queue...");
            
            foreach (var cue in cues)
            {
                // Simulate driving a Blend Tree parameter
                Console.WriteLine($"[Blend Tree] Setting '{cue.BodyPart}_{cue.Trigger}' to {cue.Intensity:F2}");
                
                // Simulate triggering a specific State Machine transition
                if (cue.Intensity > 0.7f)
                {
                    Console.WriteLine($"[State Machine] Triggering High Intensity State: {cue.Trigger}");
                }
                
                // Simulate IK Weight adjustment (Inverse Kinematics)
                // e.g., Looking at the player while talking
                if (cue.BodyPart == "Head")
                {
                    Console.WriteLine($"[IK System] Adjusting Head Look Weight: {cue.Intensity:F2}");
                }
            }
            Console.WriteLine("--------------------------------");
        }
    }

    // Main Application Entry Point
    class Program
    {
        static void Main(string[] args)
        {
            // 1. Setup Systems
            DialogueAnalyzer analyzer = new DialogueAnalyzer();
            BodyLanguageMapper mapper = new BodyLanguageMapper();
            AnimationController animController = new AnimationController();

            // 2. Simulate Player Input Scenarios
            string[] testDialogues = {
                "I am absolutely thrilled about this news!",
                "No, I don't think that's right.",
                "Could you please explain that again?",
                "This is just bad."
            };

            // 3. Process Loop
            foreach (string dialogue in testDialogues)
            {
                Console.WriteLine($"\nProcessing Dialogue: \"{dialogue}\"");

                // A. Analyze Text
                AnalysisResult result = analyzer.Analyze(dialogue);
                Console.WriteLine($"Analysis -> Sentiment: {result.Sentiment} | Intent: {result.Intent} | Multiplier: {result.IntensityMultiplier}");

                // B. Map to Body Language
                List<AnimationCue> cues = mapper.GenerateCues(result);

                // C. Drive Animation
                animController.ExecuteAnimation(cues);
            }

            Console.WriteLine("\nSimulation Complete.");
        }
    }
}
