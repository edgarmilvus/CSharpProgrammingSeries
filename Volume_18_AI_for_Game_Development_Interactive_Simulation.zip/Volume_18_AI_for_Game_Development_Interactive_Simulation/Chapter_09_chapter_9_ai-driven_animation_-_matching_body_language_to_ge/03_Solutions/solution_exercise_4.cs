
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum GazeTargetType { Eyes, Mouth, Hands, Background }

public class GazeController : MonoBehaviour
{
    [SerializeField] private Transform _eyeLeft;
    [SerializeField] private Transform _eyeRight;
    [SerializeField] private Transform _currentTarget;
    [SerializeField] private float _saccadeInterval = 3f;
    
    // Simulated target positions (in a real scenario, these would be transforms on the listener)
    private Dictionary<GazeTargetType, Vector3> _targetPositions = new Dictionary<GazeTargetType, Vector3>();
    
    private Coroutine _gazeRoutine;
    private Coroutine _blinkRoutine;
    private float _blinkFrequency = 0.5f; // Base frequency

    private void Start()
    {
        // Initialize dummy positions for demonstration
        _targetPositions[GazeTargetType.Eyes] = new Vector3(0, 1.7f, 2f);
        _targetPositions[GazeTargetType.Mouth] = new Vector3(0, 1.5f, 2f);
        _targetPositions[GazeTargetType.Hands] = new Vector3(0.5f, 1.2f, 2f);
        _targetPositions[GazeTargetType.Background] = new Vector3(5f, 2f, 5f);

        // Start routines
        _gazeRoutine = StartCoroutine(SaccadeRoutine());
        _blinkRoutine = StartCoroutine(BlinkRoutine());
    }

    // 1. Target Selection based on Context
    public void UpdateContext(string dialogue, float confidence)
    {
        // Modify blink frequency based on confidence (nervous = higher freq)
        _blinkFrequency = Mathf.Lerp(0.2f, 1.0f, confidence);

        GazeTargetType selectedTarget = GazeTargetType.Background; // Default

        if (dialogue.Contains("what") || dialogue.Contains("how"))
            selectedTarget = GazeTargetType.Mouth;
        else if (dialogue.Contains("happy") || dialogue.Contains("sad"))
            selectedTarget = GazeTargetType.Eyes;
        else if (dialogue.Contains("grab") || dialogue.Contains("throw"))
            selectedTarget = GazeTargetType.Hands;

        // Immediate update if priority demands
        if (_targetPositions.ContainsKey(selectedTarget))
        {
            // Smoothly lerp target position (visualized as a debug ray)
            _currentTarget.position = _targetPositions[selectedTarget];
        }
    }

    // 2. Saccade Generation
    private IEnumerator SaccadeRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(Random.Range(2f, 5f));
            
            // Randomly pick a new target
            var keys = new List<GazeTargetType>(_targetPositions.Keys);
            var randomKey = keys[Random.Range(0, keys.Count)];
            
            // Move current target logic (ease-in-out simulation)
            Vector3 destination = _targetPositions[randomKey];
            float duration = 0.5f;
            float elapsed = 0f;
            Vector3 start = _currentTarget.position;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                // Ease-in-out curve (squared)
                t = t < 0.5 ? 2 * t * t : 1 - Mathf.Pow(-2 * t + 2, 2) / 2;
                _currentTarget.position = Vector3.Lerp(start, destination, t);
                yield return null;
            }
        }
    }

    // 3. Blinking Mechanism
    private IEnumerator BlinkRoutine()
    {
        float time = 0f;
        while (true)
        {
            time += Time.deltaTime * _blinkFrequency;
            float blinkWeight = (Mathf.Sin(time * 10) + 1) / 2; // Sine wave 0 to 1

            // Apply to blend shapes (Simulated via Debug for this example)
            // In Unity, you would use SkinnedMeshRenderer.SetBlendShapeWeight
            Debug.Log($"Blink Weight: {blinkWeight}");
            
            // Visualize Eye rotation towards target
            if (_eyeLeft != null && _currentTarget != null)
            {
                _eyeLeft.LookAt(_currentTarget);
                _eyeRight.LookAt(_currentTarget);
            }

            yield return null;
        }
    }

    // 4. Edge Case - Interruption
    public void OnHighPriorityGesture(GestureData gesture)
    {
        // Snap gaze to gesture location (Simulated)
        if (_gazeRoutine != null) StopCoroutine(_gazeRoutine);
        
        // Example: If pointing, look at the hand (simulated offset)
        Vector3 gesturePos = _targetPositions[GazeTargetType.Hands]; 
        _currentTarget.position = gesturePos;
        
        // Resume saccades after gesture duration
        StartCoroutine(ResumeSaccadesAfter(gesture.Duration));
    }

    private IEnumerator ResumeSaccadesAfter(float delay)
    {
        yield return new WaitForSeconds(delay);
        _gazeRoutine = StartCoroutine(SaccadeRoutine());
    }
}
