
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;

// 1. IK Solver Implementation
public class TwoBoneIKSolver : MonoBehaviour
{
    [SerializeField] private Transform _upperBone; // e.g., UpperArm or UpperSpine
    [SerializeField] private Transform _lowerBone; // e.g., Forearm or LowerSpine
    [SerializeField] private Transform _target;
    [SerializeField] private Transform _pole; // Optional: for elbow/knee direction
    [SerializeField] [Range(0f, 1f)] public float Weight = 1.0f;

    private Vector3 _startPos, _midPos, _endPos;
    private float _upperLen, _lowerLen, _totalLen;

    private void Awake()
    {
        if (_lowerBone == null) _lowerBone = transform;
        CalculateLengths();
    }

    private void CalculateLengths()
    {
        _upperLen = Vector3.Distance(_upperBone.position, _lowerBone.position);
        _lowerLen = Vector3.Distance(_lowerBone.position, _lowerBone.position); // Assuming _lowerBone is the end effector
        _totalLen = _upperLen + _lowerLen;
    }

    // Basic CCD-like solver simplified for Two-Bone chain
    public void Solve()
    {
        if (_target == null || Weight <= 0.01f) return;

        Vector3 targetPos = Vector3.Lerp(_lowerBone.position, _target.position, Weight);
        Vector3 toTarget = targetPos - _upperBone.position;
        float distToTarget = toTarget.magnitude;

        // If target is out of reach, stretch fully
        if (distToTarget > _totalLen)
        {
            // Just point upper bone at target
            Quaternion lookRot = Quaternion.LookRotation(toTarget, _upperBone.up);
            _upperBone.rotation = lookRot;
        }
        else
        {
            // Solve triangle
            Vector3 toEnd = _lowerBone.position - _upperBone.position;
            Vector3 axis = Vector3.Cross(toEnd, toTarget).normalized;
            float angle = Vector3.SignedAngle(toEnd, toTarget, axis);
            
            // Apply rotation to upper bone
            _upperBone.Rotate(axis, angle, Space.World);

            // Recalculate lower bone position
            Vector3 newLowerPos = _upperBone.position + _upperBone.forward * _upperLen;
            
            // Rotate lower bone to reach target
            Vector3 toLowerTarget = targetPos - newLowerPos;
            Quaternion lowerLookRot = Quaternion.LookRotation(toLowerTarget, _lowerBone.up);
            _lowerBone.rotation = lowerLookRot;
        }
    }

    private void OnDrawGizmos()
    {
        // 5. Visualization
        if (_upperBone != null && _lowerBone != null)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawLine(_upperBone.position, _lowerBone.position);
            if (_target != null)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawSphere(_target.position, 0.1f);
            }
        }
    }
}

// 2. Look-At System & 3. Dynamic Weighting
public class HeadLookAt : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _lookAtTarget;
    [SerializeField] private float _weight = 1.0f;
    
    // Bone references
    [SerializeField] private Transform _headBone;
    [SerializeField] private Transform _spineBone; // For leaning

    // Reference to the IK solver from Exercise 1
    [SerializeField] private TwoBoneIKSolver _spineIK;

    // Sentiment result reference (simulated for this exercise)
    private SentimentAnalysisResult _currentSentiment;

    public void UpdateSentiment(SentimentAnalysisResult result)
    {
        _currentSentiment = result;
        
        // 3. Dynamic Weighting based on Confidence
        // High Confidence = 1.0, Low = 0.2
        _weight = Mathf.Lerp(0.2f, 1.0f, result.Confidence);

        // 4. Spine Leaning Mapping
        if (_spineIK != null)
        {
            // Map Anger to Spine IK Weight
            _spineIK.Weight = result.Anger; // Direct mapping 0-1
        }
    }

    private void LateUpdate()
    {
        if (_animator == null || _headBone == null) return;

        // 4. Constraint: If Anger > 0.8, override target to fixed forward
        Vector3 actualTarget;
        if (_currentSentiment.Anger > 0.8f)
        {
            // Aggressive staring
            actualTarget = _headBone.position + _headBone.forward * 5f; 
            _weight = 1.0f; // Force max weight
        }
        else
        {
            actualTarget = _lookAtTarget != null ? _lookAtTarget.position : _headBone.position + _headBone.forward;
        }

        // Apply Look-At Logic
        Vector3 direction = actualTarget - _headBone.position;
        Quaternion targetRotation = Quaternion.LookRotation(direction, Vector3.up);
        
        // Smooth interpolation based on calculated weight
        _headBone.rotation = Quaternion.Slerp(_headBone.rotation, targetRotation, _weight * Time.deltaTime * 5f);

        // 5. Visualize IK targets
        Debug.DrawRay(_headBone.position, direction * 2f, Color.cyan);
    }
}
