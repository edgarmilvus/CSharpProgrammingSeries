
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

// 1. Verlet Point Struct
public struct VerletPoint
{
    public Vector3 Position;
    public Vector3 OldPosition;
    public bool Pinned;
    public Vector3 Acceleration;
}

// 2. Constraint Class
public class Constraint
{
    public int PointA;
    public int PointB;
    public float RestLength;

    public void Solve(List<VerletPoint> points)
    {
        if (points[PointA].Pinned && points[PointB].Pinned) return;

        Vector3 delta = points[PointB].Position - points[PointA].Position;
        float currentLength = delta.magnitude;
        
        // Avoid division by zero
        if (currentLength < 0.0001f) return;

        float difference = (currentLength - RestLength) / currentLength;
        Vector3 offset = delta * difference * 0.5f; // Stiffness 0.5 for each

        if (!points[PointA].Pinned) points[PointA].Position += offset;
        if (!points[PointB].Pinned) points[PointB].Position -= offset;
    }
}

public class ClothSimulator : MonoBehaviour
{
    [SerializeField] private Transform _anchorPoint; // e.g., UpperSpine
    [SerializeField] private int _resolution = 10;
    [SerializeField] private float _stiffness = 1.0f;
    
    private List<VerletPoint> _points = new List<VerletPoint>();
    private List<Constraint> _constraints = new List<Constraint>();
    
    // 5. Performance: Async handling
    private bool _isProcessing = false;
    private Vector3 _externalForce;

    private void Start()
    {
        InitializeCloth();
    }

    private void InitializeCloth()
    {
        // Create a simple grid of points
        for (int x = 0; x < _resolution; x++)
        {
            for (int y = 0; y < _resolution; y++)
            {
                Vector3 pos = _anchorPoint.position + new Vector3(x * 0.1f, -y * 0.1f, 0);
                _points.Add(new VerletPoint 
                { 
                    Position = pos, 
                    OldPosition = pos, 
                    Pinned = (y == 0) // Pin the top row
                });
            }
        }

        // Create constraints (structural)
        for (int x = 0; x < _resolution; x++)
        {
            for (int y = 0; y < _resolution; y++)
            {
                int index = x * _resolution + y;
                if (x < _resolution - 1)
                    _constraints.Add(new Constraint { PointA = index, PointB = index + _resolution, RestLength = 0.1f });
                if (y < _resolution - 1)
                    _constraints.Add(new Constraint { PointA = index, PointB = index + 1, RestLength = 0.1f });
            }
        }
    }

    // 4. Animation Force Injection
    public void AddForce(Vector3 force)
    {
        _externalForce = force;
    }

    private void Update()
    {
        // Visualize current state (Main Thread)
        DrawCloth();
        
        // Trigger Physics Step asynchronously
        if (!_isProcessing)
        {
            _isProcessing = true;
            Task.Run(() => PhysicsStepAsync(Time.deltaTime));
        }
    }

    private async void PhysicsStepAsync(float dt)
    {
        // 3. Verlet Integration & 2. Constraint Solving
        // This runs on a background thread
        
        // 1. Integration
        for (int i = 0; i < _points.Count; i++)
        {
            var p = _points[i];
            if (p.Pinned) continue;

            Vector3 velocity = p.Position - p.OldPosition;
            p.OldPosition = p.Position;
            
            // Gravity + External Force
            Vector3 gravity = new Vector3(0, -9.81f, 0);
            p.Acceleration = gravity + _externalForce;
            
            p.Position += velocity + p.Acceleration * dt * dt;
            _points[i] = p;
        }

        // 2. Constraint Solving (Relaxation Loop)
        int iterations = 3;
        for (int k = 0; k < iterations; k++)
        {
            foreach (var constraint in _constraints)
            {
                constraint.Solve(_points);
            }
        }

        // Reset external force
        _externalForce = Vector3.zero;

        // Sync back to main thread context (simplified for this example)
        // In a full JobSystem implementation, we would use NativeArrays and JobHandle.
        await Task.Yield(); 
        _isProcessing = false;
    }

    private void DrawCloth()
    {
        // Debug visualization on Main Thread
        foreach (var c in _constraints)
        {
            Debug.DrawLine(_points[c.PointA].Position, _points[c.PointB].Position, Color.white);
        }
    }
}
