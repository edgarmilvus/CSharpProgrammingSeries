
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

[System.Serializable]
public class GestureData
{
    public string AnimationTrigger;
    public int Priority; // 0: Idle, 1: Conversational, 2: Reactive
    public float Duration;
}

public class AdvancedBodyLanguageManager : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _headTransform;
    
    // Queue System
    private Queue<GestureData> _gestureQueue = new Queue<GestureData>();
    private bool _isProcessingQueue = false;
    private CancellationTokenSource _cts; // For cancellation if needed

    // Idle Sway Settings
    [SerializeField] private float _swayAmplitude = 5f;
    [SerializeField] private float _swaySpeed = 1f;
    private float _idleTime = 0f;

    // 1. Latency Injection Simulation
    public async void ProcessLLMResponse(string dialogue, List<GestureData> parsedGestures)
    {
        // Simulate network latency
        int latencyMs = Random.Range(500, 2000);
        await Task.Delay(latencyMs);

        // 3. Queueing Gestures
        foreach (var gesture in parsedGestures)
        {
            // 4. Priority System: Only enqueue if priority is high enough or queue is empty
            // In a real scenario, we might interrupt, but here we queue.
            _gestureQueue.Enqueue(gesture);
        }

        // Start processing if not already running
        if (!_isProcessingQueue)
        {
            ProcessQueueAsync();
        }
    }

    private async void ProcessQueueAsync()
    {
        _isProcessingQueue = true;

        while (_gestureQueue.Count > 0)
        {
            GestureData nextGesture = _gestureQueue.Peek();

            // 4. Priority Check (Simulated interruption logic)
            // If a high priority gesture arrives while low priority is playing, 
            // we would typically interrupt. Here we just process the queue order.
            
            // Trigger Animation
            _animator.SetTrigger(nextGesture.AnimationTrigger);
            
            // Wait for duration (non-blocking)
            await Task.Delay((int)(nextGesture.Duration * 1000));
            
            // Dequeue
            _gestureQueue.Dequeue();
        }

        _isProcessingQueue = false;
    }

    private void Update()
    {
        // 2. Idle State Enhancement (Perlin Noise)
        // Only sway if not speaking (no high priority gestures active)
        if (!_isProcessingQueue || (_gestureQueue.Count > 0 && _gestureQueue.Peek().Priority == 0))
        {
            _idleTime += Time.deltaTime * _swaySpeed;
            
            // Perlin Noise for smooth random motion
            float noiseX = Mathf.PerlinNoise(_idleTime, 0) * 2 - 1; // Map 0-1 to -1-1
            float noiseZ = Mathf.PerlinNoise(0, _idleTime) * 2 - 1;

            Quaternion targetRot = Quaternion.Euler(noiseX * _swayAmplitude, 0, noiseZ * _swayAmplitude);
            
            // Smoothly apply to head
            if (_headTransform != null)
            {
                _headTransform.localRotation = Quaternion.Slerp(_headTransform.localRotation, targetRot, Time.deltaTime);
            }
        }
    }
}
