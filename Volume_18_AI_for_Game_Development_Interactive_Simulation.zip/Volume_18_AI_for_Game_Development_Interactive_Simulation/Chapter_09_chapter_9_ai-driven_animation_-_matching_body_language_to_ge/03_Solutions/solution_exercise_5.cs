
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using System;

[System.Serializable]
public class CurveMapping
{
    public AnimationCurve MappingCurve = AnimationCurve.Linear(0, 0, 1, 1);
    
    public float Evaluate(float input)
    {
        // Clamp input to 0-1 range before evaluation
        return MappingCurve.Evaluate(Mathf.Clamp01(input));
    }
}

public class EmotionalBlender : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    
    // Layer Indices (Must match Animator Controller setup)
    private const int BASE_LAYER = 0;
    private const int UPPER_BODY_LAYER = 1;
    private const int FACE_LAYER = 2;

    // 3. Curve-Based Mapping
    [SerializeField] private CurveMapping _joyCurve;
    [SerializeField] private CurveMapping _sadnessCurve;
    
    // Anatomical Limits
    [SerializeField] private float _maxEyebrowRaise = 0.5f; // Example limit

    public void ApplyEmotionalBlend(SentimentAnalysisResult sentiment)
    {
        if (_animator == null) return;

        // 2. Additive Blending Logic
        
        // Calculate weights using curves
        float joyWeight = _joyCurve.Evaluate(sentiment.Joy);
        float sadnessWeight = _sadnessCurve.Evaluate(sentiment.Sadness);

        // Normalize weights if they exceed 1.0 combined (optional, depending on design)
        // Here we keep them independent for additive layers.

        // 1. Layered Animator Control
        
        // Set Layer Weights
        // Upper Body (Gestures) might be driven by Joy
        _animator.SetLayerWeight(UPPER_BODY_LAYER, joyWeight);
        
        // Face Layer (Expressions) handles mixing
        _animator.SetLayerWeight(FACE_LAYER, 1.0f); // Face layer is always active

        // Set Parameters for Blend Trees within layers
        // Example: A 2D Blend Tree on the Face Layer
        _animator.SetFloat("JoyParam", joyWeight);
        _animator.SetFloat("SadParam", sadnessWeight);

        // 4. Constraint: Anatomical Limits (Clamping)
        // If we were driving a bone rotation directly (e.g., eyebrow raise)
        float calculatedEyebrowRaise = joyWeight * 30f; // Degrees
        
        // Ensure we don't break the neck (literally or figuratively)
        float clampedRotation = Mathf.Clamp(calculatedEyebrowRaise, -45f, _maxEyebrowRaise);
        
        // Apply to a bone (Simulated)
        // _headBone.Rotate(clampedRotation, 0, 0); 
    }
}
