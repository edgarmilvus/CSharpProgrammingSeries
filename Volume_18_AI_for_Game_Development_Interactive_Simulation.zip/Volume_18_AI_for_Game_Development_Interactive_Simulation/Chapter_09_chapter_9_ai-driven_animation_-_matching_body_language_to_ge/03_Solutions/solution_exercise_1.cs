
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// 1. Data Structure
public struct SentimentAnalysisResult
{
    public float Joy;
    public float Anger;
    public float Sadness;
    public float Confidence;
}

// 2. Analysis Logic & Observer Pattern
public class SentimentAnalyzer : MonoBehaviour
{
    // Event declaration
    public event Action<SentimentAnalysisResult> OnSentimentAnalyzed;

    // Dictionary for word weights (Joy, Anger, Sadness)
    // Values range typically -1.0 to 1.0, but we will map them to 0-1 later.
    private readonly Dictionary<string, (float joy, float anger, float sadness)> _wordWeights = new()
    {
        { "happy", (1.0f, 0.0f, 0.0f) },
        { "ecstatic", (1.0f, 0.0f, 0.0f) },
        { "joy", (1.0f, 0.0f, 0.0f) },
        { "angry", (0.0f, 1.0f, 0.0f) },
        { "enraged", (0.0f, 1.0f, 0.0f) },
        { "furious", (0.0f, 1.0f, 0.0f) },
        { "sad", (0.0f, 0.0f, 1.0f) },
        { "grief", (0.0f, 0.0f, 1.0f) },
        { "depressed", (0.0f, 0.0f, 1.0f) },
        { "neutral", (0.0f, 0.0f, 0.0f) } // Baseline
    };

    public void AnalyzeSentiment(string dialogue)
    {
        string[] tokens = dialogue.ToLower().Split(new char[] { ' ', '.', ',', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);
        
        float totalJoy = 0f;
        float totalAnger = 0f;
        float totalSadness = 0f;
        int emotiveWordCount = 0;

        // Calculate weighted sums
        foreach (var token in tokens)
        {
            if (_wordWeights.TryGetValue(token, out var weights))
            {
                totalJoy += weights.joy;
                totalAnger += weights.anger;
                totalSadness += weights.sadness;
                emotiveWordCount++;
            }
        }

        // Calculate Confidence (Ratio of emotive words to total words)
        // Clamped to 0-1 range.
        float confidence = tokens.Length > 0 ? (float)emotiveWordCount / tokens.Length : 0f;
        confidence = Mathf.Clamp01(confidence);

        // Edge Case: Low Confidence defaults to Neutral
        if (confidence < 0.5f)
        {
            totalJoy = 0f;
            totalAnger = 0f;
            totalSadness = 0f;
        }
        else
        {
            // Normalize intensities to 0-1 range based on the sum of weights found
            // Using Clamp01 to ensure we don't exceed 1.0
            totalJoy = Mathf.Clamp01(totalJoy);
            totalAnger = Mathf.Clamp01(totalAnger);
            totalSadness = Mathf.Clamp01(totalSadness);
        }

        var result = new SentimentAnalysisResult
        {
            Joy = totalJoy,
            Anger = totalAnger,
            Sadness = totalSadness,
            Confidence = confidence
        };

        // Notify subscribers
        OnSentimentAnalyzed?.Invoke(result);
    }
}

// 3. Intensity Mapping & 4. Architecture (Observer Subscriber)
public class BlendTreeMapper : MonoBehaviour
{
    [SerializeField] private SentimentAnalyzer _analyzer;
    [SerializeField] private Animator _animator;

    private void OnEnable()
    {
        if (_analyzer != null)
        {
            _analyzer.OnSentimentAnalyzed += HandleSentimentUpdate;
        }
    }

    private void OnDisable()
    {
        if (_analyzer != null)
        {
            _analyzer.OnSentimentAnalyzed -= HandleSentimentUpdate;
        }
    }

    private void HandleSentimentUpdate(SentimentAnalysisResult result)
    {
        if (_animator == null) return;

        // 5. Constraint: No 'if' statements for mapping logic.
        // Use Mathf.Lerp to map input (0-1) to output (0-1).
        // While inputs are already 0-1, Lerp ensures valid range even if inputs were raw scores.
        
        float joyIntensity = Mathf.Lerp(0f, 1f, result.Joy);
        
        // Apply to Animator
        _animator.SetFloat("JoyIntensity", joyIntensity);
        
        // Example of mapping other parameters
        _animator.SetFloat("AngerIntensity", Mathf.Lerp(0f, 1f, result.Anger));
        _animator.SetFloat("SadnessIntensity", Mathf.Lerp(0f, 1f, result.Sadness));
    }
}
