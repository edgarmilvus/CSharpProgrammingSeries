
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using UnityEngine.Profiling;
using System.Diagnostics;
using System.Collections.Generic;
using System;

public class LibraryProfiler : MonoBehaviour
{
    // Simulated external library that allocates memory
    private List<string> _externalDataCache = new List<string>();

    public void RunExternalCalculation()
    {
        // 1. Profiler Integration
        Profiler.BeginSample("ExternalLibrary_NoiseGeneration");

        // Simulate heavy external call
        // Example: A library that generates strings and arrays internally
        string result = HeavyExternalLibraryCall();

        Profiler.EndSample();

        Debug.Log($"Result: {result}");
    }

    private string HeavyExternalLibraryCall()
    {
        // Simulating allocation (Gen 0 garbage)
        var data = new List<byte>();
        for (int i = 0; i < 1000; i++)
        {
            data.Add((byte)(i % 256));
        }
        // Simulate string manipulation (allocations)
        return BitConverter.ToString(data.ToArray());
    }

    [ContextMenu("Benchmark Memory")]
    public void BenchmarkMemory()
    {
        // 2. GC Allocation Tracking
        long memoryBefore = GC.GetTotalMemory(true); // Force GC before measuring

        // Run the loop
        for (int i = 0; i < 1000; i++)
        {
            RunExternalCalculation();
        }

        long memoryAfter = GC.GetTotalMemory(true);
        long allocatedBytes = memoryAfter - memoryBefore;

        UnityEngine.Debug.Log($"Total Bytes Allocated (approx): {allocatedBytes}");
        UnityEngine.Debug.Log($"Gen 0 Collections: {GC.CollectionCount(0)}");
    }

    [ContextMenu("Refactor for Zero-Allocation")]
    public void RefactoredCalculation()
    {
        Profiler.BeginSample("Refactored_NoiseGeneration");

        // 3. Refactoring for Zero-Allocation
        // Instead of creating new lists/strings in a loop, we reuse buffers.
        // Pre-allocate array
        byte[] buffer = new byte[1000];
        
        for (int i = 0; i < 1000; i++)
        {
            buffer[i % 1000] = (byte)(i % 256);
        }
        // Use Span<T> or direct array access to avoid string allocations if possible
        // (Simulating a low-allocation wrapper)

        Profiler.EndSample();
    }

    // 4. Exception Breakpoints Simulation
    public void TriggerNativeException()
    {
        try
        {
            // Simulating a P/Invoke call that causes an AccessViolation
            // In a real scenario, this would be a DllImport method
            // IntPtr ptr = IntPtr.Zero;
            // Marshal.WriteByte(ptr, 0); // This would throw AccessViolationException

            // Simulating a managed wrapper throwing an exception
            throw new InvalidOperationException("Simulated native access failure");
        }
        catch (Exception ex)
        {
            Debug.LogError($"Caught exception: {ex.Message}\nStack Trace: {ex.StackTrace}");
            // To debug native exceptions in Unity:
            // 1. Attach Visual Studio to Unity process.
            // 2. In VS: Debug > Windows > Exception Settings.
            // 3. Check "Common Language Runtime Exceptions" and "Native Run-Time Checks".
            // 4. When the crash occurs, VS breaks. The Call Stack window will show 
            //    mixed-mode (Managed C# frames followed by Native DLL frames).
        }
    }
}

// Custom Editor Window for Interactive Challenge
#if UNITY_EDITOR
using UnityEditor;
public class LibraryProfilerWindow : EditorWindow
{
    LibraryProfiler _target;
    Stopwatch _sw = new Stopwatch();
    List<long> _last100Times = new List<long>();
    Vector2 _scrollPos;

    [MenuItem("Tools/Library Profiler")]
    public static void ShowWindow()
    {
        GetWindow<LibraryProfilerWindow>("Library Stats");
    }

    void OnGUI()
    {
        GUILayout.Label("Real-time Statistics", EditorStyles.boldLabel);
        
        _target = (LibraryProfiler)EditorGUILayout.ObjectField("Target", _target, typeof(LibraryProfiler), true);

        if (GUILayout.Button("Trigger Library Call"))
        {
            if (_target != null)
            {
                // Measure execution time
                _sw.Restart();
                _target.RunExternalCalculation();
                _sw.Stop();

                // Add to history
                _last100Times.Add(_sw.ElapsedMilliseconds);
                if (_last100Times.Count > 100) _last100Times.RemoveAt(0);

                // Measure Memory (Runtime)
                long memSize = Profiler.GetRuntimeMemorySizeLong(_target);
                UnityEngine.Debug.Log($"Execution Time: {_sw.ElapsedMilliseconds}ms | Memory: {memSize} bytes");
            }
        }

        // Graph execution time
        _scrollPos = EditorGUILayout.BeginScrollView(_scrollPos);
        foreach (var time in _last100Times)
        {
            EditorGUILayout.LabelField($"Call: {time} ms", GUILayout.Width(200));
            // Visual bar
            GUILayout.Box("", GUILayout.Width(time * 10), GUILayout.Height(10));
        }
        EditorGUILayout.EndScrollView();
    }
}
#endif
