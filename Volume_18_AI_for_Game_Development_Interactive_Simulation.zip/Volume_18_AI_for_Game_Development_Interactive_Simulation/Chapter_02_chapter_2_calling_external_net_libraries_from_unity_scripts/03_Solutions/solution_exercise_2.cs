
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System.Collections;
using System.Threading.Tasks;
using UnityEngine;
using System.Exception; // Needed for exception handling in older contexts, though usually implicit

public static class AsyncWrapper
{
    /// <summary>
    /// Converts a Task<T> into an IEnumerator usable by Unity Coroutines.
    /// </summary>
    public static IEnumerator RunTaskAsCoroutine<T>(Task<T> task)
    {
        // Wait for the task to complete
        while (!task.IsCompleted)
        {
            yield return null;
        }

        // Check for faults (exceptions)
        if (task.IsFaulted)
        {
            // Log the exception to the Unity Console
            // AggregateException contains all exceptions thrown in the task
            Debug.LogError($"Task failed with exception: {task.Exception}");
            
            // Optional: Re-throw to stop execution if needed, 
            // but usually in coroutines we just log and exit.
            yield break; 
        }
        else if (task.IsCanceled)
        {
            Debug.LogWarning("Task was cancelled.");
            yield break;
        }

        // If successful, the result is available via task.Result
        // Note: Accessing task.Result here is safe because IsCompleted is true.
        T result = task.Result;
        
        // In a real scenario, you might want to return the result via an event or callback
        // since IEnumerators don't support returning values directly easily.
        Debug.Log($"Task completed successfully. Result: {result}");
    }
}

// --- Integration Example ---
public class AsyncFileLoader : MonoBehaviour
{
    // Example usage with a dummy async method simulating file I/O
    public void LoadFileButton()
    {
        // Simulate an async file load
        Task<string> loadTask = SimulateAsyncFileLoad("config.json");
        
        // Start the coroutine wrapper
        StartCoroutine(AsyncWrapper.RunTaskAsCoroutine(loadTask));
    }

    private async Task<string> SimulateAsyncFileLoad(string path)
    {
        // Simulate network/disk delay
        await Task.Delay(1000); 
        
        // Simulate an error for testing
        if (path.Contains("error")) 
            throw new System.IO.IOException("File not found (simulated).");

        return "{ \"data\": \"loaded\" }";
    }
}
