
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using UnityEngine;
using Unity.Collections; // For NativeArray (better alternative, but we will use GCHandle as requested)

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct ExternalVertex
{
    public float x;
    public float y;
    public float z;
}

public class DataMarshaller : MonoBehaviour
{
    // Simulated external method signature (P/Invoke)
    // In a real scenario, this would be in a DLL like "ExternalPhysics.dll"
    [DllImport("ExternalPhysics")]
    private static extern void ProcessVertices(IntPtr vertices, int count);

    // Dummy implementation for demonstration purposes
    private static void DummyProcessVertices(IntPtr vertices, int count)
    {
        // In a real scenario, we would read from the pointer here.
        // For this solution, we simulate the call to ensure code compiles.
        Debug.Log($"Processing {count} vertices at memory address {vertices}");
    }

    void Start()
    {
        // 1. Create a list of Vector3 (Managed Memory)
        List<Vector3> unityVertices = new List<Vector3>();
        for (int i = 0; i < 10000; i++)
        {
            unityVertices.Add(new Vector3(i, i * 2, i * 3));
        }

        // 2. Benchmark Marshaling
        BenchmarkMarshaling(unityVertices);
    }

    private void BenchmarkMarshaling(List<Vector3> unityVertices)
    {
        int count = unityVertices.Count;
        
        // --- Method 1: Using GCHandle (Manual Pinning) ---
        Stopwatch sw = Stopwatch.StartNew();
        
        // Convert List<Vector3> to array of ExternalVertex
        ExternalVertex[] externalArray = new ExternalVertex[count];
        for (int i = 0; i < count; i++)
        {
            externalArray[i] = new ExternalVertex 
            { 
                x = unityVertices[i].x, 
                y = unityVertices[i].y, 
                z = unityVertices[i].z 
            };
        }

        // Pin the array in memory so GC doesn't move it
        GCHandle handle = GCHandle.Alloc(externalArray, GCHandleType.Pinned);
        IntPtr pointer = handle.AddrOfPinnedObject();

        // Call external method (Simulated)
        // ProcessVertices(pointer, count); 
        DummyProcessVertices(pointer, count);

        // CRITICAL: Cleanup
        handle.Free(); 

        sw.Stop();
        Debug.Log($"GCHandle Marshaling Time: {sw.ElapsedMilliseconds} ms");

        // --- Method 2: Manual Iteration (Comparison) ---
        // This represents the overhead of accessing data without direct memory mapping
        Stopwatch sw2 = Stopwatch.StartNew();
        float[] rawFloats = new float[count * 3];
        for (int i = 0; i < count; i++)
        {
            rawFloats[i * 3] = unityVertices[i].x;
            rawFloats[i * 3 + 1] = unityVertices[i].y;
            rawFloats[i * 3 + 2] = unityVertices[i].z;
        }
        sw2.Stop();
        Debug.Log($"Manual Iteration Time: {sw2.ElapsedMilliseconds} ms");
    }
}
