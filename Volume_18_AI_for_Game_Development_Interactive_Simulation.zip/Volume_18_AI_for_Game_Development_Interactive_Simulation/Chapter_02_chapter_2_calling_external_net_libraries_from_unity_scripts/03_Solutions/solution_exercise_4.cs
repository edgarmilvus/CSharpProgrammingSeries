
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using System.Linq; // For List manipulation

// 1. Interface for decoupling
public interface IPathfindingService
{
    Task<List<Vector3>> GetPathAsync(Vector3 start, Vector3 end);
    void UpdateGraphBounds(int width, int height);
}

// Mock external library class (Simulating GraphX or similar)
public class ExternalGraphLibrary
{
    public void AddNode(int id, float x, float y) { /* ... */ }
    public void RemoveNode(int id) { /* ... */ }
    public List<int> CalculatePath(int startId, int endId) { return new List<int> { 1, 2, 3 }; }
}

public class DynamicPathfindingManager : MonoBehaviour, IPathfindingService
{
    // Thread safety lock object
    private readonly object _syncRoot = new object();
    private ExternalGraphLibrary _graphLibrary;
    
    // State tracking
    private bool _isGraphReady = true;

    private void Awake()
    {
        _graphLibrary = new ExternalGraphLibrary();
    }

    // 2. Dynamic Graph Modification
    public void UpdateGraphBounds(int width, int height)
    {
        // In a real scenario, this would rebuild the graph nodes.
        // Since this is CPU intensive, we run it on a background thread.
        Task.Run(() =>
        {
            lock (_syncRoot)
            {
                _isGraphReady = false;
                Debug.Log($"Rebuilding graph to {width}x{height} on thread {System.Threading.Thread.CurrentThread.ManagedThreadId}");
                
                // Simulate heavy processing
                System.Threading.Thread.Sleep(500); 
                
                // Update external library
                // _graphLibrary.Clear();
                // _graphLibrary.GenerateGrid(width, height);
                
                _isGraphReady = true;
            }
        });
    }

    // 3. Asynchronous Path Request
    public async Task<List<Vector3>> GetPathAsync(Vector3 start, Vector3 end)
    {
        // Wait for graph to be ready
        while (!_isGraphReady)
        {
            await Task.Delay(50); // Polling efficiently
        }

        // Offload calculation to background thread
        return await Task.Run(() =>
        {
            lock (_syncRoot)
            {
                // Map Vector3 coordinates to node IDs (Simplified logic)
                int startId = (int)start.x; // Dummy mapping
                int endId = (int)end.x;

                // Call external library
                List<int> pathIds = _graphLibrary.CalculatePath(startId, endId);

                // Convert back to Vector3 (Simulated)
                List<Vector3> path = new List<Vector3>();
                foreach (var id in pathIds)
                {
                    path.Add(new Vector3(id, 0, id));
                }

                return path;
            }
        });
    }

    // 4. Interactive Challenge: UI Integration
    public void OnGridSizeChanged(int newSize)
    {
        UpdateGraphBounds(newSize, newSize);
    }

    public async void OnPathRequested(Vector3 start, Vector3 end)
    {
        List<Vector3> path = await GetPathAsync(start, end);
        
        // Important: Return to Main Thread to update Unity Transforms
        // (Unity API calls are not thread safe)
        MainThreadDispatcher.Instance.Enqueue(() => 
        {
            VisualizePath(path);
        });
    }

    private void VisualizePath(List<Vector3> path)
    {
        Debug.Log($"Path received with {path.Count} nodes.");
        // Logic to draw lines or move objects
    }
}

// Helper class to execute actions on the main thread
public class MainThreadDispatcher : MonoBehaviour
{
    private static MainThreadDispatcher _instance;
    private readonly Queue<System.Action> _actions = new Queue<System.Action>();

    public static MainThreadDispatcher Instance 
    {
        get 
        {
            if (_instance == null)
            {
                GameObject go = new GameObject("MainThreadDispatcher");
                DontDestroyOnLoad(go);
                _instance = go.AddComponent<MainThreadDispatcher>();
            }
            return _instance;
        }
    }

    public void Enqueue(System.Action action)
    {
        lock (_actions)
        {
            _actions.Enqueue(action);
        }
    }

    void Update()
    {
        lock (_actions)
        {
            while (_actions.Count > 0)
            {
                _actions.Dequeue().Invoke();
            }
        }
    }
}
