
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using MathNet.Numerics.LinearAlgebra; // Required namespace for matrix operations
using System; // For Exception handling

// This script must be placed in a folder associated with the 'GameLogic.asmdef' assembly.
// Ensure 'GameLogic.asmdef' references the 'MathNet.Numerics' assembly in the Inspector.
public class MatrixCalculator : MonoBehaviour
{
    // Struct to hold matrix data for Inspector input
    [Serializable]
    public struct Matrix3x3
    {
        public float m00, m01, m02;
        public float m10, m11, m12;
        public float m20, m21, m22;
    }

    [Header("Input Matrix")]
    public Matrix3x3 inputMatrix;

    [Header("Control")]
    [Tooltip("Click this button in the Inspector to calculate the determinant.")]
    [ContextMenu("Calculate Determinant")]
    public bool calculateTrigger; // Dummy field to show context menu in Inspector

    void Start()
    {
        // Optional: Run a calculation on start for testing
        CalculateAndLogDeterminant();
    }

    // Explicit method called by the ContextMenu or other scripts
    [ContextMenu("Calculate Determinant")]
    public void CalculateAndLogDeterminant()
    {
        try
        {
            // Convert the Inspector struct to a MathNet DenseMatrix
            var matrix = DenseMatrix.OfArray(new double[,]
            {
                { inputMatrix.m00, inputMatrix.m01, inputMatrix.m02 },
                { inputMatrix.m10, inputMatrix.m11, inputMatrix.m12 },
                { inputMatrix.m20, inputMatrix.m21, inputMatrix.m22 }
            });

            // Calculate determinant
            double determinant = matrix.Determinant();

            // Handle singular matrix edge case
            if (Math.Abs(determinant) < 0.00001f)
            {
                Debug.LogWarning($"Matrix is singular (Determinant is effectively zero): {determinant}");
            }
            else
            {
                Debug.Log($"Matrix Determinant: {determinant}");
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"Failed to calculate determinant: {ex.Message}");
        }
    }
}
