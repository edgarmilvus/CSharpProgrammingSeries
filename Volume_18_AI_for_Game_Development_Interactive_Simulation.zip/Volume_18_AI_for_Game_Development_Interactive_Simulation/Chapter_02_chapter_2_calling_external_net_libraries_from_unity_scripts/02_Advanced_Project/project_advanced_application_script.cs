
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace GameAnalyticsDashboard
{
    /// <summary>
    /// Represents a single player's session data.
    /// This is a basic class (no generics or records) used to structure raw data.
    /// </summary>
    public class PlayerSession
    {
        public string PlayerId;
        public string Region;
        public double SessionDurationMinutes;
        public int EnemiesDefeated;
        public bool IsPremiumUser;

        public PlayerSession(string id, string region, double duration, int enemies, bool premium)
        {
            PlayerId = id;
            Region = region;
            SessionDurationMinutes = duration;
            EnemiesDefeated = enemies;
            IsPremiumUser = premium;
        }
    }

    /// <summary>
    /// Simulates an external .NET library for fetching raw telemetry data.
    /// In a real scenario, this might wrap an SDK like Application Insights or a custom DLL.
    /// </summary>
    public static class TelemetryService
    {
        // Mock data source to simulate an external API call
        private static readonly List<PlayerSession> MockDatabase = new List<PlayerSession>
        {
            new PlayerSession("P001", "NA", 45.5, 120, true),
            new PlayerSession("P002", "EU", 12.0, 30, false),
            new PlayerSession("P003", "ASIA", 90.2, 450, true),
            new PlayerSession("P004", "NA", 5.5, 5, false),
            new PlayerSession("P005", "EU", 60.0, 200, true),
            new PlayerSession("P006", "ASIA", 30.0, 80, false)
        };

        /// <summary>
        /// Simulates an async network request to retrieve player data.
        /// </summary>
        public static async Task<List<PlayerSession>> FetchSessionDataAsync()
        {
            // Simulate network latency
            await Task.Delay(500); 
            return MockDatabase;
        }
    }

    /// <summary>
    /// The core logic processor. This class handles data analysis using basic loops and conditionals.
    /// </summary>
    public class AnalyticsEngine
    {
        private List<PlayerSession> _sessions;

        public AnalyticsEngine(List<PlayerSession> sessions)
        {
            _sessions = sessions;
        }

        /// <summary>
        /// Calculates the average session duration for a specific region.
        /// </summary>
        public double GetAverageDurationByRegion(string region)
        {
            double totalDuration = 0;
            int count = 0;

            // Basic loop to iterate through data
            for (int i = 0; i < _sessions.Count; i++)
            {
                if (_sessions[i].Region == region)
                {
                    totalDuration += _sessions[i].SessionDurationMinutes;
                    count++;
                }
            }

            if (count == 0) return 0.0;
            return totalDuration / count;
        }

        /// <summary>
        /// Identifies top-performing premium players based on enemies defeated.
        /// </summary>
        public List<string> GetTopPremiumPlayers(int threshold)
        {
            List<string> topPlayers = new List<string>();

            foreach (var session in _sessions)
            {
                // Conditional logic to filter data
                if (session.IsPremiumUser && session.EnemiesDefeated > threshold)
                {
                    topPlayers.Add(session.PlayerId);
                }
            }

            return topPlayers;
        }
    }

    /// <summary>
    /// Main entry point. Simulates a Unity script calling an external library 
    /// and processing the results.
    /// </summary>
    class Program
    {
        // Entry point for the console application
        static async Task Main(string[] args)
        {
            Console.WriteLine("Initializing Game Analytics Dashboard...");
            Console.WriteLine("--------------------------------------");

            try
            {
                // 1. CALL EXTERNAL LIBRARY
                // We await the data fetch, simulating the bridging of async C# logic.
                Console.WriteLine("Fetching telemetry data from external service...");
                List<PlayerSession> rawData = await TelemetryService.FetchSessionDataAsync();
                Console.WriteLine($"Data received: {rawData.Count} records.");

                // 2. INITIALIZE ANALYTICS ENGINE
                // Passing data into our processing logic.
                AnalyticsEngine engine = new AnalyticsEngine(rawData);

                // 3. PERFORM COMPLEX CALCULATIONS
                // Calculate average duration for the 'NA' region.
                double avgDurationNA = engine.GetAverageDurationByRegion("NA");
                Console.WriteLine($"\nAverage Session Duration (NA Region): {avgDurationNA:F2} minutes");

                // 4. FILTER AND EXTRACT INSIGHTS
                // Identify premium players who defeated more than 100 enemies.
                int killThreshold = 100;
                List<string> topPlayers = engine.GetTopPremiumPlayers(killThreshold);

                Console.WriteLine($"\nTop Premium Players (Kills > {killThreshold}):");
                if (topPlayers.Count > 0)
                {
                    foreach (string id in topPlayers)
                    {
                        Console.WriteLine($" - Player ID: {id}");
                    }
                }
                else
                {
                    Console.WriteLine(" No players met the criteria.");
                }
            }
            catch (Exception ex)
            {
                // Basic error handling
                Console.WriteLine($"Error processing analytics: {ex.Message}");
            }

            Console.WriteLine("\nDashboard Update Complete.");
        }
    }
}
