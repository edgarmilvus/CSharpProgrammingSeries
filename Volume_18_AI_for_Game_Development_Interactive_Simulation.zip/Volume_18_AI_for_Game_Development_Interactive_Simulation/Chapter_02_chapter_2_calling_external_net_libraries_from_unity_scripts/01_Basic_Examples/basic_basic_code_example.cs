
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

// 1. Import necessary namespaces
// System.Linq is required for the .Sum() extension method used on collections.
using System.Linq;
// We import the namespace from the external NuGet package.
using MathNet.Numerics.Statistics;
// Standard Unity namespaces.
using UnityEngine;
using System.Collections.Generic;

// 2. Define the wrapper class
// This class must inherit from MonoBehaviour to attach to a GameObject in the Unity scene.
public class InventoryAnalyzer : MonoBehaviour
{
    // 3. Define the data structure
    // A simple class to represent an item in the player's inventory.
    public class GameItem
    {
        public string Name { get; set; }
        public double AttackPower { get; set; }
        public double DefenseRating { get; set; }
    }

    // 4. Mock Data Generation
    // A list to hold our inventory items. In a real game, this would be loaded from a database or JSON.
    private List<GameItem> _inventory = new List<GameItem>();

    // 5. Unity Lifecycle: Start
    // Called on the frame when a script is enabled just before any of the Update methods are called the first time.
    void Start()
    {
        // Populate the inventory with dummy data
        InitializeInventory();

        // 6. Perform the calculation
        // We calculate the "Power Level" using the Geometric Mean of all Attack Powers.
        // The Geometric Mean is often better than the Arithmetic Mean for multiplicative scales (like RPG stats).
        double powerLevel = CalculatePowerLevel();

        // 7. Output the result
        Debug.Log($"Calculated Geometric Mean (Power Level): {powerLevel:F2}");
    }

    private void InitializeInventory()
    {
        _inventory.Add(new GameItem { Name = "Iron Sword", AttackPower = 15.5, DefenseRating = 2.0 });
        _inventory.Add(new GameItem { Name = "Steel Shield", AttackPower = 5.0, DefenseRating = 25.0 });
        _inventory.Add(new GameItem { Name = "Dragon Helm", AttackPower = 8.2, DefenseRating = 18.5 });
        _inventory.Add(new GameItem { Name = "Magic Amulet", AttackPower = 12.0, DefenseRating = 10.0 });
    }

    private double CalculatePowerLevel()
    {
        // 8. Data Extraction
        // We need to extract just the AttackPower values into a format MathNet understands (IEnumerable<double>).
        // Using LINQ's Select method projects each item into its AttackPower property.
        IEnumerable<double> attackValues = _inventory.Select(item => item.AttackPower);

        // 9. Calling the External Library
        // We call the static extension method 'GeometricMean' provided by the MathNet.Numerics.Statistics namespace.
        // This performs the complex statistical calculation that we did not have to write ourselves.
        double geometricMean = attackValues.GeometricMean();

        // 10. Return the result
        return geometricMean;
    }
}
