
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

/*
 * PROBLEM CONTEXT: DYNAMIC LORE GENERATION FOR AN RPG INVENTORY SYSTEM
 * 
 * In a modern RPG, players constantly acquire items with varying properties. 
 * Static, hand-written descriptions become repetitive and fail to reflect the 
 * player's unique journey. This application solves the "Static Lore Problem" by 
 * implementing a procedural narrative engine.
 * 
 * SCENARIO: 
 * You are a Game Developer working on "Aetheria," an open-world fantasy RPG. 
 * The design team wants every loot drop to feel unique. Instead of a generic 
 * "Iron Sword," the player might find "The Scorched Iron Sword of the Fallen 
 * Guard," with a description that hints at its origin based on where it was 
 * found (e.g., a volcano vs. a graveyard).
 * 
 * SOLUTION OVERVIEW:
 * We will build a modular Lore Generator using the "Builder Pattern" and 
 * "Context Injection." This system will:
 * 1. Define raw narrative components (Adjectives, Origins, Flavors).
 * 2. Construct item names dynamically based on rarity and type.
 * 3. Generate multi-sentence descriptions that weave the item's properties 
 *    into a cohesive story snippet.
 * 4. Output formatted text suitable for Unity's UI Text components.
 */

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("=== AETHERIA: DYNAMIC LORE GENERATOR v1.0 ===\n");

        // 1. Initialize the Narrative Database
        // In a real Unity game, this data would be loaded from JSON/ScriptableObjects.
        NarrativeDatabase db = new NarrativeDatabase();
        db.Initialize();

        // 2. Define a Player Context
        // This simulates the game state at the moment of item generation.
        PlayerContext context = new PlayerContext
        {
            CurrentRegion = "Volcanic Peaks",
            PlayerClass = "Pyromancer",
            CurrentLevel = 12
        };

        // 3. Generate Sample Items
        // We simulate looting 3 different items to demonstrate variability.
        Console.WriteLine("Generating Loot...\n");

        // Case 1: A Common Weapon found in current region
        GenerateItemLoot(db, context, ItemType.Weapon, Rarity.Common);

        // Case 2: A Rare Armor found in current region
        GenerateItemLoot(db, context, ItemType.Armor, Rarity.Rare);

        // Case 3: A Legendary Weapon found in a specific location (simulated override)
        // Note: We modify context slightly to show adaptability.
        context.CurrentRegion = "Frozen Wastes";
        GenerateItemLoot(db, context, ItemType.Weapon, Rarity.Legendary);
    }

    // Helper method to encapsulate the generation logic
    static void GenerateItemLoot(NarrativeDatabase db, PlayerContext context, ItemType type, Rarity rarity)
    {
        // Instantiate the builder
        LoreBuilder builder = new LoreBuilder(db, context);

        // Construct the item
        ItemLore item = builder
            .SetType(type)
            .SetRarity(rarity)
            .Build();

        // Output the result
        Console.WriteLine(item.GetFormattedDisplay());
        Console.WriteLine(new string('-', 40));
    }
}

// ==========================================
// DATA STRUCTURES & MODELS
// ==========================================

public enum ItemType { Weapon, Armor, Trinket }
public enum Rarity { Common, Uncommon, Rare, Legendary }

// Represents the current state of the player, essential for contextual generation.
public class PlayerContext
{
    public string CurrentRegion { get; set; }
    public string PlayerClass { get; set; }
    public int CurrentLevel { get; set; }
}

// Represents the final generated item with name and lore.
public class ItemLore
{
    public string Name { get; set; }
    public string Description { get; set; }
    public Rarity Rarity { get; set; }

    public string GetFormattedDisplay()
    {
        // Color coding simulation for console output
        string rarityColor = Rarity == Rarity.Legendary ? "GOLD" : 
                             Rarity == Rarity.Rare ? "PURPLE" : 
                             Rarity == Rarity.Uncommon ? "GREEN" : "WHITE";
        
        return $"[{rarityColor}] {Name} [/{rarityColor}]\n" +
               $"Type: {Rarity} Item\n" +
               $"Lore: {Description}";
    }
}

// ==========================================
// NARRATIVE DATABASE (The Knowledge Base)
// ==========================================

public class NarrativeDatabase
{
    // Arrays to hold narrative fragments. 
    // In Expert Mode, we use Lists for dynamic sizing, but arrays are fine for static data.
    public List<string> WeaponAdjectives { get; private set; }
    public List<string> ArmorAdjectives { get; private set; }
    public List<string> Origins { get; private set; }
    public List<string> FlavorTexts { get; private set; }

    public void Initialize()
    {
        WeaponAdjectives = new List<string>
        {
            "Rusted", "Gleaming", "Singed", "Frostbitten", "Ethereal", "Obsidian"
        };

        ArmorAdjectives = new List<string>
        {
            "Dented", "Polished", "Ashen", "Icy", "Spectral", "Imbued"
        };

        Origins = new List<string>
        {
            "of the Fallen Guard", "of the Deep Mines", "of the North Wind", 
            "of the Void Walker", "belonging to a Lost King", "crafted by Goblins"
        };

        FlavorTexts = new List<string>
        {
            "It hums with a faint energy.",
            "Cold to the touch, yet warms the soul.",
            "Smells of sulfur and regret.",
            "Traces of ancient runes are barely visible.",
            "It feels heavier than it looks."
        };
    }

    public string GetRandomAdjective(ItemType type, Rarity rarity)
    {
        // Logic to pick adjectives based on type and rarity
        List<string> sourceList = (type == ItemType.Weapon) ? WeaponAdjectives : ArmorAdjectives;
        
        // Basic weighting: Higher rarity gets access to more exotic adjectives (simulated by index)
        // In a real scenario, we'd have separate arrays for tiers.
        int maxIndex = sourceList.Count;
        int index = (int)rarity; // 0=Common, 3=Legendary
        
        // Clamp index to avoid out of bounds
        if (index >= maxIndex) index = maxIndex - 1;
        
        return sourceList[index];
    }

    public string GetRandomOrigin()
    {
        // Simple random selection
        Random rnd = new Random();
        return Origins[rnd.Next(Origins.Count)];
    }

    public string GetFlavorText(PlayerContext context)
    {
        // Context-aware flavor text generation
        // If in Volcanic Peaks, prioritize "Singed" flavor
        if (context.CurrentRegion.Contains("Volcanic"))
        {
            return "Radiates a comforting, dry heat.";
        }
        if (context.CurrentRegion.Contains("Frozen"))
        {
            return "A layer of frost clings to the surface.";
        }
        return FlavorTexts[new Random().Next(FlavorTexts.Count)];
    }
}

// ==========================================
// THE LORE BUILDER (Logic Core)
// ==========================================

public class LoreBuilder
{
    private readonly NarrativeDatabase _db;
    private readonly PlayerContext _context;
    
    // State variables for the item being built
    private ItemType _type;
    private Rarity _rarity;

    public LoreBuilder(NarrativeDatabase db, PlayerContext context)
    {
        _db = db;
        _context = context;
    }

    // Fluent Interface Methods
    public LoreBuilder SetType(ItemType type)
    {
        _type = type;
        return this;
    }

    public LoreBuilder SetRarity(Rarity rarity)
    {
        _rarity = rarity;
        return this;
    }

    // The Core Construction Method
    public ItemLore Build()
    {
        ItemLore item = new ItemLore();
        item.Rarity = _rarity;

        // 1. Construct the Name
        // Logic: [Adjective] [Type] [Origin]
        string adjective = _db.GetRandomAdjective(_type, _rarity);
        string typeStr = _type.ToString();
        string origin = _db.GetRandomOrigin();

        // For Common items, we might skip the Origin to keep it simple
        if (_rarity == Rarity.Common)
        {
            item.Name = $"{adjective} {typeStr}";
        }
        else
        {
            item.Name = $"{adjective} {typeStr} {origin}";
        }

        // 2. Construct the Description
        // Logic: A 2-3 sentence paragraph mixing database flavor and context.
        item.Description = GenerateDescription();

        return item;
    }

    // Private helper to handle the narrative logic
    private string GenerateDescription()
    {
        // Sentence 1: The "Hook" - Based on Region
        string sentence1 = $"Found in the {_context.CurrentRegion}, this item bears the marks of its origin. ";

        // Sentence 2: The "Properties" - Based on Rarity and Type
        string qualityDescriptor = "";
        switch (_rarity)
        {
            case Rarity.Common:
                qualityDescriptor = "simple but sturdy";
                break;
            case Rarity.Uncommon:
                qualityDescriptor = "well-balanced";
                break;
            case Rarity.Rare:
                qualityDescriptor = "imbued with magical potential";
                break;
            case Rarity.Legendary:
                qualityDescriptor = "destined for greatness";
                break;
        }

        string sentence2 = $"It is {qualityDescriptor}, making it a valuable asset for a {_context.PlayerClass}. ";

        // Sentence 3: The "Flavor" - Random atmospheric detail
        string sentence3 = _db.GetFlavorText(_context);

        // Combine
        return sentence1 + sentence2 + sentence3;
    }
}
