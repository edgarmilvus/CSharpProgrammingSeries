
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

// 1. Data Structures
public enum Tone { Neutral, Menacing, Whimsical, Melancholic }

public readonly record struct ItemData(
    Guid Id, 
    string Name, 
    string BaseDescription, 
    int RarityLevel, 
    List<string> Tags,
    Tone ItemTone
);

public record PlayerContext(
    int CurrentLevel, 
    string LastEnemyDefeated, 
    string CurrentBiome
);

// 2. Context Aggregation & Prompt Engineering
public static class PromptBuilder
{
    public static string ConstructPrompt(ItemData item, PlayerContext context)
    {
        string rarityWord = item.RarityLevel switch
        {
            1 => "common",
            2 => "uncommon",
            3 => "rare",
            4 => "epic",
            5 => "legendary",
            _ => "mythic"
        };

        string toneInstruction = item.ItemTone switch
        {
            Tone.Menacing => "Use a dark, threatening tone.",
            Tone.Whimsical => "Use a playful, fairy-tale tone.",
            Tone.Melancholic => "Use a sorrowful, reflective tone.",
            _ => "Use a neutral, descriptive tone."
        };

        return $"""
            You are a creative writer for a fantasy RPG. Generate a short description (20-50 words) for an item.
            
            Item: {item.Name}
            Rarity: {rarityWord}
            Tags: {string.Join(", ", item.Tags)}
            Context: The player (Level {context.CurrentLevel}) is in {context.CurrentBiome} and recently defeated {context.LastEnemyDefeated}.
            
            {toneInstruction}
            Incorporate the item's rarity and the player's recent activity into the narrative.
            """;
    }
}

// 3. Asynchronous Generation & Caching
public class ItemDescriptionGenerator
{
    private readonly HttpClient _httpClient;
    private readonly ConcurrentDictionary<string, string> _cache = new();
    
    // Mock API URL (replace with real endpoint)
    private const string ApiUrl = "https://api.mock-llm.com/generate";

    public ItemDescriptionGenerator(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<string> GenerateDescriptionAsync(ItemData item, PlayerContext context)
    {
        // 4. Caching: Composite key includes ItemID, PlayerLevel, and Tone (Interactive Challenge requirement)
        string cacheKey = $"{item.Id}_{context.CurrentLevel}_{item.ItemTone}";
        
        if (_cache.TryGetValue(cacheKey, out var cachedDescription))
        {
            return cachedDescription;
        }

        string prompt = PromptBuilder.ConstructPrompt(item, context);
        string generatedDescription;

        try
        {
            // Simulate API Call
            var payload = new { prompt = prompt };
            var content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json");
            
            // Using a timeout to prevent UI freezing
            using var cts = new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(5));
            
            var response = await _httpClient.PostAsync(ApiUrl, content, cts.Token);
            response.EnsureSuccessStatusCode();
            
            var jsonResponse = await response.Content.ReadAsStringAsync();
            // Assuming API returns { "text": "..." }
            var result = JsonSerializer.Deserialize<ApiResult>(jsonResponse);
            generatedDescription = result?.Text ?? throw new Exception("Empty response");
        }
        catch (Exception ex)
        {
            // Fallback to BaseDescription on failure
            Console.WriteLine($"API Error: {ex.Message}");
            generatedDescription = item.BaseDescription;
        }

        // Store in cache
        _cache.TryAdd(cacheKey, generatedDescription);
        return generatedDescription;
    }

    private record ApiResult(string Text);
}
