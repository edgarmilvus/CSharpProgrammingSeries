
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// 1. Analyze the Flaw
// Context Drift occurs because LLMs have a limited context window. 
// As history grows, the model forgets the earliest messages. 
// Furthermore, without a guiding "North Star" (Theme/NPCs), the model tends to wander into irrelevant tangents.

public record struct NarrativeFocus(string PrimaryTheme, List<string> KeyNPCs);

public enum PlayerActionType { FoundArtifact, KilledFriendlyNPC, ExploredNewArea }

public record PlayerAction(PlayerActionType Type, string Detail);

public class AdvancedGenerator
{
    private NarrativeFocus _currentFocus = new("Discovery", new List<string> { "The Guide" });
    private List<string> _conversationHistory = new();

    // 3. Refactor the Generator
    public async Task<string> GenerateResponse(string playerInput)
    {
        // 4. Optimization: Summarize older history
        string historyContext = await SummarizeHistory(_conversationHistory.TakeLast(3).ToList(), _conversationHistory.SkipLast(3).ToList());

        // 3. Inject Narrative Focus
        string systemPrompt = $"""
            You are a narrative engine.
            Current Narrative Focus: Theme='{_currentFocus.PrimaryTheme}', NPCs={string.Join(", ", _currentFocus.KeyNPCs)}.
            You MUST prioritize these elements in your response.
            Recent Chat History: {historyContext}
            Player says: {playerInput}
            """;

        string response = await SimulateLLM(systemPrompt);
        
        _conversationHistory.Add($"Player: {playerInput}");
        _conversationHistory.Add($"NPC: {response}");
        
        return response;
    }

    // 4. Dynamic Focus Shift
    public void UpdateFocusBasedOnPlayerAction(PlayerAction action)
    {
        switch (action.Type)
        {
            case PlayerActionType.FoundArtifact:
                _currentFocus = _currentFocus with { PrimaryTheme = "Betrayal" }; // Using 'with' expression (modern C#)
                if (!_currentFocus.KeyNPCs.Contains("The Ancient One"))
                    _currentFocus.KeyNPCs.Add("The Ancient One");
                break;
            case PlayerActionType.KilledFriendlyNPC:
                _currentFocus = _currentFocus with { PrimaryTheme = "Guilt" };
                break;
        }
    }

    // 5. Optimization: Summarization
    private async Task<string> SummarizeHistory(List<string> recent, List<string> old)
    {
        if (!old.Any()) return string.Join("\n", recent);

        // Send old history to LLM to get a dense summary
        string summaryPrompt = $"Summarize the following conversation into 2 sentences: {string.Join("\n", old)}";
        string summary = await SimulateLLM(summaryPrompt);
        
        return $"[Summary of past events]: {summary}\n[Recent]: {string.Join("\n", recent)}";
    }

    private async Task<string> SimulateLLM(string prompt)
    {
        await Task.Delay(50);
        return "The narrative flows according to your focus...";
    }
}
