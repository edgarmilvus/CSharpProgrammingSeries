
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

public enum GameEra { TheAgeOfFire, TheGreatWar, TheSilentWinter }

public class LoreGenerator
{
    // 2. Summary Anchor
    private static readonly Dictionary<GameEra, string> CanonicalSummaries = new()
    {
        { GameEra.TheAgeOfFire, "Dragons ruled the skies. Magic was volatile. The first cities were built in volcanic craters." },
        { GameEra.TheGreatWar, "A conflict between the Empire of Light and the Shadow Cult. Ended with the Sundering." },
        { GameEra.TheSilentWinter, "A magical ice age caused by the death of the Sun God. Survival is scarce." }
    };

    // 3. Generation Logic
    public async Task<List<string>> GenerateLoreBook(GameEra era, int bookLengthPages)
    {
        string canonical = CanonicalSummaries[era];
        string prompt = $"""
            Write a lore book entry for the era: {era}.
            Canonical Summary: {canonical}
            Length: Approximately {bookLengthPages * 200} words.
            Ensure the narrative strictly adheres to the summary provided.
            """;

        // Simulate LLM call
        string fullText = await SimulateLLMCall(prompt);

        // 4. Pagination Handling
        return SplitIntoPages(fullText, 500); // 500 chars per page
    }

    private List<string> SplitIntoPages(string text, int charLimit)
    {
        var pages = new List<string>();
        var sb = new StringBuilder();
        
        // Split by sentences to avoid cutting words
        var sentences = Regex.Split(text, @"(?<=[.!?])\s+");
        
        foreach (var sentence in sentences)
        {
            if (sb.Length + sentence.Length > charLimit)
            {
                pages.Add(sb.ToString());
                sb.Clear();
            }
            sb.Append(sentence + " ");
        }
        
        if (sb.Length > 0) pages.Add(sb.ToString());
        return pages;
    }

    // 5. Consistency Check (Simulation)
    public async Task<bool> VerifyConsistency(GameEra era, string generatedText)
    {
        string prompt = $"""
            Extract 5 key facts from the following text as a comma-separated list:
            {generatedText}
            """;
        
        string factsStr = await SimulateLLMCall(prompt);
        var extractedFacts = factsStr.Split(',').Select(f => f.Trim().ToLower()).ToList();
        
        string canonical = CanonicalSummaries[era].ToLower();
        int matches = extractedFacts.Count(f => canonical.Contains(f));
        
        // Threshold 50%
        return (matches / (float)extractedFacts.Count) >= 0.5f;
    }

    // Mock helper
    private async Task<string> SimulateLLMCall(string prompt)
    {
        await Task.Delay(100); // Simulate network latency
        return "The Age of Fire began with a spark. Dragons soared above the molten rivers. " +
               "People huddled in caves, fearing the heat. Yet, magic was born in this chaos. " +
               "It was a time of great danger and greater opportunity.";
    }
}
