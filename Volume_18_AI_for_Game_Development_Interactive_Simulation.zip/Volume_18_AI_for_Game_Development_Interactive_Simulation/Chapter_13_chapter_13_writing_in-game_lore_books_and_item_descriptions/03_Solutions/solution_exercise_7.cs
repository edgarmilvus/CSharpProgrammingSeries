
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.cs
// Description: Solution for Exercise 7
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class NPCProfile
{
    public string Name { get; set; }
    public string PersonalityTraits { get; set; }
    public string CurrentMood { get; set; }
    // 5. State Persistence
    public List<string> InteractionHistory { get; } = new();
}

public class DialogueOption
{
    public string Text { get; set; }
    public string ContextKey { get; set; } // e.g., "Betrayal", "Agreement"
}

public class DialogueNode
{
    public string Text { get; set; }
    public List<DialogueOption> Options { get; set; }
    public string SpeakerID { get; set; }
}

public class DialogueGenerator
{
    // 3. Generation Logic
    public async Task<DialogueNode> GenerateDialogue(NPCProfile profile, string playerInput, DialogueNode previousNode)
    {
        // Construct history context from the tree traversal or profile history
        string historyContext = string.Join("\n", profile.InteractionHistory.TakeLast(5));
        
        // 4. Option Validation will happen after generation, but we guide the LLM
        string prompt = $"""
            NPC Profile: {profile.Name}, {profile.PersonalityTraits}, Mood: {profile.CurrentMood}.
            Recent History: {historyContext}
            Player says: "{playerInput}"
            
            Generate the NPC's response and 3 distinct dialogue options for the player.
            Format as:
            RESPONSE: [Text]
            OPTION 1: [Text] | [ContextKey]
            OPTION 2: [Text] | [ContextKey]
            OPTION 3: [Text] | [ContextKey]
            """;

        string rawResponse = await SimulateLLM(prompt);
        
        // Parse Response (Simplified)
        var lines = rawResponse.Split('\n');
        var responseText = lines.FirstOrDefault(l => l.StartsWith("RESPONSE:"))?.Substring(9).Trim();
        
        var options = lines
            .Where(l => l.StartsWith("OPTION"))
            .Select(l => l.Split('|'))
            .Select(parts => new DialogueOption 
            { 
                Text = parts[0].Substring(parts[0].IndexOf(':') + 1).Trim(), 
                ContextKey = parts[1].Trim() 
            })
            .ToList();

        // 4. Option Validation (Simple Check)
        if (options.Count < 3) 
        {
            // Fallback if LLM fails to generate 3 options
            options.Add(new DialogueOption { Text = "Say nothing.", ContextKey = "Silence" });
        }

        return new DialogueNode
        {
            Text = responseText,
            Options = options,
            SpeakerID = profile.Name
        };
    }

    // 5. State Persistence
    public void SaveKeyDialogueChoice(DialogueNode node, int optionIndex, NPCProfile profile)
    {
        if (optionIndex >= 0 && optionIndex < node.Options.Count)
        {
            var choice = node.Options[optionIndex];
            profile.InteractionHistory.Add($"Player chose: {choice.Text} ({choice.ContextKey})");
            
            // Update Mood based on context
            if (choice.ContextKey == "Betrayal") profile.CurrentMood = "Angry";
            if (choice.ContextKey == "Agreement") profile.CurrentMood = "Friendly";
        }
    }

    private async Task<string> SimulateLLM(string prompt)
    {
        await Task.Delay(50);
        return """
            RESPONSE: I understand. Be careful out there.
            OPTION 1: I will return soon. | Promise
            OPTION 2: I need supplies. | Trade
            OPTION 3: Watch your back. | Warning
            """;
    }
}
