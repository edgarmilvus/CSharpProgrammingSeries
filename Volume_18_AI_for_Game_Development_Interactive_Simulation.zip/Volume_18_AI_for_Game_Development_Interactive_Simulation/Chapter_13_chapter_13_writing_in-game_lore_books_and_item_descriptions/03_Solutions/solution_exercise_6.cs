
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

public record BookData(string Title, string Summary, string Content = "");

public class LibraryGenerator
{
    private readonly HttpClient _httpClient;
    private readonly SemaphoreSlim _throttle = new(3, 3); // Limit to 3 concurrent requests

    public LibraryGenerator(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // 1. Batch Prompt Construction
    public string ConstructBatchPrompt(List<string> bookTopics)
    {
        string topicsList = string.Join(", ", bookTopics);
        return $"""
            Generate a library catalog for topics: {topicsList}.
            Return the result as a JSON array of objects.
            Each object must have "Title" and "Summary" properties.
            Do not include any text outside the JSON array.
            """;
    }

    public async Task<List<BookData>> GenerateLibraryAsync(List<string> topics, Action<float> onProgress)
    {
        // 2. Batch Generation
        string prompt = ConstructBatchPrompt(topics);
        string jsonResponse = await CallLLM(prompt);
        
        List<BookData> books;
        try
        {
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            books = JsonSerializer.Deserialize<List<BookData>>(jsonResponse, options);
        }
        catch (JsonException)
        {
            // 4. Error Resilience: Fallback to sequential
            Console.WriteLine("Batch generation failed. Falling back to sequential.");
            books = await GenerateSequentially(topics);
        }

        // 3. Parallel Expansion with Throttling
        var tasks = books.Select(async book =>
        {
            await _throttle.WaitAsync();
            try
            {
                // Simulate expanding summary to full content
                book.Content = await ExpandBookContent(book.Summary);
                onProgress?.Invoke(0.1f); // Report progress
            }
            finally
            {
                _throttle.Release();
            }
        }).ToList();

        await Task.WhenAll(tasks);
        
        return books;
    }

    private async Task<List<BookData>> GenerateSequentially(List<string> topics)
    {
        var list = new List<BookData>();
        foreach (var topic in topics)
        {
            string json = await CallLLM($"Generate a title and summary for: {topic}");
            // Simplified parsing for fallback
            try 
            {
                var book = JsonSerializer.Deserialize<BookData>(json);
                list.Add(book);
            } catch { /* Ignore error for brevity */ }
        }
        return list;
    }

    private async Task<string> ExpandBookContent(string summary)
    {
        await Task.Delay(100); // Simulate work
        return $"Full content based on: {summary} ... [End of Book]";
    }

    private async Task<string> CallLLM(string prompt)
    {
        // Mock API call
        await Task.Delay(50);
        // Returning a valid JSON array string
        return $$"""
            [
                {"Title": "The History of {{prompt.Substring(0, 5)}}", "Summary": "A short summary of {{prompt}}."}
            ]
            """;
    }
}
