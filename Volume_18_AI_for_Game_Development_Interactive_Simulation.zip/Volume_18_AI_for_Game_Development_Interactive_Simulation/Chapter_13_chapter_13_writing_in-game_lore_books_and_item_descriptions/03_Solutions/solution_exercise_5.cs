
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

// Mock interface for Unity TextMeshPro
public interface ITextMeshPro 
{
    void.SetText(string text);
    string text { get; set; }
}

public class TextStreamer
{
    private readonly ITextMeshPro _uiElement;
    private CancellationTokenSource _cts;

    public TextStreamer(ITextMeshPro uiElement)
    {
        _uiElement = uiElement;
    }

    // 4. Cancellation Token
    public void CancelStream()
    {
        _cts?.Cancel();
    }

    // 2. Typewriter Effect
    public async Task StreamText(string text, float baseSpeed)
    {
        _cts = new CancellationTokenSource();
        var token = _cts.Token;
        
        _uiElement.text = ""; // Clear UI

        var buffer = new StringBuilder();
        bool isBold = false;
        bool isItalic = false;

        for (int i = 0; i < text.Length; i++)
        {
            if (token.IsCancellationRequested)
            {
                // 4. On Cancel: Display full text immediately
                _uiElement.SetText(ParseMarkdown(text)); 
                return;
            }

            char c = text[i];

            // 5. Rich Text Parsing (Simple Markdown)
            if (c == '*' && i + 1 < text.Length)
            {
                if (text[i + 1] == '*')
                {
                    isBold = !isBold;
                    buffer.Append("<b>");
                    i++; // Skip second asterisk
                    continue;
                }
                else
                {
                    isItalic = !isItalic;
                    buffer.Append("<i>");
                    continue;
                }
            }

            buffer.Append(c);

            // Update UI (Simulating TMP update)
            _uiElement.SetText(buffer.ToString());

            // 3. Punctuation Handling
            float delay = baseSpeed;
            if (c == '.' || c == '!' || c == '?') delay = 0.5f;
            else if (c == ',') delay = 0.1f;

            await Task.Delay((int)(delay * 1000));
        }
    }

    private string ParseMarkdown(string input)
    {
        // Helper to strip markdown for final display if needed, 
        // though our streamer builds HTML tags directly.
        return input.Replace("**", "<b>").Replace("*", "<i>");
    }
}
