
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;

public enum ItemState { Dormant, Activated, Corrupted, Purified }

public class ItemInstance
{
    public Guid UniqueId { get; }
    public ItemState CurrentState { get; private set; }

    public ItemInstance(Guid id)
    {
        UniqueId = id;
        CurrentState = ItemState.Dormant;
    }

    // 5. Thread Safety: Locking for state updates
    private readonly object _stateLock = new();

    public void TransitionState(ItemState newState)
    {
        lock (_stateLock)
        {
            CurrentState = newState;
            // Simulate persistence
            StatePersistence.SaveState(UniqueId, newState);
        }
    }
}

public static class StatePersistence
{
    // 4. Persistence Simulation
    private static readonly ConcurrentDictionary<Guid, ItemState> _savedStates = new();

    public static void SaveState(Guid id, ItemState state) => _savedStates[id] = state;
    public static ItemState LoadState(Guid id) => _savedStates.TryGetValue(id, out var state) ? state : ItemState.Dormant;
}

public class HybridDescriptionGenerator
{
    // 2. State-Description Mapping
    private static readonly Dictionary<ItemState, string> StateModifiers = new()
    {
        { ItemState.Corrupted, "The item pulses with a dark energy..." },
        { ItemState.Purified, "A holy aura radiates from the hilt..." },
        { ItemState.Activated, "It hums with latent power." }
    };

    // 3. Hybrid Generation
    public string GetDescription(ItemInstance item, PlayerContext context, ItemData baseData)
    {
        // Ensure we have the latest state (simulating loading from DB if needed)
        item.CurrentState = StatePersistence.LoadState(item.UniqueId);

        if (item.CurrentState == ItemState.Dormant)
        {
            // Dynamic generation (as per Exercise 1)
            return $"[LLM Generated]: {baseData.BaseDescription} - A standard item for a Level {context.CurrentLevel} adventurer.";
        }

        // Specific State Logic
        string modifier = StateModifiers.GetValueOrDefault(item.CurrentState, "");
        
        // Dynamic snippet explaining WHY (simulated LLM call)
        string reasonSnippet = GetReasonForState(item.CurrentState);

        return $"{baseData.Name}\n{modifier}\n{baseData.BaseDescription}\n{reasonSnippet}";
    }

    private string GetReasonForState(ItemState state)
    {
        return state switch
        {
            ItemState.Corrupted => "(Corrupted by the Void Altar)",
            ItemState.Purified => "(Cleansed in the Holy Spring)",
            _ => ""
        };
    }
}
