
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_8.cs
// Description: Solution for Exercise 8
// ==========================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

// Modern C# DTOs using Records
public record GenerationRequest(
    string ContextSnapshot, 
    List<GameEvent> RecentEvents, 
    string PromptTemplate
);

public record GenerationResponse(
    string GeneratedText, 
    Guid RequestId, 
    DateTime Timestamp
);

public record GameEvent(string Type, string Detail, DateTime Time);

// Context Manager
public class ContextManager
{
    private readonly ILLMService _llmService;
    private readonly List<GameEvent> _eventHistory = new();

    public ContextManager(ILLMService llmService)
    {
        _llmService = llmService;
    }

    public void OnGameEvent(GameEvent gameEvent)
    {
        _eventHistory.Add(gameEvent);
        // In a real system, we might debounce this or trigger based on specific events
        _ = ProcessEventAsync(gameEvent);
    }

    private async Task ProcessEventAsync(GameEvent gameEvent)
    {
        // Aggregate context
        var request = new GenerationRequest(
            ContextSnapshot: $"Player Level: 10, Biome: Forest",
            RecentEvents: _eventHistory,
            PromptTemplate: "Describe the atmosphere based on recent events."
        );

        var response = await _llmService.GenerateAsync(request);
        
        // Notify UI or DB
        Console.WriteLine($"Generated Lore: {response.GeneratedText}");
    }
}

// LLM Service Interface
public interface ILLMService
{
    Task<GenerationResponse> GenerateAsync(GenerationRequest request);
}

public class LLMService : ILLMService
{
    private readonly HttpClient _httpClient;

    public LLMService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<GenerationResponse> GenerateAsync(GenerationRequest request)
    {
        // Serialize DTO
        var json = JsonSerializer.Serialize(request);
        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

        try 
        {
            // Simulate API Call
            var res = await _httpClient.PostAsync("https://api.llm.com/world-gen", content);
            res.EnsureSuccessStatusCode();
            
            var responseBody = await res.Content.ReadAsStringAsync();
            // Deserialize response
            return JsonSerializer.Deserialize<GenerationResponse>(responseBody) 
                   ?? new GenerationResponse("Default Text", Guid.NewGuid(), DateTime.UtcNow);
        }
        catch (Exception ex)
        {
            // Fallback logic
            return new GenerationResponse($"Error generating lore: {ex.Message}", Guid.NewGuid(), DateTime.UtcNow);
        }
    }
}
