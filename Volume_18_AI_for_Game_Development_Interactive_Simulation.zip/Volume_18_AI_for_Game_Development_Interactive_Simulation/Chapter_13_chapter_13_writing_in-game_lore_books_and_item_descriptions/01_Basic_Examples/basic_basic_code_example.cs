
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Represents the context in which an item description is being generated.
/// This allows the LLM to tailor the text based on player state, location, or actions.
/// </summary>
public struct GenerationContext
{
    public string PlayerName;
    public string CurrentBiome;
    public int PlayerLevel;
    public string ItemRarity; // e.g., "Common", "Rare", "Legendary"
    public string ItemType;   // e.g., "Sword", "Potion", "Book"
}

/// <summary>
/// A mock interface for an LLM service. In a real project, this would wrap an API call
/// to a service like OpenAI, Azure AI, or a local model.
/// </summary>
public interface ILLMService
{
    Task<string> GenerateTextAsync(string prompt);
}

/// <summary>
/// A concrete implementation of the LLM service for demonstration purposes.
/// This simulates an API call with a delay and returns a hardcoded response
/// to ensure the example is runnable without external dependencies.
/// </summary>
public class MockLLMService : ILLMService
{
    public async Task<string> GenerateTextAsync(string prompt)
    {
        // Simulate network latency
        await Task.Delay(100); 

        // In a real scenario, we would send the prompt to an LLM here.
        // For this "Hello World" example, we return a static string that 
        // demonstrates the structure of a generated lore entry.
        return "The Blade of Whispering Winds. \n\n" +
               "Forged in the high peaks of the Aethelgard mountains, this sword " +
               $"hums with the energy of the eternal storms. It is said that {prompt.Contains("Legendary") ? "only the chosen hero" : "a worthy adventurer"} " +
               "can hear the secrets it guards. The hilt is wrapped in the leather of a fallen sky-drake.";
    }
}

/// <summary>
/// Core logic for generating in-game lore. Handles prompt engineering and text processing.
/// </summary>
public class LoreGenerator
{
    private readonly ILLMService _llmService;

    public LoreGenerator(ILLMService llmService)
    {
        _llmService = llmService;
    }

    /// <summary>
    /// Generates a rich item description based on the provided context.
    /// </summary>
    public async Task<string> GenerateItemDescriptionAsync(GenerationContext context)
    {
        // Step 1: Construct a detailed prompt. This is the most critical part of the process.
        // The prompt guides the LLM's tone, style, and content.
        string prompt = ConstructPrompt(context);

        // Step 2: Call the LLM service.
        string rawGeneratedText = await _llmService.GenerateTextAsync(prompt);

        // Step 3: Post-process the text (optional but recommended).
        // This could involve sanitizing, formatting, or adding game-specific tags.
        string formattedText = FormatForUnityUI(rawGeneratedText);

        return formattedText;
    }

    private string ConstructPrompt(GenerationContext context)
    {
        // Using modern C# string interpolation for readability.
        return $"""
                You are a master fantasy writer. Generate a short, immersive lore description for an in-game item.
                
                Item Details:
                - Type: {context.ItemType}
                - Rarity: {context.ItemRarity}
                - Location Found: {context.CurrentBiome}
                
                Player Context:
                - Name: {context.PlayerName}
                - Level: {context.PlayerLevel}
                
                Instructions:
                1. Write 2-3 sentences.
                2. Maintain a consistent tone based on the rarity (e.g., Legendary items should sound epic).
                3. Reference the location or the player's level if appropriate.
                4. Do not use markdown headers.
                
                Generated Lore:
                """;
    }

    private string FormatForUnityUI(string text)
    {
        // Unity's UI Text components (especially TextMeshPro) support rich text tags.
        // We can programmatically add color or style based on rarity.
        string colorTag = context.ItemRarity switch
        {
            "Legendary" => "<color=#FFD700>", // Gold
            "Rare" => "<color=#00BFFF>",      // Deep Sky Blue
            _ => "<color=#FFFFFF>"            // White
        };

        // Simple formatting: Close the color tag at the end.
        // In a real system, you might parse the text and wrap specific words.
        return $"{colorTag}{text}</color>";
    }
}

/// <summary>
/// Unity MonoBehaviour that acts as the controller, bridging the game logic and the UI.
/// </summary>
public class LoreDisplayController : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private Text _loreTextDisplay; // Legacy UI Text for simplicity
    [SerializeField] private Button _generateButton;

    [Header("Simulation Data")]
    [SerializeField] private string _playerName = "Aethelred";
    [SerializeField] private string _currentBiome = "Whispering Peaks";
    [SerializeField] private int _playerLevel = 25;
    [SerializeField] private string _itemRarity = "Legendary";
    [SerializeField] private string _itemType = "Sword";

    private LoreGenerator _loreGenerator;

    private void Start()
    {
        // Dependency Injection: Pass the service to the generator.
        // This makes the system testable and modular.
        _loreGenerator = new LoreGenerator(new MockLLMService());

        // Hook up the UI button click event.
        if (_generateButton != null)
        {
            _generateButton.onClick.AddListener(OnGenerateClicked);
        }
        else
        {
            Debug.LogError("Generate Button is not assigned in the Inspector.");
        }

        if (_loreTextDisplay == null)
        {
            Debug.LogError("Lore Text Display is not assigned in the Inspector.");
        }
    }

    // Unity event handlers must be void and return quickly. 
    // We use async void here because button clicks are fire-and-forget events.
    private async void OnGenerateClicked()
    {
        // Disable button to prevent spamming requests
        _generateButton.interactable = false;
        _loreTextDisplay.text = "Generating...";

        try
        {
            // 1. Assemble the context from current game state.
            var context = new GenerationContext
            {
                PlayerName = _playerName,
                CurrentBiome = _currentBiome,
                PlayerLevel = _playerLevel,
                ItemRarity = _itemRarity,
                ItemType = _itemType
            };

            // 2. Await the generation process.
            string loreDescription = await _loreGenerator.GenerateItemDescriptionAsync(context);

            // 3. Update the UI on the main thread (Unity's synchronization context handles this automatically).
            _loreTextDisplay.text = loreDescription;
        }
        catch (Exception ex)
        {
            Debug.LogError($"Failed to generate lore: {ex.Message}");
            _loreTextDisplay.text = "Error generating lore. Check console.";
        }
        finally
        {
            // Re-enable the button regardless of success or failure.
            _generateButton.interactable = true;
        }
    }
}
