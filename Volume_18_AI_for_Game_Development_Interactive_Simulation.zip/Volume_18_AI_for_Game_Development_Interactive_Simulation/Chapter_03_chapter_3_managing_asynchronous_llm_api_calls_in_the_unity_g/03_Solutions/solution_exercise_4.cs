
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

public class NPCController : MonoBehaviour
{
    public enum NPCState { Idle, Thinking, Talking, Moving }
    private NPCState _currentState;
    
    private Transform _playerTransform;
    private CancellationTokenSource _interactionCts;

    private void Start()
    {
        _playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        _currentState = NPCState.Idle;
    }

    // Called when player interacts with NPC
    public async void StartDialogue()
    {
        // 1. Interruption Logic: Cancel previous thinking
        CancelPendingRequest();

        // 2. Transition to Thinking State
        _currentState = NPCState.Thinking;
        
        // Create a new token source for this interaction
        _interactionCts = new CancellationTokenSource();

        try
        {
            // 3. Pass the token down to the async wrapper
            // We simulate the AsyncWebWrapper call here
            string response = await RequestLLMResponseAsync("Player Greeting", _interactionCts.Token);

            // 4. Check context validity before acting on response
            // If we are no longer in Thinking state (e.g. interrupted by movement), ignore result
            if (_currentState != NPCState.Talking && _currentState != NPCState.Thinking) return;

            // Execute Logic
            _currentState = NPCState.Talking;
            PlayDialogue(response);
        }
        catch (OperationCanceledException)
        {
            // 5. State Reversion on Cancellation
            Debug.Log("Dialogue cancelled.");
            _currentState = NPCState.Idle; // Or Moving
            // Reset visual state (stop thinking animation)
        }
    }

    private void Update()
    {
        // Monitor distance for cancellation logic
        if (_currentState == NPCState.Thinking && _interactionCts != null)
        {
            float distance = Vector3.Distance(transform.position, _playerTransform.position);
            if (distance > 10f)
            {
                CancelPendingRequest();
                _currentState = NPCState.Moving; // Revert state
            }
        }
    }

    private void CancelPendingRequest()
    {
        if (_interactionCts != null)
        {
            _interactionCts.Cancel();
            _interactionCts.Dispose();
            _interactionCts = null;
        }
    }

    // Mock Async Wrapper Call
    private async Task<string> RequestLLMResponseAsync(string prompt, CancellationToken token)
    {
        // In a real scenario, this calls AsyncWebWrapper.PostJsonAsync(...)
        await Task.Delay(3000, token); // Simulate long network call
        return "NPC Response";
    }

    private void PlayDialogue(string text)
    {
        Debug.Log($"NPC says: {text}");
        // Trigger audio, animation, etc.
    }

    private void OnDestroy()
    {
        CancelPendingRequest();
    }
}
