
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Threading;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;

public class FixedLLMUI : MonoBehaviour
{
    public TextMeshProUGUI statusText;
    private CancellationTokenSource _cts; // Manages cancellation for the current request

    // Called by a button
    public async void OnGenerateButtonClicked()
    {
        // 1. Cancel any existing request immediately
        if (_cts != null)
        {
            _cts.Cancel();
            _cts.Dispose();
        }

        // 2. Create a new CancellationTokenSource for this specific click
        _cts = new CancellationTokenSource();

        statusText.text = "Generating...";

        try
        {
            // 3. Change signature to async Task and await the delay (or API call)
            // We pass the token to the awaitable method
            await RunGenerationAsync(_cts.Token);
        }
        catch (OperationCanceledException)
        {
            // 4. Handle cancellation specifically
            // Do NOT update the UI here. The previous state remains or a new request is starting.
            Debug.Log("Previous request cancelled.");
            return; 
        }
        catch (System.Exception e)
        {
            statusText.text = "Error occurred.";
            Debug.LogError(e);
        }
    }

    private async Task RunGenerationAsync(CancellationToken token)
    {
        // Simulate API call
        await Task.Delay(2000, token); // This throws OperationCanceledException if token is cancelled
        
        // If we reached here, the task completed successfully without cancellation
        string newResponse = "Response for " + UnityEngine.Random.Range(0, 100);
        
        // 5. Update UI safely
        // Note: We are still on a background thread here due to Task.Delay. 
        // In Unity, we usually need to switch back to the main thread to update UI.
        // However, for this exercise, we assume the context is handled or we use a main thread dispatcher.
        UpdateUI(newResponse);
    }

    private void UpdateUI(string text)
    {
        // Only update if this specific request hasn't been cancelled
        if (_cts != null && !_cts.IsCancellationRequested)
        {
            statusText.text = text;
        }
    }

    private void OnDestroy()
    {
        // Cleanup to prevent memory leaks
        if (_cts != null)
        {
            _cts.Cancel();
            _cts.Dispose();
        }
    }
}
