
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

public class PredictiveAnimationNPC : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    private CancellationTokenSource _animCts;

    public async void OnPlayerAskQuestion(string prompt)
    {
        // Cancel any existing animation sequence
        if (_animCts != null)
        {
            _animCts.Cancel();
            _animCts.Dispose();
        }
        _animCts = new CancellationTokenSource();

        try
        {
            // 1. Start the sequence
            await PlayLLMResponseSequence(prompt, _animCts.Token);
        }
        catch (OperationCanceledException)
        {
            // Reset animations immediately on cancellation
            _animator.SetBool("IsSpeaking", false);
            _animator.SetFloat("VoiceIntensity", 0f);
        }
    }

    private async Task PlayLLMResponseSequence(string prompt, CancellationToken token)
    {
        // --- STEP 1: Thinking State ---
        _animator.SetBool("IsSpeaking", false); // Ensure talking is off
        
        // Start the "Thinking" loop in a fire-and-forget task, 
        // but we keep a handle to it to stop it later.
        var thinkingTask = RunThinkingAnimationLoop(token);

        // --- STEP 2: Await LLM Response ---
        // Simulate API call
        await Task.Delay(2000, token); 
        string responseText = "Here is the generated text.";

        // --- STEP 3: The Handoff ---
        // Cancel the thinking loop immediately
        token.ThrowIfCancellationRequested();

        // Switch to talking state
        _animator.SetBool("IsSpeaking", true);

        // --- STEP 4: Synchronized Playback ---
        // We don't await the thinking loop anymore, we just let it terminate 
        // via the cancellation token we passed to it.
        await PlayTalkingAnimationSequence(responseText, token);
    }

    private async Task RunThinkingAnimationLoop(CancellationToken token)
    {
        // This runs in parallel with the Task.Delay in PlayLLMResponseSequence
        while (!token.IsCancellationRequested)
        {
            // Generate a ping-pong value for jaw movement or idle twitching
            float intensity = Mathf.PingPong(Time.time * 2f, 1f);
            _animator.SetFloat("VoiceIntensity", intensity);
            
            // Wait for next frame
            await Task.Yield();
        }
    }

    private async Task PlayTalkingAnimationSequence(string text, CancellationToken token)
    {
        // Parse text for timing (simplified example)
        // Real implementation would parse TTS metadata or punctuation for delays.
        
        float baseDuration = 0.1f; // Speed of reading
        
        for (int i = 0; i < text.Length; i++)
        {
            token.ThrowIfCancellationRequested();

            // Simulate voice intensity based on text processing
            // In a real TTS system, this would be driven by audio amplitude
            float intensity = (text[i] == ' ' || text[i] == '.') ? 0f : 1f;
            _animator.SetFloat("VoiceIntensity", intensity);

            // Artificial delay to simulate reading speed
            await Task.Delay((int)(baseDuration * 1000), token);
        }

        // Reset at end
        _animator.SetBool("IsSpeaking", false);
        _animator.SetFloat("VoiceIntensity", 0f);
    }
}
