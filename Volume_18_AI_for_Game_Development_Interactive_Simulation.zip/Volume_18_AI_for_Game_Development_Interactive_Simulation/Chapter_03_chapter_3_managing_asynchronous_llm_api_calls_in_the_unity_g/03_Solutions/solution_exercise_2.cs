
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

// Data structure for the queue item
public struct LLMRequestTask
{
    public string Prompt;
    public Action<string> Callback;
    public int Priority;
}

public class RequestQueueManager : MonoBehaviour
{
    public static RequestQueueManager Instance { get; private set; }

    private readonly Queue<LLMRequestTask> _requestQueue = new Queue<LLMRequestTask>();
    private bool _isProcessing = false;
    private CancellationTokenSource _processingCts;

    private void Awake()
    {
        if (Instance != null && Instance != this) Destroy(this);
        else Instance = this;
    }

    // Public method to enqueue a request
    public void Enqueue(string prompt, Action<string> callback, int priority)
    {
        var request = new LLMRequestTask
        {
            Prompt = prompt,
            Callback = callback,
            Priority = priority
        };

        _requestQueue.Enqueue(request);
        
        // Trigger processing if not already running
        if (!_isProcessing)
        {
            ProcessQueueAsync().ConfigureAwait(false);
        }
    }

    private async Task ProcessQueueAsync()
    {
        _isProcessing = true;

        while (_requestQueue.Count > 0)
        {
            // 1. Sort the queue based on priority (High to Low)
            // Note: Converting to list to sort, then back to queue. 
            // For high-performance systems, consider a PriorityQueue (available in .NET 6+)
            var sortedList = _requestQueue.ToList();
            sortedList.Sort((a, b) => b.Priority.CompareTo(a.Priority));
            
            _requestQueue.Clear();
            foreach (var item in sortedList) _requestQueue.Enqueue(item);

            // 2. Dequeue the highest priority item
            var currentRequest = _requestQueue.Dequeue();

            try
            {
                // 3. Call the AsyncWebWrapper (Simulated here for the exercise context)
                // In a real scenario, you would pass a CancellationToken. 
                // Here we create a new token for this specific request processing.
                using (var cts = new CancellationTokenSource())
                {
                    // Simulate API call delay
                    await Task.Delay(1000, cts.Token); 
                    
                    // Mock response
                    string response = $"Response to: {currentRequest.Prompt}";
                    
                    // 4. Invoke callback on the main thread if necessary (Unity requires this for GameObject access)
                    // We use Unity's main thread context if needed, but for this exercise, we assume the callback is safe.
                    currentRequest.Callback?.Invoke(response);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"LLM Request failed: {ex.Message}");
                // Optional: Retry logic or specific error callback
                currentRequest.Callback?.Invoke($"Error: {ex.Message}");
            }

            // Small delay to respect rate limits (e.g., 60 RPM = 1 request per second)
            await Task.Delay(100); 
        }

        _isProcessing = false;
    }
}
