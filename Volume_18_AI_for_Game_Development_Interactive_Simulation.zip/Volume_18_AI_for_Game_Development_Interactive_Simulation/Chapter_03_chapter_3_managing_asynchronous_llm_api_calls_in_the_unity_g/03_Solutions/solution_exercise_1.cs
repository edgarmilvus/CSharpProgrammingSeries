
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

public static class AsyncWebWrapper
{
    /// <summary>
    /// Sends a POST request and awaits the result as a Task.
    /// </summary>
    public static async Task<string> PostJsonAsync(string url, string jsonPayload, CancellationToken cancellationToken = default)
    {
        // 1. Create the UnityWebRequest
        // Note: UnityWebRequest.Post is used here as per instructions, 
        // but for raw JSON, we usually set uploadHandler to a new UploadHandlerRaw(Encoding.UTF8.GetBytes(jsonPayload))
        UnityWebRequest request = UnityWebRequest.Post(url, jsonPayload);
        request.downloadHandler = new DownloadHandlerBuffer();

        // 2. Create a TaskCompletionSource to bridge the async operation
        var tcs = new TaskCompletionSource<bool>();

        // 3. Start the request
        var asyncOp = request.SendWebRequest();

        // 4. Register a callback for when the request finishes
        asyncOp.completed += (op) =>
        {
            // We use a try-catch here to handle any exceptions that might occur
            // when accessing the request result, though the operation itself is 'done'.
            try
            {
                if (request.result == UnityWebRequest.Result.ConnectionError || 
                    request.result == UnityWebRequest.Result.ProtocolError)
                {
                    // Fail the task with an HttpRequestException
                    tcs.TrySetException(new HttpRequestException(request.error));
                }
                else
                {
                    // Success
                    tcs.TrySetResult(true);
                }
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
            finally
            {
                // Cleanup
                request.Dispose();
            }
        };

        // 5. Register cancellation callback
        // If the token is cancelled, we abort the request and set the task to cancelled.
        using (cancellationToken.Register(() =>
        {
            request.Abort();
            tcs.TrySetCanceled();
        }))
        {
            try
            {
                // Await the completion source
                await tcs.Task;
            }
            catch (OperationCanceledException)
            {
                // Re-throw to let the caller know it was cancelled
                throw new OperationCanceledException("Request was cancelled.", cancellationToken);
            }
        }

        // 6. Return the result text if successful
        // Note: If we reach here, tcs.Task completed successfully.
        return request.downloadHandler.text;
    }
}
