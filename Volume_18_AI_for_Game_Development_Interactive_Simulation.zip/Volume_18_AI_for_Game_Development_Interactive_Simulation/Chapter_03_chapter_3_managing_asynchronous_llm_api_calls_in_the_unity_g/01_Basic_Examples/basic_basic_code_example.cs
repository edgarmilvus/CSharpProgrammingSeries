
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

/// <summary>
/// A self-contained "Hello World" example demonstrating asynchronous LLM API calls
/// within Unity's execution loop. This script simulates a game character asking an
/// LLM for a dynamic backstory.
/// 
/// KEY CONCEPTS:
/// 1. Coroutine-based asynchronous execution (IEnumerator)
/// 2. WebRequest handling for API simulation
/// 3. Preventing main thread blocking
/// 4. Handling latency and updating UI
/// </summary>
public class AsyncLLMExample : MonoBehaviour
{
    [Header("Configuration")]
    [Tooltip("Simulated API Endpoint. In production, this would be your LLM provider's URL.")]
    public string apiEndpoint = "https://api.mock-llm.com/v1/generate";
    
    [Tooltip("Prompt to send to the LLM.")]
    public string prompt = "Generate a short backstory for a fantasy warrior.";

    [Header("UI References")]
    public UnityEngine.UI.Text statusText;
    public UnityEngine.UI.Text responseText;

    // Internal state tracking
    private bool isRequesting = false;
    private string lastResponse = "No response yet.";

    /// <summary>
    /// Unity Entry Point: Called on the frame the script instance is first loaded.
    /// </summary>
    void Start()
    {
        UpdateUI("Ready. Press 'Generate' to start.");
    }

    /// <summary>
    /// Public method triggered by a UI Button click in the Unity Editor.
    /// </summary>
    public void OnGenerateButtonClicked()
    {
        if (isRequesting)
        {
            UpdateUI("Request already in progress...");
            return;
        }

        StartCoroutine(SendLLMRequestCoroutine(prompt));
    }

    /// <summary>
    /// COROUTINE: The primary mechanism for handling asynchronous operations in older Unity versions.
    /// This pattern allows us to yield execution back to Unity's main loop while waiting for data.
    /// </summary>
    private IEnumerator SendLLMRequestCoroutine(string userPrompt)
    {
        isRequesting = true;
        UpdateUI("Sending request to LLM...");

        // 1. Create the Web Request
        // We use UnityWebRequest for HTTP calls. 
        // Note: In a real scenario, we would POST JSON data. Here we simulate a GET for simplicity.
        // We append the prompt as a query parameter to simulate the request.
        string fullUrl = $"{apiEndpoint}?prompt={UnityWebRequest.EscapeURL(userPrompt)}";
        
        using (UnityWebRequest webRequest = UnityWebRequest.Get(fullUrl))
        {
            // 2. Send the request asynchronously
            // UnityWebRequest.SendWebRequest() is non-blocking. It returns a UnityWebRequestAsyncOperation.
            UnityWebRequestAsyncOperation asyncOperation = webRequest.SendWebRequest();

            // 3. Yield control until the request completes
            // We use a 'while' loop to check the 'isDone' flag frame-by-frame.
            // This keeps the game running smoothly while we wait.
            while (!asyncOperation.isDone)
            {
                // Optional: Update progress bar here
                UpdateUI($"Waiting for response... ({(asyncOperation.progress * 100):F0}%)");
                
                // Yield null returns control to Unity's main loop for one frame.
                // Without this, the while loop would freeze the game (tight loop).
                yield return null; 
            }

            // 4. Handle the Result
            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                lastResponse = webRequest.downloadHandler.text;
                UpdateUI($"Success! Received: {lastResponse}");
            }
            else
            {
                lastResponse = $"Error: {webRequest.error}";
                UpdateUI($"Request Failed: {webRequest.error}");
            }
        }

        isRequesting = false;
    }

    /// <summary>
    /// ASYNC/AWAIT: The modern C# approach (Unity 2023.1+ supports this fully).
    /// This is cleaner syntax for the same asynchronous logic.
    /// </summary>
    public async void OnGenerateButtonClickedModern()
    {
        if (isRequesting) return;
        
        isRequesting = true;
        UpdateUI("Sending request (Modern Async)...");

        try
        {
            // 1. Create the task
            string fullUrl = $"{apiEndpoint}?prompt={UnityWebRequest.EscapeURL(prompt)}";
            
            // 2. Create a custom Task wrapper for UnityWebRequest (Unity doesn't natively return Task)
            // This helper method converts the coroutine-based WebRequest into an awaitable Task.
            string result = await SendWebRequestTask(fullUrl);

            lastResponse = result;
            UpdateUI($"Success! Received: {lastResponse}");
        }
        catch (Exception e)
        {
            UpdateUI($"Error: {e.Message}");
        }
        finally
        {
            isRequesting = false;
        }
    }

    /// <summary>
    /// Helper method to wrap UnityWebRequest in a Task for async/await usage.
    /// </summary>
    private Task<string> SendWebRequestTask(string url)
    {
        var tcs = new TaskCompletionSource<string>();
        
        UnityWebRequest webRequest = UnityWebRequest.Get(url);
        UnityWebRequestAsyncOperation asyncOp = webRequest.SendWebRequest();

        asyncOp.completed += (op) =>
        {
            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                tcs.SetResult(webRequest.downloadHandler.text);
            }
            else
            {
                tcs.SetException(new Exception(webRequest.error));
            }
            webRequest.Dispose();
        };

        return tcs.Task;
    }

    /// <summary>
    /// Updates the UI Text elements safely.
    /// </summary>
    private void UpdateUI(string message)
    {
        if (statusText != null) statusText.text = message;
        if (responseText != null) responseText.text = lastResponse;
        
        // Log to console for debugging
        Debug.Log($"[AsyncLLM] {message}");
    }
}
