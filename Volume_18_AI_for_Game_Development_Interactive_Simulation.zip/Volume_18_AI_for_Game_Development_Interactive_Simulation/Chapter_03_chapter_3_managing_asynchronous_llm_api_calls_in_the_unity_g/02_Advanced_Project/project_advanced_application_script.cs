
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Real-World Context:
/// Imagine you are building a dynamic dialogue system for an NPC (Non-Player Character) in a Unity game.
/// When the player speaks to the NPC, the game must send the conversation history to an LLM (Large Language Model) API
/// to generate a response. This API call is asynchronous and takes time (latency).
/// If we block the main game thread waiting for the response, the game will freeze.
/// This application demonstrates the "Advanced Application Script" pattern:
/// 1. A Request Queue to hold pending API calls.
/// 2. A Coroutine-style Manager (using async/await) to process the queue without blocking.
/// 3. A Callback system to update the game world once the data arrives.
/// </summary>
class Program
{
    // --- MOCK SYSTEM CONSTANTS ---
    // In a real Unity game, these would be API keys and Endpoint URLs.
    const string API_ENDPOINT = "https://api.fantasy-llm.com/v1/generate";
    const int MAX_CONCURRENT_REQUESTS = 2;
    const int TIMEOUT_SECONDS = 5;

    static async Task Main(string[] args)
    {
        Console.WriteLine("=== Game Dialogue System: Async LLM Manager ===\n");

        // 1. Initialize the Request Manager
        var dialogueManager = new DialogueRequestManager();

        // 2. Simulate Player Interactions (Firing multiple requests rapidly)
        // These represent in-game events triggered by player collisions or inputs.
        dialogueManager.EnqueueRequest("Player asks: Where is the nearest town?", response => Console.WriteLine($"[Response]: {response}"));
        dialogueManager.EnqueueRequest("Player asks: What is the weather like?", response => Console.WriteLine($"[Response]: {response}"));
        dialogueManager.EnqueueRequest("Player asks: Tell me a secret.", response => Console.WriteLine($"[Response]: {response}"));
        
        // 3. Start Processing
        // We 'await' the processing loop. In Unity, this would be a Coroutine running in the background.
        // We pass a cancellation token to allow graceful stopping (simulating game exit).
        var cts = new System.Threading.CancellationTokenSource();
        
        // Run the processing loop for a specific duration to demonstrate the output
        var processingTask = dialogueManager.ProcessQueueAsync(cts.Token);

        // Simulate the game running for a few seconds
        await Task.Delay(8000); 
        cts.Cancel(); // Stop the loop

        try {
            await processingTask;
        } catch (OperationCanceledException) {
            Console.WriteLine("\n[System]: Simulation ended. Manager stopped.");
        }
    }
}

/// <summary>
/// Represents a single request to the LLM.
/// Uses basic classes and delegates (callbacks) to handle the result.
/// </summary>
public class DialogueRequest
{
    public string PlayerInput { get; private set; }
    public Action<string> OnResponseReceived { get; private set; }

    public DialogueRequest(string input, Action<string> callback)
    {
        PlayerInput = input;
        OnResponseReceived = callback;
    }
}

/// <summary>
/// Manages the queue of requests and processes them asynchronously.
/// This is the core "Advanced Application Script" logic.
/// </summary>
public class DialogueRequestManager
{
    // The queue holds pending requests. 
    // We use a Queue to ensure First-In-First-Out (FIFO) processing order.
    private Queue<DialogueRequest> _requestQueue = new Queue<DialogueRequest>();
    
    // We use an HttpClient instance for making web requests.
    // In Unity, you would typically use UnityWebRequest, but the logic is identical.
    private HttpClient _httpClient;

    public DialogueRequestManager()
    {
        _httpClient = new HttpClient();
        // Set a reasonable timeout to prevent hanging indefinitely.
        _httpClient.Timeout = TimeSpan.FromSeconds(TIMEOUT_SECONDS);
    }

    /// <summary>
    /// Adds a new request to the processing queue.
    /// This is thread-safe in this context because we only modify the queue from the main thread
    /// before the processing loop starts. In a multithreaded Unity env, we'd use locks.
    /// </summary>
    public void EnqueueRequest(string input, Action<string> callback)
    {
        var request = new DialogueRequest(input, callback);
        _requestQueue.Enqueue(request);
        Console.WriteLine($"[Queue]: Added request '{input}' (Queue Count: {_requestQueue.Count})");
    }

    /// <summary>
    /// The main processing loop. This mimics a Unity Coroutine or an Update loop.
    /// It continuously checks the queue and processes items.
    /// </summary>
    public async Task ProcessQueueAsync(System.Threading.CancellationToken token)
    {
        Console.WriteLine("[System]: Processor Started. Waiting for requests...");

        // Loop indefinitely until the token is cancelled (game exit)
        while (!token.IsCancellationRequested)
        {
            // Check if there are requests to process
            if (_requestQueue.Count > 0)
            {
                // Dequeue the next request
                DialogueRequest currentRequest = _requestQueue.Dequeue();
                
                Console.WriteLine($"[System]: Processing '{currentRequest.PlayerInput}'...");

                try
                {
                    // --- THE CRITICAL ASYNC CALL ---
                    // We await the network call. This yields control back to the main loop
                    // so the game doesn't freeze while waiting for the API.
                    string llmResponse = await CallLLMApiAsync(currentRequest.PlayerInput);

                    // --- UPDATE GAME STATE ---
                    // Once the data arrives, we execute the callback.
                    // In Unity, this might update a UI Text component or an NPC state.
                    currentRequest.OnResponseReceived(llmResponse);
                }
                catch (Exception ex)
                {
                    // Handle errors (Timeouts, Network Errors)
                    Console.WriteLine($"[Error]: Failed to process request. Reason: {ex.Message}");
                    // In a real game, we might trigger a "Sorry, I can't talk right now" dialogue.
                    currentRequest.OnResponseReceived("I am currently unavailable.");
                }
            }
            else
            {
                // If the queue is empty, we don't want to spam the CPU.
                // We wait for a short duration before checking again.
                // In Unity, 'yield return new WaitForSeconds(0.5f)' achieves this.
                await Task.Delay(500);
            }
        }
    }

    /// <summary>
    /// Simulates the network call to the LLM API.
    /// Uses async/await to handle the I/O operation.
    /// </summary>
    private async Task<string> CallLLMApiAsync(string prompt)
    {
        // Simulate network latency (random between 1 and 3 seconds)
        // In a real app, this is the time the HttpClient spends sending/receiving.
        Random rnd = new Random();
        int latency = rnd.Next(1000, 3000);
        await Task.Delay(latency);

        // Simulate the API response logic
        // We construct a response based on the prompt.
        string responseContent = $"[LLM Generated in {latency}ms]: I understand you asked about '{prompt}'. The answer lies within the ancient scrolls.";
        
        return responseContent;
    }
}
