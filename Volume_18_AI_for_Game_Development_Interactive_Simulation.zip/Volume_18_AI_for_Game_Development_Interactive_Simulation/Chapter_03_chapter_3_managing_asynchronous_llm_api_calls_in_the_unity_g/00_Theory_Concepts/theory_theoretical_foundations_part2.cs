
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.cs
// Description: Theoretical Foundations
// ==========================================

// Conceptual async/await usage in Unity (no implementation details)
using System.Threading.Tasks;
using UnityEngine;

public class AICharacter : MonoBehaviour
{
    // This method is marked 'async' and returns a Task.
    // It can be awaited by another method.
    public async Task<string> GetLLMResponseAsync(string prompt)
    {
        // 1. Initiate the long-running network request on a background thread.
        // 2. The 'await' keyword pauses this method and returns control to the caller (e.g., Update).
        // 3. Unity's main thread is now free to render frames, process physics, etc.
        string response = await LLMService.QueryAsync(prompt);
        
        // 4. When the LLM responds, the execution resumes here, ON THE MAIN THREAD.
        // 5. We can now safely interact with Unity's API.
        Debug.Log($"LLM Response received: {response}");
        return response;
    }

    // Example of a caller
    public async void StartConversation()
    {
        // This call is non-blocking. The game continues to run.
        string result = await GetLLMResponseAsync("Tell me a story.");
        // Process the result...
    }
}
