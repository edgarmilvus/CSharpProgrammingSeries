
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using UnityEngine;

// Generic Spatial Hash class for efficient neighbor queries
public class SpatialHash<T> where T : struct
{
    // Struct to hold agent data
    public struct AgentData
    {
        public Vector3 Position;
        public T Item;
    }

    private float _cellSize;
    private Dictionary<Vector3Int, List<AgentData>> _grid;

    public SpatialHash(float cellSize)
    {
        _cellSize = cellSize;
        _grid = new Dictionary<Vector3Int, List<AgentData>>();
    }

    // Convert world position to grid key
    private Vector3Int GetGridKey(Vector3 pos)
    {
        int x = Mathf.FloorToInt(pos.x / _cellSize);
        int y = Mathf.FloorToInt(pos.y / _cellSize);
        int z = Mathf.FloorToInt(pos.z / _cellSize);
        return new Vector3Int(x, y, z);
    }

    // Insert an item into the grid
    public void Insert(Vector3 position, T item)
    {
        Vector3Int key = GetGridKey(position);

        if (!_grid.ContainsKey(key))
        {
            _grid[key] = new List<AgentData>();
        }

        _grid[key].Add(new AgentData { Position = position, Item = item });
    }

    // Query items within a radius from a specific position
    public List<AgentData> Query(Vector3 position, float radius)
    {
        List<AgentData> neighbors = new List<AgentData>();
        Vector3Int centerKey = GetGridKey(position);
        
        // Calculate the range of cells to check based on radius
        // We add 1 to ensure we cover the full radius even at cell edges
        int range = Mathf.CeilToInt(radius / _cellSize);

        for (int x = -range; x <= range; x++)
        {
            for (int y = -range; y <= range; y++)
            {
                for (int z = -range; z <= range; z++)
                {
                    Vector3Int checkKey = centerKey + new Vector3Int(x, y, z);
                    
                    if (_grid.TryGetValue(checkKey, out List<AgentData> cellItems))
                    {
                        foreach (var data in cellItems)
                        {
                            // Check actual distance to ensure it's within the sphere radius
                            if (Vector3.SqrMagnitude(data.Position - position) <= radius * radius)
                            {
                                neighbors.Add(data);
                            }
                        }
                    }
                }
            }
        }

        return neighbors;
    }

    // Clear the grid for the next frame
    public void Clear()
    {
        foreach (var list in _grid.Values)
        {
            list.Clear();
        }
        _grid.Clear();
    }
}

// Example Integration with a Boid Agent
public class BoidAgent : MonoBehaviour
{
    public float perceptionRadius = 2.5f;
    public float separationWeight = 2.0f;
    public float cohesionWeight = 1.0f;
    public float alignmentWeight = 1.0f;
    
    private Vector3 _velocity;
    private SpatialHash<BoidAgent> _spatialHash;

    // Initialize in Start or Manager
    public void Initialize(SpatialHash<BoidAgent> hash)
    {
        _spatialHash = hash;
    }

    // Called by a central manager after all agents move
    public void UpdateBoids()
    {
        // 1. Query Spatial Hash instead of Physics.OverlapSphere
        var neighbors = _spatialHash.Query(transform.position, perceptionRadius);
        
        Vector3 separation = Vector3.zero;
        Vector3 alignment = Vector3.zero;
        Vector3 cohesion = Vector3.zero;
        int count = 0;

        foreach (var neighbor in neighbors)
        {
            if (neighbor.Item == this) continue; // Skip self

            float dist = Vector3.Distance(transform.position, neighbor.Position);
            if (dist > 0 && dist < perceptionRadius)
            {
                // Separation: Vector pointing away from neighbor
                separation += (transform.position - neighbor.Position).normalized / dist;
                
                // Alignment: Sum of neighbor velocities
                alignment += neighbor.Item._velocity;
                
                // Cohesion: Sum of neighbor positions
                cohesion += neighbor.Position;
                
                count++;
            }
        }

        if (count > 0)
        {
            separation /= count;
            alignment /= count;
            cohesion = (cohesion / count) - transform.position;
            
            // Apply weights
            _velocity += separation * separationWeight * Time.deltaTime;
            _velocity += alignment * alignmentWeight * Time.deltaTime;
            _velocity += cohesion * cohesionWeight * Time.deltaTime;
        }

        // Normalize speed (optional)
        if (_velocity.magnitude > 5.0f) _velocity = _velocity.normalized * 5.0f;
        
        transform.position += _velocity * Time.deltaTime;
        if (_velocity != Vector3.zero) transform.rotation = Quaternion.LookRotation(_velocity);
    }
}

// Manager to handle the grid and updates
public class BoidManager : MonoBehaviour
{
    public List<BoidAgent> agents;
    public float cellSize = 5.0f;
    private SpatialHash<BoidAgent> _spatialHash;
    
    // Performance tracking
    private System.Diagnostics.Stopwatch _stopwatch = new System.Diagnostics.Stopwatch();
    public float averageUpdateTime { get; private set; }

    void Start()
    {
        _spatialHash = new SpatialHash<BoidAgent>(cellSize);
        foreach(var agent in agents)
        {
            agent.Initialize(_spatialHash);
        }
    }

    void LateUpdate()
    {
        _stopwatch.Restart();
        
        // 1. Rebuild Grid
        _spatialHash.Clear();
        foreach (var agent in agents)
        {
            _spatialHash.Insert(agent.transform.position, agent);
        }

        // 2. Update Agents
        foreach (var agent in agents)
        {
            agent.UpdateBoids();
        }

        _stopwatch.Stop();
        averageUpdateTime = _stopwatch.Elapsed.TotalMilliseconds;
    }
}
