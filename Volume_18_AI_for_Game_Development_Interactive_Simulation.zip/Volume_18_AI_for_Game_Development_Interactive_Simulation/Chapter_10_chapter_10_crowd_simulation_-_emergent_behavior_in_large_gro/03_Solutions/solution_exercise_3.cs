
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class SteeringAvoidance : MonoBehaviour
{
    private NavMeshAgent _agent;
    
    [Header("Raycast Settings")]
    public int rayCount = 5;
    public float maxRayDistance = 5f;
    public float raySpreadAngle = 45f;
    public LayerMask obstacleMask;

    [Header("Steering Settings")]
    public float avoidanceWeight = 1.5f;
    public float smoothingFactor = 5f;
    public float deadlockThreshold = 2.0f; // Time to wait if stuck

    private float _deadlockTimer = 0f;
    private Vector3 _lastPosition;
    private bool _isDeadlocked = false;

    void Start()
    {
        _agent = GetComponent<NavMeshAgent>();
        _lastPosition = transform.position;
    }

    void Update()
    {
        // 1. Deadlock Detection
        CheckDeadlock();

        if (_isDeadlocked)
        {
            HandleDeadlock();
            return;
        }

        // 2. Obstacle Detection via Raycasting
        Vector3 steeringForce = CalculateSteeringForce();

        // 3. Velocity Modification
        ApplySteering(steeringForce);
    }

    private Vector3 CalculateSteeringForce()
    {
        Vector3 totalForce = Vector3.zero;
        int hitCount = 0;

        // Calculate dynamic ray distance based on speed
        float currentSpeed = _agent.velocity.magnitude;
        float dynamicDistance = Mathf.Lerp(maxRayDistance * 0.5f, maxRayDistance, currentSpeed / _agent.speed);

        for (int i = 0; i < rayCount; i++)
        {
            // Calculate direction for each ray (fan pattern)
            float t = i / (float)(rayCount - 1); // 0 to 1
            float angle = Mathf.Lerp(-raySpreadAngle, raySpreadAngle, t);
            Vector3 dir = Quaternion.Euler(0, angle, 0) * transform.forward;

            Ray ray = new Ray(transform.position + Vector3.up * 0.5f, dir);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, dynamicDistance, obstacleMask))
            {
                // 4. Steering Calculation
                // Reflection vector: R = I - 2(N.I)N
                Vector3 reflectDir = Vector3.Reflect(dir, hit.normal).normalized;
                
                // Lateral offset: Perpendicular to the hit normal
                Vector3 lateralOffset = Vector3.Cross(hit.normal, Vector3.up).normalized;

                // Combine forces
                Vector3 avoidance = (reflectDir + lateralOffset * 0.5f).normalized;
                totalForce += avoidance * (1.0f / hit.distance); // Closer hits = stronger force
                hitCount++;
                
                // Visual Debug
                Debug.DrawRay(ray.origin, dir * dynamicDistance, Color.red);
            }
            else
            {
                Debug.DrawRay(ray.origin, dir * dynamicDistance, Color.green);
            }
        }

        if (hitCount > 0)
        {
            return totalForce / hitCount; // Average force
        }

        return Vector3.zero;
    }

    private void ApplySteering(Vector3 steeringForce)
    {
        // 3. Velocity Modification (Lerp for smoothness)
        Vector3 desiredVelocity = _agent.desiredVelocity;
        
        // If steering is active, blend it. If not, use desired velocity.
        Vector3 targetVelocity = desiredVelocity + (steeringForce * avoidanceWeight);
        
        // Normalize and apply speed
        targetVelocity = targetVelocity.normalized * _agent.speed;

        // Smoothly interpolate current velocity towards target velocity
        _agent.velocity = Vector3.Lerp(_agent.velocity, targetVelocity, Time.deltaTime * smoothingFactor);
    }

    private void CheckDeadlock()
    {
        // If moved very little over time
        if (Vector3.Distance(transform.position, _lastPosition) < 0.1f)
        {
            _deadlockTimer += Time.deltaTime;
            if (_deadlockTimer > deadlockThreshold)
            {
                _isDeadlocked = true;
            }
        }
        else
        {
            _deadlockTimer = 0f;
            _isDeadlocked = false;
        }
        _lastPosition = transform.position;
    }

    private void HandleDeadlock()
    {
        // 5. Edge Case - Deadlocks
        // Stop moving and try to recalculate path or nudge slightly
        _agent.velocity = Vector3.zero;
        
        // Try to find a random point nearby to unstuck
        Vector3 randomDir = Random.insideUnitSphere * 2f;
        randomDir.y = 0;
        NavMeshHit hit;
        if (NavMesh.SamplePosition(transform.position + randomDir, out hit, 2.0f, NavMesh.AllAreas))
        {
            _agent.SetDestination(hit.position);
            _isDeadlocked = false; // Reset to try moving again
            _deadlockTimer = 0f;
        }
    }
}
