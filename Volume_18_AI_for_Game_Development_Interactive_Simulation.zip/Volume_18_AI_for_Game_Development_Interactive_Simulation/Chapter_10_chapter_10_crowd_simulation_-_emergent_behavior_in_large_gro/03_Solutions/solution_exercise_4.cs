
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

// Enum for LLM-decided strategies
public enum CrowdStrategy
{
    OrderlyEvacuation,
    PanicSpread,
    SeekShelter,
    Idle
}

// 1. LLM Interface (Simulated)
public static class LLMInterface
{
    // Simulate an async API call
    public static async Task<CrowdStrategy> GetStrategyAsync(string contextPrompt)
    {
        // Simulate network latency (e.g., 1.5 seconds)
        await Task.Delay(1500);

        // Mock Logic: Parse context to return a strategy
        // In a real scenario, this would parse JSON from an API response
        if (contextPrompt.Contains("Fire") && contextPrompt.Contains("Dense"))
            return CrowdStrategy.PanicSpread;
        if (contextPrompt.Contains("Fire"))
            return CrowdStrategy.OrderlyEvacuation;
        if (contextPrompt.Contains("Shelter"))
            return CrowdStrategy.SeekShelter;

        return CrowdStrategy.Idle;
    }

    public static string GeneratePrompt(Vector3 threatPos, float density, List<Vector3> exits)
    {
        return $"Context: Threat at {threatPos}, Density: {density}, Exits: {exits.Count}. Determine strategy.";
    }
}

// 2. Leader Agent
public class LeaderAgent : MonoBehaviour
{
    public float queryCooldown = 5.0f;
    private float _cooldownTimer = 0f;
    private CrowdStrategy _currentStrategy = CrowdStrategy.Idle;
    
    // Event to broadcast strategy
    public static event Action<CrowdStrategy> OnStrategyChanged;

    void Update()
    {
        if (_cooldownTimer > 0) _cooldownTimer -= Time.deltaTime;

        // Example trigger: Fire appears nearby
        // In a real app, this would be triggered by sensors
        if (Input.GetKeyDown(KeyCode.Space) || (_cooldownTimer <= 0 && CheckForThreatChange()))
        {
            RequestStrategyUpdate();
        }
    }

    private bool CheckForThreatChange()
    {
        // Logic to detect significant environmental change
        // Returning true for demo purposes
        return true; 
    }

    private async void RequestStrategyUpdate()
    {
        _cooldownTimer = queryCooldown; // Start cooldown immediately
        
        // Gather Context
        float density = CalculateGroupDensity();
        string prompt = LLMInterface.GeneratePrompt(transform.position, density, FindExits());
        
        Debug.Log($"Leader querying LLM: {prompt}");
        
        // Call LLM
        CrowdStrategy newStrategy = await LLMInterface.GetStrategyAsync(prompt);
        
        if (newStrategy != _currentStrategy)
        {
            _currentStrategy = newStrategy;
            Debug.Log($"LLM Strategy Received: {newStrategy}");
            OnStrategyChanged?.Invoke(_currentStrategy); // Broadcast to followers
        }
    }

    private float CalculateGroupDensity()
    {
        // Use SpatialHash or Physics.OverlapSphere to get local density
        Collider[] hits = Physics.OverlapSphere(transform.position, 10f);
        return hits.Length;
    }

    private List<Vector3> FindExits()
    {
        // Return hardcoded or detected exit points
        return new List<Vector3> { new Vector3(10, 0, 10), new Vector3(-10, 0, -10) };
    }
}

// 3. Follower Agent
public class FollowerAgent : MonoBehaviour
{
    private NavMeshAgent _agent;
    private CrowdStrategy _activeStrategy = CrowdStrategy.Idle;
    private Vector3 _threatPos;

    void Start()
    {
        _agent = GetComponent<NavMeshAgent>();
        LeaderAgent.OnStrategyChanged += UpdateStrategy;
        
        // Subscribe to global threat for immediate reaction if needed
        AgentController.OnThreatDetected += (pos) => _threatPos = pos;
    }

    void OnDestroy()
    {
        LeaderAgent.OnStrategyChanged -= UpdateStrategy;
    }

    void UpdateStrategy(CrowdStrategy strategy)
    {
        _activeStrategy = strategy;
        Debug.Log($"Agent {gameObject.name} adopting strategy: {strategy}");
    }

    void Update()
    {
        ExecuteStrategy();
    }

    private void ExecuteStrategy()
    {
        switch (_activeStrategy)
        {
            case CrowdStrategy.OrderlyEvacuation:
                // Move to nearest exit with capped speed
                _agent.speed = 3.0f;
                _agent.SetDestination(FindNearestExit());
                break;

            case CrowdStrategy.PanicSpread:
                // Run fast, ignore efficiency
                _agent.speed = 8.0f;
                if (_threatPos != Vector3.zero)
                {
                    Vector3 runDir = (transform.position - _threatPos).normalized * 20f;
                    _agent.SetDestination(transform.position + runDir);
                }
                break;

            case CrowdStrategy.SeekShelter:
                // Move to indoor zones (tagged in NavMesh)
                _agent.speed = 4.0f;
                // Logic to find "Shelter" NavMesh area
                break;
                
            case CrowdStrategy.Idle:
                _agent.ResetPath();
                break;
        }
    }

    private Vector3 FindNearestExit()
    {
        // Simplified: return a hardcoded point for demo
        return new Vector3(10, 0, 10);
    }
}
