
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using UnityEngine.AI;
using System;

// 1. State Interface
public interface IAgentState
{
    void Enter(AgentController agent);
    void Execute(AgentController agent);
    void Exit(AgentController agent);
    void HandleInput(AgentController agent, Vector3 threatPos, float density);
}

// 2. Concrete States
public class WanderingState : IAgentState
{
    public void Enter(AgentController agent) 
    {
        agent.MeshRenderer.material.color = Color.white;
        agent.NavAgent.speed = 2.0f;
    }

    public void Execute(AgentController agent)
    {
        // Simple random wandering if no path
        if (agent.NavAgent.remainingDistance < 0.5f)
        {
            Vector3 randomPoint = agent.transform.position + UnityEngine.Random.insideUnitSphere * 5f;
            NavMeshHit hit;
            if (NavMesh.SamplePosition(randomPoint, out hit, 5.0f, NavMesh.AllAreas))
            {
                agent.NavAgent.SetDestination(hit.position);
            }
        }
    }

    public void Exit(AgentController agent) { }

    public void HandleInput(AgentController agent, Vector3 threatPos, float density)
    {
        float distToThreat = Vector3.Distance(agent.transform.position, threatPos);
        // Transition to Panic if threat is close
        if (distToThreat < 10.0f)
        {
            agent.StateMachine.ChangeState(new PanicState(threatPos));
        }
    }
}

// 3. Hierarchical Super-State: Panic
public class PanicState : IAgentState
{
    private Vector3 _threatPos;
    private IAgentState _subState;
    private float _decisionTimer = 0f;

    public PanicState(Vector3 threatPos)
    {
        _threatPos = threatPos;
    }

    public void Enter(AgentController agent)
    {
        agent.MeshRenderer.material.color = Color.red; // Base panic color
        agent.NavAgent.speed = 4.0f; // Run speed
        // Initial sub-state decision
        DecideSubState(agent, 0f); 
    }

    public void Execute(AgentController agent)
    {
        _decisionTimer -= Time.deltaTime;
        
        // Periodically re-evaluate sub-state
        if (_decisionTimer <= 0)
        {
            // Calculate local density (simplified for example)
            float density = agent.CalculateLocalDensity(); 
            DecideSubState(agent, density);
            _decisionTimer = 1.0f; // Re-evaluate every second
        }

        // Execute current sub-state
        _subState?.Execute(agent);
    }

    public void Exit(AgentController agent)
    {
        _subState?.Exit(agent);
    }

    public void HandleInput(AgentController agent, Vector3 threatPos, float density)
    {
        _threatPos = threatPos; // Update threat position
    }

    private void DecideSubState(AgentController agent, float density)
    {
        float distToThreat = Vector3.Distance(agent.transform.position, _threatPos);
        
        // Logic: High density + Far threat = Cower. Open path + Close threat = Flee.
        if (density > 0.5f && distToThreat > 5.0f)
        {
            if (!(_subState is CoweringState))
            {
                _subState?.Exit(agent);
                _subState = new CoweringState();
                _subState.Enter(agent);
            }
        }
        else
        {
            if (!(_subState is FleeingState))
            {
                _subState?.Exit(agent);
                _subState = new FleeingState(_threatPos);
                _subState.Enter(agent);
            }
        }
    }
}

// 3b. Panic Sub-State: Fleeing
public class FleeingState : IAgentState
{
    private Vector3 _threatPos;

    public FleeingState(Vector3 threatPos) { _threatPos = threatPos; }

    public void Enter(AgentController agent)
    {
        agent.MeshRenderer.material.color = Color.red; // Red for Fleeing
    }

    public void Execute(AgentController agent)
    {
        // Calculate flee vector
        Vector3 fleeDir = (agent.transform.position - _threatPos).normalized;
        Vector3 fleeTarget = agent.transform.position + (fleeDir * 15f);
        
        NavMeshHit hit;
        if (NavMesh.SamplePosition(fleeTarget, out hit, 10.0f, NavMesh.AllAreas))
        {
            agent.NavAgent.SetDestination(hit.position);
        }
    }

    public void Exit(AgentController agent) { }
    public void HandleInput(AgentController agent, Vector3 threatPos, float density) { }
}

// 3c. Panic Sub-State: Cowering
public class CoweringState : IAgentState
{
    public void Enter(AgentController agent)
    {
        agent.MeshRenderer.material.color = Color.grey; // Grey for Cowering
        agent.NavAgent.isStopped = true; // Stop moving
    }

    public void Execute(AgentController agent)
    {
        // Cower logic: huddle down (scale down) or just wait
        // Here we just wait for the PanicState to switch us back
    }

    public void Exit(AgentController agent)
    {
        agent.NavAgent.isStopped = false;
    }

    public void HandleInput(AgentController agent, Vector3 threatPos, float density) { }
}

// 4. State Machine Controller
public class StateMachine
{
    private IAgentState _currentState;

    public void ChangeState(IAgentState newState)
    {
        _currentState?.Exit(_agent);
        _currentState = newState;
        _currentState?.Enter(_agent);
    }

    public void Update()
    {
        _currentState?.Execute(_agent);
    }

    // Reference to the agent owning this machine
    private AgentController _agent;
    public StateMachine(AgentController agent) { _agent = agent; }
}

// 5. Agent Controller integrating the HFSM
public class AgentController : MonoBehaviour
{
    public NavMeshAgent NavAgent;
    public Renderer MeshRenderer;
    public StateMachine StateMachine;
    
    // Threat Event System
    public static event Action<Vector3> OnThreatDetected;

    void Start()
    {
        NavAgent = GetComponent<NavMeshAgent>();
        MeshRenderer = GetComponent<Renderer>();
        StateMachine = new StateMachine(this);
        
        // Start in Wandering state
        StateMachine.ChangeState(new WanderingState());

        // Subscribe to global threat event
        OnThreatDetected += ReactToThreat;
    }

    void Update()
    {
        StateMachine.Update();
    }

    // 4. Event Handler
    private void ReactToThreat(Vector3 threatPos)
    {
        float dist = Vector3.Distance(transform.position, threatPos);
        if (dist < 15.0f) // Hearing/Seeing radius
        {
            // Pass input to current state to trigger transition
            StateMachine.CurrentState?.HandleInput(this, threatPos, CalculateLocalDensity());
        }
    }

    // Helper for density calculation (simplified)
    public float CalculateLocalDensity()
    {
        // In a real scenario, use SpatialHash from Exercise 1 here
        Collider[] hits = Physics.OverlapSphere(transform.position, 3.0f);
        return hits.Length / 10f; // Normalized arbitrary value
    }
}

// 6. Threat Object (e.g., Explosion/Fire)
public class ThreatObject : MonoBehaviour
{
    void Start()
    {
        // Broadcast threat position immediately upon appearing
        AgentController.OnThreatDetected?.Invoke(transform.position);
    }
}
