
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;
using System.Linq;

public enum CrowdLOD
{
    High,   // Full NavMesh + Boids
    Medium, // Simplified NavMesh (low freq) + Simple Cohesion
    Low     // Imposter (Sprite/Static Mesh) + Flow Field
}

// 1. Central LOD Manager
public class CrowdLODManager : MonoBehaviour
{
    public static CrowdLODManager Instance;
    
    [Header("Settings")]
    public Transform cameraTransform;
    public float highDetailDist = 20f;
    public float mediumDetailDist = 50f;
    public float updateInterval = 0.5f; // Update LOD every 0.5s

    [Header("References")]
    public List<CrowdAgentLOD> allAgents;
    
    private float _timer;

    void Awake() { Instance = this; }

    void Update()
    {
        _timer -= Time.deltaTime;
        if (_timer <= 0)
        {
            _timer = updateInterval;
            UpdateLODs();
        }
    }

    void UpdateLODs()
    {
        foreach (var agent in allAgents)
        {
            if (agent == null) continue;

            float dist = Vector3.Distance(cameraTransform.position, agent.transform.position);
            CrowdLOD newLOD = DetermineLOD(dist);

            // Hysteresis: Only switch if the difference is significant to prevent flickering
            // If currently High and dist is slightly > 20, keep High. Only switch at 25.
            if (newLOD != agent.CurrentLOD)
            {
                agent.SwitchLOD(newLOD);
            }
        }
    }

    CrowdLOD DetermineLOD(float dist)
    {
        if (dist < highDetailDist) return CrowdLOD.High;
        if (dist < mediumDetailDist) return CrowdLOD.Medium;
        return CrowdLOD.Low;
    }
}

// 2. Agent LOD Component
public class CrowdAgentLOD : MonoBehaviour
{
    public CrowdLOD CurrentLOD { get; private set; }
    
    private NavMeshAgent _navAgent;
    private Renderer _renderer;
    private MonoBehaviour[] _highDetailScripts; // e.g., BoidAgent, SteeringAvoidance
    private Rigidbody _rb; // For imposter physics if needed
    private Vector3 _imposterTarget;

    void Start()
    {
        _navAgent = GetComponent<NavMeshAgent>();
        _renderer = GetComponent<Renderer>();
        _highDetailScripts = GetComponents<MonoBehaviour>().Where(c => c != this).ToArray();
        CurrentLOD = CrowdLOD.High; // Assume start high
    }

    public void SwitchLOD(CrowdLOD newLOD)
    {
        if (CurrentLOD == newLOD) return;

        // Exit current state
        if (CurrentLOD == CrowdLOD.High) ExitHighDetail();
        else if (CurrentLOD == CrowdLOD.Medium) ExitMediumDetail();
        else if (CurrentLOD == CrowdLOD.Low) ExitLowDetail();

        // Enter new state
        CurrentLOD = newLOD;
        if (newLOD == CrowdLOD.High) EnterHighDetail();
        else if (newLOD == CrowdLOD.Medium) EnterMediumDetail();
        else if (newLOD == CrowdLOD.Low) EnterLowDetail();
    }

    // --- HIGH DETAIL ---
    private void EnterHighDetail()
    {
        // Enable full simulation
        _navAgent.enabled = true;
        _renderer.enabled = true;
        foreach (var script in _highDetailScripts) script.enabled = true;
        
        // Ensure position is valid (re-sync from imposter if needed)
        if (!_navAgent.isOnNavMesh) 
            NavMesh.SamplePosition(transform.position, out NavMeshHit hit, 2.0f, NavMesh.AllAreas);
    }
    private void ExitHighDetail()
    {
        // Standard disable
    }

    // --- MEDIUM DETAIL ---
    private void EnterMediumDetail()
    {
        _navAgent.enabled = true;
        _renderer.enabled = true;
        // Disable heavy calculations (Boids/Steering)
        foreach (var script in _highDetailScripts) script.enabled = false;
        
        // Lower pathfinding frequency (simulate by disabling agent periodically in Update)
        _navAgent.updatePosition = true; 
    }
    private void ExitMediumDetail() { }

    // --- LOW DETAIL (IMPOSTER) ---
    private void EnterLowDetail()
    {
        _navAgent.enabled = false; // Disable expensive NavMesh pathfinding
        _renderer.enabled = true;  // Keep renderer (or swap to sprite)
        
        // Optional: Swap material to unlit/cheaper version
        // _renderer.material = PoolManager.Instance.GetImposterMaterial();

        // Calculate target based on global flow field or simple linear interpolation
        _imposterTarget = GetGlobalFlowTarget();
    }

    private void ExitLowDetail()
    {
        // Cleanup imposter logic
    }

    void Update()
    {
        // Specific logic per LOD
        if (CurrentLOD == CrowdLOD.Medium)
        {
            // Throttle updates (e.g., only recalc path every 2 seconds)
            if (Time.frameCount % 60 == 0) 
                _navAgent.SetDestination(GetGlobalFlowTarget());
        }
        else if (CurrentLOD == CrowdLOD.Low)
        {
            // Simple linear movement towards target (Flow Field)
            float speed = 2.0f;
            transform.position = Vector3.MoveTowards(transform.position, _imposterTarget, speed * Time.deltaTime);
            // Rotate visually
            if (_imposterTarget != transform.position)
                transform.rotation = Quaternion.LookRotation(_imposterTarget - transform.position);
        }
    }

    private Vector3 GetGlobalFlowTarget()
    {
        // Example: Move towards a central point or exit
        return Vector3.zero; 
    }
}

// 3. Object Pooling for Imposters (Conceptual)
public class PoolManager : MonoBehaviour
{
    // In a real scenario, this would manage switching meshes/materials
    // to avoid instantiating/destroying GameObjects.
    public Queue<GameObject> imposterPool = new Queue<GameObject>();
    
    public void ReturnToPool(GameObject obj)
    {
        obj.SetActive(false);
        imposterPool.Enqueue(obj);
    }
    
    public GameObject GetFromPool()
    {
        if (imposterPool.Count > 0)
        {
            GameObject obj = imposterPool.Dequeue();
            obj.SetActive(true);
            return obj;
        }
        return null; // Or instantiate new if strict limit not reached
    }
}
