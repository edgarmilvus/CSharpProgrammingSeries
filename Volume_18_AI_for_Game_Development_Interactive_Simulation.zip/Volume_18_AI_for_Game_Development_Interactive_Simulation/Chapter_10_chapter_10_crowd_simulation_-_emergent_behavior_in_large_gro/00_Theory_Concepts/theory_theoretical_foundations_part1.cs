
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

using System.Collections.Generic;
using UnityEngine;

// Using modern C# records for immutable data structures. 
// These hold the context we feed to the AI.
public record CrowdContext(
    Vector3 CenterOfMass, 
    Vector3 AverageVelocity, 
    float Density, 
    string RecentEventDescription
);

// Using Records for the LLM's response.
public record LLMBehaviorResponse(
    string SuggestedState, 
    float PanicLevel, 
    Vector3? CollectiveFocusPoint
);

// The core interface that abstracts the "Brain" of the agent.
public interface IAgentDecisionEngine
{
    // Async is critical here. LLM calls are network-bound.
    // We use Task<T> to prevent freezing the main Unity thread.
    Task<LLMBehaviorResponse> AnalyzeAndDecideAsync(CrowdContext context);
}

// The interface for the physical movement (Steering behaviors).
public interface ISteeringBehavior
{
    Vector3 CalculateSteeringForce(Vector3 currentVelocity);
}
