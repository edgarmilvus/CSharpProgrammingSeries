
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.cs
// Description: Theoretical Foundations
// ==========================================

// Conceptual representation of a state handling an LLM call.
public class ThinkingState : IState
{
    private readonly IAgentDecisionEngine _decisionEngine;
    private Task<LLMBehaviorResponse> _pendingDecision;

    public void OnEnter(Agent agent)
    {
        // We kick off the async call but do not block.
        var context = GatherContext(agent);
        _pendingDecision = _decisionEngine.AnalyzeAndDecideAsync(context);
    }

    public void OnUpdate(Agent agent)
    {
        // If the task is not null and is completed, we have a result.
        if (_pendingDecision != null && _pendingDecision.IsCompleted)
        {
            var result = _pendingDecision.Result;
            // Now we transition based on the LLM's output.
            if (result.SuggestedState == "Panic")
                agent.StateMachine.ChangeState(new PanicState(result.PanicLevel));
            else
                agent.StateMachine.ChangeState(new IdleState());
        }
        // While waiting, the agent might just continue flocking.
    }
}
