
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Burst;
using System;

/// <summary>
/// A self-contained, 'Hello World' level crowd simulation demonstrating 
/// emergent flocking behavior (Boids) combined with simple obstacle avoidance.
/// This script should be attached to a GameObject in the Unity scene.
/// </summary>
public class BasicCrowdSimulation : MonoBehaviour
{
    // --- Configuration & Inspector Settings ---

    [Header("Simulation Settings")]
    [Tooltip("Number of agents to spawn.")]
    [SerializeField] private int agentCount = 50;

    [Tooltip("Prefab for the individual agent visual.")]
    [SerializeField] private GameObject agentPrefab;

    [Tooltip("Bounds within which agents are allowed to roam.")]
    [SerializeField] private Vector3 simulationBounds = new Vector3(20f, 10f, 20f);

    [Header("Flocking Weights")]
    [Tooltip("Weight for Cohesion (move towards center of local group).")]
    [Range(0f, 5f)] [SerializeField] private float cohesionWeight = 1.0f;

    [Tooltip("Weight for Alignment (match velocity of local group).")]
    [Range(0f, 5f)] [SerializeField] private float alignmentWeight = 1.0f;

    [Tooltip("Weight for Separation (avoid crowding neighbors).")]
    [Range(0f, 5f)] [SerializeField] private float separationWeight = 1.5f;

    [Tooltip("Weight for Boundary Avoidance (stay within bounds).")]
    [Range(0f, 5f)] [SerializeField] private float boundaryWeight = 2.0f;

    [Header("Perception")]
    [Tooltip("Radius to detect neighbors.")]
    [SerializeField] private float perceptionRadius = 3.0f;

    [Tooltip("Maximum speed of agents.")]
    [SerializeField] private float maxSpeed = 3.0f;

    [Tooltip("Maximum steering force (how fast they can turn).")]
    [SerializeField] private float maxForce = 0.1f;

    // --- Internal State ---
    private NativeArray<float3> positions;
    private NativeArray<float3> velocities;
    private Transform[] agentTransforms;
    private bool isInitialized = false;

    // --- Unity Lifecycle ---

    private void Start()
    {
        InitializeAgents();
    }

    private void Update()
    {
        if (!isInitialized) return;

        // 1. Schedule the Job
        FlockingJob flockingJob = new FlockingJob
        {
            Positions = positions,
            Velocities = velocities,
            PerceptionRadius = perceptionRadius,
            MaxSpeed = maxSpeed,
            MaxForce = maxForce,
            CohesionWeight = cohesionWeight,
            AlignmentWeight = alignmentWeight,
            SeparationWeight = separationWeight,
            BoundaryWeight = boundaryWeight,
            BoundsCenter = transform.position,
            BoundsSize = simulationBounds,
            DeltaTime = Time.deltaTime
        };

        // Schedule the job on the main thread (simplest for "Hello World")
        JobHandle handle = flockingJob.Schedule(agentCount, 64);
        handle.Complete(); // Wait for job to finish

        // 2. Apply Results to Visuals
        UpdateVisuals();

        // 3. Cleanup if needed
        // (In a real production scenario, we would use JobHandle.Complete() 
        // asynchronously or use IJobParallelForTransform for direct transform manipulation)
    }

    private void OnDestroy()
    {
        // Critical: Dispose native arrays to prevent memory leaks
        if (positions.IsCreated) positions.Dispose();
        if (velocities.IsCreated) velocities.Dispose();
    }

    // --- Helper Methods ---

    private void InitializeAgents()
    {
        if (agentPrefab == null)
        {
            Debug.LogError("Agent Prefab is not assigned!");
            return;
        }

        // Initialize Native Arrays (High-performance memory allocation)
        positions = new NativeArray<float3>(agentCount, Allocator.Persistent);
        velocities = new NativeArray<float3>(agentCount, Allocator.Persistent);
        agentTransforms = new Transform[agentCount];

        // Spawn Agents
        for (int i = 0; i < agentCount; i++)
        {
            // Random position within bounds
            Vector3 randomPos = transform.position + new Vector3(
                UnityEngine.Random.Range(-simulationBounds.x / 2, simulationBounds.x / 2),
                UnityEngine.Random.Range(-simulationBounds.y / 2, simulationBounds.y / 2),
                UnityEngine.Random.Range(-simulationBounds.z / 2, simulationBounds.z / 2)
            );

            GameObject instance = Instantiate(agentPrefab, randomPos, Quaternion.identity, transform);
            agentTransforms[i] = instance.transform;

            // Set initial data
            positions[i] = randomPos;
            velocities[i] = UnityEngine.Random.insideUnitSphere * maxSpeed;
        }

        isInitialized = true;
    }

    private void UpdateVisuals()
    {
        // Since we aren't using IJobParallelForTransform (to keep the example simple),
        // we manually update transforms here. This is the bottleneck in a real scenario.
        for (int i = 0; i < agentCount; i++)
        {
            agentTransforms[i].position = positions[i];
            
            // Rotate to face velocity direction
            if (velocities[i].sqrMagnitude > 0.001f)
            {
                agentTransforms[i].rotation = Quaternion.LookRotation(velocities[i]);
            }
        }
    }

    // --- Visual Debugging ---
    private void OnDrawGizmosSelected()
    {
        if (!isInitialized) return;

        // Draw simulation bounds
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(transform.position, simulationBounds);

        // Draw a sample agent's perception radius (first agent only)
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(positions[0], perceptionRadius);
    }
}

/// <summary>
/// The Burst-compiled job that performs the flocking calculations in parallel.
/// This separates the logic from the Unity main thread overhead.
/// </summary>
[BurstCompile]
public struct FlockingJob : IJobParallelFor
{
    // --- Data Inputs/Outputs ---
    // NativeArrays are accessible across the managed/unmanaged boundary
    [ReadOnly] public NativeArray<float3> Positions;
    public NativeArray<float3> Velocities;

    // --- Parameters ---
    [ReadOnly] public float PerceptionRadius;
    [ReadOnly] public float MaxSpeed;
    [ReadOnly] public float MaxForce;
    [ReadOnly] public float CohesionWeight;
    [ReadOnly] public float AlignmentWeight;
    [ReadOnly] public float SeparationWeight;
    [ReadOnly] public float BoundaryWeight;
    [ReadOnly] public float3 BoundsCenter;
    [ReadOnly] public float3 BoundsSize;
    [ReadOnly] public float DeltaTime;

    // --- Job Execution ---
    // This method runs in parallel for every index from 0 to agentCount
    public void Execute(int index)
    {
        float3 position = Positions[index];
        float3 velocity = Velocities[index];

        // 1. Calculate Flocking Forces
        float3 cohesion = float3.zero;
        float3 alignment = float3.zero;
        float3 separation = float3.zero;
        int neighborCount = 0;

        // Iterate over all other agents to find neighbors
        // NOTE: O(N^2) complexity. For "Hello World" this is acceptable.
        // Production systems use Spatial Hashing or QuadTrees.
        for (int i = 0; i < Positions.Length; i++)
        {
            if (i == index) continue;

            float3 otherPos = Positions[i];
            float dist = math.distance(position, otherPos);

            if (dist < PerceptionRadius)
            {
                // Cohesion: Accumulate neighbor positions
                cohesion += otherPos;

                // Alignment: Accumulate neighbor velocities
                alignment += Velocities[i];

                // Separation: Calculate vector pointing away from neighbor
                // The closer the neighbor, the stronger the push
                float3 diff = position - otherPos;
                separation += math.normalize(diff) / dist; // Weight by distance

                neighborCount++;
            }
        }

        // Average out the forces if we have neighbors
        if (neighborCount > 0)
        {
            // Cohesion: Steer towards the average position of neighbors
            cohesion /= neighborCount;
            cohesion = Steer(cohesion, position, velocity);

            // Alignment: Steer towards the average velocity of neighbors
            alignment /= neighborCount;
            alignment = Steer(alignment, position, velocity);

            // Separation: Steer away from the crowded area
            separation /= neighborCount;
            separation = Steer(separation, position, velocity);
        }

        // 2. Calculate Boundary Avoidance (Keep inside the box)
        float3 boundaryForce = CalculateBoundaryForce(position);

        // 3. Apply Weights and Combine Forces
        float3 acceleration = float3.zero;
        acceleration += cohesion * CohesionWeight;
        acceleration += alignment * AlignmentWeight;
        acceleration += separation * SeparationWeight;
        acceleration += boundaryForce * BoundaryWeight;

        // 4. Update Velocity and Position (Euler Integration)
        velocity += acceleration * DeltaTime;
        
        // Limit speed
        float3 velNormalized = math.normalize(velocity);
        if (math.length(velocity) > MaxSpeed)
        {
            velocity = velNormalized * MaxSpeed;
        }

        // Update position
        float3 newPos = position + velocity * DeltaTime;

        // 5. Write back to NativeArrays
        Positions[index] = newPos;
        Velocities[index] = velocity;
    }

    // --- Physics Helpers ---

    /// <summary>
    /// Calculates a steering force towards a target.
    /// Standard Reynolds steering behavior: Desired - Current.
    /// </summary>
    private float3 Steer(float3 target, float3 position, float3 currentVelocity)
    {
        float3 desired = target - position;
        // If target is exactly at position, desired is zero; handle edge case
        if (math.lengthsq(desired) < 0.0001f) return float3.zero;

        desired = math.normalize(desired) * MaxSpeed;
        float3 steer = desired - currentVelocity;
        
        // Limit force
        float3 steerNormalized = math.normalize(steer);
        if (math.length(steer) > MaxForce)
        {
            steer = steerNormalized * MaxForce;
        }
        
        return steer;
    }

    /// <summary>
    /// Calculates a force pushing the agent back into the defined bounds.
    /// </summary>
    private float3 CalculateBoundaryForce(float3 position)
    {
        float3 force = float3.zero;
        float3 halfBounds = BoundsSize * 0.5f;
        float3 localPos = position - BoundsCenter;

        // Check X boundaries
        if (localPos.x > halfBounds.x) force.x = -1;
        else if (localPos.x < -halfBounds.x) force.x = 1;

        // Check Y boundaries
        if (localPos.y > halfBounds.y) force.y = -1;
        else if (localPos.y < -halfBounds.y) force.y = 1;

        // Check Z boundaries
        if (localPos.z > halfBounds.z) force.z = -1;
        else if (localPos.z < -halfBounds.z) force.z = 1;

        // If we are inside bounds, force is (0,0,0).
        // If outside, we push back towards center.
        if (math.lengthsq(force) > 0)
        {
            // Steer towards the center of the bounds
            float3 target = BoundsCenter;
            return Steer(target, position, float3.zero); // Simplified steering
        }

        return float3.zero;
    }
}
