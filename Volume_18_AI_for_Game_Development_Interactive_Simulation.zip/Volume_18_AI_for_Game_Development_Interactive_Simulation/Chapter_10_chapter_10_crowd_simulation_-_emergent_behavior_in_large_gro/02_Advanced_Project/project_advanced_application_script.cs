
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

namespace CrowdSimulationAdvanced
{
    // Represents a 2D coordinate in the simulation space.
    public struct Vector2
    {
        public float X;
        public float Y;

        public Vector2(float x, float y)
        {
            X = x;
            Y = y;
        }

        // Calculates Euclidean distance between two vectors.
        public static float Distance(Vector2 a, Vector2 b)
        {
            float dx = a.X - b.X;
            float dy = a.Y - b.Y;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        // Adds two vectors together.
        public static Vector2 Add(Vector2 a, Vector2 b)
        {
            return new Vector2(a.X + b.X, a.Y + b.Y);
        }

        // Multiplies a vector by a scalar value.
        public static Vector2 Scale(Vector2 v, float scalar)
        {
            return new Vector2(v.X * scalar, v.Y * scalar);
        }
    }

    // Defines the current state of an agent using a simple enumeration.
    public enum AgentState
    {
        Wandering,
        Fleeing,
        Regrouping
    }

    // Represents a single AI agent in the crowd simulation.
    public class Agent
    {
        public Vector2 Position;
        public Vector2 Velocity;
        public AgentState CurrentState;
        public float Speed;
        public int Id;

        // The agent's personal "safe zone" radius. If a threat enters this, it flees.
        private const float PersonalSpace = 5.0f;
        
        // The maximum distance an agent can see a threat.
        private const float VisionRange = 15.0f;

        public Agent(int id, float startX, float startY)
        {
            Id = id;
            Position = new Vector2(startX, startY);
            Velocity = new Vector2(0, 0);
            CurrentState = AgentState.Wandering;
            Speed = 2.0f; // Base speed
        }

        // The core decision-making logic for the agent.
        // This acts as a Finite State Machine (FSM) transition handler.
        public void UpdateState(List<Threat> threats, List<Agent> neighbors)
        {
            bool threatDetected = false;

            // Check for nearby threats
            foreach (var threat in threats)
            {
                float dist = Vector2.Distance(Position, threat.Position);
                if (dist < VisionRange)
                {
                    threatDetected = true;
                    break;
                }
            }

            // State Transitions
            if (threatDetected)
            {
                CurrentState = AgentState.Fleeing;
                Speed = 4.0f; // Run faster when scared
            }
            else if (CurrentState == AgentState.Fleeing)
            {
                // If no longer seeing threats, check if we need to regroup
                if (neighbors.Count > 0)
                {
                    CurrentState = AgentState.Regrouping;
                    Speed = 1.5f; // Walk slowly to regroup
                }
                else
                {
                    CurrentState = AgentState.Wandering;
                    Speed = 2.0f;
                }
            }
            else if (CurrentState == AgentState.Regrouping)
            {
                // If too far from group, go back to wandering
                if (neighbors.Count == 0)
                {
                    CurrentState = AgentState.Wandering;
                    Speed = 2.0f;
                }
            }
            else
            {
                // Default state
                CurrentState = AgentState.Wandering;
                Speed = 2.0f;
            }
        }

        // Applies movement logic based on the current state.
        public void Move(List<Agent> neighbors, List<Threat> threats)
        {
            Vector2 steeringForce = new Vector2(0, 0);

            if (CurrentState == AgentState.Fleeing)
            {
                // Fleeing Logic: Calculate vector directly away from the nearest threat
                Vector2 closestThreatPos = new Vector2(0, 0);
                float minDist = float.MaxValue;

                foreach (var threat in threats)
                {
                    float d = Vector2.Distance(Position, threat.Position);
                    if (d < minDist)
                    {
                        minDist = d;
                        closestThreatPos = threat.Position;
                    }
                }

                // Vector pointing from threat to agent (direction to run)
                Vector2 fleeDirection = Vector2.Add(Position, Vector2.Scale(closestThreatPos, -1));
                steeringForce = Vector2.Add(steeringForce, fleeDirection);
            }
            else if (CurrentState == AgentState.Regrouping)
            {
                // Cohesion Logic: Calculate center of mass of neighbors
                Vector2 centerOfMass = new Vector2(0, 0);
                int count = 0;
                foreach (var neighbor in neighbors)
                {
                    centerOfMass = Vector2.Add(centerOfMass, neighbor.Position);
                    count++;
                }

                if (count > 0)
                {
                    centerOfMass = Vector2.Scale(centerOfMass, 1.0f / count);
                    // Steer towards center
                    Vector2 directionToCenter = Vector2.Add(centerOfMass, Vector2.Scale(Position, -1));
                    steeringForce = Vector2.Add(steeringForce, directionToCenter);
                }
            }
            else
            {
                // Wandering Logic: Random drift
                Random rand = new Random();
                float xDir = (float)(rand.NextDouble() * 2 - 1); // -1 to 1
                float yDir = (float)(rand.NextDouble() * 2 - 1);
                steeringForce = Vector2.Add(steeringForce, new Vector2(xDir, yDir));
            }

            // Normalize and apply speed
            float magnitude = (float)Math.Sqrt(steeringForce.X * steeringForce.X + steeringForce.Y * steeringForce.Y);
            if (magnitude > 0)
            {
                // Normalize
                Vector2 normalizedForce = Vector2.Scale(steeringForce, 1.0f / magnitude);
                // Apply Velocity
                Velocity = Vector2.Scale(normalizedForce, Speed);
            }

            // Update Position
            Position = Vector2.Add(Position, Velocity);
        }
    }

    // Represents a hostile entity that causes the crowd to react.
    public class Threat
    {
        public Vector2 Position;
        public float Range;

        public Threat(float x, float y, float range)
        {
            Position = new Vector2(x, y);
            Range = range;
        }

        // Simple movement for the threat to demonstrate dynamic reaction
        public void Move()
        {
            // Moves in a circle for demonstration
            float time = DateTime.Now.Millisecond / 1000.0f;
            Position = new Vector2(
                Position.X + (float)Math.Cos(time) * 0.5f,
                Position.Y + (float)Math.Sin(time) * 0.5f
            );
        }
    }

    // The main simulation controller.
    public class Simulation
    {
        private List<Agent> agents;
        private List<Threat> threats;
        private const float NeighborRadius = 8.0f;
        private const int GridWidth = 50;
        private const int GridHeight = 50;

        public Simulation(int agentCount)
        {
            agents = new List<Agent>();
            threats = new List<Threat>();
            Random rand = new Random();

            // Initialize Agents
            for (int i = 0; i < agentCount; i++)
            {
                agents.Add(new Agent(i, 
                    (float)rand.NextDouble() * GridWidth, 
                    (float)rand.NextDouble() * GridHeight));
            }

            // Initialize Threats
            threats.Add(new Threat(25, 25, 10.0f));
        }

        // Runs a single tick of the simulation.
        public void Tick()
        {
            // 1. Update Threat Positions
            foreach (var threat in threats)
            {
                threat.Move();
            }

            // 2. Update Agents
            foreach (var agent in agents)
            {
                // Identify neighbors (Simplified O(N^2) check for clarity)
                // In a production Unity system, we would use a Spatial Hash or QuadTree here.
                List<Agent> neighbors = new List<Agent>();
                foreach (var other in agents)
                {
                    if (agent.Id != other.Id)
                    {
                        float dist = Vector2.Distance(agent.Position, other.Position);
                        if (dist < NeighborRadius)
                        {
                            neighbors.Add(other);
                        }
                    }
                }

                // Update State Machine
                agent.UpdateState(threats, neighbors);

                // Move Agent
                agent.Move(neighbors, threats);

                // Boundary wrapping (Keep agents inside the simulation box)
                if (agent.Position.X < 0) agent.Position = new Vector2(GridWidth, agent.Position.Y);
                if (agent.Position.X > GridWidth) agent.Position = new Vector2(0, agent.Position.Y);
                if (agent.Position.Y < 0) agent.Position = new Vector2(agent.Position.X, GridHeight);
                if (agent.Position.Y > GridHeight) agent.Position = new Vector2(agent.Position.X, 0);
            }
        }

        // Output current state for debugging/visualization.
        public void PrintStatus()
        {
            Console.Clear();
            Console.WriteLine($"--- Simulation Tick ---");
            Console.WriteLine($"Agents: {agents.Count} | Threats: {threats.Count}");
            
            int fleeing = 0, regrouping = 0, wandering = 0;
            foreach(var a in agents)
            {
                if (a.CurrentState == AgentState.Fleeing) fleeing++;
                else if (a.CurrentState == AgentState.Regrouping) regrouping++;
                else wandering++;
            }

            Console.WriteLine($"[Wandering: {wandering}] [Regrouping: {regrouping}] [Fleeing: {fleeing}]");
            
            // Visualizing a small subset
            Console.WriteLine("\nTop-Left Corner Activity (Sample):");
            foreach(var a in agents)
            {
                if (a.Position.X < 10 && a.Position.Y < 10)
                {
                    Console.WriteLine($" - Agent {a.Id} at ({a.Position.X:F1}, {a.Position.Y:F1}) - State: {a.CurrentState}");
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Initialize simulation with 20 agents
            Simulation sim = new Simulation(20);

            // Run for 5 ticks to demonstrate behavior changes
            for (int i = 0; i < 5; i++)
            {
                sim.Tick();
                sim.PrintStatus();
                System.Threading.Thread.Sleep(1000); // Pause to make output readable
            }
        }
    }
}
