
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

// A simple, self-contained memory system for an NPC.
// This example simulates an NPC that remembers the player's name and past topics discussed.
public class SimpleMemoryNPC : MonoBehaviour
{
    // 1. DATA STRUCTURES: The core memory structures.
    // We use a simple struct to represent a memory fragment.
    // In a production system, this would be more complex (vector embeddings, timestamps, etc.).
    public struct MemoryFragment
    {
        public string Content;      // What was said or observed
        public string Importance;   // "Low", "Medium", "High" (simulating salience)
        public DateTime Timestamp;  // When it happened

        public MemoryFragment(string content, string importance)
        {
            Content = content;
            Importance = importance;
            Timestamp = DateTime.Now;
        }
    }

    // 2. STATE: The NPC's internal memory bank.
    // We use a List for simplicity, but a Vector Database would be used for scale.
    private List<MemoryFragment> _memoryBank = new List<MemoryFragment>();

    // 3. CONTEXT: The current session's conversation history.
    // This is distinct from long-term memory.
    private List<string> _currentSessionHistory = new List<string>();

    // 4. CONFIGURATION: Simulating LLM parameters.
    private const float MEMORY_RETENTION_THRESHOLD = 0.5f; // 0.0 to 1.0

    /// <summary>
    /// The entry point for processing a player's input.
    /// </summary>
    public async Task<string> ProcessPlayerInput(string playerInput)
    {
        // Log the input to the current session
        _currentSessionHistory.Add($"Player: {playerInput}");

        // Step 1: Analyze the input for memory-worthy content
        var memoryCandidate = AnalyzeInput(playerInput);

        // Step 2: If significant, store it in long-term memory
        if (memoryCandidate != null)
        {
            _memoryBank.Add(memoryCandidate.Value);
            Debug.Log($"[Memory System] New memory stored: '{memoryCandidate.Value.Content}' (Importance: {memoryCandidate.Value.Importance})");
        }

        // Step 3: Retrieve relevant memories from the bank
        var relevantMemories = RetrieveRelevantMemories(playerInput);

        // Step 4: Construct the context for the LLM
        string contextPrompt = ConstructContextPrompt(relevantMemories);

        // Step 5: Simulate generating a response (In reality, this calls an LLM API)
        string npcResponse = await GenerateResponseAsync(contextPrompt, playerInput);

        // Log the response to session history
        _currentSessionHistory.Add($"NPC: {npcResponse}");

        return npcResponse;
    }

    // --- CORE LOGIC METHODS ---

    /// <summary>
    /// Analyzes input to decide if it should be remembered.
    /// This simulates the "Reflection" module mentioned in the chapter.
    /// </summary>
    private MemoryFragment? AnalyzeInput(string input)
    {
        // Simple heuristic: If input contains "my name is" or "remember", store it.
        // In a real LLM system, we would ask the LLM: "Rate the importance of this text 0-1."
        
        if (input.ToLower().Contains("my name is"))
        {
            return new MemoryFragment(input, "High");
        }
        
        if (input.ToLower().Contains("remember") || input.ToLower().Contains("quest"))
        {
            return new MemoryFragment(input, "Medium");
        }

        return null; // Not worth remembering
    }

    /// <summary>
    /// Retrieves memories relevant to the current input.
    /// This simulates Vector Search / RAG (Retrieval Augmented Generation).
    /// </summary>
    private List<MemoryFragment> RetrieveRelevantMemories(string currentInput)
    {
        var relevant = new List<MemoryFragment>();

        // Heuristic matching: Check for keyword overlap.
        // Real systems use Cosine Similarity on vector embeddings.
        
        foreach (var memory in _memoryBank)
        {
            // Check if memory content shares words with current input
            if (currentInput.ToLower().Split(' ').Any(word => 
                memory.Content.ToLower().Contains(word) && word.Length > 3))
            {
                relevant.Add(memory);
            }
        }

        return relevant;
    }

    /// <summary>
    /// Constructs the prompt by injecting retrieved memories.
    /// This is the "Context Manager" logic.
    /// </summary>
    private string ConstructContextPrompt(List<MemoryFragment> relevantMemories)
    {
        string prompt = "You are an NPC assistant. You have access to the following memories:\n";

        if (relevantMemories.Count == 0)
        {
            prompt += "- No specific memories relevant to this topic.\n";
        }
        else
        {
            foreach (var mem in relevantMemories)
            {
                // Format: [High Importance] Memory: "I like apples"
                prompt += $"- [{mem.Importance} Importance] Memory: \"{mem.Content}\"\n";
            }
        }

        prompt += "\nBased on these memories and the conversation history, respond naturally.\n";
        prompt += "Conversation History:\n";

        // Add last 2 exchanges for context
        int historyCount = _currentSessionHistory.Count;
        int startIndex = Math.Max(0, historyCount - 4); // Last 4 lines (2 pairs)
        
        for (int i = startIndex; i < historyCount; i++)
        {
            prompt += $"{_currentSessionHistory[i]}\n";
        }

        return prompt;
    }

    /// <summary>
    /// Simulates the LLM call.
    /// </summary>
    private async Task<string> GenerateResponseAsync(string context, string playerInput)
    {
        // SIMULATION: In a real project, you would send 'context' + 'playerInput' to an API.
        // Example: var response = await LLMClient.ChatAsync(context, playerInput);
        
        // Simulate network delay
        await Task.Delay(100);

        // Simple logic to demonstrate memory usage in response
        if (playerInput.ToLower().Contains("my name is"))
        {
            // Extract name for a personalized response
            return "Nice to meet you! I will remember that.";
        }

        if (_memoryBank.Count > 0)
        {
            return "I recall us discussing something similar before. Tell me more.";
        }

        return "Hello traveler. How can I help you?";
    }

    // --- UNITY EXAMPLE USAGE ---

    private async void Start()
    {
        // Example Conversation Flow
        Debug.Log("--- Starting Conversation ---");
        
        // 1. Initial Greeting
        string response1 = await ProcessPlayerInput("Hello there.");
        Debug.Log($"NPC: {response1}");

        // 2. Player introduces themselves (Triggering Memory Storage)
        string response2 = await ProcessPlayerInput("My name is Arthur.");
        Debug.Log($"NPC: {response2}");

        // 3. Player asks about a quest (Triggering Memory Storage)
        string response3 = await ProcessPlayerInput("Do you remember the quest I mentioned?");
        Debug.Log($"NPC: {response3}");

        // 4. Player changes topic, but NPC retrieves memory based on keyword overlap
        string response4 = await ProcessPlayerInput("What do you know about the dragon?");
        Debug.Log($"NPC: {response4}");
        
        // 5. NPC demonstrates recall of name
        string response5 = await ProcessPlayerInput("Arthur, do you like dragons?");
        Debug.Log($"NPC: {response5}");
    }
}
