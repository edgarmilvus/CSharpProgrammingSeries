
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace Chapter6_AdvancedMemorySystem
{
    // =============================================================================================================
    // REAL-WORLD CONTEXT: "The Persistent Shopkeeper"
    // =============================================================================================================
    // Problem: In an open-world RPG, players interact with merchants. Typically, these interactions are "amnesiac."
    // If a player steals an item and returns later, the merchant acts as if they've never met. This breaks immersion.
    // 
    // Solution: We implement a "Long-Term Memory" system using Vector Embeddings (simplified as float arrays) 
    // and a Reflection Module. The NPC will:
    // 1. Summarize conversations into "Memory Fragments."
    // 2. Embed these fragments into a vector space.
    // 3. Retrieve relevant memories based on the current context.
    // 4. Reflect on the player's behavior to update internal beliefs (e.g., "Player is a thief").
    // 5. Generate a context-aware response that evolves over time.
    // =============================================================================================================

    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the NPC with a base personality
            NPC shopkeeper = new NPC("Elias", "Stoic and observant merchant.");
            
            // Simulate a sequence of player interactions over time
            Console.WriteLine("--- DAY 1: The Initial Meeting ---");
            SimulateInteraction(shopkeeper, "Hello! What do you sell?");
            
            Console.WriteLine("\n--- DAY 2: A Theft Occurs ---");
            SimulateInteraction(shopkeeper, "I'm just browsing... (Steals a potion)");
            
            Console.WriteLine("\n--- DAY 3: The Return ---");
            // The player returns. The NPC should remember the theft.
            SimulateInteraction(shopkeeper, "Good morning!");
        }

        // Helper method to simulate the interaction loop
        static void SimulateInteraction(NPC npc, string playerInput)
        {
            // 1. Perception: The NPC processes the input and current state
            string perception = npc.Observe(playerInput);
            
            // 2. Memory Retrieval: The NPC searches for relevant past experiences
            string retrievedMemory = npc.RetrieveMemory(perception);
            
            // 3. Reflection: The NPC updates internal beliefs based on the interaction
            npc.Reflect(playerInput);
            
            // 4. Response Generation: Synthesize context + memory + belief
            string response = npc.GenerateResponse(retrievedMemory);
            
            Console.WriteLine($"[Player]: {playerInput}");
            Console.WriteLine($"[Elias]: {response}");
            Console.WriteLine($"[System]: Internal Belief State: {npc.GetBeliefSummary()}");
        }
    }

    // =============================================================================================================
    // CLASS: MemoryFragment
    // Purpose: Represents a single unit of long-term memory.
    // =============================================================================================================
    public class MemoryFragment
    {
        public string Content { get; set; }       // The summarized text of the event
        public float[] Embedding { get; set; }    // The vector representation of the content
        public int Importance { get; set; }       // Weight of the memory (1-10)

        public MemoryFragment(string content, float[] embedding, int importance)
        {
            Content = content;
            Embedding = embedding;
            Importance = importance;
        }
    }

    // =============================================================================================================
    // CLASS: VectorDatabase
    // Purpose: Simulates a vector store (like Pinecone or Milvus) for efficient similarity search.
    // Constraint: We use basic loops and math (Cosine Similarity) to find relevant memories.
    // =============================================================================================================
    public class VectorDatabase
    {
        private List<MemoryFragment> _memories = new List<MemoryFragment>();

        // Stores a new memory fragment
        public void AddMemory(string content, float[] queryVector, int importance)
        {
            // In a real system, we would generate the embedding here. 
            // For this simulation, we assume the queryVector is the embedding of the content.
            _memories.Add(new MemoryFragment(content, queryVector, importance));
        }

        // Searches for the most relevant memory based on Cosine Similarity
        public string Search(float[] queryVector, float threshold = 0.7f)
        {
            if (_memories.Count == 0) return null;

            float bestScore = -1;
            MemoryFragment bestMatch = null;

            // Iterate through all memories (Brute force search for simplicity)
            foreach (var memory in _memories)
            {
                float score = CalculateCosineSimilarity(queryVector, memory.Embedding);
                
                // Boost score based on importance
                float weightedScore = score * (memory.Importance / 10.0f);

                if (weightedScore > bestScore)
                {
                    bestScore = weightedScore;
                    bestMatch = memory;
                }
            }

            // Return the content if the similarity is above the threshold
            if (bestScore >= threshold && bestMatch != null)
            {
                return bestMatch.Content;
            }

            return null;
        }

        // Mathematical helper: Cosine Similarity (Normalized Dot Product)
        private float CalculateCosineSimilarity(float[] vecA, float[] vecB)
        {
            if (vecA.Length != vecB.Length) return 0f;

            float dotProduct = 0.0f;
            float magnitudeA = 0.0f;
            float magnitudeB = 0.0f;

            for (int i = 0; i < vecA.Length; i++)
            {
                dotProduct += vecA[i] * vecB[i];
                magnitudeA += vecA[i] * vecA[i];
                magnitudeB += vecB[i] * vecB[i];
            }

            magnitudeA = (float)Math.Sqrt(magnitudeA);
            magnitudeB = (float)Math.Sqrt(magnitudeB);

            if (magnitudeA == 0 || magnitudeB == 0) return 0;

            return dotProduct / (magnitudeA * magnitudeB);
        }
    }

    // =============================================================================================================
    // CLASS: NPC
    // Purpose: The central intelligence unit combining Perception, Memory, Reflection, and Generation.
    // =============================================================================================================
    public class NPC
    {
        public string Name { get; private set; }
        private string _personalityTrait;
        
        // The Memory System (Vector Database)
        private VectorDatabase _longTermMemory = new VectorDatabase();
        
        // The Reflection System (Internal Beliefs)
        private Dictionary<string, int> _beliefs = new Dictionary<string, int>(); 

        public NPC(string name, string personality)
        {
            Name = name;
            _personalityTrait = personality;
            
            // Initialize beliefs
            _beliefs["Trust"] = 50; // 0-100 scale
            _beliefs["Suspicion"] = 10;
        }

        // ---------------------------------------------------------------------
        // 1. PERCEPTION MODULE
        // ---------------------------------------------------------------------
        // Converts raw text input into a query vector (embedding) for the system.
        // In a real app, this would call an LLM API (e.g., OpenAI) to get the vector.
        // Here, we simulate it with a hashing function to create deterministic floats.
        public string Observe(string playerInput)
        {
            // Simulate embedding generation
            float[] inputVector = GenerateEmbedding(playerInput);
            
            // We return the string representation for the next step, 
            // but in a real pipeline, we'd pass the vector directly.
            return playerInput; 
        }

        // ---------------------------------------------------------------------
        // 2. MEMORY RETRIEVAL MODULE
        // ---------------------------------------------------------------------
        // Uses the Vector Database to find relevant past experiences.
        public string RetrieveMemory(string perception)
        {
            float[] queryVector = GenerateEmbedding(perception);
            string memoryContent = _longTermMemory.Search(queryVector);
            
            if (memoryContent != null)
            {
                return $"(Memory Triggered: Remembering '{memoryContent}')";
            }
            return "(No specific memory triggered)";
        }

        // ---------------------------------------------------------------------
        // 3. REFLECTION MODULE
        // ---------------------------------------------------------------------
        // Autonomous process where the NPC updates beliefs based on recent events.
        public void Reflect(string playerAction)
        {
            // Analyze text for keywords to update beliefs (Simplified Sentiment Analysis)
            if (playerAction.Contains("Steal") || playerAction.Contains("Thief") || playerAction.Contains("browsing"))
            {
                _beliefs["Suspicion"] += 20;
                _beliefs["Trust"] -= 20;
                
                // Cap values
                if (_beliefs["Suspicion"] > 100) _beliefs["Suspicion"] = 100;
                if (_beliefs["Trust"] < 0) _beliefs["Trust"] = 0;

                // Store this significant event in Long-Term Memory
                // Summarization: "Player stole an item."
                string summary = "Player behaved suspiciously (theft).";
                float[] summaryVector = GenerateEmbedding(summary);
                _longTermMemory.AddMemory(summary, summaryVector, 9); // High importance
            }
            else if (playerAction.Contains("Buy") || playerAction.Contains("Hello"))
            {
                _beliefs["Trust"] += 5;
                if (_beliefs["Trust"] > 100) _beliefs["Trust"] = 100;
            }
        }

        // ---------------------------------------------------------------------
        // 4. RESPONSE GENERATION MODULE
        // ---------------------------------------------------------------------
        // Synthesizes the current context, retrieved memory, and internal beliefs.
        public string GenerateResponse(string retrievedMemory)
        {
            StringBuilder sb = new StringBuilder();
            
            // 1. Base Personality
            sb.Append($"[{_personalityTrait}] ");

            // 2. Contextual Reaction based on Beliefs
            if (_beliefs["Suspicion"] > 50)
            {
                sb.Append("I'm watching you closely. ");
            }
            else if (_beliefs["Trust"] > 70)
            {
                sb.Append("Welcome back, friend! ");
            }
            else
            {
                sb.Append("Greetings. ");
            }

            // 3. Inject Retrieved Memory (Long-term context)
            if (retrievedMemory.Contains("Memory Triggered"))
            {
                sb.Append($"I haven't forgotten our past interaction. {retrievedMemory} ");
            }

            // 4. Dynamic Closing based on State
            if (_beliefs["Suspicion"] > 80)
            {
                sb.Append("State your business, then leave.");
            }
            else
            {
                sb.Append("How can I help you today?");
            }

            return sb.ToString();
        }

        public string GetBeliefSummary()
        {
            return $"Trust: {_beliefs["Trust"]}, Suspicion: {_beliefs["Suspicion"]}";
        }

        // ---------------------------------------------------------------------
        // HELPER: Embedding Generator (Simulation)
        // ---------------------------------------------------------------------
        // Converts a string into a fixed-size float array (Vector).
        // This mimics how LLMs convert text to numbers for semantic processing.
        private float[] GenerateEmbedding(string text)
        {
            float[] vector = new float[4]; // Small dimension for demo
            int hash = text.GetHashCode();
            
            // Use the hash code to populate the vector deterministically
            vector[0] = Math.Abs(hash % 100) / 100.0f;
            vector[1] = Math.Abs((hash >> 4) % 100) / 100.0f;
            vector[2] = Math.Abs((hash >> 8) % 100) / 100.0f;
            vector[3] = Math.Abs((hash >> 12) % 100) / 100.0f;

            return vector;
        }
    }
}
