
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

// 1. Quantization Logic
public static class VectorQuantizer
{
    // Scalar Quantization: Float [-1, 1] -> Byte [0, 255]
    public static byte[] QuantizeScalar(ReadOnlyMemory<float> vector)
    {
        byte[] quantized = new byte[vector.Length];
        for (int i = 0; i < vector.Length; i++)
        {
            // Clamp and map
            float val = Mathf.Clamp(vector.Span[i], -1f, 1f);
            quantized[i] = (byte)((val + 1.0f) * 127.5f);
        }
        return quantized;
    }

    // Product Quantization: Split vector into M sub-vectors
    public static byte[][] QuantizeProduct(ReadOnlyMemory<float> vector, int numSubVectors)
    {
        int dim = vector.Length;
        int subDim = dim / numSubVectors;
        byte[][] pq = new byte[numSubVectors][];

        for (int i = 0; i < numSubVectors; i++)
        {
            int start = i * subDim;
            var slice = vector.Slice(start, subDim);
            pq[i] = QuantizeScalar(slice);
        }
        return pq;
    }

    // Distance: Scalar (Manhattan)
    public static int FastScalarDistance(byte[] q, byte[] d)
    {
        int dist = 0;
        for (int i = 0; i < q.Length; i++) dist += Math.Abs(q[i] - d[i]);
        return dist;
    }

    // Distance: Product (Sum of Manhattan)
    public static int FastProductDistance(byte[][] q, byte[][] d)
    {
        int dist = 0;
        for (int i = 0; i < q.Length; i++)
        {
            dist += FastScalarDistance(q[i], d[i]);
        }
        return dist;
    }

    // Helper to generate float vector for testing
    public static ReadOnlyMemory<float> GenerateFloatVector(int size)
    {
        float[] v = new float[size];
        for (int i = 0; i < size; i++) v[i] = (float)new System.Random().NextDouble() * 2f - 1f;
        return v;
    }
}

// 2. Benchmark Runner
public class BenchmarkRunner : MonoBehaviour
{
    public TMP_Text resultText;
    public Slider pqSlider;
    public TMP_Text sliderLabel;

    private const int VectorDim = 384;
    private const int DatabaseSize = 5000; // Reduced for runtime safety
    private List<ReadOnlyMemory<float>> _floatDb = new List<ReadOnlyMemory<float>>();
    
    // Storage for quantized data
    private List<byte[]> _scalarDb = new List<byte[]>();
    private List<byte[][]> _pqDb = new List<byte[][]>();
    
    private int _currentPQClusters = 4;

    void Start()
    {
        // Initialize DB
        for (int i = 0; i < DatabaseSize; i++)
        {
            var vec = VectorQuantizer.GenerateFloatVector(VectorDim);
            _floatDb.Add(vec);
            _scalarDb.Add(VectorQuantizer.QuantizeScalar(vec));
            // Default PQ
            _pqDb.Add(VectorQuantizer.QuantizeProduct(vec, _currentPQClusters));
        }

        if (pqSlider != null)
        {
            pqSlider.onValueChanged.AddListener(val => 
            {
                _currentPQClusters = (int)val;
                sliderLabel.text = $"PQ Clusters: {_currentPQClusters}";
            });
            pqSlider.value = 4;
        }
    }

    public void RunBenchmarks()
    {
        StartCoroutine(RunBenchmarkCoroutine());
    }

    private System.Collections.IEnumerator RunBenchmarkCoroutine()
    {
        resultText.text = "Running benchmarks...";
        yield return null; // Wait frame

        // 1. Float Search (Baseline)
        var sw = Stopwatch.StartNew();
        var query = VectorQuantizer.GenerateFloatVector(VectorDim);
        
        // Simple linear scan for top 5
        var floatResults = _floatDb
            .Select((v, i) => new { Index = i, Score = CosineSimilarity(query, v) })
            .OrderByDescending(x => x.Score)
            .Take(5)
            .Select(x => x.Index)
            .ToHashSet();
        
        sw.Stop();
        long floatTime = sw.ElapsedMilliseconds;
        float floatMem = _floatDb.Count * VectorDim * 4 / 1024f / 1024f; // MB

        yield return null;

        // 2. Scalar Quantized Search
        sw.Restart();
        var qScalar = VectorQuantizer.QuantizeScalar(query);
        var scalarResults = _scalarDb
            .Select((v, i) => new { Index = i, Dist = VectorQuantizer.FastScalarDistance(qScalar, v) })
            .OrderBy(x => x.Dist) // Lower Manhattan distance is better
            .Take(5)
            .Select(x => x.Index)
            .ToHashSet();
        
        sw.Stop();
        long scalarTime = sw.ElapsedMilliseconds;
        float scalarMem = _scalarDb.Count * VectorDim * 1 / 1024f / 1024f; // MB

        yield return null;

        // 3. Product Quantized Search (Rebuild DB if slider changed)
        // Note: In real app, we wouldn't rebuild DB every click, but for demo:
        if (_pqDb.Count == 0 || _pqDb[0].Length != _currentPQClusters)
        {
            _pqDb.Clear();
            foreach (var v in _floatDb) _pqDb.Add(VectorQuantizer.QuantizeProduct(v, _currentPQClusters));
        }

        sw.Restart();
        var qPQ = VectorQuantizer.QuantizeProduct(query, _currentPQClusters);
        var pqResults = _pqDb
            .Select((v, i) => new { Index = i, Dist = VectorQuantizer.FastProductDistance(qPQ, v) })
            .OrderBy(x => x.Dist)
            .Take(5)
            .Select(x => x.Index)
            .ToHashSet();

        sw.Stop();
        long pqTime = sw.ElapsedMilliseconds;
        // PQ memory: M * (Dim/M) * 1 byte. Same as Scalar usually, but allows smaller codebooks
        float pqMem = (_pqDb.Count * _currentPQClusters * (VectorDim / _currentPQClusters) * 1f) / 1024f / 1024f;

        // 4. Accuracy Check (Recall@5)
        int overlapFloatScalar = floatResults.Intersect(scalarResults).Count();
        int overlapFloatPQ = floatResults.Intersect(pqResults).Count();

        string report = $"<b>Results (Database: {DatabaseSize} vectors, Dim: {VectorDim})</b>\n\n";
        report += $"1. Float (Cosine):\n   Time: {floatTime}ms | Mem: {floatMem:F2}MB\n\n";
        report += $"2. Scalar (Manhattan):\n   Time: {scalarTime}ms | Mem: {scalarMem:F2}MB\n   Recall@5 vs Float: {overlapFloatScalar * 20}%\n\n";
        report += $"3. PQ (Clusters: {_currentPQClusters}):\n   Time: {pqTime}ms | Mem: {pqMem:F2}MB\n   Recall@5 vs Float: {overlapFloatPQ * 20}%\n\n";
        
        // Speedup calc
        if (floatTime > 0)
            report += $"Speedup (Scalar): {floatTime / (float)scalarTime:F1}x\n";
        if (floatTime > 0)
            report += $"Speedup (PQ): {floatTime / (float)pqTime:F1}x";

        resultText.text = report;
    }

    private float CosineSimilarity(ReadOnlyMemory<float> a, ReadOnlyMemory<float> b)
    {
        float dot = 0.0f, magA = 0.0f, magB = 0.0f;
        for (int i = 0; i < a.Length; i++)
        {
            dot += a.Span[i] * b.Span[i];
            magA += a.Span[i] * a.Span[i];
            magB += b.Span[i] * b.Span[i];
        }
        return dot / (float)(Math.Sqrt(magA) * Math.Sqrt(magB));
    }
}
