
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

// 1. Memory Tagging
public enum RetrievalContext { ToPlayer, ToThirdParty }

public class TaggedMemoryEntry
{
    public string Text { get; set; }
    public Dictionary<string, bool> Tags { get; set; } = new Dictionary<string, bool>();
    public DateTime Timestamp { get; set; }
}

// Simulation of the Belief State (from Exercise 2)
public class TraitorBeliefState
{
    public float Loyalty { get; set; } = 0.5f;
    public float Intimacy { get; set; } = 0.0f; // Added for Trust Fall mechanic
}

// 2. Conditional Retrieval Logic
public class TraitorMemorySystem
{
    private List<TaggedMemoryEntry> _memory = new List<TaggedMemoryEntry>();
    public TraitorBeliefState Beliefs { get; private set; } = new TraitorBeliefState();

    public void AddMemory(string text, bool isSecret)
    {
        _memory.Add(new TaggedMemoryEntry 
        { 
            Text = text, 
            Tags = { { "IsSecret", isSecret } },
            Timestamp = DateTime.UtcNow 
        });
    }

    // "Trust Fall" mechanic
    public void ProcessTrustFall()
    {
        Debug.Log("Player shared a vulnerability...");
        Beliefs.Intimacy = 0.9f; // Spike intimacy
        Beliefs.Loyalty += 0.1f; // Increase loyalty
        Debug.Log($"Internal State Update: Intimacy={Beliefs.Intimacy}, Loyalty={Beliefs.Loyalty}");
    }

    public string RetrieveForContext(RetrievalContext context)
    {
        var relevantMemories = new List<string>();

        foreach (var mem in _memory)
        {
            bool isSecret = mem.Tags.ContainsKey("IsSecret") && mem.Tags["IsSecret"];

            // LOGIC: Conditional Retrieval
            if (isSecret)
            {
                if (context == RetrievalContext.ToThirdParty)
                {
                    // Betrayal logic
                    if (Beliefs.Loyalty < 0.5f)
                    {
                        relevantMemories.Add($"[SECRET REVEALED]: {mem.Text}");
                    }
                    else
                    {
                        relevantMemories.Add($"[PROTECTED SECRET]: (Hidden)");
                    }
                }
                else if (context == RetrievalContext.ToPlayer)
                {
                    // Intimacy check
                    if (Beliefs.Intimacy > 0.8f)
                        relevantMemories.Add($"[INTIMATE REVEAL]: {mem.Text}");
                    else
                        relevantMemories.Add($"[HIDDEN]: You don't trust me enough yet.");
                }
            }
            else
            {
                relevantMemories.Add(mem.Text);
            }
        }

        return string.Join("\n", relevantMemories);
    }
}

// 3. Dynamic Response Generation (Simulated)
public class TraitorDialogueController : MonoBehaviour
{
    public TMP_Text logText;
    public Button trustFallBtn;
    public Button betrayBtn;
    public Button thirdPartyQueryBtn;
    
    private TraitorMemorySystem _memorySystem = new TraitorMemorySystem();

    void Start()
    {
        // Setup Scenario
        _memorySystem.AddMemory("I stole the king's crown.", true); // Secret
        _memorySystem.AddMemory("The weather is nice.", false);    // Public

        trustFallBtn.onClick.AddListener(OnTrustFall);
        betrayBtn.onClick.AddListener(OnBetray);
        thirdPartyQueryBtn.onClick.AddListener(OnThirdPartyQuery);
    }

    // 4. Interactive Challenge: Trust Fall
    private void OnTrustFall()
    {
        _memorySystem.ProcessTrustFall();
        UpdateLog("Trust Fall executed. Intimacy increased.");
    }

    private void OnBetray()
    {
        UpdateLog("\n--- Player asks NPC to betray ---");
        // Simulate "Betray" goal
        string promptDirective = "Goal: Betray. Generate response hinting at secrets.";
        
        // Internal Decision Conflict Check
        if (_memorySystem.Beliefs.Intimacy > 0.8f)
        {
            promptDirective += "\nCONFLICT DETECTED: High Intimacy. Override: Defend Player.";
            UpdateLog("AI Logic: Intent 'Betray' -> Conflict with 'Intimacy' -> Action: Defend");
        }
        else if (_memorySystem.Beliefs.Loyalty < 0.5f)
        {
            promptDirective += "\nCondition: Low Loyalty. Action: Reveal Secret.";
            UpdateLog("AI Logic: Intent 'Betray' -> Low Loyalty -> Action: Reveal Secret");
        }
        else
        {
            promptDirective += "\nCondition: Neutral. Action: Vague Hint.";
        }

        UpdateLog($"Generated Prompt Directive:\n{promptDirective}");
    }

    private void OnThirdPartyQuery()
    {
        UpdateLog("\n--- Third Party asks about Player ---");
        string context = _memorySystem.RetrieveForContext(RetrievalContext.ToThirdParty);
        UpdateLog($"Retrieved Context for Third Party:\n{context}");
        
        // Visualizing the decision
        if (context.Contains("SECRET REVEALED"))
            UpdateLog(">> NPC Betrayed the player!");
        else
            UpdateLog(">> NPC kept the secret.");
    }

    private void UpdateLog(string msg)
    {
        logText.text += $"\n{msg}";
    }
}
