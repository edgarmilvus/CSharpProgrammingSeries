
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using TMPro;
using System.Text.Json;

// 1. Data Structure: Conditional Beliefs
public struct ContextKey : IEquatable<ContextKey>
{
    public string Concept; // e.g., "Trust"
    public string Tag;     // e.g., "Combat", "Trade"

    public bool Equals(ContextKey other) => Concept == other.Concept && Tag == other.Tag;
    public override int GetHashCode() => HashCode.Combine(Concept, Tag);
}

public class BeliefState
{
    // Thread-safe storage for conditional beliefs
    public ConcurrentDictionary<ContextKey, float> Values { get; set; } = new ConcurrentDictionary<ContextKey, float>();
}

// 2. Sentiment Analyzer
public static class SentimentAnalyzer
{
    private static readonly Dictionary<string, float> _lexicon = new Dictionary<string, float>
    {
        { "good", 0.2f }, { "great", 0.3f }, { "excellent", 0.5f },
        { "bad", -0.2f }, { "terrible", -0.4f }, { "lie", -0.5f },
        { "trust", 0.3f }, { "help", 0.2f }, { "fight", -0.1f }
    };

    public static (float Score, string Context) Analyze(string text)
    {
        float score = 0.0f;
        string context = "General"; // Default context
        bool negate = false;

        // Simple keyword parsing
        string[] words = text.ToLower().Split(' ', '.', ',', '!');
        
        // Context detection (Interactive Challenge)
        if (words.Contains("fight") || words.Contains("attack") || words.Contains("weapon")) context = "Combat";
        else if (words.Contains("buy") || words.Contains("sell") || words.Contains("gold")) context = "Trade";
        else if (words.Contains("secret") || words.Contains("love") || words.Contains("trust")) context = "Intimacy";

        foreach (var word in words)
        {
            if (word == "not" || word == "no" || word == "never")
            {
                negate = true;
                continue;
            }

            if (_lexicon.TryGetValue(word, out float val))
            {
                score += negate ? -val : val;
                negate = false; // Reset negation after applying
            }
        }

        // Normalize
        return (Mathf.Clamp(score, -1f, 1f), context);
    }
}

// 3. Reflection Module
public class ReflectionModule
{
    private BeliefState _beliefState = new BeliefState();
    private readonly object _lock = new object();

    // Learning rate
    private const float Alpha = 0.1f;

    public async Task Reflect(List<string> recentMessages)
    {
        await Task.Run(() => 
        {
            float totalSentiment = 0f;
            int count = 0;
            string dominantContext = "General";

            // Aggregate sentiment
            foreach (var msg in recentMessages)
            {
                var (score, context) = SentimentAnalyzer.Analyze(msg);
                totalSentiment += score;
                count++;
                if (context != "General") dominantContext = context;
            }

            if (count == 0) return;

            float avgSentiment = totalSentiment / count;
            string[] concepts = { "Trust", "Fear", "Respect" };

            // Update beliefs per concept
            foreach (var concept in concepts)
            {
                var key = new ContextKey { Concept = concept, Tag = dominantContext };
                
                // Lerp logic (Thread-safe update)
                _beliefState.Values.AddOrUpdate(key, 
                    avgSentiment, // Initial value if key doesn't exist
                    (k, oldVal) => Mathf.Lerp(oldVal, avgSentiment, Alpha)
                );
            }
        });
    }

    // 4. Persistence
    public void SaveBeliefState(string npcId)
    {
        // Convert ConcurrentDictionary to simple Dictionary for JSON serialization
        var serializableDict = _beliefState.Values.ToDictionary(k => $"{k.Key.Concept}|{k.Key.Tag}", v => v.Value);
        string json = JsonSerializer.Serialize(serializableDict, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText($"{Application.persistentDataPath}/{npcId}_beliefs.json", json);
        Debug.Log($"Belief state saved to {Application.persistentDataPath}");
    }

    public void LoadBeliefState(string npcId)
    {
        string path = $"{Application.persistentDataPath}/{npcId}_beliefs.json";
        if (!File.Exists(path)) return;

        string json = File.ReadAllText(path);
        var dict = JsonSerializer.Deserialize<Dictionary<string, float>>(json);

        _beliefState.Values.Clear();
        foreach (var kvp in dict)
        {
            var parts = kvp.Key.Split('|');
            if (parts.Length == 2)
            {
                _beliefState.Values.TryAdd(new ContextKey { Concept = parts[0], Tag = parts[1] }, kvp.Value);
            }
        }
    }

    // Helper for visualization
    public IEnumerable<KeyValuePair<ContextKey, float>> GetAllBeliefs() => _beliefState.Values;
}

// 5. Unity Integration & Visualization
public class ReflectionDebugger : MonoBehaviour
{
    public ReflectionModule Module = new ReflectionModule();
    public GameObject barPrefab; // UI Slider or Image prefab
    public Transform chartRoot;
    public TMP_Text logText;

    // Interactive Challenge: Simulate incoming messages
    public async void SimulateInteraction()
    {
        var messages = new List<string> 
        { 
            "I need you to fight for me.", 
            "I promise I will pay you well." 
        };
        
        await Module.Reflect(messages);
        UpdateChart();

        // Save/Load test
        Module.SaveBeliefState("NPC_Test");
        Module.LoadBeliefState("NPC_Test");
    }

    private void UpdateChart()
    {
        // Clear old bars
        foreach (Transform child in chartRoot) Destroy(child.gameObject);

        foreach (var belief in Module.GetAllBeliefs())
        {
            // Create UI Bar
            GameObject bar = Instantiate(barPrefab, chartRoot);
            
            // Set Name (Concept + Tag)
            bar.transform.Find("Label").GetComponent<TMP_Text>().text = $"{belief.Key.Concept} ({belief.Key.Tag})";
            
            // Set Value
            var slider = bar.transform.Find("Bar").GetComponent<UnityEngine.UI.Slider>();
            slider.value = (belief.Value + 1.0f) / 2.0f; // Map [-1, 1] to [0, 1]
            
            // Set Color
            var fill = bar.transform.Find("Bar/Fill Area/Fill").GetComponent<UnityEngine.UI.Image>();
            fill.color = belief.Value < 0 ? Color.red : Color.green;

            logText.text += $"\nUpdated {belief.Key.Concept} ({belief.Key.Tag}): {belief.Value:F2}";
        }
    }
}
