
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

// 1. Context Layers & Data
public enum ContextLayer { System, Personality, CurrentGoal, RecentHistory, SemanticMemory, ReflectionState }

public class ContextData
{
    public string Content;
    public ContextLayer Layer;
}

// 2. Strategy Pattern Interfaces
public interface IContextStrategy
{
    string Format(ContextData data, int tokenBudget);
}

// Concrete Strategies
public class FullTextStrategy : IContextStrategy
{
    public string Format(ContextData data, int tokenBudget)
    {
        // Simple char count approximation: 1 token ~= 4 chars
        int maxChars = tokenBudget * 4;
        if (data.Content.Length > maxChars)
            return data.Content.Substring(0, maxChars) + "...";
        return data.Content;
    }
}

public class CompressionStrategy : IContextStrategy
{
    public string Format(ContextData data, int tokenBudget)
    {
        // Mock compression: Take first half + key verbs
        int maxChars = tokenBudget * 4;
        if (data.Content.Length <= maxChars) return data.Content;

        // Simple "summarization" logic
        string[] words = data.Content.Split(' ');
        string compressed = string.Join(" ", words.Take(5)) + " [Compressed] " + string.Join(" ", words.Skip(words.Length - 3));
        return compressed.Substring(0, Math.Min(compressed.Length, maxChars));
    }
}

public class ExtractionStrategy : IContextStrategy
{
    public string Format(ContextData data, int tokenBudget)
    {
        // Mock Entity Extraction: Extract Capitalized words (Proper Nouns)
        var entities = data.Content.Split(' ')
            .Where(w => w.Length > 2 && char.IsUpper(w[0]))
            .Distinct();
        string extracted = "Entities: " + string.Join(", ", entities);
        return extracted.Substring(0, Math.Min(extracted.Length, tokenBudget * 4));
    }
}

// 3. Token Budget & Manager
public struct TokenBudget
{
    public int Total;
    public Dictionary<ContextLayer, int> Allocations;

    public TokenBudget(int total)
    {
        Total = total;
        Allocations = new Dictionary<ContextLayer, int>
        {
            { ContextLayer.System, 50 },
            { ContextLayer.Personality, 100 },
            { ContextLayer.CurrentGoal, 50 },
            { ContextLayer.RecentHistory, 300 },
            { ContextLayer.SemanticMemory, 500 },
            { ContextLayer.ReflectionState, 100 }
        };
    }
}

public class HierarchicalContextManager
{
    private TokenBudget _budget;
    private Dictionary<ContextLayer, IContextStrategy> _strategies;
    private Dictionary<ContextLayer, ContextData> _contextPool = new Dictionary<ContextLayer, ContextData>();

    public HierarchicalContextManager()
    {
        _budget = new TokenBudget(2048);
        // Default strategies
        _strategies = new Dictionary<ContextLayer, IContextStrategy>
        {
            { ContextLayer.System, new FullTextStrategy() },
            { ContextLayer.Personality, new FullTextStrategy() },
            { ContextLayer.CurrentGoal, new FullTextStrategy() },
            { ContextLayer.RecentHistory, new CompressionStrategy() }, // Default to compression for history
            { ContextLayer.SemanticMemory, new FullTextStrategy() },
            { ContextLayer.ReflectionState, new FullTextStrategy() }
        };
    }

    public void SetData(ContextLayer layer, string content)
    {
        _contextPool[layer] = new ContextData { Content = content, Layer = layer };
    }

    public void SetStrategy(ContextLayer layer, IContextStrategy strategy)
    {
        _strategies[layer] = strategy;
    }

    // 4. Dynamic Prompt Builder
    public string BuildPrompt()
    {
        var promptParts = new List<string>();
        int usedTokens = 0;

        // Iterate layers in priority order
        foreach (var layer in Enum.GetValues(typeof(ContextLayer)).Cast<ContextLayer>())
        {
            if (!_contextPool.ContainsKey(layer)) continue;

            int budget = _budget.Allocations[layer];
            var data = _contextPool[layer];
            var strategy = _strategies[layer];

            // Format content
            string formatted = strategy.Format(data, budget);

            // Approximate tokens used
            int tokensUsed = (int)Math.Ceiling(formatted.Length / 4.0);
            
            // 5. Overflow Handling (Critical Info Extraction)
            if (tokensUsed > budget)
            {
                // If the chosen strategy wasn't enough, force Extraction
                if (strategy is not ExtractionStrategy)
                {
                    formatted = new ExtractionStrategy().Format(data, budget);
                    tokensUsed = (int)Math.Ceiling(formatted.Length / 4.0);
                }
                // Truncate if still too long
                if (tokensUsed > budget)
                {
                    formatted = formatted.Substring(0, budget * 4);
                    tokensUsed = budget;
                }
            }

            usedTokens += tokensUsed;
            if (usedTokens > _budget.Total) break; // Stop if total budget exceeded

            promptParts.Add($"[{layer}]: {formatted}");
        }

        return string.Join("\n\n", promptParts);
    }
}

// 6. Unity Integration
public class ContextManagerUI : MonoBehaviour
{
    public InputField[] inputs; // Map to layers
    public Slider[] prioritySliders; // Interactive Challenge: Adjust weights
    public Dropdown strategyDropdown; // Switch strategies
    public TMP_Text outputText;

    private HierarchicalContextManager _manager = new HierarchicalContextManager();

    void Start()
    {
        // Initialize dummy data
        _manager.SetData(ContextLayer.Personality, "You are a grumpy dwarf blacksmith who hates elves.");
        _manager.SetData(ContextLayer.RecentHistory, "The player asked about the legendary sword Excalibur and mentioned they like gold.");
        _manager.SetData(ContextLayer.SemanticMemory, "Summary: Player interest in weapons and wealth.");
    }

    public void OnBuildPrompt()
    {
        // Update data from inputs (simplified for brevity)
        if(inputs[0] != null && !string.IsNullOrEmpty(inputs[0].text)) 
            _manager.SetData(ContextLayer.RecentHistory, inputs[0].text);

        // Apply dynamic strategy based on dropdown
        IContextStrategy selectedStrategy = GetStrategyFromDropdown();
        
        // Apply to all layers for demonstration, or specific ones
        foreach (ContextLayer layer in Enum.GetValues(typeof(ContextLayer)))
        {
            _manager.SetStrategy(layer, selectedStrategy);
        }

        string result = _manager.BuildPrompt();
        outputText.text = result;
    }

    private IContextStrategy GetStrategyFromDropdown()
    {
        return strategyDropdown.value switch
        {
            0 => new FullTextStrategy(),
            1 => new CompressionStrategy(),
            2 => new ExtractionStrategy(),
            _ => new FullTextStrategy()
        };
    }
}
