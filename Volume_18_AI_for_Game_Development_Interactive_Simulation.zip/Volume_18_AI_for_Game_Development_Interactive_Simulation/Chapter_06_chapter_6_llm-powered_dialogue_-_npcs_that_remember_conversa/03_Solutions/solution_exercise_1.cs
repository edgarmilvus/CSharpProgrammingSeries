
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using TMPro;
using System.Security.Cryptography;
using System.Collections.Concurrent;

// 1. Architecture: Abstract interface for the memory system
public interface IConversationMemory
{
    Task AddMessageAsync(string text);
    Task<string> RetrieveRelevantContextAsync(string query, int k);
}

// Data structure for memory entries
public class MemoryEntry
{
    public string Text { get; set; }
    public ReadOnlyMemory<float> Embedding { get; set; }
    public DateTime Timestamp { get; set; }
    public bool IsSummarized { get; set; }
}

// The Core Summarizer Logic
public class SemanticConversationSummarizer : IConversationMemory
{
    private readonly List<MemoryEntry> _memory = new List<MemoryEntry>();
    private readonly object _lock = new object();
    
    // Configuration
    public int MaxRawMessages { get; set; } = 10;
    public float SimilarityThreshold { get; set; } = 0.85f;
    public float DecayFactor { get; set; } = 0.1f; // Interactive Challenge: Recency Decay parameter

    // 2. Embedding Generation (Simulated for exercise purposes)
    public async Task<ReadOnlyMemory<float>> GenerateEmbedding(string text)
    {
        // Simulate async work
        await Task.Yield(); 
        
        // Deterministic hash to vector (384 dimensions)
        using (MD5 md5 = MD5.Create())
        {
            byte[] hash = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(text));
            float[] vector = new float[384];
            
            // Map hash bytes to float vector [-1, 1]
            for (int i = 0; i < vector.Length; i++)
            {
                // Cycle through hash bytes
                byte b = hash[i % hash.Length];
                vector[i] = (b / 127.5f) - 1.0f; 
            }
            return new ReadOnlyMemory<float>(vector);
        }
    }

    // Helper: Cosine Similarity
    private float CosineSimilarity(ReadOnlyMemory<float> a, ReadOnlyMemory<float> b)
    {
        float dot = 0.0f;
        float magA = 0.0f;
        float magB = 0.0f;
        for (int i = 0; i < a.Length; i++)
        {
            dot += a.Span[i] * b.Span[i];
            magA += a.Span[i] * a.Span[i];
            magB += b.Span[i] * b.Span[i];
        }
        return dot / (float)(Math.Sqrt(magA) * Math.Sqrt(magB));
    }

    // 3. Clustering Logic
    public async Task Summarize()
    {
        List<MemoryEntry> rawMessages;
        lock (_lock)
        {
            rawMessages = _memory.Where(m => !m.IsSummarized).ToList();
            if (rawMessages.Count <= MaxRawMessages) return;
        }

        // Simple greedy clustering
        var clusters = new List<List<MemoryEntry>>();
        var processedIndices = new HashSet<int>();

        for (int i = 0; i < rawMessages.Count; i++)
        {
            if (processedIndices.Contains(i)) continue;

            var cluster = new List<MemoryEntry> { rawMessages[i] };
            processedIndices.Add(i);

            for (int j = i + 1; j < rawMessages.Count; j++)
            {
                if (processedIndices.Contains(j)) continue;
                
                float sim = CosineSimilarity(rawMessages[i].Embedding, rawMessages[j].Embedding);
                if (sim > SimilarityThreshold)
                {
                    cluster.Add(rawMessages[j]);
                    processedIndices.Add(j);
                }
            }
            clusters.Add(cluster);
        }

        // Process clusters
        foreach (var cluster in clusters)
        {
            if (cluster.Count < 2) continue; // Don't summarize singletons

            // Generate summary text
            string summaryText = $"Summary of discussion about: {string.Join(", ", cluster.Select(c => c.Text.Substring(0, Math.Min(10, c.Text.Length))))}...";
            var summaryEmbedding = await GenerateEmbedding(summaryText);
            
            var summaryEntry = new MemoryEntry
            {
                Text = summaryText,
                Embedding = summaryEmbedding,
                Timestamp = DateTime.UtcNow,
                IsSummarized = true
            };

            lock (_lock)
            {
                // Remove old raw messages
                foreach (var msg in cluster)
                {
                    _memory.Remove(msg);
                }
                // Add summary
                _memory.Add(summaryEntry);
            }
        }
    }

    // 4. Retrieval with Recency Decay
    public async Task<string> RetrieveRelevantContextAsync(string query, int k)
    {
        var queryEmbedding = await GenerateEmbedding(query);
        var results = new List<(float Score, MemoryEntry Entry)>();

        lock (_lock)
        {
            foreach (var entry in _memory)
            {
                float sim = CosineSimilarity(queryEmbedding, entry.Embedding);
                
                // Interactive Challenge: Recency Decay
                float ageInHours = (float)(DateTime.UtcNow - entry.Timestamp).TotalHours;
                float decay = 1.0f / (1.0f + DecayFactor * ageInHours); // Logarithmic-like decay
                
                float weightedScore = sim * decay;
                results.Add((weightedScore, entry));
            }
        }

        // Sort using a custom comparer for the tuple
        return string.Join("\n", results
            .OrderByDescending(x => x.Score)
            .Take(k)
            .Select(x => $"[{(x.Entry.IsSummarized ? "SUMMARY" : "RAW")}] Score: {x.Score:F2} | {x.Entry.Text}"));
    }

    public async Task AddMessageAsync(string text)
    {
        var embedding = await GenerateEmbedding(text);
        lock (_lock)
        {
            _memory.Add(new MemoryEntry 
            { 
                Text = text, 
                Embedding = embedding, 
                Timestamp = DateTime.UtcNow,
                IsSummarized = false
            });
        }
        await Summarize(); // Check if we need to summarize immediately
    }
}

// 5. Unity Integration
public class SemanticMemoryManager : MonoBehaviour
{
    public TextAsset mockModelData; // Placeholder for model
    public TMP_InputField inputField;
    public TMP_Text debugOutput;
    public Slider decaySlider; // Interactive Challenge: UI Slider

    private SemanticConversationSummarizer _summarizer = new SemanticConversationSummarizer();

    void Start()
    {
        if (decaySlider != null)
        {
            decaySlider.onValueChanged.AddListener(val => 
            {
                _summarizer.DecayFactor = val;
                Debug.Log($"Decay Factor set to: {val}");
            });
            decaySlider.value = _summarizer.DecayFactor;
        }
    }

    public async void OnSend()
    {
        if (string.IsNullOrWhiteSpace(inputField.text)) return;
        
        string userText = inputField.text;
        inputField.text = "";

        await _summarizer.AddMessageAsync(userText);
        
        // Visualize state
        await UpdateDebugView();
    }

    private async Task UpdateDebugView()
    {
        // Mock query to show retrieval
        string context = await _summarizer.RetrieveRelevantContextAsync("quest details", 5);
        debugOutput.text = $"Current Memory State:\n\n{context}";
    }
}
