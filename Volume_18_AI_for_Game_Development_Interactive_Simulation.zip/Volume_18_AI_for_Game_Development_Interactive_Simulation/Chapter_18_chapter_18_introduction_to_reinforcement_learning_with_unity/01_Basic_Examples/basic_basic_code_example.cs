
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;

/// <summary>
/// A simple "Hello World" example for Reinforcement Learning in Unity.
/// This agent learns to move a cube toward a target sphere.
/// </summary>
public class BasicRLAgent : Agent
{
    // --- Public Fields (Inspector Configuration) ---
    
    [Tooltip("The target object the agent must reach.")]
    public Transform target;

    [Tooltip("The speed at which the agent moves.")]
    public float moveSpeed = 5f;

    [Tooltip("The boundary limit for the agent's position.")]
    public float boundaryLimit = 10f;

    // --- Private State ---
    private Rigidbody agentRb;
    private Rigidbody targetRb;

    // --- Core ML-Agents Lifecycle ---

    /// <summary>
    /// Called once when the agent is first initialized.
    /// Use this for expensive setup operations like component caching.
    /// </summary>
    public override void Initialize()
    {
        // Cache the Rigidbody component for performance (avoids GetComponent calls in Update).
        agentRb = GetComponent<Rigidbody>();
        
        // We need the target's Rigidbody to reset its position dynamically.
        if (target != null)
        {
            targetRb = target.GetComponent<Rigidbody>();
        }
    }

    /// <summary>
    /// Called at the start of every new episode (training trial).
    /// Resets the environment to a clean slate.
    /// </summary>
    public override void OnEpisodeBegin()
    {
        // 1. Reset Agent Position and Velocity
        // --------------------------------------------------
        // If the agent fell off the platform (simulated by y < 0), reset it.
        // We use localPosition to ensure it works regardless of the parent object's transform.
        if (transform.localPosition.y < 0)
        {
            transform.localPosition = new Vector3(0f, 0.5f, 0f);
            agentRb.velocity = Vector3.zero;
            agentRb.angularVelocity = Vector3.zero;
        }

        // 2. Reset Target Position
        // --------------------------------------------------
        // Move the target to a random position within the bounds.
        // We use Random.Range for both X and Z axes.
        // Note: We keep y = 0.5f to keep it on the same plane as the agent.
        if (target != null)
        {
            bool positionValid = false;
            Vector3 newTargetPos;
            
            // Loop to ensure target doesn't spawn on top of the agent (optional constraint)
            do 
            {
                newTargetPos = new Vector3(
                    Random.Range(-boundaryLimit, boundaryLimit),
                    0.5f,
                    Random.Range(-boundaryLimit, boundaryLimit)
                );
                
                // Prevent spawning exactly on the agent
                if (Vector3.Distance(newTargetPos, transform.localPosition) > 2.0f)
                {
                    positionValid = true;
                }
            } while (!positionValid);

            target.localPosition = newTargetPos;
            
            // Reset target physics
            if (targetRb != null)
            {
                targetRb.velocity = Vector3.zero;
            }
        }
    }

    /// <summary>
    /// Defines what the agent "sees" and "feels" (Observations).
    /// The neural network uses these values to make decisions.
    /// </summary>
    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Observe Target Position (3 floats)
        // --------------------------------------------------
        // We observe the relative vector from agent to target.
        // This is crucial: if we observed absolute world coordinates, 
        // the agent wouldn't generalize if we moved the whole arena.
        Vector3 toTarget = target.localPosition - transform.localPosition;
        sensor.AddObservation(toTarget.normalized); // Normalized helps with generalization

        // 2. Observe Agent Velocity (3 floats)
        // --------------------------------------------------
        // Observing velocity helps the agent understand momentum.
        // Without this, the agent might overshoot the target constantly.
        sensor.AddObservation(agentRb.velocity.x);
        sensor.AddObservation(agentRb.velocity.z);
        
        // Total Observations: 3 (toTarget) + 2 (velocity x,z) = 5 floats.
        // If y movement is allowed, add agentRb.velocity.y.
    }

    /// <summary>
    /// Receives actions from the Neural Network (or Heuristic/Player).
    /// Converts abstract numbers into concrete physics movements.
    /// </summary>
    /// <param name="actions">The discrete or continuous actions provided by the model.</param>
    public override void OnActionReceived(ActionBuffers actions)
    {
        // 1. Extract Actions
        // --------------------------------------------------
        // We use Continuous Actions (default for movement).
        // Index 0 = Horizontal movement (X axis)
        // Index 1 = Vertical movement (Z axis)
        float moveX = actions.ContinuousActions[0];
        float moveZ = actions.ContinuousActions[1];

        // 2. Apply Movement
        // --------------------------------------------------
        // We use Rigidbody forces for physics-based movement.
        // This feels more natural for games than direct transform manipulation.
        Vector3 moveVector = new Vector3(moveX, 0f, moveZ);
        agentRb.AddForce(moveVector * moveSpeed, ForceMode.VelocityChange);

        // 3. Calculate Reward
        // --------------------------------------------------
        // Reward shaping is the most critical part of RL.
        
        // Small penalty for existing (encourages faster solutions)
        // Note: In complex games, this is often called "Time Penalty".
        AddReward(-1f / MaxStep);

        // Check distance to target
        float distanceToTarget = Vector3.Distance(transform.localPosition, target.localPosition);

        // Success Condition
        if (distanceToTarget < 1.5f) // 1.5f is the approximate radius sum
        {
            // Give a large positive reward
            AddReward(1.0f);
            
            // End the episode immediately
            EndEpisode();
        }

        // Failure Condition (Boundary)
        if (transform.localPosition.x > boundaryLimit || transform.localPosition.x < -boundaryLimit ||
            transform.localPosition.z > boundaryLimit || transform.localPosition.z < -boundaryLimit)
        {
            // Give a negative penalty
            AddReward(-1.0f);
            
            // End the episode
            EndEpisode();
        }
    }

    /// <summary>
    /// Used for manual testing without training.
    /// Maps keyboard inputs to the same action space used by the neural network.
    /// </summary>
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        // Create a copy of the continuous actions array
        var continuousActions = actionsOut.ContinuousActions;

        // Map WASD keys to -1 to 1 range
        continuousActions[0] = Input.GetAxisRaw("Horizontal"); // A/D or Left/Right Arrow
        continuousActions[1] = Input.GetAxisRaw("Vertical");   // W/S or Up/Down Arrow
    }
}
