
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace ReinforcementLearningSimulation
{
    /// <summary>
    /// A simplified simulation of a Reinforcement Learning agent learning to navigate a grid world.
    /// This represents the core loop of ML-Agents: Agent -> Environment -> Reward -> Learning.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // 1. SETUP: Initialize the Environment and the Agent
            // We define a 5x5 grid. The Agent starts at (0,0) and the Goal is at (4,4).
            GridEnvironment environment = new GridEnvironment(5, 5);
            QLearningAgent agent = new QLearningAgent();

            // 2. HYPERPARAMETERS: Define training parameters
            int episodes = 1000; // Number of times the agent tries to solve the task
            double learningRate = 0.1; // How much we update Q-values based on new information
            double discountFactor = 0.9; // Importance of future rewards
            double explorationRate = 0.3; // Chance of taking a random action (Epsilon)

            Console.WriteLine("Starting Reinforcement Learning Simulation...");
            Console.WriteLine("Goal: Move from (0,0) to (4,4).");
            Console.WriteLine("Actions: 0=Up, 1=Down, 2=Left, 3=Right");
            Console.WriteLine("--------------------------------------------------");

            // 3. TRAINING LOOP: The core RL cycle
            for (int i = 0; i < episodes; i++)
            {
                // Reset environment for new episode
                environment.Reset();
                int currentState = environment.GetStateId();
                bool done = false;
                int steps = 0;

                // Run episode until goal is reached or timeout
                while (!done && steps < 100)
                {
                    // A. OBSERVATION: Agent sees the current state
                    // In ML-Agents, this is the VectorSensor or RayPerceptionSensor
                    int state = currentState;

                    // B. DECISION: Agent chooses an action (Policy)
                    // Epsilon-Greedy Strategy: Explore (random) or Exploit (best known)
                    int action;
                    if (new Random().NextDouble() < explorationRate)
                    {
                        action = new Random().Next(0, 4); // Random action
                    }
                    else
                    {
                        action = agent.GetBestAction(state); // Greedy action
                    }

                    // C. ACTION: Execute action in environment
                    // In Unity, this moves the Rigidbody/Transform
                    (int nextState, double reward, bool episodeDone) = environment.Step(action);

                    // D. LEARNING: Update the Agent's Brain (Q-Table)
                    // Bellman Equation: Q(s,a) = Q(s,a) + α * [R + γ * max(Q(s',a')) - Q(s,a)]
                    double maxNextQ = agent.GetMaxQ(nextState);
                    double currentQ = agent.GetQ(state, action);
                    double newQ = currentQ + learningRate * (reward + (discountFactor * maxNextQ) - currentQ);
                    agent.UpdateQ(state, action, newQ);

                    // Move to next state
                    currentState = nextState;
                    done = episodeDone;
                    steps++;
                }

                // Decay exploration rate over time (Agent gets smarter/more confident)
                if (explorationRate > 0.01) explorationRate *= 0.995;

                // Log progress every 100 episodes
                if ((i + 1) % 100 == 0)
                {
                    Console.WriteLine($"Episode {i + 1}: Completed in {steps} steps. Exploration: {explorationRate:F3}");
                }
            }

            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Training Complete.");
            
            // 4. INFERENCE: Using the Trained Model
            // In Unity, this is where we load the .onnx file and run agent.OnActionReceived()
            Console.WriteLine("\nRunning Inference (Trained Policy):");
            environment.Reset();
            int currentStep = 0;
            while (!environment.IsGoalReached() && currentStep < 20)
            {
                int state = environment.GetStateId();
                int action = agent.GetBestAction(state); // No random exploration here!
                environment.Step(action);
                
                // Visualize path
                Console.WriteLine($"Step {currentStep}: Moved to {environment.AgentPosition}");
                currentStep++;
            }
            
            if (environment.IsGoalReached()) Console.WriteLine("Success! Agent reached the goal.");
            else Console.WriteLine("Failed to reach goal within step limit.");
        }
    }

    /// <summary>
    /// Represents the "Academy" or Environment where the simulation takes place.
    /// Handles physics, boundaries, and reward calculation.
    /// </summary>
    public class GridEnvironment
    {
        public int GridWidth { get; private set; }
        public int GridHeight { get; private set; }
        public (int x, int y) AgentPosition { get; private set; }
        private readonly (int x, int y) _goalPosition;

        public GridEnvironment(int width, int height)
        {
            GridWidth = width;
            GridHeight = height;
            AgentPosition = (0, 0);
            _goalPosition = (width - 1, height - 1);
        }

        /// <summary>
        /// Resets the agent to the starting position.
        /// Equivalent to ML-Agents Agent.OnEpisodeBegin().
        /// </summary>
        public void Reset()
        {
            AgentPosition = (0, 0);
        }

        /// <summary>
        /// Executes an action and returns the result.
        /// Equivalent to ML-Agents Agent.OnActionReceived(VectorAction).
        /// </summary>
        public (int nextState, double reward, bool done) Step(int action)
        {
            // 0: Up, 1: Down, 2: Left, 3: Right
            int newX = AgentPosition.x;
            int newY = AgentPosition.y;

            switch (action)
            {
                case 0: newY -= 1; break; // Up
                case 1: newY += 1; break; // Down
                case 2: newX -= 1; break; // Left
                case 3: newX += 1; break; // Right
            }

            // Boundary Checks (Punish for hitting walls)
            if (newX < 0 || newX >= GridWidth || newY < 0 || newY >= GridHeight)
            {
                // Return to previous position with negative reward
                return (GetStateId(), -0.5, false);
            }

            // Update Position
            AgentPosition = (newX, newY);

            // Check Goal
            if (newX == _goalPosition.x && newY == _goalPosition.y)
            {
                return (GetStateId(), 1.0, true); // Positive reward + End Episode
            }

            // Distance Heuristic Reward (Optional but helpful for dense rewards)
            // Calculate distance before and after move to encourage getting closer
            double distBefore = Math.Abs(AgentPosition.x - _goalPosition.x) + Math.Abs(AgentPosition.y - _goalPosition.y);
            double reward = -0.01 * distBefore; // Small penalty per step to encourage speed

            return (GetStateId(), reward, false);
        }

        /// <summary>
        /// Maps 2D coordinates to a unique 1D integer ID (State).
        /// This is a simplified form of Vector Observation.
        /// </summary>
        public int GetStateId()
        {
            return AgentPosition.y * GridWidth + AgentPosition.x;
        }

        public bool IsGoalReached()
        {
            return AgentPosition.x == _goalPosition.x && AgentPosition.y == _goalPosition.y;
        }
    }

    /// <summary>
    /// Represents the "Brain" of the agent.
    /// In this simulation, we use a Q-Table (Tabular RL).
    /// In complex Unity scenarios, this would be a Neural Network (Policy).
    /// </summary>
    public class QLearningAgent
    {
        // Q-Table: [State, Action] -> Value
        // Dimensions: 25 states (5x5 grid) * 4 actions
        private double[,] _qTable;
        private const int NumStates = 25;
        private const int NumActions = 4;

        public QLearningAgent()
        {
            // Initialize Q-Table with zeros
            _qTable = new double[NumStates, NumActions];
        }

        /// <summary>
        /// Retrieves the estimated value of taking a specific action in a specific state.
        /// </summary>
        public double GetQ(int state, int action)
        {
            // Bounds checking for safety
            if (state < 0 || state >= NumStates || action < 0 || action >= NumActions) return 0.0;
            return _qTable[state, action];
        }

        /// <summary>
        /// Updates the Q-Table with the newly calculated Q-value.
        /// </summary>
        public void UpdateQ(int state, int action, double value)
        {
            if (state >= 0 && state < NumStates && action >= 0 && action < NumActions)
            {
                _qTable[state, action] = value;
            }
        }

        /// <summary>
        /// Returns the action with the highest Q-value for a given state.
        /// Equivalent to ML-Agents Heuristic() or Policy inference.
        /// </summary>
        public int GetBestAction(int state)
        {
            if (state < 0 || state >= NumStates) return 0;

            int bestAction = 0;
            double maxQ = double.MinValue;

            for (int a = 0; a < NumActions; a++)
            {
                if (_qTable[state, a] > maxQ)
                {
                    maxQ = _qTable[state, a];
                    bestAction = a;
                }
            }

            return bestAction;
        }

        /// <summary>
        /// Helper to get the maximum possible Q-value for a state (used in Bellman equation).
        /// </summary>
        public double GetMaxQ(int state)
        {
            if (state < 0 || state >= NumStates) return 0.0;

            double maxQ = double.MinValue;
            for (int a = 0; a < NumActions; a++)
            {
                if (_qTable[state, a] > maxQ)
                {
                    maxQ = _qTable[state, a];
                }
            }
            
            // If all Q's are 0 (unvisited), return 0
            return maxQ == double.MinValue ? 0.0 : maxQ;
        }
    }
}
