
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;

// --- Manager Script ---
public class PushBlockManager : MonoBehaviour
{
    public GameObject block;
    public Transform targetZone;
    public float platformYLevel = 0f;

    // Singleton-like access for agents to check status
    public static PushBlockManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public bool IsBlockInZone()
    {
        if (block == null || targetZone == null) return false;
        // Simple distance check or trigger overlap
        return Vector3.Distance(block.transform.position, targetZone.position) < 1.5f;
    }

    public bool IsBlockFallen()
    {
        return block.transform.position.y < platformYLevel - 0.5f;
    }
}

// --- Base Agent Script ---
public abstract class PushBlockAgentBase : Agent
{
    protected Rigidbody blockRb;
    protected PushBlockManager manager;
    protected Rigidbody rb;

    public override void Initialize()
    {
        rb = GetComponent<Rigidbody>();
        manager = PushBlockManager.Instance;
        if (manager != null && manager.block != null)
        {
            blockRb = manager.block.GetComponent<Rigidbody>();
        }
    }

    public override void OnEpisodeBegin()
    {
        // Reset Agent Position (Randomized slightly)
        transform.localPosition = new Vector3(Random.Range(-4f, 4f), 0.5f, Random.Range(-4f, 4f));
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        // Reset Block Position (if managed by agent, otherwise manager handles it)
        if (manager != null && manager.block != null)
        {
            manager.block.transform.position = new Vector3(0, 0.5f, 0); // Center
            blockRb.velocity = Vector3.zero;
            blockRb.angularVelocity = Vector3.zero;
        }
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Agent's local velocity (3 values)
        sensor.AddObservation(rb.velocity);

        // 2. Relative position of the target zone (3 values)
        // Note: This is common to both agents
        Vector3 relTarget = manager.targetZone.position - transform.position;
        sensor.AddObservation(relTarget);

        // 3. Specific Observations (implemented in child classes)
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Discrete Actions: 0:Nothing, 1:Fwd, 2:Bwd, 3:Left, 4:Right
        int moveAction = actions.DiscreteActions[0];
        float moveSpeed = 5f;
        Vector3 moveDir = Vector3.zero;

        switch (moveAction)
        {
            case 1: moveDir = transform.forward; break;
            case 2: moveDir = -transform.forward; break;
            case 3: moveDir = -transform.right; break;
            case 4: moveDir = transform.right; break;
        }

        rb.AddForce(moveDir * moveSpeed, ForceMode.VelocityChange);

        // Check for Shared Rewards/Penalties
        CheckEpisodeStatus();
    }

    protected void CheckEpisodeStatus()
    {
        if (manager.IsBlockFallen())
        {
            AddReward(-1.0f);
            EndEpisode();
        }
        else if (manager.IsBlockInZone())
        {
            // Shared Reward Calculation
            // Reward = 1.0f / (Time.fixedDeltaTime * StepCount)
            // Note: StepCount increments every action received
            float jointReward = 1.0f / (Time.fixedDeltaTime * StepCount);
            AddReward(jointReward);
            EndEpisode(); // Success, end episode
        }
    }
}

// --- Concrete Agent A ---
public class AgentA : PushBlockAgentBase
{
    public override void CollectObservations(VectorSensor sensor)
    {
        base.CollectObservations(sensor); // Add common obs

        // Agent A sees block relative to ITSELF
        Vector3 relBlock = blockRb.transform.position - transform.position;
        sensor.AddObservation(relBlock); // 3 values
    }
}

// --- Concrete Agent B ---
public class AgentB : PushBlockAgentBase
{
    public override void CollectObservations(VectorSensor sensor)
    {
        base.CollectObservations(sensor); // Add common obs

        // Agent B sees block relative to THE TARGET
        Vector3 blockToTarget = manager.targetZone.position - blockRb.transform.position;
        sensor.AddObservation(blockToTarget); // 3 values
    }
}
