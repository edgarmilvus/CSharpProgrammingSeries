
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Policies;
using System.IO; // For Path.Combine

public class SmartNPC : Agent
{
    [Header("AI Configuration")]
    public string modelName = "BalanceSphere.onnx"; // Example model
    public BehaviorType behaviorType = BehaviorType.Inference; // Force Inference

    [Header("Hybrid Control")]
    public float assistedDuration = 5f;
    private float assistedTimer = 0f;
    private bool isAssisted = false;

    [Header("Fallback Patrol")]
    public Transform[] waypoints;
    private int currentWaypoint = 0;
    public float patrolSpeed = 3f;

    [Header("References")]
    public RayPerceptionSensorComponent3D raySensor;

    private BehaviorParameters behaviorParams;
    private bool modelLoadedSuccessfully = false;

    public override void Initialize()
    {
        behaviorParams = GetComponent<BehaviorParameters>();
        
        // 1. Attempt to load model programmatically
        LoadModelRuntime();

        // 2. Setup Event Listeners (Example)
        EventManager.OnResourceProtected += HandleResourceProtected;
    }

    private void LoadModelRuntime()
    {
        if (behaviorParams == null) return;

        // Construct path to StreamingAssets
        string modelPath = Path.Combine(Application.streamingAssetsPath, modelName);

        if (File.Exists(modelPath))
        {
            try
            {
                // Load the model
                NNModel model = ModelLoader.Load(modelPath);
                
                // Assign to Behavior Parameters
                behaviorParams.Model = model;
                behaviorParams.BehaviorType = BehaviorType.Inference;
                
                modelLoadedSuccessfully = true;
                Debug.Log($"NPC: Model {modelName} loaded successfully.");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"NPC: Failed to load model: {e.Message}");
                modelLoadedSuccessfully = false;
            }
        }
        else
        {
            Debug.LogError($"NPC: Model file not found at {modelPath}");
            modelLoadedSuccessfully = false;
        }

        // Handle Fallback
        if (!modelLoadedSuccessfully)
        {
            behaviorParams.BehaviorType = BehaviorType.HeuristicOnly;
            // Or custom fallback logic in Update()
        }
    }

    public override void OnEpisodeBegin()
    {
        // Reset positions if needed
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // Standard observations handled by RayPerceptionSensorComponent3D
        // We don't need to add code here if using the Component
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // If we are in Autonomous Mode (Model loaded), this is called by the NN
        // We can still add rewards here via EventManager
    }

    // --- Event Driven Rewards ---
    private void HandleResourceProtected()
    {
        if (!isAssisted) // Only reward autonomous behavior? Or always?
        {
            AddReward(1.0f);
        }
    }

    // --- Update Loop for Hybrid Control & Fallback ---
    void Update()
    {
        // 1. Handle Hybrid Control (Assisted Mode)
        if (Input.GetKeyDown(KeyCode.E))
        {
            isAssisted = true;
            assistedTimer = assistedDuration;
            behaviorParams.BehaviorType = BehaviorType.HeuristicOnly; // Switch to manual control
        }

        if (isAssisted)
        {
            assistedTimer -= Time.deltaTime;
            if (assistedTimer <= 0)
            {
                isAssisted = false;
                // Revert to model if loaded, else Heuristic
                behaviorParams.BehaviorType = modelLoadedSuccessfully ? BehaviorType.Inference : BehaviorType.HeuristicOnly;
            }
        }

        // 2. Fallback Patrol Logic (If Model Failed)
        if (!modelLoadedSuccessfully && !isAssisted)
        {
            Patrol();
        }
    }

    private void Patrol()
    {
        if (waypoints.Length == 0) return;

        Transform target = waypoints[currentWaypoint];
        transform.position = Vector3.MoveTowards(transform.position, target.position, patrolSpeed * Time.deltaTime);
        transform.LookAt(target);

        if (Vector3.Distance(transform.position, target.position) < 0.1f)
        {
            currentWaypoint = (currentWaypoint + 1) % waypoints.Length;
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        // Manual controls for Assisted Mode
        // Assuming simple movement for testing
        var continuous = actionsOut.ContinuousActions;
        continuous[0] = Input.GetAxis("Horizontal");
        continuous[1] = Input.GetAxis("Vertical");
    }

    private void OnDrawGizmos()
    {
        // Visualize Raycasts
        if (raySensor != null)
        {
            Gizmos.color = Color.yellow;
            // RayPerceptionSensorComponent3D handles its own gizmos, but we can add custom debug info
        }

        // Visualize Mode
        GUIStyle style = new GUIStyle();
        style.normal.textColor = isAssisted ? Color.green : Color.red;
        UnityEditor.Handles.Label(transform.position + Vector3.up * 2f, 
            isAssisted ? "ASSISTED" : (modelLoadedSuccessfully ? "AUTONOMOUS" : "PATROL"), style);
        
        // Visualize Patrol Path
        if (!modelLoadedSuccessfully && waypoints != null)
        {
            Gizmos.color = Color.gray;
            for (int i = 0; i < waypoints.Length; i++)
            {
                if (waypoints[i] != null)
                {
                    Gizmos.DrawSphere(waypoints[i].position, 0.2f);
                    if (i < waypoints.Length - 1 && waypoints[i+1] != null)
                        Gizmos.DrawLine(waypoints[i].position, waypoints[i+1].position);
                }
            }
        }
    }

    private void OnDestroy()
    {
        // Clean up events
        EventManager.OnResourceProtected -= HandleResourceProtected;
    }
}

// --- Mock Event Manager for Context ---
public static class EventManager
{
    public static System.Action OnResourceProtected;
    
    // Call this from game logic when NPC protects a resource
    public static void TriggerResourceProtection()
    {
        OnResourceProtected?.Invoke();
    }
}
