
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

// --- Moving Platform Script ---
public class MovingPlatform : MonoBehaviour
{
    public Transform pointA;
    public Transform pointB;
    private float speed = 2.0f;
    private bool movingToB = true;

    public void SetSpeed(float newSpeed)
    {
        speed = newSpeed;
    }

    void Update()
    {
        // Oscillate between points
        float step = speed * Time.deltaTime;
        if (movingToB)
        {
            transform.position = Vector3.MoveTowards(transform.position, pointB.position, step);
            if (Vector3.Distance(transform.position, pointB.position) < 0.01f) movingToB = false;
        }
        else
        {
            transform.position = Vector3.MoveTowards(transform.position, pointA.position, step);
            if (Vector3.Distance(transform.position, pointA.position) < 0.01f) movingToB = true;
        }
    }
}

// --- Updated Wall Jump Agent ---
public class WallJumpAgent : Agent
{
    [Header("Agent Components")]
    public Rigidbody rb;
    public MovingPlatform platform;
    
    [Header("Settings")]
    public float jumpForce = 5f;
    public float dashForce = 10f;
    public float groundCheckDistance = 0.1f;
    public LayerMask groundLayer;

    // State tracking
    private bool isGrounded = false;
    private bool isOnPlatform = false;

    public override void Initialize()
    {
        if (rb == null) rb = GetComponent<Rigidbody>();
    }

    public override void OnEpisodeBegin()
    {
        rb.velocity = Vector3.zero;
        transform.position = Vector3.zero; // Reset to start
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Agent Velocity (3)
        sensor.AddObservation(rb.velocity);

        // 2. Platform Relative Position (3)
        Vector3 relPos = platform.transform.position - transform.position;
        sensor.AddObservation(relPos);

        // 3. Platform Velocity (3)
        // Calculate velocity manually since MovingPlatform uses Update, not physics
        // (Approximated here for the exercise, ideally cached in MovingPlatform)
        sensor.AddObservation(platform.GetComponent<Rigidbody>()?.velocity ?? Vector3.zero);

        // 4. Raycasts for walls (Standard for WallJump)
        // (Assuming standard raycast logic here for brevity)
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Discrete Actions: 0=Nothing, 1=Jump, 2=Dash
        int action = actions.DiscreteActions[0];

        if (isGrounded)
        {
            if (action == 1) // Jump
            {
                rb.AddForce(Vector3.up * jumpForce, ForceMode.VelocityChange);
            }
            else if (action == 2) // Dash
            {
                // Dash forward
                rb.AddForce(transform.forward * dashForce, ForceMode.VelocityChange);
            }
        }

        // Rewards
        if (isOnPlatform)
        {
            // Bonus for riding platform
            AddReward(0.05f);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        // Check for Platform Collision (Penalty)
        if (collision.gameObject.CompareTag("MovingPlatform"))
        {
            AddReward(-0.2f); // Penalty for hitting platform
            isOnPlatform = true;
        }
        
        // Check for Wall Collision (Standard WallJump penalty)
        if (collision.gameObject.CompareTag("Wall"))
        {
            AddReward(-1.0f);
            EndEpisode();
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("MovingPlatform"))
        {
            isOnPlatform = false;
        }
    }

    private void FixedUpdate()
    {
        // Ground Check
        isGrounded = Physics.Raycast(transform.position, Vector3.down, groundCheckDistance, groundLayer);
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discrete = actionsOut.DiscreteActions;
        discrete[0] = 0;
        if (Input.GetKey(KeyCode.Space)) discrete[0] = 1; // Jump
        if (Input.GetKey(KeyCode.LeftShift)) discrete[0] = 2; // Dash
    }

    private void OnDrawGizmos()
    {
        // Visualize Ground Check
        Gizmos.color = isGrounded ? Color.green : Color.red;
        Gizmos.DrawLine(transform.position, transform.position + Vector3.down * groundCheckDistance);
        
        // Visualize Mode
        Gizmos.color = isOnPlatform ? Color.blue : Color.white;
        Gizmos.DrawWireSphere(transform.position, 0.5f);
    }
}
