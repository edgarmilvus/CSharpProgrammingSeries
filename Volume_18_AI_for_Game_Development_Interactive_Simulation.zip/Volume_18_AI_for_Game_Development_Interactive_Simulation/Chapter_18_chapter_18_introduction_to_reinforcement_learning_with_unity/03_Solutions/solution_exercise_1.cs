
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class BalanceSphereAgent : Agent
{
    [Header("References")]
    public Rigidbody sphereRb;
    public Transform plankTransform; // Reference to the plank to calculate width and edges

    [Header("Parameters")]
    public float torqueForce = 100f;
    public float maxPlankWidth = 6.0f;
    public float minPlankWidth = 4.0f;

    private float plankWidth;
    private float plankYThreshold;

    public override void Initialize()
    {
        // Ensure we have references
        if (sphereRb == null) sphereRb = GetComponent<Rigidbody>();
        
        // Set the initial plank size randomly
        RandomizePlankWidth();
        plankYThreshold = plankTransform.position.y;
    }

    public override void OnEpisodeBegin()
    {
        // Reset Physics
        sphereRb.velocity = Vector3.zero;
        sphereRb.angularVelocity = Vector3.zero;

        // Reset Position: Center of the plank, slightly above surface
        Vector3 resetPos = plankTransform.position;
        resetPos.y += 0.5f; // Lift sphere slightly
        transform.position = resetPos;

        // Reset Rotation
        transform.rotation = Quaternion.identity;

        // Randomize Environment (Generalization)
        RandomizePlankWidth();
    }

    private void RandomizePlankWidth()
    {
        plankWidth = Random.Range(minPlankWidth, maxPlankWidth);
        
        // Assuming the plank is a cube or stretched object, we scale X.
        // We keep Y (thickness) and Z (depth) constant.
        Vector3 currentScale = plankTransform.localScale;
        plankTransform.localScale = new Vector3(plankWidth, currentScale.y, currentScale.z);
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Sphere's local position relative to plank center (3 values)
        // We convert world position to local space relative to the plank
        Vector3 localPos = plankTransform.InverseTransformPoint(transform.position);
        sensor.AddObservation(localPos); 

        // 2. Sphere's velocity (3 values)
        sensor.AddObservation(sphereRb.velocity);

        // 3. Sphere's angular velocity (3 values)
        sensor.AddObservation(sphereRb.angularVelocity);

        // 4. Normalized distance to left and right edges (2 values)
        // localPos.x ranges from -width/2 to +width/2
        float normalizedDistLeft = (localPos.x + plankWidth / 2f) / plankWidth;
        float normalizedDistRight = (plankWidth / 2f - localPos.x) / plankWidth;
        
        sensor.AddObservation(normalizedDistLeft);
        sensor.AddObservation(normalizedDistRight);
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Continuous Action Space: Size 2
        float torqueX = Mathf.Clamp(actions.ContinuousActions[0], -1f, 1f);
        float torqueZ = Mathf.Clamp(actions.ContinuousActions[1], -1f, 1f);

        // Apply Torque
        sphereRb.AddTorque(new Vector3(torqueX, 0, torqueZ) * torqueForce, ForceMode.VelocityChange);

        // Reward Function
        // 1. Survival Reward
        AddReward(0.1f);

        // 2. Failure Conditions
        bool fellOff = transform.position.y < plankYThreshold - 0.5f;
        
        // Check rotation (absolute Euler angles)
        Vector3 rot = transform.rotation.eulerAngles;
        // Normalize angles to -180 to 180 for accurate checking
        float xRot = Mathf.Abs(Quaternion.Normalize(transform.rotation).eulerAngles.x);
        float zRot = Mathf.Abs(Quaternion.Normalize(transform.rotation).eulerAngles.z);
        // Handle wrap-around (e.g. 350 degrees is close to 0, not 350)
        if (xRot > 180) xRot -= 360;
        if (zRot > 180) zRot -= 360;
        
        bool tippedOver = Mathf.Abs(xRot) > 45f || Mathf.Abs(zRot) > 45f;

        if (fellOff || tippedOver)
        {
            AddReward(-1.0f);
            EndEpisode();
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        // Map Keyboard inputs to Continuous Actions
        var continuousActions = actionsOut.ContinuousActions;

        // W/S for X-axis torque (Forward/Backward)
        continuousActions[0] = 0f;
        if (Input.GetKey(KeyCode.W)) continuousActions[0] = 1f;
        if (Input.GetKey(KeyCode.S)) continuousActions[0] = -1f;

        // A/D for Z-axis torque (Left/Right)
        continuousActions[1] = 0f;
        if (Input.GetKey(KeyCode.D)) continuousActions[1] = 1f;
        if (Input.GetKey(KeyCode.A)) continuousActions[1] = -1f;
    }
}
