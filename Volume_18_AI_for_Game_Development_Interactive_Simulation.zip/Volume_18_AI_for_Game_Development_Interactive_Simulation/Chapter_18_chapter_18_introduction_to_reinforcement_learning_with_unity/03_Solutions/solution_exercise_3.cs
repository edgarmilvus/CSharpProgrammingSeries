
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.EnvironmentParameters;

// --- Curriculum Controller ---
public class CurriculumController : MonoBehaviour
{
    [Header("References")]
    public JumpAgent agent;
    public EnvironmentParameters parameters;

    [Header("Curriculum Settings")]
    public int slidingWindowSize = 100;
    public float successThreshold = 0.8f; // 80%
    public float failThreshold = 0.4f;    // 40%
    
    private Queue<float> recentResults = new Queue<float>(); // 1 for success, 0 for fail

    public void ReportResult(bool success)
    {
        recentResults.Enqueue(success ? 1f : 0f);
        if (recentResults.Count > slidingWindowSize) recentResults.Dequeue();

        if (recentResults.Count >= slidingWindowSize)
        {
            float successRate = CalculateSuccessRate();
            AdjustDifficulty(successRate);
        }
    }

    private float CalculateSuccessRate()
    {
        float sum = 0f;
        foreach (var r in recentResults) sum += r;
        return sum / recentResults.Count;
    }

    private void AdjustDifficulty(float rate)
    {
        float currentHeight = parameters.GetWithDefault("hurdle_height", 1.0f);
        float newHeight = currentHeight;

        if (rate > successThreshold)
        {
            newHeight = Mathf.Min(currentHeight + 0.1f, 2.0f);
        }
        else if (rate < failThreshold)
        {
            newHeight = Mathf.Max(currentHeight - 0.1f, 0.5f);
        }

        // Only update if changed to avoid spamming
        if (!Mathf.Approximately(newHeight, currentHeight))
        {
            parameters.SetFloatParameter("hurdle_height", newHeight);
            Debug.Log($"Curriculum Update: Success Rate {rate:P}. New Height: {newHeight}");
        }
    }
}

// --- Jump Agent ---
public class JumpAgent : Agent
{
    [Header("Agent Components")]
    public Rigidbody rb;
    public Transform hurdleSpawnPoint;
    public GameObject hurdlePrefab;
    public CurriculumController curriculum;

    private GameObject currentHurdle;
    private bool isGrounded = true;
    private float forwardSpeed = 5f;

    public override void Initialize()
    {
        if (rb == null) rb = GetComponent<Rigidbody>();
        if (curriculum == null) curriculum = FindObjectOfType<CurriculumController>();
    }

    public override void OnEpisodeBegin()
    {
        rb.velocity = Vector3.zero;
        transform.position = Vector3.zero;
        transform.rotation = Quaternion.identity;

        // Destroy old hurdle
        if (currentHurdle != null) Destroy(currentHurdle);

        // Get dynamic height from Environment Parameters
        float hurdleHeight = Academy.Instance.EnvironmentParameters.GetWithDefault("hurdle_height", 1.0f);

        // Instantiate new hurdle
        currentHurdle = Instantiate(hurdlePrefab, hurdleSpawnPoint.position, Quaternion.identity);
        
        // Scale hurdle based on height parameter
        Vector3 scale = currentHurdle.transform.localScale;
        scale.y = hurdleHeight;
        currentHurdle.transform.localScale = scale;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        if (currentHurdle == null) return;

        // 1. Distance to nearest hurdle
        float distance = Vector3.Distance(transform.position, currentHurdle.transform.position);
        sensor.AddObservation(distance);

        // 2. Hurdle height (normalized roughly)
        sensor.AddObservation(currentHurdle.transform.localScale.y);
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Continuous forward movement
        rb.AddForce(Vector3.forward * forwardSpeed, ForceMode.VelocityChange);

        // Discrete Action: 0=Nothing, 1=Jump
        int jumpAction = actions.DiscreteActions[0];
        if (jumpAction == 1 && isGrounded)
        {
            rb.AddForce(Vector3.up * 8f, ForceMode.VelocityChange);
            isGrounded = false;
        }

        // Small penalty per step to encourage speed
        AddReward(-0.001f);

        // Check bounds
        if (transform.position.y < -2f) // Fell off
        {
            curriculum.ReportResult(false);
            AddReward(-0.5f);
            EndEpisode();
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground")) isGrounded = true;

        // Hurdle Hit Logic
        if (collision.gameObject.CompareTag("Hurdle"))
        {
            AddReward(-0.5f);
            curriculum.ReportResult(false);
            EndEpisode();
        }
    }

    // Trigger Logic for Success
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("HurdleZone")) // A trigger placed just after the hurdle
        {
            AddReward(1.0f);
            curriculum.ReportResult(true);
            EndEpisode();
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var discrete = actionsOut.DiscreteActions;
        if (Input.GetKeyDown(KeyCode.Space)) discrete[0] = 1;
        else discrete[0] = 0;
    }
}
