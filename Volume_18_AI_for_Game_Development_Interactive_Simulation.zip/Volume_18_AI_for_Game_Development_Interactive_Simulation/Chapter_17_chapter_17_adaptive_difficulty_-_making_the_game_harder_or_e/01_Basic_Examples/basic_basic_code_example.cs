
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace AdaptiveDifficultySimulation
{
    // 1. Data Structure: Represents the current state of the game world
    public class GameState
    {
        public float PlayerHealth { get; set; } = 100.0f;
        public int EnemiesDefeated { get; set; }
        public float TimeElapsed { get; set; }
        public float PlayerAccuracy { get; set; } // 0.0 to 1.0
        
        // Snapshot of current difficulty parameters
        public float CurrentEnemyHealthMultiplier { get; set; } = 1.0f;
        public float CurrentSpawnRate { get; set; } = 1.0f; // Enemies per second
    }

    // 2. The "Brain": Analyzes metrics and decides on new difficulty settings
    public class DifficultyController
    {
        // Configuration for difficulty bounds
        private const float MinSpawnRate = 0.5f;
        private const float MaxSpawnRate = 3.0f;
        private const float MinHealthMult = 0.5f;
        private const float MaxHealthMult = 2.0f;

        // Smoothing factor to prevent difficulty from jumping erratically
        private const float AdjustmentSpeed = 0.1f;

        public GameState CalculateNewDifficulty(GameState currentSnapshot)
        {
            // Heuristic 1: Performance Score (0.0 = terrible, 1.0 = perfect)
            // We weigh accuracy heavily, but survival time matters too.
            // If the player is dying instantly (TimeElapsed < 5), score drops.
            float performanceScore = (currentSnapshot.PlayerAccuracy * 0.7f) 
                                   + (Math.Clamp(currentSnapshot.TimeElapsed / 30.0f, 0, 1) * 0.3f);

            // Heuristic 2: Stress Level (Inverse of Health)
            // If player health is low, we might want to ease up, 
            // but if they are low because they are reckless, we might punish them.
            // For this simple example, low health triggers an "Easier" request.
            float stressFactor = 1.0f - (currentSnapshot.PlayerHealth / 100.0f);

            // Logic: Determine Target Multipliers
            float targetHealthMult;
            float targetSpawnRate;

            if (performanceScore > 0.8f && stressFactor < 0.3f)
            {
                // Player is dominating. Increase difficulty.
                targetHealthMult = 1.5f;
                targetSpawnRate = 2.0f;
            }
            else if (performanceScore < 0.4f || currentSnapshot.PlayerHealth < 20)
            {
                // Player is struggling or dying. Decrease difficulty.
                targetHealthMult = 0.8f;
                targetSpawnRate = 0.8f;
            }
            else
            {
                // Balanced state. Maintain current challenge.
                targetHealthMult = 1.0f;
                targetSpawnRate = 1.2f;
            }

            // Apply Linear Interpolation (Lerp) for smooth transitions
            // This prevents the game from feeling "jumpy" or unfair.
            var newState = new GameState
            {
                PlayerHealth = currentSnapshot.PlayerHealth,
                EnemiesDefeated = currentSnapshot.EnemiesDefeated,
                TimeElapsed = currentSnapshot.TimeElapsed,
                PlayerAccuracy = currentSnapshot.PlayerAccuracy,
                
                CurrentEnemyHealthMultiplier = Lerp(currentSnapshot.CurrentEnemyHealthMultiplier, targetHealthMult, AdjustmentSpeed),
                CurrentSpawnRate = Lerp(currentSnapshot.CurrentSpawnRate, targetSpawnRate, AdjustmentSpeed)
            };

            return newState;
        }

        private float Lerp(float start, float end, float t)
        {
            return start + (end - start) * t;
        }
    }

    // 3. Simulation Engine: Simulates the game loop and player actions
    public class GameSimulation
    {
        private GameState _currentState;
        private readonly DifficultyController _controller;

        public GameSimulation()
        {
            _currentState = new GameState();
            _controller = new DifficultyController();
        }

        public void RunSimulation()
        {
            Console.WriteLine("--- Starting Adaptive Difficulty Simulation ---");
            Console.WriteLine($"Initial Spawn Rate: {_currentState.CurrentSpawnRate}, Initial Enemy HP Mult: {_currentState.CurrentEnemyHealthMultiplier}");
            Console.WriteLine();

            // Simulate 10 time steps (e.g., 10 seconds of gameplay)
            for (int i = 0; i < 10; i++)
            {
                SimulateTimeStep(i);
                
                // Analyze the current state and adjust difficulty
                _currentState = _controller.CalculateNewDifficulty(_currentState);
                
                PrintStatus(i);
            }
        }

        private void SimulateTimeStep(int step)
        {
            // Simulate random player performance fluctuations
            // In a real game, this data comes from actual inputs and physics
            var rand = new Random();
            
            // Scenario: Player starts strong, then struggles, then recovers
            float accuracyBase = step < 3 ? 0.9f : (step < 6 ? 0.4f : 0.85f);
            // Add some noise
            _currentState.PlayerAccuracy = (float)Math.Clamp(accuracyBase + (rand.NextDouble() * 0.1 - 0.05), 0, 1);
            
            // Simulate Health changes based on difficulty
            // Higher difficulty = more damage taken
            float damage = (float)rand.NextDouble() * _currentState.CurrentEnemyHealthMultiplier * 5;
            _currentState.PlayerHealth -= damage;
            
            // Cap health
            if (_currentState.PlayerHealth < 0) _currentState.PlayerHealth = 0;
            
            // Simulate enemies defeated
            // Higher spawn rate = more kills possible
            int kills = (int)(_currentState.CurrentSpawnRate * (rand.NextDouble() > 0.5 ? 1 : 0));
            _currentState.EnemiesDefeated += kills;

            _currentState.TimeElapsed += 1.0f;
        }

        private void PrintStatus(int step)
        {
            Console.WriteLine($"[Time Step {step + 1}]");
            Console.WriteLine($"  Player Health: {_currentState.PlayerHealth:F1} | Accuracy: {_currentState.PlayerAccuracy:P0}");
            Console.WriteLine($"  -> ADJUSTMENT: Spawn Rate: {_currentState.CurrentSpawnRate:F2} | Enemy HP Mult: {_currentState.CurrentEnemyHealthMultiplier:F2}");
            Console.WriteLine();
        }
    }

    // 4. Entry Point
    class Program
    {
        static void Main(string[] args)
        {
            var sim = new GameSimulation();
            sim.RunSimulation();
            Console.WriteLine("--- End Simulation ---");
        }
    }
}
