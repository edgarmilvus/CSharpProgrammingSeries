
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace AdaptiveDifficultyConsole
{
    // Represents the core difficulty parameters that can be adjusted in real-time.
    // This struct encapsulates the state of the game environment.
    public struct DifficultyProfile
    {
        public float EnemyHealthMultiplier; // Scales enemy durability
        public float EnemyDamageMultiplier; // Scales enemy attack power
        public float SpawnRateMultiplier;   // Scales frequency of enemy spawns
        public int MaxConcurrentEnemies;    // Limits the number of enemies on screen

        // Default constructor for initialization
        public DifficultyProfile(float health, float damage, float spawnRate, int maxEnemies)
        {
            EnemyHealthMultiplier = health;
            EnemyDamageMultiplier = damage;
            SpawnRateMultiplier = spawnRate;
            MaxConcurrentEnemies = maxEnemies;
        }
    }

    // Simulates the collection of player performance metrics.
    // In a real Unity game, this would hook into PlayerController or GameManager events.
    public class PlayerMetricsMonitor
    {
        public float Accuracy { get; private set; } // 0.0 to 1.0
        public float SurvivalTime { get; private set; } // Seconds
        public int DamageTaken { get; private set; }
        public int EnemiesDefeated { get; private set; }

        public PlayerMetricsMonitor()
        {
            ResetMetrics();
        }

        // Simulates a gameplay session update
        public void RecordSessionData(float accuracy, float survivalTime, int damageTaken, int enemiesDefeated)
        {
            this.Accuracy = accuracy;
            this.SurvivalTime = survivalTime;
            this.DamageTaken = damageTaken;
            this.EnemiesDefeated = enemiesDefeated;
        }

        public void ResetMetrics()
        {
            Accuracy = 0.0f;
            SurvivalTime = 0.0f;
            DamageTaken = 0;
            EnemiesDefeated = 0;
        }
    }

    // The core logic engine for Adaptive Difficulty.
    // It uses a rule-based system to interpret player metrics and adjust the DifficultyProfile.
    public class AdaptiveDifficultyEngine
    {
        // Thresholds for determining player skill level
        private const float HIGH_ACCURACY_THRESHOLD = 0.80f;
        private const float LOW_ACCURACY_THRESHOLD = 0.40f;
        private const float LONG_SURVIVAL_THRESHOLD = 60.0f; // Seconds
        private const float SHORT_SURVIVAL_THRESHOLD = 15.0f;

        // Clamping limits to prevent the game from becoming unplayable
        private const float MAX_MULTIPLIER = 2.0f;
        private const float MIN_MULTIPLIER = 0.5f;
        private const int MAX_ENEMIES_LIMIT = 20;
        private const int MIN_ENEMIES_LIMIT = 2;

        // Current difficulty state
        private DifficultyProfile _currentDifficulty;

        public AdaptiveDifficultyEngine()
        {
            // Initialize with balanced "Normal" difficulty
            _currentDifficulty = new DifficultyProfile(1.0f, 1.0f, 1.0f, 5);
        }

        // Analyzes metrics and returns a new adjusted difficulty profile
        public DifficultyProfile CalculateAdjustment(PlayerMetricsMonitor metrics)
        {
            Console.WriteLine($"\n--- Analyzing Metrics ---");
            Console.WriteLine($"Accuracy: {metrics.Accuracy:P0} | Survival: {metrics.SurvivalTime:F1}s | Kills: {metrics.EnemiesDefeated}");

            // Heuristic Logic 1: Assess Player Dominance (High Accuracy + High Survival)
            if (metrics.Accuracy > HIGH_ACCURACY_THRESHOLD && metrics.SurvivalTime > LONG_SURVIVAL_THRESHOLD)
            {
                Console.WriteLine("Result: Player is dominating. Increasing difficulty.");
                return AdjustDifficulty(1.2f); // Increase difficulty by 20%
            }

            // Heuristic Logic 2: Assess Player Struggle (Low Accuracy + Low Survival)
            if (metrics.Accuracy < LOW_ACCURACY_THRESHOLD && metrics.SurvivalTime < SHORT_SURVIVAL_THRESHOLD)
            {
                Console.WriteLine("Result: Player is struggling. Decreasing difficulty.");
                return AdjustDifficulty(0.8f); // Decrease difficulty by 20%
            }

            // Heuristic Logic 3: Assess High Risk (High Damage Taken)
            // Even if survival is okay, if damage taken is extreme, reduce aggression
            if (metrics.DamageTaken > 50 && metrics.EnemiesDefeated < 5)
            {
                Console.WriteLine("Result: Player taking excessive damage. Reducing enemy aggression.");
                return AdjustDifficulty(0.9f);
            }

            // Default: No significant change required
            Console.WriteLine("Result: Performance stable. Maintaining current difficulty.");
            return _currentDifficulty;
        }

        // Internal helper to apply multipliers safely
        private DifficultyProfile AdjustDifficulty(float scalar)
        {
            // Apply scalar to existing multipliers
            float newHealth = _currentDifficulty.EnemyHealthMultiplier * scalar;
            float newDamage = _currentDifficulty.EnemyDamageMultiplier * scalar;
            float newSpawn = _currentDifficulty.SpawnRateMultiplier * scalar;
            int newMaxEnemies = (int)(_currentDifficulty.MaxConcurrentEnemies * scalar);

            // Clamp values to defined limits (Safety Mechanism)
            newHealth = Math.Clamp(newHealth, MIN_MULTIPLIER, MAX_MULTIPLIER);
            newDamage = Math.Clamp(newDamage, MIN_MULTIPLIER, MAX_MULTIPLIER);
            newSpawn = Math.Clamp(newSpawn, MIN_MULTIPLIER, MAX_MULTIPLIER);
            newMaxEnemies = Math.Clamp(newMaxEnemies, MIN_ENEMIES_LIMIT, MAX_ENEMIES_LIMIT);

            // Update internal state
            _currentDifficulty = new DifficultyProfile(newHealth, newDamage, newSpawn, newMaxEnemies);
            return _currentDifficulty;
        }
    }

    // Main Application Entry Point
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Initializing Adaptive Difficulty System...");
            
            // Initialize Systems
            var monitor = new PlayerMetricsMonitor();
            var engine = new AdaptiveDifficultyEngine();

            // --- Simulation Scenario 1: The Expert Player ---
            Console.WriteLine("\n[SCENARIO 1: Expert Player]");
            // Player has high accuracy, long survival, decent kills
            monitor.RecordSessionData(accuracy: 0.85f, survivalTime: 90.0f, damageTaken: 10, enemiesDefeated: 15);
            
            DifficultyProfile diff1 = engine.CalculateAdjustment(monitor);
            PrintDifficulty(diff1);

            // --- Simulation Scenario 2: The Struggling Player ---
            Console.WriteLine("\n[SCENARIO 2: Struggling Player]");
            // Player has low accuracy, dies quickly, low kills
            monitor.ResetMetrics();
            monitor.RecordSessionData(accuracy: 0.30f, survivalTime: 12.0f, damageTaken: 80, enemiesDefeated: 1);
            
            DifficultyProfile diff2 = engine.CalculateAdjustment(monitor);
            PrintDifficulty(diff2);

            // --- Simulation Scenario 3: The "Glass Cannon" (High Damage Taken) ---
            Console.WriteLine("\n[SCENARIO 3: Aggressive but Fragile Player]");
            // Player kills things but takes massive damage
            monitor.ResetMetrics();
            monitor.RecordSessionData(accuracy: 0.60f, survivalTime: 45.0f, damageTaken: 60, enemiesDefeated: 8);
            
            DifficultyProfile diff3 = engine.CalculateAdjustment(monitor);
            PrintDifficulty(diff3);

            // --- Simulation Scenario 4: Testing Edge Cases (Max Limit) ---
            Console.WriteLine("\n[SCENARIO 4: Pushing Limits]");
            // Simulate a player who has been winning for a long time to push limits
            // Note: We manually set the engine state to near-max for demonstration
            // In a real loop, this would happen naturally.
            Console.WriteLine("Simulating extended winning streak...");
            // (We can't easily access private fields here without reflection, so we rely on the engine's clamping logic)
            // Let's run a loop to push it up.
            for(int i = 0; i < 5; i++) {
                monitor.RecordSessionData(0.90f, 120.0f, 5, 20);
                diff3 = engine.CalculateAdjustment(monitor);
            }
            PrintDifficulty(diff3);

            Console.WriteLine("\nSimulation Complete.");
        }

        // Helper to print the difficulty profile clearly
        static void PrintDifficulty(DifficultyProfile profile)
        {
            Console.WriteLine(">> New Difficulty Settings Applied:");
            Console.WriteLine($"   - Enemy Health: {profile.EnemyHealthMultiplier:F2}x");
            Console.WriteLine($"   - Enemy Damage: {profile.EnemyDamageMultiplier:F2}x");
            Console.WriteLine($"   - Spawn Rate:   {profile.SpawnRateMultiplier:F2}x");
            Console.WriteLine($"   - Max Enemies:  {profile.MaxConcurrentEnemies}");
        }
    }
}
