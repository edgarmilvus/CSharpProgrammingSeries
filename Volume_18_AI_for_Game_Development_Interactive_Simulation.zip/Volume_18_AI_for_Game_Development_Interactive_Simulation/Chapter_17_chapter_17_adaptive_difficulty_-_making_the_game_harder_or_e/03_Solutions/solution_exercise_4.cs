
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System;
using System.Threading.Tasks;

public class ResilientArbitrator : MonoBehaviour
{
    [SerializeField] private LLMDifficultyArbitrator _llmArbitrator; // Injected or found
    [SerializeField] private float _timeoutMs = 200f;
    [SerializeField] private int _allowedFailures = 3;
    
    // Circuit Breaker State
    private int _consecutiveFailures = 0;
    private DateTime _circuitBreakerUntil = DateTime.MinValue;
    
    // Fallback Learning State
    private float _baselineDifficulty = 0.5f; // 0.0 (Easy) to 1.0 (Hard)
    private float _learningRate = 0.05f;

    public async Task<DifficultyAdjustment> GetSafeAdjustment(TelemetryPayload payload)
    {
        // Check Circuit Breaker
        if (DateTime.UtcNow < _circuitBreakerUntil)
        {
            Debug.LogWarning("[ResilientArbitrator] Circuit Breaker Active. Using Fallback.");
            return CalculateFallback(payload);
        }

        try
        {
            // Create Timeout Token
            using (var timeoutCts = new System.Threading.CancellationTokenSource(TimeSpan.FromMilliseconds(_timeoutMs)))
            {
                // Wrap the LLM call with a timeout task
                Task<DifficultyAdjustment> llmTask = _llmArbitrator.RequestAdjustment(payload);
                Task timeoutTask = Task.Delay(_timeoutMs, timeoutCts.Token);

                var completedTask = await Task.WhenAny(llmTask, timeoutTask);

                if (completedTask == llmTask)
                {
                    // Success
                    Debug.Log("[ResilientArbitrator] LLM Success.");
                    _consecutiveFailures = 0; // Reset counter
                    return await llmTask;
                }
                else
                {
                    // Timeout
                    throw new TimeoutException("LLM response timed out.");
                }
            }
        }
        catch (Exception e)
        {
            _consecutiveFailures++;
            Debug.LogError($"[ResilientArbitrator] Failure #{_consecutiveFailures}: {e.Message}");
            
            // Activate Circuit Breaker if threshold reached
            if (_consecutiveFailures >= _allowedFailures)
            {
                _circuitBreakerUntil = DateTime.UtcNow.AddSeconds(60);
                Debug.LogError("[ResilientArbitrator] CIRCUIT BREAKER OPENED. Falling back for 60s.");
            }

            return CalculateFallback(payload);
        }
    }

    private DifficultyAdjustment CalculateFallback(TelemetryPayload payload)
    {
        // 1. Calculate Performance Score (0.0 to 1.0)
        // Weighted average: Accuracy (40%) + Survival (60%)
        float accuracyScore = payload.AverageAccuracy; // Assuming 0-1 range
        float survivalScore = Mathf.Clamp(payload.SurvivalTime / 60f, 0f, 1f); // Normalize 60s as max
        
        float performanceScore = (accuracyScore * 0.4f) + (survivalScore * 0.6f);

        // 2. Adjust Baseline Difficulty based on Performance
        // High performance (>0.8) -> Easier (Lower baseline)
        // Low performance (<0.3) -> Harder (Higher baseline)
        if (performanceScore > 0.8f) _baselineDifficulty -= _learningRate;
        else if (performanceScore < 0.3f) _baselineDifficulty += _learningRate;

        // Clamp baseline
        _baselineDifficulty = Mathf.Clamp(_baselineDifficulty, 0.1f, 1.0f);

        Debug.Log($"[Fallback] Perf: {performanceScore}, New Baseline: {_baselineDifficulty}");

        // 3. Map Baseline to Game Parameters
        return new DifficultyAdjustment
        {
            // Inverse mapping: Higher baseline = Harder game (Lower health multiplier for enemies? No, usually Higher health)
            // Let's say: Baseline 0.5 is normal. 
            // 0.0 -> Weak enemies (0.5x), 1.0 -> Strong enemies (1.5x)
            EnemyHealthMultiplier = 0.5f + (_baselineDifficulty * 1.0f),
            
            // Spawn rate: Higher baseline = More spawns
            SpawnRateMultiplier = 0.5f + (_baselineDifficulty * 1.0f),
            
            AggressionLevel = _baselineDifficulty > 0.7f ? AggressionLevel.Aggressive : 
                              _baselineDifficulty < 0.3f ? AggressionLevel.Passive : 
                              AggressionLevel.Normal
        };
    }
}
