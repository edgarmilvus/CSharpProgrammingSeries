
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.Json;

// Enums and Data Structures
public enum AggressionLevel { Passive, Normal, Aggressive }

public class DifficultyAdjustment
{
    public float EnemyHealthMultiplier { get; set; }
    public float SpawnRateMultiplier { get; set; }
    public AggressionLevel AggressionLevel { get; set; }
}

public class TelemetryPayload
{
    public List<PlayerMetric> RecentMetrics { get; set; } = new();
    public float AverageAccuracy { get; set; }
    public float SurvivalTime { get; set; }
    public DateTime TimeGenerated { get; set; }
}

// Interface for Dependency Injection
public interface ILLMService
{
    Task<DifficultyAdjustment> GetAdjustmentAsync(string prompt);
}

// Mock Implementation for Testing
public class MockLLMService : ILLMService
{
    public async Task<DifficultyAdjustment> GetAdjustmentAsync(string prompt)
    {
        // Simulate network latency
        await Task.Delay(UnityEngine.Random.Range(50, 150));

        // Return random valid adjustments
        return new DifficultyAdjustment
        {
            EnemyHealthMultiplier = UnityEngine.Random.Range(0.8f, 1.5f),
            SpawnRateMultiplier = UnityEngine.Random.Range(0.8f, 1.5f),
            AggressionLevel = (AggressionLevel)UnityEngine.Random.Range(0, 3)
        };
    }
}

// The Arbitrator Logic
public class LLMDifficultyArbitrator
{
    private readonly ILLMService _llmService;
    
    // History for Few-Shot Learning
    private readonly List<(string Input, string Output)> _historyLog = new();

    public LLMDifficultyArbitrator(ILLMService llmService)
    {
        _llmService = llmService;
    }

    public async Task<DifficultyAdjustment> RequestAdjustment(TelemetryPayload payload)
    {
        string prompt = GeneratePrompt(payload);
        
        DifficultyAdjustment rawResult = await _llmService.GetAdjustmentAsync(prompt);
        
        // Safety Guardrails
        return ApplySafetyGuardrails(rawResult);
    }

    private string GeneratePrompt(TelemetryPayload payload)
    {
        // Serialize payload for context
        string payloadJson = JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = false });

        // Construct System Prompt
        string systemPrompt = "You are a dynamic difficulty adjustment system for a fast-paced shooter. ";
        systemPrompt += "Analyze the player's recent metrics and output ONLY valid JSON matching the DifficultyAdjustment schema.\n";
        systemPrompt += "Constraints: EnemyHealthMultiplier (0.5-2.0), SpawnRateMultiplier (0.5-2.0), AggressionLevel (Passive, Normal, Aggressive).\n\n";

        // Few-Shot Learning: Add examples from history (keeping it short to save tokens)
        systemPrompt += "Examples:\n";
        if (_historyLog.Count > 0)
        {
            foreach (var entry in _historyLog.TakeLast(3))
            {
                systemPrompt += $"Input: {entry.Input}\nOutput: {entry.Output}\n";
            }
        }

        systemPrompt += $"\nCurrent Data: {payloadJson}\nOutput:";

        return systemPrompt;
    }

    private DifficultyAdjustment ApplySafetyGuardrails(DifficultyAdjustment adjustment)
    {
        // Clamp values
        adjustment.EnemyHealthMultiplier = Math.Clamp(adjustment.EnemyHealthMultiplier, 0.5f, 2.0f);
        adjustment.SpawnRateMultiplier = Math.Clamp(adjustment.SpawnRateMultiplier, 0.5f, 2.0f);
        
        // Ensure Enum validity (default to Normal if invalid)
        if (!Enum.IsDefined(typeof(AggressionLevel), adjustment.AggressionLevel))
        {
            adjustment.AggressionLevel = AggressionLevel.Normal;
        }

        return adjustment;
    }
    
    // Call this after applying the adjustment successfully to update history
    public void LogOutcome(string inputJson, string outputJson)
    {
        _historyLog.Add((inputJson, outputJson));
    }
}
