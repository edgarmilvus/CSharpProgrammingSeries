
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using DG.Tweening; // Assuming DOTween is installed

public class AdaptiveEnemyManager : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] private float _transitionDuration = 2.0f;
    [SerializeField] private EnemySpawner _spawner;
    [SerializeField] private List<EnemyController> _activeEnemies = new();

    // Current State
    private DifficultyAdjustment _currentTargetState;
    private DifficultyAdjustment _currentState;
    
    // Priority System (0 = Low, 10 = Critical)
    private int _currentPriority = 0;

    // Visual Feedback Material Block
    private MaterialPropertyBlock _propBlock;
    private static readonly int _EmissionColor = Shader.PropertyToID("_EmissionColor");

    private void Awake()
    {
        _propBlock = new MaterialPropertyBlock();
        // Initialize default state
        _currentState = new DifficultyAdjustment 
        { 
            EnemyHealthMultiplier = 1.0f, 
            SpawnRateMultiplier = 1.0f, 
            AggressionLevel = AggressionLevel.Normal 
        };
        _currentTargetState = _currentState;
    }

    // Called by the Telemetry/LLM system
    public void ApplyDifficultyChange(DifficultyAdjustment newAdjustment, int priority = 0)
    {
        // Priority System: Ignore lower priority updates if currently transitioning
        if (priority < _currentPriority && DOTween.IsTweening(this.transform)) 
            return;

        _currentPriority = priority;
        _currentTargetState = newAdjustment;

        // Stop existing tweens to prevent stacking conflicts
        DOTween.Kill(this);

        // Start Interpolation Coroutine
        StartCoroutine(InterpolateDifficultyRoutine());
    }

    private IEnumerator InterpolateDifficultyRoutine()
    {
        float elapsed = 0;
        DifficultyAdjustment startState = _currentState;

        while (elapsed < _transitionDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / _transitionDuration;

            // Smooth interpolation
            _currentState.EnemyHealthMultiplier = Mathf.Lerp(startState.EnemyHealthMultiplier, _currentTargetState.EnemyHealthMultiplier, t);
            _currentState.SpawnRateMultiplier = Mathf.Lerp(startState.SpawnRateMultiplier, _currentTargetState.SpawnRateMultiplier, t);
            
            // Update Spawner Logic
            UpdateSpawner(_currentState.SpawnRateMultiplier);

            // Update Active Enemies
            UpdateActiveEnemiesVisuals(_currentState);

            yield return null;
        }

        // Snap to final value
        _currentState = _currentTargetState;
        UpdateSpawner(_currentState.SpawnRateMultiplier);
        UpdateActiveEnemiesVisuals(_currentState);
        _currentPriority = 0; // Reset priority
    }

    private void UpdateSpawner(float spawnMultiplier)
    {
        if (_spawner == null) return;

        // Inverse relationship: Higher multiplier = Faster spawns (Lower interval)
        // Base interval is 2.0 seconds
        float newInterval = 2.0f / spawnMultiplier;
        
        // Clamp to prevent infinite loops or too slow spawns
        newInterval = Mathf.Clamp(newInterval, 0.5f, 5.0f);
        
        _spawner.SetSpawnInterval(newInterval);
    }

    private void UpdateActiveEnemiesVisuals(DifficultyAdjustment state)
    {
        Color targetColor = Color.white;

        // Visual Feedback based on Aggression
        switch (state.AggressionLevel)
        {
            case AggressionLevel.Passive:
                targetColor = Color.blue;
                break;
            case AggressionLevel.Normal:
                targetColor = Color.white;
                break;
            case AggressionLevel.Aggressive:
                targetColor = Color.red;
                break;
        }

        // Apply to all active enemies using MaterialPropertyBlock for performance
        foreach (var enemy in _activeEnemies)
        {
            if (enemy == null) continue;
            
            Renderer r = enemy.GetComponent<Renderer>();
            if (r != null)
            {
                r.GetPropertyBlock(_propBlock);
                _propBlock.SetColor(_EmissionColor, targetColor * 0.5f); // 0.5f intensity
                r.SetPropertyBlock(_propBlock);
            }
            
            // Apply Stat Changes
            enemy.SetHealthMultiplier(state.EnemyHealthMultiplier);
            enemy.SetAggression(state.AggressionLevel);
        }
    }
    
    // Helper to register enemies
    public void RegisterEnemy(EnemyController enemy) => _activeEnemies.Add(enemy);
    public void UnregisterEnemy(EnemyController enemy) => _activeEnemies.Remove(enemy);
}

// Mock Spawner class for context
public class EnemySpawner : MonoBehaviour 
{
    public void SetSpawnInterval(float interval) { /* Logic to change spawn timer */ }
}

// Mock Enemy class for context
public class EnemyController : MonoBehaviour 
{
    public void SetHealthMultiplier(float mult) { /* Logic to change max HP */ }
    public void SetAggression(AggressionLevel level) { /* Logic to change AI behavior */ }
}
