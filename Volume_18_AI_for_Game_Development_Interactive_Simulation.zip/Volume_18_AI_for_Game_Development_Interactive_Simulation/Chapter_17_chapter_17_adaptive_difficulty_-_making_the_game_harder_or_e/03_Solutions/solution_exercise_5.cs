
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;

public class DifficultyGraph : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private LineRenderer _performanceLine;
    [SerializeField] private LineRenderer _difficultyLine;
    [SerializeField] private LineRenderer _predictionLine;
    [SerializeField] private Transform _markerParent;
    [SerializeField] private Text _summaryText;
    [SerializeField] private RectTransform _graphBorder;

    [Header("Settings")]
    [SerializeField] private int _maxDataPoints = 100;
    [SerializeField] private float _timeWindow = 60f; // Seconds
    [SerializeField] private float _predictionHorizon = 10f; // Seconds into future

    private Queue<float> _performanceBuffer = new Queue<float>();
    private Queue<float> _difficultyBuffer = new Queue<float>();
    private float _currentTime = 0;

    // Data storage for regression
    private List<Vector2> _historyPoints = new List<Vector2>(); // X=Time, Y=Performance

    void Update()
    {
        _currentTime += Time.deltaTime;
        
        // Simulate data flow for demonstration (Remove in production)
        SimulateData();

        // Update Graphs
        UpdateLineRenderers();
        
        // Update Prediction
        UpdatePrediction();
    }

    // Called by external systems (Telemetry/Manager)
    public void LogDataPoint(float performance, float difficultyMultiplier)
    {
        if (_performanceBuffer.Count >= _maxDataPoints)
        {
            _performanceBuffer.Dequeue();
            _difficultyBuffer.Dequeue();
            if (_historyPoints.Count > 0) _historyPoints.RemoveAt(0);
        }

        _performanceBuffer.Enqueue(performance);
        _difficultyBuffer.Enqueue(difficultyMultiplier);
        
        // Store for regression (normalized time index 0-1 for simplicity in this example, 
        // or absolute time. Let's use relative index for line drawing)
        _historyPoints.Add(new Vector2(_currentTime, performance));
    }

    public void AddEventMarker(string eventType, Color color)
    {
        // Instantiate a simple UI Image or Quad
        // For brevity, we assume a prefab setup, here we just log or create a primitive
        GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Cube);
        marker.transform.SetParent(_markerParent, false);
        marker.transform.localScale = new Vector3(2, 10, 1);
        
        // Position at the far right of the graph (current time)
        // In a real UI, we map time to X position
        marker.GetComponent<Renderer>().material.color = color;
        
        // Update Text Summary
        _summaryText.text = $"Last Event: {eventType}\nTime: {_currentTime:F1}s";
    }

    private void UpdateLineRenderers()
    {
        // Map buffers to LineRenderer positions
        // X axis: Index (0 to MaxPoints)
        // Y axis: Value (0 to 1)
        
        int count = _performanceBuffer.Count;
        if (count == 0) return;

        _performanceLine.positionCount = count;
        _difficultyLine.positionCount = count;

        float[] perfArray = _performanceBuffer.ToArray();
        float[] diffArray = _difficultyBuffer.ToArray();

        for (int i = 0; i < count; i++)
        {
            // Map to graph coordinates (e.g., width 100 units)
            float x = i * (100f / _maxDataPoints);
            
            _performanceLine.SetPosition(i, new Vector3(x, perfArray[i] * 50f, 0));
            _difficultyLine.SetPosition(i, new Vector3(x, diffArray[i] * 50f, 0)); // Assuming diff mult 0.5-2.0 mapped
        }
    }

    private void UpdatePrediction()
    {
        if (_historyPoints.Count < 5) return;

        // Linear Regression (Least Squares)
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        int n = _historyPoints.Count;

        foreach (var p in _historyPoints)
        {
            sumX += p.x;
            sumY += p.y;
            sumXY += p.x * p.y;
            sumX2 += p.x * p.x;
        }

        double slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        double intercept = (sumY - slope * sumX) / n;

        // Predict future point
        float futureTime = _currentTime + _predictionHorizon;
        float predictedY = (float)(slope * futureTime + intercept);

        // Draw dotted line (using a separate LineRenderer with dash texture or just a simple line)
        _predictionLine.positionCount = 2;
        _predictionLine.SetPosition(0, new Vector3(100f, _historyPoints.Last().y * 50f, 0)); // Start at last known
        
        // End point (clamped to graph bounds)
        predictedY = Mathf.Clamp(predictedY, 0f, 1f);
        _predictionLine.SetPosition(1, new Vector3(100f + (_predictionHorizon * 2f), predictedY * 50f, 0));

        // Visual Warning
        if (predictedY > 0.8f || predictedY < 0.2f)
        {
            _graphBorder.GetComponent<Image>().color = Color.yellow;
        }
        else
        {
            _graphBorder.GetComponent<Image>().color = Color.white;
        }
    }

    private void SimulateData()
    {
        // Mock data for testing the graph
        if (Random.value > 0.95f)
        {
            float perf = Random.Range(0.3f, 0.9f);
            float diff = Random.Range(0.8f, 1.5f);
            LogDataPoint(perf, diff);
            
            if(Random.value > 0.8f) 
                AddEventMarker(Random.value > 0.5f ? "LLM Success" : "Fallback", 
                               Random.value > 0.5f ? Color.green : Color.red);
        }
    }
}
