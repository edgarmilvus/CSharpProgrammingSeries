
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.Diagnostics;

// Enum for Metric Types
public enum MetricType { Accuracy, SurvivalTime, DamageTaken, ResourceEfficiency, Death }

// Structured Data Model (Record for immutability and value semantics)
public record PlayerMetric(
    MetricType Type, 
    float Value, 
    string Context, 
    DateTime Timestamp
);

// Struct to hold a sliding window of events
public struct CorrelationWindow
{
    private Queue<PlayerMetric> _recentEvents;
    private TimeSpan _windowDuration;

    public CorrelationWindow(TimeSpan windowDuration)
    {
        _recentEvents = new Queue<PlayerMetric>();
        _windowDuration = windowDuration;
    }

    public void AddEvent(PlayerMetric metric)
    {
        _recentEvents.Enqueue(metric);
        CleanOldEvents(metric.Timestamp);
    }

    // Returns true if a specific condition was met within the window
    public bool CheckCondition(Func<PlayerMetric, bool> predicate, DateTime currentTime)
    {
        CleanOldEvents(currentTime);
        return _recentEvents.Any(predicate);
    }

    private void CleanOldEvents(DateTime currentTime)
    {
        while (_recentEvents.Count > 0 && (currentTime - _recentEvents.Peek().Timestamp) > _windowDuration)
        {
            _recentEvents.Dequeue();
        }
    }
}

// Event-Driven Manager
public static class TelemetryManager
{
    // Thread-safe queue for high-frequency data
    private static readonly ConcurrentQueue<PlayerMetric> _metricQueue = new();
    
    // Correlation window (last 10 seconds)
    private static CorrelationWindow _correlationWindow = new(TimeSpan.FromSeconds(10));
    
    // Event for subscribers (Observer Pattern)
    public static event Action<PlayerMetric> OnMetricLogged;

    // Critical metrics that bypass the queue
    private static readonly HashSet<MetricType> _criticalMetrics = new() { MetricType.Death };

    // Buffer limit to prevent memory overflow
    private const int MaxQueueSize = 10000;

    /// <summary>
    /// Call this from any game object to log a metric.
    /// </summary>
    public static void LogMetric(MetricType type, float value, string context)
    {
        var metric = new PlayerMetric(type, value, context, DateTime.UtcNow);

        // Update correlation window immediately
        _correlationWindow.AddEvent(metric);

        // Notify immediate subscribers (e.g., Achievement System)
        OnMetricLogged?.Invoke(metric);

        // Handle Critical Metrics (Bypass Queue for immediate processing)
        if (_criticalMetrics.Contains(type))
        {
            // In a real scenario, trigger a specific event for critical logic
            ProcessBatch(new[] { metric }); 
            return;
        }

        // Handle Queue Overflow (Circular Buffer Strategy: Drop oldest)
        if (_metricQueue.Count >= MaxQueueSize)
        {
            _metricQueue.TryDequeue(out _);
        }

        _metricQueue.Enqueue(metric);
    }

    /// <summary>
    /// Checks for specific sequences in the recent history.
    /// </summary>
    public static bool CheckCorrelation(MetricType trigger, MetricType result)
    {
        return _correlationWindow.CheckCondition(
            m => m.Type == trigger, 
            DateTime.UtcNow
        ) && _correlationWindow.CheckCondition(
            m => m.Type == result, 
            DateTime.UtcNow
        );
    }

    /// <summary>
    /// Async loop to process the queue in batches.
    /// </summary>
    public static async Task StartProcessingLoop()
    {
        while (true)
        {
            await Task.Delay(5000); // Process every 5 seconds

            if (_metricQueue.IsEmpty) continue;

            var batch = new List<PlayerMetric>();
            while (_metricQueue.TryDequeue(out var metric))
            {
                batch.Add(metric);
            }

            ProcessBatch(batch);
        }
    }

    // Mock Analysis Service
    private static void ProcessBatch(IEnumerable<PlayerMetric> batch)
    {
        // Simulate sending to a server or database
        // UnityEngine.Debug.Log($"[Telemetry] Flushing {batch.Count()} metrics.");
        
        // In a real implementation, serialize to JSON here
        foreach(var m in batch)
        {
            // Log specific logic for correlation examples
            if(m.Type == MetricType.DamageTaken && CheckCorrelation(MetricType.ResourceEfficiency, MetricType.DamageTaken))
            {
                 UnityEngine.Debug.Log($"[Telemetry] Correlation Detected: Player took damage shortly after efficient resource use.");
            }
        }
    }
}
