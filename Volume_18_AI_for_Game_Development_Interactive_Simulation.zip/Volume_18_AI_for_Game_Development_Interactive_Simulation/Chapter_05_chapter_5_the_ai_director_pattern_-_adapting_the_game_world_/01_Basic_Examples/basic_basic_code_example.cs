
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

// ---------------------------------------------------------
// 1. DATA MODELS
// ---------------------------------------------------------

/// <summary>
/// Represents the current state of the player and the game world.
/// This is the "Telemetry" data fed into the LLM.
/// </summary>
public class PlayerTelemetry
{
    public int PlayerHealth { get; set; }
    public int EnemiesRemaining { get; set; }
    public float PlayerStamina { get; set; }
    public string CurrentBiome { get; set; } = "Forest";
}

/// <summary>
/// Represents the decision made by the AI Director.
/// This is the structured response we expect from the LLM (via JSON mode).
/// </summary>
public class DirectorDecision
{
    [JsonPropertyName("action")]
    public string Action { get; set; } // e.g., "SpawnEnemy", "HealPlayer", "ChangeWeather"

    [JsonPropertyName("intensity")]
    public int Intensity { get; set; } // 1 to 10

    [JsonPropertyName("narrative_comment")]
    public string NarrativeComment { get; set; } // Flavor text
}

// ---------------------------------------------------------
// 2. THE AI DIRECTOR CORE
// ---------------------------------------------------------

public class AIDirector
{
    // In a real scenario, this would be an actual HTTP client to OpenAI/Anthropic.
    // For this example, we simulate the LLM's behavior.
    private readonly MockLLMService _llmService;

    public AIDirector()
    {
        _llmService = new MockLLMService();
    }

    /// <summary>
    /// The main loop: Analyze telemetry -> Call LLM -> Execute Action.
    /// </summary>
    public async Task<DirectorDecision> AnalyzeAndAdaptAsync(PlayerTelemetry telemetry)
    {
        // 1. Serialize the current state to JSON to send to the LLM.
        string telemetryJson = JsonSerializer.Serialize(telemetry);

        // 2. Construct the prompt for the LLM.
        // We instruct the LLM to act as a Game Director and output only JSON.
        string systemPrompt = @"
            You are an AI Director for a survival horror game. 
            Analyze the player's state and decide the next event.
            Rules:
            - If player health is low, consider healing or reducing enemies.
            - If enemies are zero, spawn new ones.
            - Output strictly valid JSON matching the DirectorDecision schema.
        ";

        // 3. Call the LLM (Simulated here).
        string llmResponseJson = await _llmService.QueryAsync(systemPrompt, telemetryJson);

        // 4. Parse the JSON response into our C# object.
        DirectorDecision decision = JsonSerializer.Deserialize<DirectorDecision>(llmResponseJson);

        // 5. Log the decision (Simulating the "World Adjustment").
        Console.WriteLine($"[Director] Parsed Decision: {decision.Action} (Intensity: {decision.Intensity})");
        Console.WriteLine($"[Director] Narrative: \"{decision.NarrativeComment}\"");

        return decision;
    }
}

// ---------------------------------------------------------
// 3. SIMULATION INFRASTRUCTURE (Mocking the LLM)
// ---------------------------------------------------------

/// <summary>
/// Mocks an LLM API. In production, this would use HttpClient to call GPT-4 or similar.
/// </summary>
public class MockLLMService
{
    public async Task<string> QueryAsync(string systemPrompt, string userContextJson)
    {
        // Simulate network latency
        await Task.Delay(100); 

        // Parse the context to make a logic-based decision (simulating the LLM's reasoning)
        var context = JsonSerializer.Deserialize<PlayerTelemetry>(userContextJson);

        string action;
        int intensity;
        string comment;

        // Simple logic to simulate what an LLM might decide based on the input
        if (context.PlayerHealth < 30)
        {
            action = "HealPlayer";
            intensity = 8;
            comment = "The player is struggling. Granting a moment of respite.";
        }
        else if (context.EnemiesRemaining == 0)
        {
            action = "SpawnEnemy";
            intensity = 5;
            comment = "The silence is deafening. New threats emerge from the shadows.";
        }
        else
        {
            action = "IncreaseAggression";
            intensity = 7;
            comment = "The hunt continues. Push the player harder.";
        }

        // Return a JSON string as if it came from the LLM
        return $@"
        {{
            ""action"": ""{action}"",
            ""intensity"": {intensity},
            ""narrative_comment"": ""{comment}""
        }}";
    }
}

// ---------------------------------------------------------
// 4. UNITY-LIKE GAME LOOP SIMULATION
// ---------------------------------------------------------

public class GameSimulation
{
    public static async Task Main(string[] args)
    {
        Console.WriteLine("--- AI Director 'Hello World' Simulation ---\n");

        // Initialize the Director
        var director = new AIDirector();

        // Scenario 1: Player is healthy, enemies exist
        Console.WriteLine("\n[Scenario 1] Player exploring the forest...");
        var telemetry1 = new PlayerTelemetry { PlayerHealth = 100, EnemiesRemaining = 3, PlayerStamina = 80 };
        await director.AnalyzeAndAdaptAsync(telemetry1);

        // Scenario 2: Player is low on health
        Console.WriteLine("\n[Scenario 2] Player takes heavy damage...");
        var telemetry2 = new PlayerTelemetry { PlayerHealth = 20, EnemiesRemaining = 5, PlayerStamina = 10 };
        await director.AnalyzeAndAdaptAsync(telemetry2);

        // Scenario 3: Player clears the room
        Console.WriteLine("\n[Scenario 3] Player defeats all enemies...");
        var telemetry3 = new PlayerTelemetry { PlayerHealth = 80, EnemiesRemaining = 0, PlayerStamina = 50 };
        await director.AnalyzeAndAdaptAsync(telemetry3);

        Console.WriteLine("\n--- Simulation Complete ---");
    }
}
