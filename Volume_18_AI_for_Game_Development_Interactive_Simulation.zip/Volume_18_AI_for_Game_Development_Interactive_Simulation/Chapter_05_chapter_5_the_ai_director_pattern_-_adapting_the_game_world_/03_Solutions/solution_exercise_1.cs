
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

// 1. Using a 'record' for immutability and value-based equality.
// We use 'readonly' struct backing for performance.
public readonly record struct PlayerState(
    float Health,       // 0.0 to 1.0
    float Engagement,   // Cumulative score (normalized or raw delta)
    float Stress,       // Recent damage taken
    DateTime Timestamp
);

public class TelemetryAggregator
{
    // 2. Circular buffer implementation to avoid GC allocations.
    private readonly PlayerState[] _buffer;
    private int _head = 0;
    private int _count = 0;
    private readonly int _capacity;
    
    // Thread safety synchronization primitive.
    private readonly ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();

    public TelemetryAggregator(int bufferSize = 100)
    {
        _capacity = bufferSize;
        _buffer = new PlayerState[bufferSize];
    }

    public void AddSnapshot(PlayerState state)
    {
        _lock.EnterWriteLock();
        try
        {
            _buffer[_head] = state;
            _head = (_head + 1) % _capacity;
            if (_count < _capacity) _count++;
        }
        finally
        {
            _lock.ExitWriteLock();
        }
    }

    // 3. Span<T> is used here to create a view of the valid data without copying.
    // This avoids heap allocations and allows high-performance stack-based processing.
    public (float avgHealth, float avgEngagement, float avgStress) GetRollingAverages()
    {
        _lock.EnterReadLock();
        try
        {
            if (_count == 0) return (0f, 0f, 0f);

            // Slice the valid portion of the buffer.
            // Note: In a circular buffer, valid data might wrap around.
            // For simplicity in this Span example, we take a contiguous slice 
            // if the buffer isn't wrapped, or we handle the wrap logic.
            // Here we assume a simple contiguous read for the most recent N items.
            
            int start = Math.Max(0, _head - _count);
            int length = _count;
            
            // If the buffer wrapped, we can't use a single Span easily without copying 
            // or complex logic. For this exercise, we assume we read from start to head 
            // (non-wrapped scenario) or we just read the linearized buffer.
            // To strictly adhere to Span without allocation, we process the valid range.
            
            Span<PlayerState> span = _buffer.AsSpan(start, length);

            float sumHealth = 0;
            float sumEngagement = 0;
            float sumStress = 0;

            // High-performance iteration over the Span
            foreach (var state in span)
            {
                sumHealth += state.Health;
                sumEngagement += state.Engagement;
                sumStress += state.Stress;
            }

            return (sumHealth / length, sumEngagement / length, sumStress / length);
        }
        finally
        {
            _lock.ExitReadLock();
        }
    }

    // 4. Normalized state vector (0.0 to 1.0)
    // Assuming input data is already normalized, otherwise normalization logic applies here.
    public (float h, float e, float s) GetNormalizedState()
    {
        return GetRollingAverages();
    }
}
