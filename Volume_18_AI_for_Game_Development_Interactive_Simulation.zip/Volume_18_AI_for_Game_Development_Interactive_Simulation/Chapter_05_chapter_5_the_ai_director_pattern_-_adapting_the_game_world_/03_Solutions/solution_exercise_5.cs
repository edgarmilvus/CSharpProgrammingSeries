
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class AIDirectorVisualizer : EditorWindow
{
    // 1. History storage
    private static Queue<PlayerState> _history = new Queue<PlayerState>();
    private const int MAX_HISTORY = 200;

    // Mock data generator for demonstration
    private static bool _isSimulating = false;
    private static float _simTime = 0f;

    [MenuItem("Tools/AI Director Visualizer")]
    public static void ShowWindow()
    {
        GetWindow<AIDirectorVisualizer>("AI Director Mind");
    }

    void OnEnable()
    {
        // Subscribe to editor update for simulation
        EditorApplication.update += OnEditorUpdate;
    }

    void OnDisable()
    {
        EditorApplication.update -= OnEditorUpdate;
    }

    void OnEditorUpdate()
    {
        if (!_isSimulating) return;

        _simTime += 0.1f;
        if (_simTime > 0.5f) // Add data point every 0.5s
        {
            _simTime = 0;
            // Generate synthetic data (Sine waves for visual appeal)
            float h = Mathf.Clamp01(Mathf.Sin(Time.time) * 0.5f + 0.5f);
            float e = Mathf.Clamp01(Mathf.Cos(Time.time * 1.5f) * 0.5f + 0.5f);
            float s = Random.Range(0f, 1f);

            AddData(new PlayerState(h, e, s, System.DateTime.Now));
        }
    }

    // 2. Data Management
    public static void AddData(PlayerState state)
    {
        _history.Enqueue(state);
        if (_history.Count > MAX_HISTORY) _history.Dequeue();
        // Force repaint to see live updates
        if (EditorWindow.HasOpenInstances<AIDirectorVisualizer>())
            GetWindow<AIDirectorVisualizer>().Repaint();
    }

    // 3. IMGUI Visualization
    void OnGUI()
    {
        GUILayout.BeginVertical();

        // Controls
        GUILayout.BeginHorizontal();
        if (GUILayout.Button(_isSimulating ? "Stop Simulation" : "Start Simulation"))
        {
            _isSimulating = !_isSimulating;
        }
        if (GUILayout.Button("Clear")) _history.Clear();
        GUILayout.EndHorizontal();

        // Draw Graphs
        DrawTelemetryGraph();
        
        // Mock Decision Confidence (Bar Chart)
        DrawDecisionConfidence();

        GUILayout.EndVertical();
    }

    private void DrawTelemetryGraph()
    {
        GUILayout.Label("Telemetry History (Last 60s)", EditorStyles.boldLabel);
        
        Rect rect = GUILayoutUtility.GetRect(100, 100);
        
        // Background
        EditorGUI.DrawRect(rect, Color.black);

        if (_history.Count < 2) return;

        var historyArray = _history.ToArray();

        // Helper to draw a specific metric line
        void DrawLine(System.Func<PlayerState, float> selector, Color color)
        {
            Handles.BeginGUI();
            Handles.color = color;
            Vector3[] points = new Vector3[historyArray.Length];
            for (int i = 0; i < historyArray.Length; i++)
            {
                float x = Mathf.Lerp(rect.x, rect.x + rect.width, (float)i / historyArray.Length);
                float y = Mathf.Lerp(rect.y + rect.height, rect.y, selector(historyArray[i]));
                points[i] = new Vector3(x, y, 0);
            }
            Handles.DrawAAPolyLine(2f, points);
            Handles.EndGUI();
        }

        DrawLine(p => p.Health, Color.green);
        DrawLine(p => p.Engagement, Color.blue);
        DrawLine(p => p.Stress, Color.red);

        // Legend
        GUILayout.BeginHorizontal();
        GUILayout.Label("Health", GUILayout.Width(50)); GUILayout.Box("", GUILayout.BackgroundColor(Color.green), GUILayout.Width(20));
        GUILayout.Label("Engagement", GUILayout.Width(80)); GUILayout.Box("", GUILayout.BackgroundColor(Color.blue), GUILayout.Width(20));
        GUILayout.Label("Stress", GUILayout.Width(50)); GUILayout.Box("", GUILayout.BackgroundColor(Color.red), GUILayout.Width(20));
        GUILayout.EndHorizontal();
    }

    private void DrawDecisionConfidence()
    {
        GUILayout.Space(10);
        GUILayout.Label("Decision Confidence (Mock)", EditorStyles.boldLabel);
        
        // Mock data based on history
        float spawnProb = _history.Count > 0 ? _history.Last().Engagement : 0.2f;
        float pacingProb = _history.Count > 0 ? (1.0f - _history.Last().Health) : 0.2f;

        Rect barRect = GUILayoutUtility.GetRect(100, 20);
        
        // Draw "Spawn Enemy" bar
        Rect spawnBar = new Rect(barRect.x, barRect.y, barRect.width * spawnProb, barRect.height);
        EditorGUI.DrawRect(spawnBar, Color.cyan);
        EditorGUI.LabelField(spawnBar, $"Spawn Enemy: {spawnProb:P0}");

        barRect.y += 25;
        
        // Draw "Adjust Pacing" bar
        Rect pacingBar = new Rect(barRect.x, barRect.y, barRect.width * pacingProb, barRect.height);
        EditorGUI.DrawRect(pacingBar, Color.magenta);
        EditorGUI.LabelField(pacingBar, $"Adjust Pacing: {pacingProb:P0}");
    }
}
