
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System;

// 1. Modified TelemetryAggregator with Flow Score
public class EnhancedTelemetryAggregator : TelemetryAggregator
{
    public float CalculateFlowScore(float health, float engagement)
    {
        // Logic: High engagement is good, but low health penalizes.
        // We use a sigmoid-like curve or weighted subtraction.
        // Formula: (Engagement * Weight) - ((1 - Health) * Penalty)
        
        float engagementWeight = 0.7f;
        float healthPenalty = 0.4f; // Higher penalty for low health
        
        float rawScore = (engagement * engagementWeight) - ((1.0f - health) * healthPenalty);
        
        // Clamp to -1.0 to 1.0 range for easier thresholding
        return Mathf.Clamp(rawScore, -1.0f, 1.0f);
    }
}

// 2. Updated Prompt Builder
public static class FlowPromptBuilder
{
    public static string BuildPrompt(float h, float e, float s, float flowScore)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("You are the AI Director. Analyze player state.");
        sb.AppendLine($"Health: {h:P0} | Engagement: {e:P0} | Stress: {s:P0}");
        sb.AppendLine($"Flow Score: {flowScore:F2}");

        // 3. Context Injection
        if (flowScore > 0.5f)
        {
            sb.AppendLine("[CONTEXT: FLOW_STATE_DETECTED]");
            sb.AppendLine("Player is in a Flow State. Do NOT reduce difficulty.");
            sb.AppendLine("Prioritize 'NarrativeClimax', 'BossEncounter', or 'PowerUp'.");
        }
        else if (h < 0.3f && flowScore < 0.0f)
        {
            sb.AppendLine("[CONTEXT: STRUGGLING]");
            sb.AppendLine("Player is struggling. Prioritize 'HealthPack' or 'DifficultyReduction'.");
        }
        else if (e < 0.1f && h > 0.9f)
        {
            sb.AppendLine("[CONTEXT: AFK_BORED]");
            sb.AppendLine("Player is idle/bored. Trigger 'Distraction' or 'Event'.");
        }

        return sb.ToString();
    }
}

// 4. Updated AIDirector Logic
public class FlowAIDirector : AIDirector
{
    public EnhancedTelemetryAggregator EnhancedTelemetry => (EnhancedTelemetryAggregator)Telemetry;

    private async Task MakeDecisionWithFlow()
    {
        // Get raw data
        var state = Telemetry.GetNormalizedState();
        
        // Calculate Flow Score
        float flowScore = EnhancedTelemetry.CalculateFlowScore(state.h, state.e);

        // Build Prompt with Context
        string prompt = FlowPromptBuilder.BuildPrompt(state.h, state.e, state.s, flowScore);

        // Simulate LLM Call
        string response = await SimulateLLMCall(prompt, flowScore);

        // Dispatch
        DispatchResponse(response);
    }

    // Mock logic to simulate LLM response based on our context injection
    private async Task<string> SimulateLLMCall(string prompt, float flowScore)
    {
        await Task.Delay(200);

        // 5. Simulation Logic
        if (prompt.Contains("[CONTEXT: FLOW_STATE_DETECTED]"))
        {
            // 20% Health, 80% Engagement -> Flow State
            // Should return Boss or PowerUp
            return "{\"FunctionName\":\"SpawnNarrativeEvent\",\"Arguments\":{\"EventType\":\"BossEncounter\"}}";
        }
        
        if (prompt.Contains("[CONTEXT: AFK_BORED]"))
        {
            return "{\"FunctionName\":\"SpawnNarrativeEvent\",\"Arguments\":{\"EventType\":\"AmbientDistraction\"}}";
        }

        return "{\"FunctionName\":\"AdjustPacing\",\"Arguments\":{\"DifficultyMultiplier\":1.0}}";
    }
}
