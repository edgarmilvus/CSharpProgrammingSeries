
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using UnityEngine;

// 1. Base schema record
public record FunctionSchema(string Name, string Description, object Parameters);

// Concrete implementations for specific actions
public record AdjustPacingSchema(float DifficultyMultiplier, string Reason) 
    : FunctionSchema("AdjustPacing", "Modifies the game's difficulty curve.", new { DifficultyMultiplier, Reason });

public record SpawnNarrativeEventSchema(string EventType, Vector3 Location) 
    : FunctionSchema("SpawnNarrativeEvent", "Triggers a story element or visual effect.", new { EventType, Location });

// 2. Wrapper for JSON deserialization
public class ToolCallRequest
{
    public string FunctionName { get; set; }
    public string Arguments { get; set; } // JSON string
}

public class FunctionDispatcher
{
    // 3. Registry of functions (Name -> Delegate)
    private readonly Dictionary<string, Action<JsonElement>> _functionRegistry = new();

    public void RegisterFunction(string name, Action<JsonElement> handler)
    {
        _functionRegistry[name] = handler;
    }

    // 4. Dispatch logic using Pattern Matching
    public void Dispatch(ToolCallRequest request)
    {
        if (!_functionRegistry.TryGetValue(request.FunctionName, out var handler))
        {
            Debug.LogError($"[Director] Unknown function: {request.FunctionName}");
            return;
        }

        try
        {
            // Parse arguments safely
            using JsonDocument doc = JsonDocument.Parse(request.Arguments);
            JsonElement root = doc.RootElement;

            // 5. Execute on Main Thread (Mocking Unity's Dispatcher)
            // In a real Unity project, we would check Thread.CurrentThread.ManagedThreadId 
            // and queue to MainThreadDispatcher if needed. 
            // For this solution, we assume the handler is wrapped or we are on the main thread.
            
            handler(root);
        }
        catch (JsonException ex)
        {
            Debug.LogError($"[Director] Invalid JSON for {request.FunctionName}: {ex.Message}");
        }
        catch (Exception ex)
        {
            Debug.LogError($"[Director] Execution error: {ex.Message}");
        }
    }
}

// Example Usage / Integration
public class DirectorCore
{
    private FunctionDispatcher _dispatcher;

    public DirectorCore()
    {
        _dispatcher = new FunctionDispatcher();
        
        // Registering handlers with validation
        _dispatcher.RegisterFunction("AdjustPacing", (args) => 
        {
            float multiplier = args.GetProperty("DifficultyMultiplier").GetSingle();
            string reason = args.GetProperty("Reason").GetString();

            if (multiplier < 0) throw new ArgumentOutOfRangeException("DifficultyMultiplier cannot be negative");
            
            // Execute Game Logic
            Debug.Log($"[Game] Adjusting Pacing: x{multiplier}. Reason: {reason}");
            // GameWorld.Instance.SetDifficultyMultiplier(multiplier);
        });

        _dispatcher.RegisterFunction("SpawnNarrativeEvent", (args) =>
        {
            string type = args.GetProperty("EventType").GetString();
            // Vector3 parsing would go here
            Debug.Log($"[Game] Spawning Event: {type}");
        });
    }

    public void ProcessLLMResponse(string jsonResponse)
    {
        // Simulate parsing LLM output
        var request = JsonSerializer.Deserialize<ToolCallRequest>(jsonResponse);
        _dispatcher.Dispatch(request);
    }
}
