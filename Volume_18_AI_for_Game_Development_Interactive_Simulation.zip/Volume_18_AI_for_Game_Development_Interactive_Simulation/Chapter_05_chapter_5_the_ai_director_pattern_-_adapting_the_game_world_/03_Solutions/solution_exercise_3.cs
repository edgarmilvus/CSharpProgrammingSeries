
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using System.Threading.Tasks;
using System.Text;

// Mock GameWorld for context
public class GameWorld : MonoBehaviour
{
    public void SetDifficultyMultiplier(float m) => Debug.Log($"Difficulty set to {m}");
    public void SpawnEvent(string type) => Debug.Log($"Spawned: {type}");
}

public class AIDirector : MonoBehaviour
{
    [Header("Configuration")]
    public float DecisionInterval = 5.0f;
    
    [Header("Dependencies")]
    public TelemetryAggregator Telemetry;
    public GameWorld World;

    private float _timer;
    private bool _isProcessing = false;

    void Start()
    {
        // Initialize Telemetry (Singleton or Inspector reference)
        if (Telemetry == null) Telemetry = new TelemetryAggregator();
    }

    void Update()
    {
        // 1. Timer logic
        _timer += Time.deltaTime;
        if (_timer >= DecisionInterval && !_isProcessing)
        {
            _timer = 0;
            _ = MakeDecision(); // Fire and forget async task
        }
    }

    private async Task MakeDecision()
    {
        _isProcessing = true;

        // 2. Collect State
        var state = Telemetry.GetNormalizedState();
        
        // 3. Build Prompt
        string prompt = DirectorPromptBuilder.BuildSystemPrompt(state);

        // 4. Simulate LLM Call (Async to prevent freezing)
        // In a real scenario, this would be an HTTP request to an API
        string llmResponse = await SimulateLLMCall(prompt);

        // 5. Parse and Dispatch
        DispatchResponse(llmResponse);

        _isProcessing = false;
    }

    private async Task<string> SimulateLLMCall(string prompt)
    {
        // Simulate network latency
        await Task.Delay(500); 
        
        // Mock response based on input (simple logic for testing)
        // In reality, this returns a JSON tool call
        if (prompt.Contains("Health: 0.1")) 
            return "{\"FunctionName\":\"AdjustPacing\",\"Arguments\":{\"DifficultyMultiplier\":0.5, \"Reason\":\"Low Health\"}}";
        
        return "{\"FunctionName\":\"SpawnNarrativeEvent\",\"Arguments\":{\"EventType\":\"AmbientSound\", \"Location\":{\"x\":0,\"y\":0,\"z\":0}}}";
    }

    private void DispatchResponse(string json)
    {
        // Re-use the dispatcher from Exercise 2
        var dispatcher = new FunctionDispatcher();
        
        // Register handlers linked to this specific World instance
        dispatcher.RegisterFunction("AdjustPacing", (args) => 
        {
            float m = args.GetProperty("DifficultyMultiplier").GetSingle();
            World.SetDifficultyMultiplier(m);
        });

        dispatcher.RegisterFunction("SpawnNarrativeEvent", (args) =>
        {
            string t = args.GetProperty("EventType").GetString();
            World.SpawnEvent(t);
        });

        var request = System.Text.Json.JsonSerializer.Deserialize<ToolCallRequest>(json);
        dispatcher.Dispatch(request);
    }
}

public static class DirectorPromptBuilder
{
    public static string BuildSystemPrompt((float h, float e, float s) state)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("You are the AI Director of a 3D shooter game.");
        sb.AppendLine("Analyze the player state and choose a function call.");
        sb.AppendLine($"Current State: Health={state.h:F2}, Engagement={state.e:F2}, Stress={state.s:F2}");
        sb.AppendLine("Available functions: AdjustPacing, SpawnNarrativeEvent");
        return sb.ToString();
    }
}
