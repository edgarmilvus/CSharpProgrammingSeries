
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AIDirectorSimulation
{
    // ========================================================================
    // REAL-WORLD CONTEXT: "Dynamic Difficulty Adjustment (DDA) for a Survival Game"
    // ========================================================================
    // Problem: In modern games, static difficulty levels (Easy, Normal, Hard) often fail
    // to adapt to individual player skill. A player might find "Normal" too easy after
    // learning the mechanics, leading to boredom, or too hard after a few mistakes,
    // leading to frustration.
    //
    // Solution: We implement an "AI Director" (inspired by games like Left 4 Dead).
    // This system monitors player telemetry (health, speed, accuracy) in real-time.
    // Using an LLM (simulated here), it analyzes this data and dynamically modifies
    // the game world (enemy spawn rates, resource availability) to maintain a
    // "Flow State" for the player.
    // ========================================================================

    public class Program
    {
        public static async Task Main(string[] args)
        {
            // 1. Initialize the Simulation Environment
            GameWorld world = new GameWorld();
            AIDirector director = new AIDirector();
            Player player = new Player("Hero");
            TelemetryLogger logger = new TelemetryLogger();

            Console.WriteLine("=== Starting AI Director Simulation ===");
            Console.WriteLine("Scenario: Player navigating a zombie-infested warehouse.\n");

            // 2. Simulation Loop (Represents Game Frames)
            // We simulate 10 distinct time steps (e.g., seconds or minutes).
            for (int timeStep = 1; timeStep <= 10; timeStep++)
            {
                Console.WriteLine($"\n--- Time Step {timeStep} ---");

                // A. Player Action (Simulated)
                // In a real game, this comes from input. Here, we simulate varying skill.
                player.PerformAction(timeStep);

                // B. Data Collection
                // The Director observes the player's state.
                PlayerTelemetry telemetry = logger.CollectData(player, world);

                // C. Analysis & Decision (The AI Director Core)
                // The Director uses an LLM (or heuristic logic) to decide on a world adjustment.
                WorldAdjustmentCommand command = await director.AnalyzeAndDecide(telemetry);

                // D. Execution
                // Apply the command to the game world parameters.
                world.ApplyAdjustment(command);

                // E. Feedback
                // Log the state for the instructor/student to observe.
                world.DisplayStatus();
            }

            Console.WriteLine("\n=== Simulation Complete ===");
            Console.WriteLine("Observe how the 'Intensity' fluctuated based on player performance.");
        }
    }

    // ========================================================================
    // DATA STRUCTURES
    // ========================================================================

    /// <summary>
    /// Represents the raw data collected from the player during gameplay.
    /// This is the input to the AI Director.
    /// </summary>
    public struct PlayerTelemetry
    {
        public float HealthPercentage; // 0.0 to 1.0
        public float AggressionLevel;  // 0.0 (Hiding) to 1.0 (Rambo)
        public float SurvivalTime;     // Seconds alive in current encounter
        public int   CurrentWave;      // Progression metric
    }

    /// <summary>
    /// Represents the output command generated by the AI Director.
    /// This is the instruction sent to the Game World engine.
    /// </summary>
    public class WorldAdjustmentCommand
    {
        public string Reasoning { get; set; } // Why the change is happening (Narrative context)
        public float  SpawnRateMultiplier { get; set; } // 0.5 (Reduce) to 2.0 (Increase)
        public float  ResourceDropRate { get; set; }    // 0.5 to 2.0
        public string EventTrigger { get; set; }        // e.g., "Horde", "Quiet", "LootCrate"
    }

    // ========================================================================
    // CORE COMPONENTS
    // ========================================================================

    /// <summary>
    /// The Player entity.
    /// </summary>
    public class Player
    {
        public string Name { get; }
        public float Health { get; private set; } = 1.0f;
        public float Aggression { get; private set; } = 0.5f;

        public Player(string name) => Name = name;

        // Simulates player input. In a real Unity app, this would be Update() reading Input.GetAxis()
        public void PerformAction(int timeStep)
        {
            // Simulate a "struggle": Player starts strong, gets overwhelmed, then recovers.
            if (timeStep < 4)
            {
                Health = 0.9f; // Doing well
                Aggression = 0.8f;
            }
            else if (timeStep < 7)
            {
                Health = 0.4f; // Taking damage
                Aggression = 0.3f; // Playing defensively
            }
            else
            {
                Health = 0.7f; // Recovered
                Aggression = 0.6f;
            }
        }
    }

    /// <summary>
    /// Simulates the Unity Game World parameters.
    /// </summary>
    public class GameWorld
    {
        // These would typically be Unity Scene parameters or ScriptableObject values.
        public float CurrentSpawnRate { get; private set; } = 1.0f;
        public float CurrentLootRate { get; private set; } = 1.0f;
        public string CurrentEvent { get; private set; } = "None";

        public void ApplyAdjustment(WorldAdjustmentCommand cmd)
        {
            // Apply constraints (Clamping) to prevent breaking the game.
            // The Director might suggest a spawn rate of 1000, which would crash the frame rate.
            CurrentSpawnRate = Math.Clamp(cmd.SpawnRateMultiplier, 0.1f, 3.0f);
            CurrentLootRate = Math.Clamp(cmd.ResourceDropRate, 0.1f, 3.0f);
            CurrentEvent = cmd.EventTrigger;
        }

        public void DisplayStatus()
        {
            Console.WriteLine($"[World State] SpawnRate: {CurrentSpawnRate:F2} | LootRate: {CurrentLootRate:F2} | Event: {CurrentEvent}");
        }
    }

    /// <summary>
    /// Collects data from the game loop.
    /// </summary>
    public class TelemetryLogger
    {
        public PlayerTelemetry CollectData(Player player, GameWorld world)
        {
            // In a real app, this aggregates data over a time window.
            return new PlayerTelemetry
            {
                HealthPercentage = player.Health,
                AggressionLevel = player.Aggression,
                SurvivalTime = 10.0f, // Mock value
                CurrentWave = 1       // Mock value
            };
        }
    }

    // ========================================================================
    // THE AI DIRECTOR (PATTERN IMPLEMENTATION)
    // ========================================================================

    public class AIDirector
    {
        // Simulates an LLM Context Window (History)
        private List<string> _decisionHistory = new List<string>();

        /// <summary>
        /// Analyzes telemetry and generates a World Adjustment Command.
        /// In a production environment, this method would make an API call to an LLM (e.g., GPT-4).
        /// For this console app, we use heuristic logic to simulate the LLM's reasoning.
        /// </summary>
        public async Task<WorldAdjustmentCommand> AnalyzeAndDecide(PlayerTelemetry telemetry)
        {
            Console.WriteLine($"[Director] Analyzing Telemetry: Health={telemetry.HealthPercentage:P0}, Aggression={telemetry.AggressionLevel:P0}");

            // 1. Construct the "Prompt" (Context)
            // This is the data we send to the LLM.
            string contextPrompt = $"Player Health: {telemetry.HealthPercentage}, Aggression: {telemetry.AggressionLevel}";

            // 2. Simulate LLM Processing Delay
            // In a real app, we await the network request here.
            await Task.Delay(100); 

            // 3. Heuristic Logic (Simulating LLM Output)
            // We categorize the player state into archetypes to determine the world response.
            WorldAdjustmentCommand cmd = new WorldAdjustmentCommand();

            if (telemetry.HealthPercentage < 0.5f && telemetry.AggressionLevel < 0.4f)
            {
                // STATE: "The Struggler"
                // Player is low health and playing passively.
                // DIRECTOR ACTION: Reduce pressure, provide hope (loot).
                cmd.Reasoning = "Player is struggling. Reducing intensity to prevent frustration.";
                cmd.SpawnRateMultiplier = 0.5f; // Halve the enemies
                cmd.ResourceDropRate = 1.5f;    // Increase loot
                cmd.EventTrigger = "QuietMoment";
            }
            else if (telemetry.HealthPercentage > 0.8f && telemetry.AggressionLevel > 0.7f)
            {
                // STATE: "The Powerhouse"
                // Player is healthy and aggressive (boredom risk).
                // DIRECTOR ACTION: Increase pressure, introduce challenge.
                cmd.Reasoning = "Player is dominating. Spiking intensity to maintain engagement.";
                cmd.SpawnRateMultiplier = 2.0f; // Double the enemies
                cmd.ResourceDropRate = 0.5f;    // Scarcity
                cmd.EventTrigger = "HordeAttack";
            }
            else
            {
                // STATE: "The Flow State"
                // Player is stable. Maintain equilibrium.
                cmd.Reasoning = "Player is in the flow. Maintaining baseline intensity.";
                cmd.SpawnRateMultiplier = 1.0f;
                cmd.ResourceDropRate = 1.0f;
                cmd.EventTrigger = "StandardPatrol";
            }

            // 4. Log Decision for Transparency (Crucial for debugging AI)
            Console.WriteLine($"[Director] Decision: {cmd.Reasoning}");
            _decisionHistory.Add($"Step: {DateTime.Now.Second} - {cmd.EventTrigger}");

            return cmd;
        }
    }
}
