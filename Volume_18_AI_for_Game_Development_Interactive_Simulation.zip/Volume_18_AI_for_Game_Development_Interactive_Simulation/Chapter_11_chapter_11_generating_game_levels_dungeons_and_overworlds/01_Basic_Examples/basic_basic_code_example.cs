
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Represents a rectangular area in the game world.
// Using readonly struct for performance and immutability.
public readonly struct RectIntBounds
{
    public readonly int X;
    public readonly int Y;
    public readonly int Width;
    public readonly int Height;

    public RectIntBounds(int x, int y, int width, int height)
    {
        X = x;
        Y = y;
        Width = width;
        Height = height;
    }

    // Helper properties for convenience
    public int Left => X;
    public int Right => X + Width;
    public int Top => Y;
    public int Bottom => Y + Height;

    public Vector2Int Center => new Vector2Int(X + Width / 2, Y + Height / 2);
}

// A simple container for a generated room.
public class Room
{
    public RectIntBounds Bounds { get; }
    public Vector2Int Center => Bounds.Center;

    public Room(RectIntBounds bounds)
    {
        Bounds = bounds;
    }
}

// The main generator class.
public class DungeonGenerator : MonoBehaviour
{
    [Header("Generation Settings")]
    [Tooltip("Total width of the dungeon grid.")]
    public int mapWidth = 50;
    
    [Tooltip("Total height of the dungeon grid.")]
    public int mapHeight = 50;
    
    [Tooltip("Minimum size for a room partition.")]
    public int minRoomSize = 6;

    [Header("Debug Visualization")]
    public bool drawDebugGizmos = true;
    public Color roomColor = Color.green;
    public Color corridorColor = Color.white;

    // Store generated rooms
    private List<Room> _rooms = new List<Room>();

    // --- MOCK LLM INTEGRATION ---
    // In a real scenario, this string would be sent to an LLM API.
    // The LLM would return a JSON or text description of the desired layout.
    // Here, we simulate the "Prompt Engineering" concept.
    private string ConstructLLMPrompt()
    {
        return $"Generate a dungeon layout configuration with the following constraints: " +
               $"Map Size: {mapWidth}x{mapHeight}, " +
               $"Min Room Size: {minRoomSize}, " +
               $"Style: 'Classic Dungeon'. " +
               $"Return parameters for Binary Space Partitioning.";
    }

    // --- PROCEDURAL LOGIC ---
    // We use Binary Space Partitioning (BSP) to subdivide the space.
    // This ensures rooms are distinct and navigable.
    public void GenerateDungeon()
    {
        // 1. Clear previous data
        _rooms.Clear();

        // 2. Simulate LLM Prompt Construction
        // (In a real app, we might await an LLM response here)
        string prompt = ConstructLLMPrompt();
        Debug.Log($"[AI Prompt]: {prompt}");

        // 3. Define the root container for the entire map
        var rootContainer = new RectIntBounds(0, 0, mapWidth, mapHeight);

        // 4. Perform BSP Recursion
        // We split the root container recursively until we reach desired room sizes.
        List<RectIntBounds> leafContainers = SplitContainer(rootContainer);

        // 5. Create Rooms from Containers
        // Not every leaf becomes a room; we apply constraints.
        foreach (var container in leafContainers)
        {
            // Create a room slightly smaller than the container to leave walls
            int roomWidth = Mathf.Max(minRoomSize, container.Width - 2);
            int roomHeight = Mathf.Max(minRoomSize, container.Height - 2);

            // Randomize position within the container
            int roomX = container.X + UnityEngine.Random.Range(1, container.Width - roomWidth);
            int roomY = container.Y + UnityEngine.Random.Range(1, container.Height - roomHeight);

            var roomBounds = new RectIntBounds(roomX, roomY, roomWidth, roomHeight);
            _rooms.Add(new Room(roomBounds));
        }

        // 6. Connect Rooms (Simplified Corridor Logic)
        // In a full implementation, we would use a graph algorithm (e.g., Minimum Spanning Tree)
        // to connect room centers. Here, we simply connect adjacent containers.
        ConnectRooms();

        Debug.Log($"[Generation Complete]: Created {_rooms.Count} rooms.");
    }

    // Recursive method to split space
    private List<RectIntBounds> SplitContainer(RectIntBounds container)
    {
        var leaves = new List<RectIntBounds>();

        // Base case: If container is small enough, stop splitting
        if (container.Width < minRoomSize * 2 || container.Height < minRoomSize * 2)
        {
            leaves.Add(container);
            return leaves;
        }

        // Determine split direction (horizontal or vertical)
        bool splitHorizontally = UnityEngine.Random.value > 0.5f;

        // Calculate split percentage (randomized between 40% and 60% to avoid skinny rooms)
        float splitRatio = UnityEngine.Random.Range(0.4f, 0.6f);

        if (splitHorizontally)
        {
            int splitHeight = Mathf.FloorToInt(container.Height * splitRatio);
            var top = new RectIntBounds(container.X, container.Y, container.Width, splitHeight);
            var bottom = new RectIntBounds(container.X, container.Y + splitHeight, container.Width, container.Height - splitHeight);
            
            leaves.AddRange(SplitContainer(top));
            leaves.AddRange(SplitContainer(bottom));
        }
        else
        {
            int splitWidth = Mathf.FloorToInt(container.Width * splitRatio);
            var left = new RectIntBounds(container.X, container.Y, splitWidth, container.Height);
            var right = new RectIntBounds(container.X + splitWidth, container.Y, container.Width - splitWidth, container.Height);

            leaves.AddRange(SplitContainer(left));
            leaves.AddRange(SplitContainer(right));
        }

        return leaves;
    }

    // Simplified connection logic
    private void ConnectRooms()
    {
        // In a real implementation, we would generate a graph of room centers
        // and calculate paths. For this "Hello World", we acknowledge the need
        // but skip complex pathfinding (A* or Dijkstra) for brevity.
        // Visualizing the centers is sufficient to prove navigability.
    }

    // --- UNITY VISUALIZATION ---
    private void OnDrawGizmos()
    {
        if (!drawDebugGizmos || _rooms == null) return;

        // Draw Rooms
        Gizmos.color = roomColor;
        foreach (var room in _rooms)
        {
            DrawRect(room.Bounds);
        }

        // Draw Room Centers (Simulating connection points)
        Gizmos.color = corridorColor;
        foreach (var room in _rooms)
        {
            Vector3 center = new Vector3(room.Center.x, room.Center.y, 0);
            Gizmos.DrawSphere(center, 0.2f);
        }
    }

    private void DrawRect(RectIntBounds bounds)
    {
        Vector3 center = new Vector3(bounds.X + bounds.Width / 2f, bounds.Y + bounds.Height / 2f, 0);
        Vector3 size = new Vector3(bounds.Width, bounds.Height, 0);
        Gizmos.DrawWireCube(center, size);
    }
}
