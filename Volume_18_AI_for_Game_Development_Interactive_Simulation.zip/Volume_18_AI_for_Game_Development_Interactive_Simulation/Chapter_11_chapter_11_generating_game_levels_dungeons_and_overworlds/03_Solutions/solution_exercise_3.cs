
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Collections.Generic;
using UnityEngine;

// Mock classes representing the existing WFC system
public class Cell { public bool IsCollapsed; public Vector2Int Pos; }
public class TileType { public bool IsWalkable; }
public class WfcGrid { 
    public Cell[,] Cells; 
    public Vector2Int StartPos; 
    public Vector2Int EndPos; 
    public TileType GetTile(Vector2Int pos) { return new TileType(); /* Mock */ } 
}

public class WaveFunctionCollapseSolver
{
    private WfcGrid _grid;
    private Stack<Snapshot> _history = new Stack<Snapshot>();

    // Snapshot for backtracking
    private class Snapshot
    {
        public Cell Cell;
        public TileType PreviousState; // Or list of possible tiles if using superposition
    }

    // Modified Collapse Method
    public void Collapse()
    {
        // 1. Find cell with lowest entropy (standard WFC step)
        Cell cellToCollapse = GetLowestEntropyCell();
        if (cellToCollapse == null) return; // All collapsed

        // 2. Select tile based on weights (Standard step)
        // We simulate selecting a tile. In a real WFC, we pick from a list of possibilities.
        TileType selectedTile = SelectRandomTile(); 
        
        // Save state for potential backtracking
        var snapshot = new Snapshot { Cell = cellToCollapse, /* Capture previous state */ };
        _history.Push(snapshot);

        // Apply the collapse
        // In a real scenario, we update the cell's possibilities. 
        // Here we assume we set it to a specific type.
        // cellToCollapse.IsCollapsed = true; 
        
        // 3. Propagate constraints (Standard WFC propagation)
        PropagateConstraints(cellToCollapse);

        // 4. CONNECTIVITY CHECK (New Requirement)
        if (!IsPathValid())
        {
            Debug.Log("Connectivity broken! Backtracking...");
            Backtrack();
        }
    }

    private bool IsPathValid()
    {
        // Optimization: Only check if Start or End is collapsed, 
        // or if the recently collapsed cell is adjacent to the current path.
        
        // Use A* or Dijkstra to find a path from Start to End
        // We only traverse "Walkable" tiles (IsWalkable == true)
        return Pathfinder.ExistsPath(_grid, _grid.StartPos, _grid.EndPos);
    }

    private void Backtrack()
    {
        if (_history.Count == 0)
        {
            // Hard Reset required if history is empty (shouldn't happen in valid logic)
            Debug.LogError("No history to backtrack. Hard Reset needed.");
            return;
        }

        var lastSnapshot = _history.Pop();
        
        // Revert the cell to previous state
        // lastSnapshot.Cell.State = lastSnapshot.PreviousState;
        
        // In a real WFC, we would blacklist the failed tile choice for this cell
        // and try another possibility. If no possibilities remain, we backtrack further.
        
        // Recursive call to try again
        Collapse();
    }

    // --- Mock Helpers for Context ---
    private Cell GetLowestEntropyCell() { return null; /* Logic to find cell */ }
    private TileType SelectRandomTile() { return new TileType(); /* Logic */ }
    private void PropagateConstraints(Cell cell) { /* Standard WFC Propagation */ }
}

// Mock Pathfinder
public static class Pathfinder
{
    public static bool ExistsPath(WfcGrid grid, Vector2Int start, Vector2Int end)
    {
        // Simplified A* logic returning true if path exists
        return true; 
    }
}
