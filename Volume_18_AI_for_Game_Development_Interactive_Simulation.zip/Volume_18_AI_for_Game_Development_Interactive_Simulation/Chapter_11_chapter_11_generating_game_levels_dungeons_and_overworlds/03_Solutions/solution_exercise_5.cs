
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using UnityEngine;

// --- Event Architecture ---

public interface IDungeonEvent
{
    void Execute(RoomNode context, RoomContent content);
}

public class SealRoomEvent : IDungeonEvent
{
    public void Execute(RoomNode context, RoomContent content)
    {
        Debug.Log($"[Event] Sealing room {context.ID}");
        content.Interactables.Add("Door Sealed");
        // Logic to disable exits in the actual room view
    }
}

public class SpawnReinforcementEvent : IDungeonEvent
{
    public void Execute(RoomNode context, RoomContent content)
    {
        // Constraint: Only spawn if room isn't a Boss room
        if (context.Type == RoomType.End) return;

        Debug.Log($"[Event] Spawning reinforcements in {context.ID}");
        content.Enemies.Add("Elite Guard");
        content.Enemies.Add("Elite Guard");
    }
}

// --- Trigger Manager ---

public class TriggerManager
{
    // State management to ensure idempotency
    private HashSet<Guid> _triggeredEvents = new HashSet<Guid>();

    // Event Delegates (Advanced Requirement)
    public event Action<RoomNode> OnPlayerEnteredRoom;
    public event Action<RoomNode, Item> OnItemPickedUp;
    public event Action<RoomNode> OnRoomTimeExceeded;

    // Dependencies
    private Dictionary<RoomNode, RoomContent> _roomData;

    public TriggerManager(Dictionary<RoomNode, RoomContent> roomData)
    {
        _roomData = roomData;
        
        // Subscribe to internal events
        OnPlayerEnteredRoom += HandleEnterRoom;
        OnItemPickedUp += HandleItemPickup;
    }

    // --- Trigger Inputs (Called by PlayerController) ---

    public void NotifyPlayerEntered(RoomNode node)
    {
        OnPlayerEnteredRoom?.Invoke(node);
    }

    public void NotifyItemPickedUp(RoomNode node, Item item)
    {
        OnItemPickedUp?.Invoke(node, item);
    }

    public void NotifyTimeElapsed(RoomNode node, float timeSpent)
    {
        if (timeSpent > 10f) // Threshold
        {
            OnRoomTimeExceeded?.Invoke(node);
        }
    }

    // --- Handlers ---

    private void HandleEnterRoom(RoomNode node)
    {
        // Example Logic: If it's a Lock room, seal it immediately
        if (node.Type == RoomType.Lock)
        {
            TriggerEvent(new SealRoomEvent(), node);
        }

        // Example Logic: Time-based trigger (simulated here for simplicity)
        // In a real game, a timer would track time spent in the room.
        // If time > X, trigger event.
    }

    private void HandleItemPickup(RoomNode node, Item item)
    {
        // Example Logic: If player picks up the Key, spawn reinforcements in the next room
        if (item.Rarity == Rarity.Legendary)
        {
            // Find adjacent room (simplified logic)
            foreach (var neighbor in node.ConnectedNodes)
            {
                TriggerEvent(new SpawnReinforcementEvent(), neighbor);
            }
        }
    }

    // --- Core Execution Logic ---

    private void TriggerEvent(IDungeonEvent evt, RoomNode node)
    {
        // Idempotency Check
        // Create a unique key for this event-node pair
        string eventKey = $"{evt.GetType().Name}_{node.ID}";
        int keyHash = eventKey.GetHashCode();

        if (_triggeredEvents.Contains(node.ID)) 
        {
            // Optional: Allow multiple different events, but prevent duplicates of the same event
            // For this implementation, we prevent re-triggering ANY event on a specific node
            // to prevent loops (e.g., SealRoom -> SpawnReinforcement -> SealRoom).
            return; 
        }

        // Execute
        if (_roomData.TryGetValue(node, out var content))
        {
            evt.Execute(node, content);
            _triggeredEvents.Add(node.ID); // Mark as triggered
        }
    }
}
