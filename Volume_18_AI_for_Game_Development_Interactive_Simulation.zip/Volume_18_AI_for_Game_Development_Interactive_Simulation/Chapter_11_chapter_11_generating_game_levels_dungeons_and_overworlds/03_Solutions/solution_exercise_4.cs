
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;
using System.Collections.Concurrent;

public class WorldChunk
{
    public Vector2Int Coord { get; set; }
    public GameObject Instance { get; set; }
    public bool IsLoaded { get; set; }
    // Data would be generated on thread, e.g., TerrainData or DungeonGraph
    public object GeneratedData { get; set; } 
}

public class WorldStreamer : MonoBehaviour
{
    public Transform player;
    public GameObject chunkPrefab;
    public int loadRadius = 3;
    public float chunkSize = 10f;

    private Dictionary<Vector2Int, WorldChunk> _activeChunks = new Dictionary<Vector2Int, WorldChunk>();
    private Queue<WorldChunk> _chunkPool = new Queue<WorldChunk>();
    
    // Thread-safe queue for main thread execution
    private ConcurrentQueue<System.Action> _mainThreadActions = new ConcurrentQueue<System.Action>();

    void Update()
    {
        // 1. Main thread execution of generated chunks
        while (_mainThreadActions.TryDequeue(out var action))
        {
            action.Invoke();
        }

        // 2. Update Stream based on player position
        UpdateStream(player.position);
    }

    public void UpdateStream(Vector3 playerPos)
    {
        // Calculate current chunk coordinate
        int currentX = Mathf.FloorToInt(playerPos.x / chunkSize);
        int currentZ = Mathf.FloorToInt(playerPos.z / chunkSize);
        Vector2Int playerChunkCoord = new Vector2Int(currentX, currentZ);

        // Identify chunks to load/unload
        var chunksToLoad = new List<Vector2Int>();
        var chunksToKeep = new HashSet<Vector2Int>();

        for (int x = -loadRadius; x <= loadRadius; x++)
        {
            for (int z = -loadRadius; z <= loadRadius; z++)
            {
                Vector2Int coord = new Vector2Int(currentX + x, currentZ + z);
                chunksToKeep.Add(coord);

                if (!_activeChunks.ContainsKey(coord))
                {
                    chunksToLoad.Add(coord);
                }
            }
        }

        // Unload chunks outside radius
        var chunksToRemove = new List<Vector2Int>(_activeChunks.Keys);
        foreach (var coord in chunksToRemove)
        {
            if (!chunksToKeep.Contains(coord))
            {
                UnloadChunk(coord);
            }
        }

        // Load new chunks (Async)
        foreach (var coord in chunksToLoad)
        {
            LoadChunkAsync(coord);
        }
    }

    private async void LoadChunkAsync(Vector2Int coord)
    {
        // 1. Data Generation (CPU Intensive - Run on Worker Thread)
        // We simulate generating data (e.g., noise or graph) here
        var generatedData = await Task.Run(() => GenerateChunkData(coord));

        // 2. Unity Instantiation (Must be on Main Thread)
        _mainThreadActions.Enqueue(() =>
        {
            InstantiateChunk(coord, generatedData);
        });
    }

    private object GenerateChunkData(Vector2Int coord)
    {
        // Simulate heavy work (e.g., Perlin Noise or Dungeon Graph Gen)
        System.Threading.Thread.Sleep(50); 
        return new { Seed = coord.x * 1000 + coord.y }; // Mock data
    }

    private void InstantiateChunk(Vector2Int coord, object data)
    {
        WorldChunk chunk;
        if (_chunkPool.Count > 0)
        {
            chunk = _chunkPool.Dequeue();
            chunk.Instance.SetActive(true);
        }
        else
        {
            chunk = new WorldChunk();
            chunk.Instance = Instantiate(chunkPrefab);
        }

        chunk.Coord = coord;
        chunk.GeneratedData = data;
        chunk.IsLoaded = true;
        
        // Position the chunk in world space
        chunk.Instance.transform.position = new Vector3(coord.x * chunkSize, 0, coord.y * chunkSize);
        
        _activeChunks[coord] = chunk;
    }

    private void UnloadChunk(Vector2Int coord)
    {
        if (_activeChunks.TryGetValue(coord, out var chunk))
        {
            chunk.Instance.SetActive(false);
            _chunkPool.Enqueue(chunk);
            _activeChunks.Remove(coord);
        }
    }
}
