
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

// --- Data Structures ---

public enum Rarity { Common, Rare, Legendary }

public class Item
{
    public string Name { get; set; }
    public Rarity Rarity { get; set; }
}

public class RoomContent
{
    public List<string> Enemies { get; } = new List<string>();
    public List<string> Interactables { get; } = new List<string>();
    public List<Item> Loot { get; } = new List<Item>();
}

// --- Population Logic ---

public class RoomPopulator
{
    private System.Random _rng = new System.Random();

    public Dictionary<RoomNode, RoomContent> PopulateEntireGraph(DungeonGraph graph)
    {
        var result = new Dictionary<RoomNode, RoomContent>();

        foreach (var node in graph.AllNodes)
        {
            var content = new RoomContent();
            PopulateRoom(node, content);
            result[node] = content;
        }

        return result;
    }

    public void PopulateRoom(RoomNode node, RoomContent content)
    {
        // 1. Key/Lock Logic
        if (node.Type == RoomType.Key)
        {
            content.Loot.Add(new Item { Name = "Dungeon Key", Rarity = Rarity.Legendary });
        }
        else if (node.Type == RoomType.Lock)
        {
            content.Interactables.Add("Magic Lock");
        }

        // 2. Density Limits & Boss Logic
        int enemyCap = 5; // Standard cap
        int enemyCount = 0;

        if (node.Type == RoomType.Standard)
        {
            // Random density up to cap
            enemyCount = _rng.Next(0, enemyCap + 1);
        }
        else if (node.Type == RoomType.End)
        {
            // Boss room: exactly 1 boss
            content.Enemies.Add("Boss Dragon");
            enemyCount = 1; // Logic handled
        }

        // 3. Connectivity Logic (Chokepoint reduction)
        // A chokepoint is defined here as a node with > 1 incoming connection.
        // Note: In our DAG generator, incoming connections aren't tracked explicitly, 
        // so we simulate this check by analyzing the graph structure or passing it in.
        // For this solution, we assume a helper method `CountIncoming` exists or we pass a pre-calculated count.
        // To keep it self-contained, let's assume we check the graph structure externally or add a property.
        // Here, we simulate the check:
        bool isChokepoint = IsChokepoint(node); // Hypothetical method checking incoming edges
        
        if (isChokepoint && node.Type == RoomType.Standard)
        {
            enemyCount = (int)(enemyCount * 0.5f); // Reduce by 50%
        }

        // Populate Enemies
        for (int i = 0; i < enemyCount; i++)
        {
            content.Enemies.Add(GetRandomEnemy(node.Type));
        }

        // Populate Generic Loot (if not Key room)
        if (node.Type != RoomType.Key && _rng.NextDouble() > 0.5)
        {
            content.Loot.Add(new Item { Name = "Gold Pouch", Rarity = Rarity.Common });
        }
    }

    // Simulated LLM Integration
    public string GenerateRoomDescription(RoomNode node, RoomContent content)
    {
        // This simulates filling a prompt template dynamically
        return $"{node.Type} room located at {node.Position}. " +
               $"Contains {content.Enemies.Count} enemies and {content.Loot.Count} items. " +
               $"Interactables: {string.Join(", ", content.Interactables)}.";
    }

    // Helper for simulation
    private bool IsChokepoint(RoomNode node)
    {
        // In a real implementation, we would traverse the graph backwards.
        // For this exercise, we simulate a 20% chance of being a chokepoint
        // or check if the node type implies complexity.
        return _rng.Next(0, 100) < 20; 
    }

    private string GetRandomEnemy(RoomType type)
    {
        string[] enemies = { "Goblin", "Skeleton", "Orc", "Slime" };
        return enemies[_rng.Next(enemies.Length)];
    }
}
