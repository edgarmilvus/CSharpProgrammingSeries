
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Enum for Room Types
public enum RoomType { Start, End, Standard, Key, Lock }

// Data structure for a Room Node
public class RoomNode
{
    public Guid ID { get; } = Guid.NewGuid();
    public RoomType Type { get; set; }
    public Vector2Int Position { get; set; }
    public List<RoomNode> ConnectedNodes { get; } = new List<RoomNode>();
    
    // For topological sort / cycle detection
    public int VisitedState { get; set; } = 0; // 0: Unvisited, 1: Visiting, 2: Visited
}

public class DungeonGraph
{
    public RoomNode StartNode { get; private set; }
    public RoomNode EndNode { get; private set; }
    public List<RoomNode> AllNodes { get; } = new List<RoomNode>();

    public DungeonGraph(RoomNode start, RoomNode end)
    {
        StartNode = start;
        EndNode = end;
        AllNodes.Add(start);
        AllNodes.Add(end);
    }
}

public class DungeonGraphGenerator
{
    private System.Random _rng = new System.Random();

    public DungeonGraph GenerateGraph(int depth, int branchingFactor)
    {
        // 1. Create Start and End Nodes
        var startNode = new RoomNode { Type = RoomType.Start, Position = Vector2Int.zero };
        var endNode = new RoomNode { Type = RoomType.End, Position = new Vector2Int(depth, 0) };
        
        var graph = new DungeonGraph(startNode, endNode);
        
        // Dictionary to hold nodes per layer: LayerIndex -> List<RoomNode>
        var layers = new Dictionary<int, List<RoomNode>>();
        layers[0] = new List<RoomNode> { startNode };

        // 2. Generate Intermediate Layers
        for (int layer = 1; layer < depth; layer++)
        {
            layers[layer] = new List<RoomNode>();
            var prevLayerNodes = layers[layer - 1];

            foreach (var parent in prevLayerNodes)
            {
                // Determine branching count (1 to branchingFactor)
                int childCount = _rng.Next(1, branchingFactor + 1);

                for (int i = 0; i < childCount; i++)
                {
                    // Create Node
                    var child = new RoomNode
                    {
                        Type = RoomType.Standard,
                        // Calculate Position: X is layer, Y offsets to prevent overlap
                        // Simple heuristic: offset based on index and parent's Y
                        Position = new Vector2Int(layer, parent.Position.y + (i * 2) - 1)
                    };

                    // Connect Parent -> Child (Directed)
                    parent.ConnectedNodes.Add(child);
                    layers[layer].Add(child);
                    graph.AllNodes.Add(child);
                }
            }
        }

        // 3. Connect Final Layer to End Node
        // Ensure every leaf in the last intermediate layer connects to End
        var lastLayer = layers[depth - 1];
        if (lastLayer != null)
        {
            foreach (var node in lastLayer)
            {
                node.ConnectedNodes.Add(endNode);
            }
        }
        else
        {
            // Edge case: depth 1 (Start -> End directly)
            startNode.ConnectedNodes.Add(endNode);
        }

        return graph;
    }

    public bool IsGraphValid(DungeonGraph graph)
    {
        // Reset visited states
        foreach (var node in graph.AllNodes) node.VisitedState = 0;

        // 1. Check for Cycles using DFS (detect back edges)
        foreach (var node in graph.AllNodes)
        {
            if (node.VisitedState == 0)
            {
                if (HasCycleDFS(node)) return false;
            }
        }

        // 2. Check Connectivity (All nodes reachable from Start)
        // Reset for connectivity check
        foreach (var node in graph.AllNodes) node.VisitedState = 0;
        ReachabilityDFS(graph.StartNode);

        // If any node (except maybe unreachable isolated ones if we allowed them, but we don't)
        // is unvisited, the graph is disconnected.
        return graph.AllNodes.All(n => n.VisitedState == 1);
    }

    private bool HasCycleDFS(RoomNode node)
    {
        node.VisitedState = 1; // Visiting
        foreach (var neighbor in node.ConnectedNodes)
        {
            if (neighbor.VisitedState == 1) return true; // Back edge found
            if (neighbor.VisitedState == 0 && HasCycleDFS(neighbor)) return true;
        }
        node.VisitedState = 2; // Visited
        return false;
    }

    private void ReachabilityDFS(RoomNode node)
    {
        node.VisitedState = 1;
        foreach (var neighbor in node.ConnectedNodes)
        {
            if (neighbor.VisitedState == 0) ReachabilityDFS(neighbor);
        }
    }
}
