
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

namespace DungeonGeneratorApp
{
    // Represents a single cell in our dungeon grid.
    // We use a simple class to hold state for each tile.
    public class DungeonCell
    {
        public int X { get; set; }
        public int Y { get; set; }
        public bool IsWalkable { get; set; }
        public bool IsCorridor { get; set; }
        public bool IsRoom { get; set; }
        public bool IsDoor { get; set; }

        public DungeonCell(int x, int y)
        {
            X = x;
            Y = y;
            IsWalkable = false; // Default to walls
            IsCorridor = false;
            IsRoom = false;
            IsDoor = false;
        }
    }

    // Configuration for the dungeon generation.
    // In a real Unity game, this would be a ScriptableObject or Inspector fields.
    public class DungeonConfig
    {
        public int Width { get; set; } = 40;
        public int Height { get; set; } = 40;
        public int MaxRooms { get; set; } = 10;
        public int MinRoomSize { get; set; } = 4;
        public int MaxRoomSize { get; set; } = 8;
    }

    public class DungeonGenerator
    {
        private DungeonConfig _config;
        private DungeonCell[,] _grid;
        private Random _random;
        private List<Room> _rooms;

        // Internal class to help with room definitions
        private class Room
        {
            public int X { get; set; }
            public int Y { get; set; }
            public int Width { get; set; }
            public int Height { get; set; }

            public Room(int x, int y, int w, int h)
            {
                X = x;
                Y = y;
                Width = w;
                Height = h;
            }

            // Check if this room intersects with another room
            public bool Intersects(Room other)
            {
                return X <= other.X + other.Width &&
                       X + Width >= other.X &&
                       Y <= other.Y + other.Height &&
                       Y + Height >= other.Y;
            }
        }

        public DungeonGenerator(DungeonConfig config)
        {
            _config = config;
            _grid = new DungeonCell[config.Width, config.Height];
            _random = new Random();
            _rooms = new List<Room>();

            // Initialize grid with walls
            for (int x = 0; x < config.Width; x++)
            {
                for (int y = 0; y < config.Height; y++)
                {
                    _grid[x, y] = new DungeonCell(x, y);
                }
            }
        }

        public DungeonCell[,] Generate()
        {
            CreateRooms();
            CreateCorridors();
            PlaceDoors();
            return _grid;
        }

        // Step 1: Carve out non-overlapping rooms
        private void CreateRooms()
        {
            for (int i = 0; i < _config.MaxRooms; i++)
            {
                int w = _random.Next(_config.MinRoomSize, _config.MaxRoomSize);
                int h = _random.Next(_config.MinRoomSize, _config.MaxRoomSize);
                int x = _random.Next(1, _config.Width - w - 1);
                int y = _random.Next(1, _config.Height - h - 1);

                Room newRoom = new Room(x, y, w, h);
                bool failed = false;

                // Check for overlaps with existing rooms
                foreach (var room in _rooms)
                {
                    if (newRoom.Intersects(room))
                    {
                        failed = true;
                        break;
                    }
                }

                if (!failed)
                {
                    ApplyRoomToGrid(newRoom);
                    _rooms.Add(newRoom);
                }
            }
        }

        private void ApplyRoomToGrid(Room room)
        {
            for (int x = room.X; x < room.X + room.Width; x++)
            {
                for (int y = room.Y; y < room.Y + room.Height; y++)
                {
                    _grid[x, y].IsWalkable = true;
                    _grid[x, y].IsRoom = true;
                }
            }
        }

        // Step 2: Connect rooms with corridors (L-shaped paths)
        private void CreateCorridors()
        {
            for (int i = 1; i < _rooms.Count; i++)
            {
                Room previous = _rooms[i - 1];
                Room current = _rooms[i];

                // Center points
                int prevCenterX = previous.X + (previous.Width / 2);
                int prevCenterY = previous.Y + (previous.Height / 2);
                int currCenterX = current.X + (current.Width / 2);
                int currCenterY = current.Y + (current.Height / 2);

                // 50% chance to go horizontal then vertical, or vertical then horizontal
                if (_random.Next(0, 2) == 0)
                {
                    CreateHorizontalCorridor(prevCenterX, currCenterX, prevCenterY);
                    CreateVerticalCorridor(prevCenterY, currCenterY, currCenterX);
                }
                else
                {
                    CreateVerticalCorridor(prevCenterY, currCenterY, prevCenterX);
                    CreateHorizontalCorridor(prevCenterX, currCenterX, currCenterY);
                }
            }
        }

        private void CreateHorizontalCorridor(int x1, int x2, int y)
        {
            int minX = Math.Min(x1, x2);
            int maxX = Math.Max(x1, x2);
            for (int x = minX; x <= maxX; x++)
            {
                CarveCell(x, y);
            }
        }

        private void CreateVerticalCorridor(int y1, int y2, int x)
        {
            int minY = Math.Min(y1, y2);
            int maxY = Math.Max(y1, y2);
            for (int y = minY; y <= maxY; y++)
            {
                CarveCell(x, y);
            }
        }

        private void CarveCell(int x, int y)
        {
            // Bounds check
            if (x >= 0 && x < _config.Width && y >= 0 && y < _config.Height)
            {
                _grid[x, y].IsWalkable = true;
                _grid[x, y].IsCorridor = true;
            }
        }

        // Step 3: Place doors at the junction of rooms and corridors
        private void PlaceDoors()
        {
            foreach (var cell in _grid)
            {
                if (cell.IsCorridor)
                {
                    // Check neighbors to see if we are adjacent to a room
                    bool adjacentToRoom = CheckNeighborsForRoom(cell.X, cell.Y);
                    if (adjacentToRoom)
                    {
                        cell.IsDoor = true;
                        cell.IsCorridor = false; // Doors are distinct from raw corridors
                    }
                }
            }
        }

        private bool CheckNeighborsForRoom(int x, int y)
        {
            // Check 4 cardinal directions
            int[] dx = { 0, 0, 1, -1 };
            int[] dy = { 1, -1, 0, 0 };

            for (int i = 0; i < 4; i++)
            {
                int nx = x + dx[i];
                int ny = y + dy[i];

                if (nx >= 0 && nx < _config.Width && ny >= 0 && ny < _config.Height)
                {
                    if (_grid[nx, ny].IsRoom)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Dungeon Generation Console Application ---");
            Console.WriteLine("Generating a layout using procedural logic...\n");

            // 1. Setup Configuration
            DungeonConfig config = new DungeonConfig
            {
                Width = 50,
                Height = 20,
                MaxRooms = 8,
                MinRoomSize = 4,
                MaxRoomSize = 10
            };

            // 2. Initialize Generator
            DungeonGenerator generator = new DungeonGenerator(config);

            // 3. Generate Data
            DungeonCell[,] dungeonMap = generator.Generate();

            // 4. Render to Console
            RenderDungeon(dungeonMap, config.Width, config.Height);

            Console.WriteLine("\nGeneration Complete. Press any key to exit.");
            Console.ReadKey();
        }

        static void RenderDungeon(DungeonCell[,] map, int width, int height)
        {
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    DungeonCell cell = map[x, y];
                    if (cell.IsDoor) Console.Write("+"); // Door
                    else if (cell.IsRoom) Console.Write("."); // Room floor
                    else if (cell.IsCorridor) Console.Write("#"); // Corridor
                    else Console.Write(" "); // Wall
                }
                Console.WriteLine();
            }
        }
    }
}
