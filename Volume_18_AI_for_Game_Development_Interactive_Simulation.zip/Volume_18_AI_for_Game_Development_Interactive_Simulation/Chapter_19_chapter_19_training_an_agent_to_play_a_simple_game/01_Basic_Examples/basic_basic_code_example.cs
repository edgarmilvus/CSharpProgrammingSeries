
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

// We inherit from the Agent class provided by Unity's ML-Agents package.
// This class handles the lifecycle of the agent (training vs. inference).
public class RollerAgent : Agent
{
    [Tooltip("The target the agent must reach")]
    public Transform target;

    [Tooltip("The Rigidbody component attached to this agent")]
    public Rigidbody agentRb;

    // Configuration for movement speed. 
    // We use a public field so we can tune it in the Unity Inspector.
    [SerializeField] private float moveSpeed = 10f;

    // Called once when the agent is first initialized.
    // This is where we cache references and set up initial physics states.
    public override void Initialize()
    {
        // If the Rigidbody reference isn't assigned in the Inspector, try to get it.
        if (agentRb == null)
        {
            agentRb = GetComponent<Rigidbody>();
        }
        
        // We set the gravity to -9.81 (standard Earth gravity) but ensure the agent 
        // doesn't tip over by freezing rotation on the X and Z axes in the physics settings.
        // (Ideally done in Inspector, but we enforce it here for robustness).
        agentRb.freezeRotation = true;
    }

    // Called at the start of every training episode (or game reset).
    // This resets the environment to a clean slate.
    public override void OnEpisodeBegin()
    {
        // Reset Agent Position
        // We place the agent back at a random or specific starting point.
        // In this simple example, we hardcode the start, but randomization helps training.
        transform.localPosition = new Vector3(0f, 0.5f, 0f);
        
        // Reset Velocity (Crucial: otherwise momentum carries over)
        agentRb.velocity = Vector3.zero;
        agentRb.angularVelocity = Vector3.zero;

        // Reset Target Position
        // We place the target randomly within a 4x4 unit square.
        // This prevents the agent from memorizing a specific path and forces generalization.
        float randomX = Random.Range(-4f, 4f);
        float randomZ = Random.Range(-4f, 4f);
        target.localPosition = new Vector3(randomX, 0.5f, randomZ);
    }

    // Called every physics step (default 50 times per second).
    // This is where we define what the agent "sees" (Observations).
    public override void CollectObservations(VectorSensor sensor)
    {
        // We use RayPerceptionSensorComponent3D (attached to the GameObject) to scan the environment.
        // However, we can also manually feed vector data. 
        // For "Hello World", we provide the relative position of the target.
        
        // 1. Target Position (3 floats: x, y, z)
        sensor.AddObservation(target.localPosition - transform.localPosition);

        // 2. Agent Velocity (3 floats: x, y, z) - helps smooth movement
        sensor.AddObservation(agentRb.velocity.x);
        sensor.AddObservation(agentRb.velocity.z);

        // Total Observations: 5 floats. 
        // Note: RayPerception adds its own observations automatically if the component is present.
    }

    // Called when the agent receives an action from the neural network (or player input).
    // 'actionBuffers' contains the signals sent by the brain.
    public override void OnActionReceived(ActionBuffers actionBuffers)
    {
        // We use Continuous Actions (ActionType = Continuous in Behavior Parameters).
        // Index 0 = X-axis force, Index 1 = Z-axis force.
        float moveX = actionBuffers.ContinuousActions[0];
        float moveZ = actionBuffers.ContinuousActions[1];

        // Create a movement vector.
        Vector3 movement = new Vector3(moveX, 0f, moveZ);

        // Apply force to the Rigidbody.
        // We multiply by moveSpeed to control the magnitude.
        agentRb.AddForce(movement * moveSpeed, ForceMode.VelocityChange);

        // REWARD SYSTEM
        // 1. Small penalty for existing (encourages efficiency).
        // Negative rewards push the agent to finish faster.
        AddReward(-1f / MaxStep);

        // Check if we hit the target (Collision detection)
        // We will handle the actual collision in OnTriggerEnter, but we could check distance here too.
    }

    // Manual control for testing (Heuristics mode).
    // This allows us to control the agent with keyboard to verify logic before training.
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        // Create a copy of the continuous actions array.
        var continuousActions = actionsOut.ContinuousActions;

        // Map keyboard inputs to float values (-1 to 1).
        continuousActions[0] = Input.GetAxis("Horizontal"); // A/D or Left/Right
        continuousActions[1] = Input.GetAxis("Vertical");   // W/S or Up/Down
    }

    // Collision Detection
    // We use Unity's physics trigger system to detect when the agent touches the target.
    private void OnTriggerEnter(Collider other)
    {
        // Check if the object we collided with is the Target.
        if (other.TryGetComponent(out TargetLogic targetComp))
        {
            // Positive Reward: Reaching the target is the goal.
            // A large positive number outweighs the step penalty.
            AddReward(10.0f);

            // End the episode immediately.
            // The OnEpisodeBegin() method will be called next frame to reset.
            EndEpisode();
        }
    }
    
    // Optional: Visual debug to see observations in the Scene view
    private void OnDrawGizmos()
    {
        if (Application.isPlaying)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawLine(transform.position, target.position);
        }
    }
}

// A tiny helper script to attach to the Target GameObject.
// This simply identifies the target for the agent's collision logic.
using UnityEngine;

public class TargetLogic : MonoBehaviour
{
    // No logic needed here, just a tag identifier.
    // We could use tags, but Components are more robust in C#.
}
