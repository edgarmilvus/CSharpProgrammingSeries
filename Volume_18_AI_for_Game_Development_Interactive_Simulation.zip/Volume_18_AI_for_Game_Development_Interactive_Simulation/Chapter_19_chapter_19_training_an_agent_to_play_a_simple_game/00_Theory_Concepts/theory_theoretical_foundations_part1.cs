
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

using UnityEngine;

// Conceptual interface representing a decision maker.
// This mirrors the flexibility we discussed when swapping LLM backends.
public interface IBrain
{
    // Takes a collection of observations (State S) and returns an Action.
    // In ML-Agents, this is handled by the 'Heuristic' method or the loaded ONNX model.
    void RequestDecision(Agent agent, ActionBuffers actions);
}

// The Agent class acts as the bridge between the Game World and the Brain.
public abstract class Agent : MonoBehaviour
{
    // The 'CollectObservations' method populates the vector sensor.
    // This is where we define what the Agent "sees".
    protected abstract void CollectObservations(VectorSensor sensor);
    
    // The 'OnActionReceived' method executes the decision.
    protected abstract void OnActionReceived(ActionBuffers actions);
}
