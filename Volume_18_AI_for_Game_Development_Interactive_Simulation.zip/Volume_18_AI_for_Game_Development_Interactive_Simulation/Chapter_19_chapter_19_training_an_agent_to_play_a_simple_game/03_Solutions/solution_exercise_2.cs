
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Policies;

public class CooperativeAgent : Agent
{
    [Header("Agent Specifics")]
    public int agentID; // 0 or 1
    public Transform box;
    public Transform targetZone;
    public CooperativeAgent otherAgent;
    public Rigidbody2D boxRb;
    public float moveSpeed = 10f;
    public float pushForce = 5f;

    // Physics check
    public float boxProximityRadius = 1.5f;
    public LayerMask boxLayer;

    public override void Initialize()
    {
        if (box != null) boxRb = box.GetComponent<Rigidbody2D>();
    }

    public override void OnEpisodeBegin()
    {
        // Reset Agent Positions (Opposite sides of the box)
        transform.localPosition = agentID == 0 ? new Vector3(-2, 0, 0) : new Vector3(2, 0, 0);
        transform.localRotation = Quaternion.identity;
        
        // Reset Box
        box.localPosition = Vector3.zero;
        boxRb.velocity = Vector2.zero;
        boxRb.angularVelocity = 0f;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Own Position (Normalized relative to play area, e.g., 10x10)
        sensor.AddObservation(transform.localPosition / 10f);

        // 2. Box Position & Velocity
        sensor.AddObservation(box.localPosition / 10f);
        sensor.AddObservation(boxRb.velocity / 10f);

        // 3. Target Zone Position
        sensor.AddObservation(targetZone.localPosition / 10f);

        // 4. Relative Position of Other Agent
        Vector3 relPos = otherAgent.transform.position - transform.position;
        sensor.AddObservation(relPos.normalized);
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Continuous Movement (Branch 0)
        float moveX = actions.ContinuousActions[0];
        float moveY = actions.ContinuousActions[1];
        Vector2 moveVector = new Vector2(moveX, moveY).normalized * moveSpeed;
        
        // Apply movement
        transform.position += (Vector3)moveVector * Time.fixedDeltaTime;

        // Local Penalty
        AddReward(-0.01f);

        // Coordination Logic
        bool isTouchingBox = Physics2D.OverlapCircle(transform.position, boxProximityRadius, boxLayer);
        bool otherIsTouchingBox = Physics2D.OverlapCircle(otherAgent.transform.position, boxProximityRadius, boxLayer);
        bool boxIsMoving = boxRb.velocity.magnitude > 0.1f;

        // Coordination Reward: Both pushing and box moves
        if (isTouchingBox && otherIsTouchingBox && boxIsMoving)
        {
            AddReward(0.05f);
            
            // Apply push force if we are touching the box
            // We push towards the target
            Vector2 pushDir = (targetZone.position - transform.position).normalized;
            boxRb.AddForce(pushDir * pushForce, ForceMode2D.Force);
        }
    }

    // Manual Control for Debugging
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var continuousActions = actionsOut.ContinuousActions;
        
        // Agent 0: WASD, Agent 1: Arrows
        Vector2 input = Vector2.zero;
        
        if (agentID == 0)
        {
            if (Input.GetKey(KeyCode.W)) input.y = 1;
            if (Input.GetKey(KeyCode.S)) input.y = -1;
            if (Input.GetKey(KeyCode.A)) input.x = -1;
            if (Input.GetKey(KeyCode.D)) input.x = 1;
        }
        else
        {
            if (Input.GetKey(KeyCode.UpArrow)) input.y = 1;
            if (Input.GetKey(KeyCode.DownArrow)) input.y = -1;
            if (Input.GetKey(KeyCode.LeftArrow)) input.x = -1;
            if (Input.GetKey(KeyCode.RightArrow)) input.x = 1;
        }

        continuousActions[0] = input.x;
        continuousActions[1] = input.y;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Target"))
        {
            // Global Reward is handled by the Academy or Group Manager, 
            // but we can add local reward here for visualization.
            AddReward(1.0f);
        }
    }
}

// Attach this to the Box
public class PushableBox : MonoBehaviour
{
    public Rigidbody2D rb;
    public float highFriction = 10f;
    public float lowFriction = 0.1f;
    public float pushThreshold = 2; // Min force to move

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.drag = highFriction;
    }

    void FixedUpdate()
    {
        // Logic: Only move if significant force is applied (simulating heavy object)
        // In this implementation, the agents apply force directly, but we can modulate friction
        // to simulate the "requires both" mechanic visually.
        
        // If velocity is very low, increase friction to stop sliding
        if (rb.velocity.magnitude < 0.1f) rb.drag = highFriction;
        else rb.drag = lowFriction;
    }
}

// Saboteur Agent (Extension)
public class SaboteurAgent : CooperativeAgent
{
    public override void OnActionReceived(ActionBuffers actions)
    {
        // Invert logic: Push AWAY from target
        float moveX = actions.ContinuousActions[0];
        float moveY = actions.ContinuousActions[1];
        Vector2 moveVector = new Vector2(moveX, moveY).normalized * moveSpeed;
        transform.position += (Vector3)moveVector * Time.fixedDeltaTime;

        bool isTouchingBox = Physics2D.OverlapCircle(transform.position, boxProximityRadius, boxLayer);
        
        if (isTouchingBox)
        {
            // Push Away
            Vector2 pushDir = (transform.position - targetZone.position).normalized;
            boxRb.AddForce(pushDir * pushForce, ForceMode2D.Force);
            
            // Cooperative agents get penalty if box moves away
            // (This would require referencing the cooperative agents to apply the penalty)
        }
    }
}
