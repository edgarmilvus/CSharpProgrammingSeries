
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using System.Collections.Generic;

public class PongAgent : Agent
{
    [Header("Pong Specifics")]
    public bool isLeftPaddle;
    public Transform ball;
    public Rigidbody2D ballRb;
    public float moveSpeed = 10f;
    public float paddleHeight = 2f;

    // Power-up references
    public static bool speedBoostActive = false;
    public static float boostTimer = 0f;

    public override void OnEpisodeBegin()
    {
        // Reset Paddle Position
        transform.localPosition = isLeftPaddle ? new Vector3(-9, 0, 0) : new Vector3(9, 0, 0);
        
        // Reset Ball (Randomize direction slightly)
        ball.localPosition = Vector3.zero;
        float dir = isLeftPaddle ? 1 : -1; // Serve towards the opponent
        ballRb.velocity = new Vector2(dir, Random.Range(-0.5f, 0.5f)).normalized * 5f;
        
        speedBoostActive = false;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Paddle Position
        sensor.AddObservation(transform.localPosition.y / 6f); // Normalized to play area

        // 2. Ball Position
        sensor.AddObservation(ball.localPosition.x / 12f);
        sensor.AddObservation(ball.localPosition.y / 6f);

        // 3. Ball Velocity
        sensor.AddObservation(ballRb.velocity.x / 10f);
        sensor.AddObservation(ballRb.velocity.y / 10f);

        // 4. Power-up Status (if active globally)
        sensor.AddObservation(speedBoostActive ? 1f : 0f);
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Continuous Action: Move Up/Down
        float moveY = actions.ContinuousActions[0];
        Vector3 newPos = transform.localPosition + Vector3.up * moveY * moveSpeed * Time.fixedDeltaTime;

        // Clamp to screen
        newPos.y = Mathf.Clamp(newPos.y, -5.5f, 5.5f);
        transform.localPosition = newPos;

        // Time Penalty (Encourage fast play)
        AddReward(-0.001f);

        // Rally Reward
        // We can check if the ball hit this paddle recently (via collision logic)
    }

    // Collision Logic for Scoring and Rallies
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ball"))
        {
            // Add small reward for hitting the ball (Rally reward)
            AddReward(0.01f);
            
            // Add spin/angle based on where it hit the paddle
            float hitPos = (ball.position.y - transform.position.y) / paddleHeight;
            ballRb.velocity = new Vector2(
                ballRb.velocity.x > 0 ? 1 : -1, 
                hitPos
            ).normalized * ballRb.velocity.magnitude * 1.05f; // Speed up slightly on hit
        }
    }

    // Goal Zones are triggers
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Goal"))
        {
            // I scored (opponent missed)
            AddReward(1.0f);
            // Opponent gets penalty handled in their script or via Group Rewards
            EndEpisode();
        }
        else if (other.CompareTag("PowerUp"))
        {
            if (other.GetComponent<PowerUp>().type == PowerUpType.Speed)
            {
                speedBoostActive = true;
                boostTimer = 5f;
                ballRb.velocity *= 1.5f;
                Destroy(other.gameObject);
            }
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var cont = actionsOut.ContinuousActions;
        cont[0] = 0;
        if (isLeftPaddle)
        {
            if (Input.GetKey(KeyCode.W)) cont[0] = 1;
            if (Input.GetKey(KeyCode.S)) cont[0] = -1;
        }
        else
        {
            if (Input.GetKey(KeyCode.UpArrow)) cont[0] = 1;
            if (Input.GetKey(KeyCode.DownArrow)) cont[0] = -1;
        }
    }
}

// Global Game Manager for Self-Play Logic
public class SelfPlayManager : MonoBehaviour
{
    public EloTracker eloTracker;
    
    // In a real ML-Agents setup, model swapping is handled by the Python Trainer.
    // In a Unity-only simulation or heuristic test, we simulate the logic:
    
    void Update()
    {
        // Handle Power-up Timer
        if (PongAgent.speedBoostActive)
        {
            PongAgent.boostTimer -= Time.deltaTime;
            if (PongAgent.boostTimer <= 0)
            {
                PongAgent.speedBoostActive = false;
                // Reset ball speed (approximate)
                // In a real scenario, we'd need a reference to the ball to reset specifically
            }
        }
    }
}

[System.Serializable]
public class EloTracker
{
    public int playerElo = 1200;
    public int opponentElo = 1200; // Represents the "Champion" snapshot

    public void UpdateScores(bool playerWon)
    {
        float kFactor = 32;
        float expectedScore = 1f / (1f + Mathf.Pow(10f, (opponentElo - playerElo) / 400f));
        float actualScore = playerWon ? 1f : 0f;
        
        playerElo = Mathf.RoundToInt(playerElo + kFactor * (actualScore - expectedScore));
        Debug.Log($"New Elo Rating: {playerElo}");
    }
}

public enum PowerUpType { Speed, Invisibility }
public class PowerUp : MonoBehaviour
{
    public PowerUpType type;
    public SpriteRenderer sprite;
    
    void Start()
    {
        // Randomize type
        type = (PowerUpType)Random.Range(0, 2);
        sprite.color = type == PowerUpType.Speed ? Color.yellow : Color.cyan;
    }

    void Update()
    {
        // Float animation
        transform.Rotate(Vector3.up * 50f * Time.deltaTime);
    }
}
