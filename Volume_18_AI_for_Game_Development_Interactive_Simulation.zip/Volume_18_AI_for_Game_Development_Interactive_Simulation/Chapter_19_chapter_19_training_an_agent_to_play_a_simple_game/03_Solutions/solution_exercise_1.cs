
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using System.Collections.Generic;
using System.Linq;

public class CurriculumAgent : Agent
{
    [Header("Agent Settings")]
    public Transform target;
    public LayerMask wallLayer;
    public LayerMask obstacleLayer;
    public float moveSpeed = 5f;
    public float rayDistance = 2f;

    private Vector3 startPosition;
    private float previousDistance;
    private Rigidbody2D rb;
    private CurriculumManager curriculumManager;

    // Dynamic Obstacle References
    public List<DynamicObstacle> dynamicObstacles;

    public override void Initialize()
    {
        rb = GetComponent<Rigidbody2D>();
        curriculumManager = FindObjectOfType<CurriculumManager>();
        startPosition = transform.position;
    }

    public override void OnEpisodeBegin()
    {
        // Reset position and physics
        transform.position = startPosition;
        rb.velocity = Vector2.zero;
        
        // Request curriculum update
        if (curriculumManager != null)
        {
            curriculumManager.RequestLevelUpdate(this);
        }

        // Reset dynamic obstacles
        foreach (var obs in dynamicObstacles)
        {
            obs.ResetObstacle();
        }

        previousDistance = Vector3.Distance(transform.position, target.position);
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // 1. Normalized Vector to Target (2 observations)
        Vector3 toTarget = target.position - transform.position;
        sensor.AddObservation(toTarget.normalized);

        // 2. Normalized Velocity (2 observations)
        sensor.AddObservation(rb.velocity.normalized);

        // 3. Raycasts in 8 Directions (8 observations)
        // Directions: N, NE, E, SE, S, SW, W, NW
        Vector2[] directions = new Vector2[]
        {
            Vector2.up, new Vector2(1, 1).normalized, Vector2.right, new Vector2(1, -1).normalized,
            Vector2.down, new Vector2(-1, -1).normalized, Vector2.left, new Vector2(-1, 1).normalized
        };

        foreach (var dir in directions)
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, dir, rayDistance, wallLayer | obstacleLayer);
            // Normalize distance (0 = no hit, 1 = hit at zero distance)
            float obsValue = hit.collider != null ? 1f - (hit.distance / rayDistance) : 0f;
            sensor.AddObservation(obsValue);
        }

        // 4. Current Difficulty Level (1 observation)
        if (curriculumManager != null)
        {
            sensor.AddObservation(curriculumManager.CurrentDifficultyNormalized);
        }
        else
        {
            sensor.AddObservation(0f);
        }
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // Continuous movement
        float moveX = actions.ContinuousActions[0];
        float moveY = actions.ContinuousActions[1];
        Vector2 moveVector = new Vector2(moveX, moveY).normalized * moveSpeed;
        rb.velocity = moveVector;

        // Time penalty
        AddReward(-0.001f);

        // Distance Reward (Dense Shaping)
        float currentDistance = Vector3.Distance(transform.position, target.position);
        float distanceChange = previousDistance - currentDistance;
        
        // Reward for getting closer, penalty for moving away
        // Multiplied by 0.1 to ensure it doesn't overshadow terminal reward
        AddReward(distanceChange * 0.1f);
        
        previousDistance = currentDistance;
    }

    // Collision Logic for Walls and Dynamic Obstacles
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            AddReward(-0.1f); // Penalty for hitting wall
            EndEpisode(); // Reset on wall hit for this simple env
        }
        else if (collision.gameObject.CompareTag("DynamicObstacle"))
        {
            AddReward(-0.5f); // Specific penalty for dynamic obstacle collision
            EndEpisode();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Target"))
        {
            AddReward(1.0f); // Terminal Goal Reward
            EndEpisode();
        }
    }

    // Proximity Bonus for Dynamic Obstacles (Check in FixedUpdate)
    private void FixedUpdate()
    {
        if (dynamicObstacles != null)
        {
            foreach (var obs in dynamicObstacles)
            {
                float dist = Vector3.Distance(transform.position, obs.transform.position);
                // Reward for passing close without colliding (e.g., within 0.5 units)
                if (dist < 0.5f && dist > 0.1f) 
                {
                    AddReward(0.001f); // Small incremental reward for proximity
                }
            }
        }
    }
}

public class CurriculumManager : MonoBehaviour
{
    public int CurrentLevel { get; private set; } = 1;
    public float CurrentDifficultyNormalized => (CurrentLevel - 1) / 2.0f; // 0.0, 0.5, 1.0

    [Header("Curriculum Settings")]
    public int windowSize = 100;
    public float successThreshold = 0.8f;
    public float failThreshold = 0.2f;
    public int consecutiveWindowsRequired = 5;

    private Queue<float> rewardWindow = new Queue<float>();
    private int consecutiveHighWindows = 0;
    private int consecutiveLowWindows = 0;

    // To be called by the agent at the start of an episode
    public void RequestLevelUpdate(CurriculumAgent agent)
    {
        // Logic to set agent start/goal based on level
        // In a real scenario, this might spawn the agent in specific positions
        // For this exercise, we assume the agent reads 'CurrentLevel' to adjust its behavior
        
        // Example: Adjust spawn radius or obstacle count dynamically
        switch (CurrentLevel)
        {
            case 1:
                // Level 1 Logic: Simple setup
                agent.transform.position = Vector3.zero; // Example
                break;
            case 2:
                // Level 2 Logic: Add obstacles
                break;
            case 3:
                // Level 3 Logic: Randomize everything
                break;
        }
    }

    // Call this when an episode ends with the cumulative reward
    public void ReportEpisodeReward(float cumulativeReward)
    {
        rewardWindow.Enqueue(cumulativeReward);
        if (rewardWindow.Count > windowSize) rewardWindow.Dequeue();

        if (rewardWindow.Count == windowSize)
        {
            float avgReward = rewardWindow.Average();

            // Check for Level Up
            if (avgReward > successThreshold)
            {
                consecutiveHighWindows++;
                consecutiveLowWindows = 0;
            }
            else if (avgReward < failThreshold)
            {
                consecutiveLowWindows++;
                consecutiveHighWindows = 0;
            }
            else
            {
                consecutiveHighWindows = 0;
                consecutiveLowWindows = 0;
            }

            // Apply Changes
            if (consecutiveHighWindows >= consecutiveWindowsRequired)
            {
                CurrentLevel = Mathf.Min(CurrentLevel + 1, 3); // Cap at Level 3
                ResetCounters();
                Debug.Log($"Curriculum Increased to Level {CurrentLevel}");
            }
            else if (consecutiveLowWindows >= consecutiveWindowsRequired)
            {
                CurrentLevel = Mathf.Max(CurrentLevel - 1, 1); // Floor at Level 1
                ResetCounters();
                Debug.Log($"Curriculum Decreased to Level {CurrentLevel}");
            }
        }
    }

    private void ResetCounters()
    {
        consecutiveHighWindows = 0;
        consecutiveLowWindows = 0;
        rewardWindow.Clear();
    }
}

public class DynamicObstacle : MonoBehaviour
{
    public Vector3 origin;
    public float amplitude = 1f;
    public float frequency = 1f;

    void Start()
    {
        origin = transform.position;
    }

    public void ResetObstacle()
    {
        transform.position = origin;
    }

    void Update()
    {
        // Sinusoidal movement
        float x = origin.x + Mathf.Sin(Time.time * frequency) * amplitude;
        float y = origin.y + Mathf.Cos(Time.time * frequency) * amplitude;
        transform.position = new Vector3(x, y, origin.z);
    }
}
