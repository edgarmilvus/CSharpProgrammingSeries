
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class PerformanceMonitor : MonoBehaviour
{
    public static PerformanceMonitor Instance;

    [Header("Metrics")]
    public int totalEpisodes = 0;
    public int successfulEpisodes = 0;
    public float totalReward = 0f;
    public float totalTime = 0f;

    // Moving averages
    public float avgSuccessRate { get; private set; }
    public float avgTime { get; private set; }
    public float avgReward { get; private set; }
    public float SkillScore { get; private set; }

    private Queue<float> rewardHistory = new Queue<float>();

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void LogEpisode(bool success, float cumulativeReward, float timeTaken)
    {
        totalEpisodes++;
        if (success) successfulEpisodes++;
        totalReward += cumulativeReward;
        totalTime += timeTaken;

        // Keep a sliding window of rewards for SkillScore calculation
        rewardHistory.Enqueue(cumulativeReward);
        if (rewardHistory.Count > 50) rewardHistory.Dequeue();

        CalculateSkillScore();
    }

    private void CalculateSkillScore()
    {
        // Weighted formula: Success Rate is most important, then Reward, then Speed
        float successRate = (float)successfulEpisodes / totalEpisodes;
        float recentAvgReward = rewardHistory.Count > 0 ? rewardHistory.Average() : 0f;
        
        // Normalize inputs (assuming max reward is 1.0, max time is 60s)
        float normReward = Mathf.Clamp01(recentAvgReward);
        float normSpeed = Mathf.Clamp01(1.0f - (totalTime / totalEpisodes / 60f)); // Faster is better

        SkillScore = (successRate * 0.6f) + (normReward * 0.3f) + (normSpeed * 0.1f);
    }
}

public class LevelGenerator : MonoBehaviour
{
    [Header("Generation Settings")]
    public float currentComplexity = 0.0f; // 0.0 to 1.0
    public Transform groundPrefab;
    public Transform obstaclePrefab;
    public Transform platformPrefab;
    public Transform agentSpawn;
    public Transform targetSpawn;

    [Header("Adaptation Settings")]
    public int episodesPerCheck = 20;
    public float upThreshold = 0.9f;
    public float downThreshold = 0.4f;
    public int hysteresisBuffer = 20; // Episodes to wait before decreasing after an increase
    
    private int episodesSinceLastCheck = 0;
    private bool wasRecentlyIncreased = false;
    private int hysteresisCounter = 0;

    void Start()
    {
        GenerateLevel();
    }

    void Update()
    {
        // In a real scenario, we might check less frequently or via event
        // Here we simulate checking every N episodes via a manual trigger or timer
        // For the exercise, we assume a manager calls CheckPerformance periodically
    }

    public void CheckPerformance()
    {
        episodesSinceLastCheck++;
        if (episodesSinceLastCheck < episodesPerCheck) return;

        episodesSinceLastCheck = 0;
        var monitor = PerformanceMonitor.Instance;
        if (monitor == null) return;

        float skill = monitor.SkillScore;

        // Hysteresis Logic
        if (wasRecentlyIncreased)
        {
            hysteresisCounter++;
            if (hysteresisCounter < hysteresisBuffer)
            {
                // Too soon to decrease difficulty
                return; 
            }
            else
            {
                wasRecentlyIncreased = false;
                hysteresisCounter = 0;
            }
        }

        if (skill > upThreshold)
        {
            // Increase Difficulty
            currentComplexity = Mathf.Min(currentComplexity + 0.1f, 1.0f);
            wasRecentlyIncreased = true; // Activate hysteresis
            GenerateLevel();
            Debug.Log($"Difficulty Increased to {currentComplexity}");
        }
        else if (skill < downThreshold && !wasRecentlyIncreased)
        {
            // Decrease Difficulty
            currentComplexity = Mathf.Max(currentComplexity - 0.1f, 0.0f);
            GenerateLevel();
            Debug.Log($"Difficulty Decreased to {currentComplexity}");
        }
    }

    public void GenerateLevel()
    {
        // 1. Destroy old level
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }

        // 2. Generate based on Complexity (0.0 - 1.0)
        
        // Base Floor
        Instantiate(groundPrefab, Vector3.zero, Quaternion.identity, transform);

        // Agent/Target Spawns
        agentSpawn.localPosition = Vector3.up * 2;
        targetSpawn.localPosition = Vector3.right * (5 + currentComplexity * 10); // Further away at high complexity

        // Obstacles
        int obstacleCount = Mathf.FloorToInt(currentComplexity * 10);
        for (int i = 0; i < obstacleCount; i++)
        {
            Vector3 pos = new Vector3(
                Random.Range(2f, 8f),
                Random.Range(0.5f, 2f),
                0
            );
            
            // If complexity is high, use moving platforms
            if (currentComplexity > 0.5f && i % 2 == 0)
            {
                var platform = Instantiate(platformPrefab, pos, Quaternion.identity, transform);
                // Add movement script
                platform.gameObject.AddComponent<MovingPlatform>();
            }
            else
            {
                Instantiate(obstaclePrefab, pos, Quaternion.identity, transform);
            }
        }
    }
}

// Helper class for dynamic obstacles
public class MovingPlatform : MonoBehaviour
{
    float speed = 2f;
    float range = 3f;
    void Update()
    {
        float x = Mathf.Sin(Time.time * speed) * range;
        transform.localPosition = new Vector3(x, transform.localPosition.y, 0);
    }
}
