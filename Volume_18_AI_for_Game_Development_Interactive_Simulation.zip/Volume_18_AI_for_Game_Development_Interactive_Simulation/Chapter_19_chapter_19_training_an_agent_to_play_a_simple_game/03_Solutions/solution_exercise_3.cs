
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Policies;

public class HybridAgent : Agent
{
    [Header("Hybrid Settings")]
    public RayPerceptionSensorComponent2D raySensor;
    public float safetyRadius = 0.5f;
    public LayerMask trapLayer;
    public LayerMask targetLayer;

    // Curiosity Model (Simplified Linear Predictor)
    private Vector3 lastPosition;
    private Vector3 lastVelocity;
    private float predictedError;

    public override void Initialize()
    {
        // Cache sensor reference for dynamic modification
        if (raySensor == null) raySensor = GetComponent<RayPerceptionSensorComponent2D>();
    }

    public override void OnEpisodeBegin()
    {
        // Reset position logic (Maze generation would happen here)
        lastPosition = transform.position;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // Standard observations (Position, Velocity) are handled by VectorSensor
        // RayPerception is handled automatically by the RayPerceptionSensorComponent2D
        // We add custom curiosity observation here
        sensor.AddObservation(predictedError);
        predictedError = 0; // Reset after adding
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        // 1. Curiosity Calculation (Intrinsic Reward)
        // Calculate prediction error between expected position and actual
        Vector3 currentPos = transform.position;
        Vector3 currentVel = (currentPos - lastPosition) / Time.fixedDeltaTime;
        
        // Simple linear prediction: NextPos = LastPos + LastVel
        Vector3 predictedPos = lastPosition + lastVelocity * Time.fixedDeltaTime;
        float distanceError = Vector3.Distance(predictedPos, currentPos);
        
        // Add intrinsic reward based on novelty (prediction error)
        // Clamped to prevent explosion
        AddReward(Mathf.Clamp(distanceError * 0.1f, 0, 0.1f));
        predictedError = distanceError;

        // Update history
        lastPosition = currentPos;
        lastVelocity = currentVel;

        // 2. Safety Heuristic Override
        // We need to access the raw observations from the RaySensor to make decisions
        // Note: In ML-Agents, accessing sensor data directly inside OnActionReceived is tricky 
        // because observations are collected *before* actions are decided.
        // Instead, we use the 'Heuristic' approach or modify the action buffer *before* processing.
        
        // However, for a safety override *post-decision*, we check the environment directly:
        RaycastHit2D hit = Physics2D.CircleCast(transform.position, safetyRadius, Vector2.zero, 0, trapLayer);
        
        if (hit.collider != null)
        {
            // Trap detected in immediate vicinity! 
            // Force a stop or reverse (Simulated override)
            // In strict RL, we shouldn't modify actions here, but we can apply a heavy penalty
            // and force a rigidbody stop for safety.
            GetComponent<Rigidbody2D>().velocity = Vector2.zero;
            AddReward(-0.5f); // Heavy penalty
            
            // To truly "steer away", we would need to detect the direction of the trap
            // and apply a physics impulse opposite to it.
            Vector2 awayFromTrap = (transform.position - hit.transform.position).normalized;
            GetComponent<Rigidbody2D>().AddForce(awayFromTrap * 10f, ForceMode2D.Impulse);
        }
    }

    // Dynamic Ray Length Logic
    void FixedUpdate()
    {
        if (raySensor != null)
        {
            // Adjust ray length based on speed
            float currentSpeed = GetComponent<Rigidbody2D>().velocity.magnitude;
            float reactionFactor = 0.5f; // Tuning parameter
            float baseLength = 2f;
            
            raySensor.RayLength = baseLength + (currentSpeed * reactionFactor);
        }
    }
}
