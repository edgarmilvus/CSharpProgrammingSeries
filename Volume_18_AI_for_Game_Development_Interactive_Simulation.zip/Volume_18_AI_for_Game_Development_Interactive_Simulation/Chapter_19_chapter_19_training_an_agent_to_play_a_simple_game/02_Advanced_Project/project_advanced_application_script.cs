
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace AdvancedApplicationScript
{
    /// <summary>
    /// Simulates the core logic of an ML-Agents training environment for a simple 2D navigation task.
    /// This console application demonstrates how an intelligent agent (neural network) perceives its environment,
    /// makes decisions, and learns from rewards/penalties to achieve a goal (reaching a target while avoiding obstacles).
    /// 
    /// REAL-WORLD CONTEXT:
    /// In a Unity game, an ML-Agents "Academy" manages the training session. The "Agent" class handles the brain's interface.
    /// This code replicates the "Step" function logic where the Agent collects observations, the Brain (neural network) 
    /// processes them to select an action, and the environment updates the Agent's state and assigns a reward.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // 1. SETUP: Initialize the Environment and the Agent
            // In Unity, this is handled by the Academy and Agent components. Here, we simulate the grid.
            GridEnvironment env = new GridEnvironment(10, 10);
            Agent agent = new Agent(x: 0, y: 0);
            Target target = new Target(x: 9, y: 9);
            Obstacle[] obstacles = new Obstacle[]
            {
                new Obstacle(3, 3), new Obstacle(3, 4), new Obstacle(3, 5),
                new Obstacle(7, 7), new Obstacle(8, 7)
            };

            // 2. CONFIGURATION: Define Hyperparameters
            // These are typical settings found in a Python training configuration file (yaml) for ML-Agents.
            int maxSteps = 100; // Episode length
            int currentStep = 0;
            bool isTraining = true;

            Console.WriteLine("--- STARTING TRAINING SIMULATION ---");
            Console.WriteLine($"Agent Start: ({agent.X}, {agent.Y}) | Target: ({target.X}, {target.Y})");
            env.PrintGrid(agent, target, obstacles);

            // 3. TRAINING LOOP: The Core "Academy" Step
            // This mimics the Academy's `AcademyStep` or the Agent's `OnActionReceived` loop.
            while (isTraining && currentStep < maxSteps)
            {
                // A. COLLECT OBSERVATIONS
                // In ML-Agents, `CollectObservations(VectorSensor sensor)` is called.
                // We calculate relative distance to target (RayCast logic simulation).
                float[] observations = agent.CollectObservations(target, obstacles, env.Width, env.Height);

                // B. DECISION PROCESS (Neural Network Inference)
                // The Brain (neural network) takes observations and outputs an action.
                // For discrete actions: 0=Up, 1=Down, 2=Left, 3=Right.
                int action = agent.RequestDecision(observations);

                // C. APPLY ACTION & UPDATE ENVIRONMENT
                // The Agent executes the action in the physics environment.
                agent.PerformAction(action);

                // D. CALCULATE REWARD
                // The environment assigns a reward based on the new state.
                // Positive reward for getting closer, negative for hitting obstacles/walls, large positive for target.
                float reward = agent.CalculateReward(agent, target, obstacles, env.Width, env.Height);

                // E. APPLY REWARD TO AGENT
                // In ML-Agents, this is `AddReward(float reward)` or `SetReward(float reward)`.
                agent.AddReward(reward);

                // F. CHECK TERMINATION (Done State)
                // If the agent hits a wall, obstacle, or reaches the target, the episode ends.
                bool done = CheckTermination(agent, target, obstacles, env.Width, env.Height);

                // G. VISUALIZATION & LOGGING
                Console.WriteLine($"\nStep {currentStep + 1}: Action {GetActionName(action)} | Reward: {reward:F2} | Total: {agent.ReturnReward():F2}");
                env.PrintGrid(agent, target, obstacles);

                // H. RESET IF DONE
                if (done)
                {
                    Console.WriteLine(">>> EPISODE ENDED (Success or Failure). Resetting...");
                    agent.Reset(x: 0, y: 0); // Reset position
                    currentStep = maxSteps;  // End training loop for this demo
                }

                currentStep++;
            }

            // 4. EXPORT / INFERENCE
            // After training, the neural network weights are saved (.onnx file).
            // We load these weights into a "Brain" to act as a policy for the NPC.
            Console.WriteLine("\n--- TRAINING COMPLETE ---");
            Console.WriteLine("Exporting trained model to 'SimpleNavigation.onnx'...");
            Console.WriteLine("Deploying Agent as Intelligent NPC...");
            
            // Simulate the Inference Phase (Runtime)
            SimulateRuntimeInference(agent, target, obstacles, env);
        }

        // --- HELPER METHODS ---

        static bool CheckTermination(Agent agent, Target target, Obstacle[] obstacles, int width, int height)
        {
            // Check boundary collision
            if (agent.X < 0 || agent.X >= width || agent.Y < 0 || agent.Y >= height) return true;

            // Check obstacle collision
            foreach (var obs in obstacles)
            {
                if (agent.X == obs.X && agent.Y == obs.Y) return true;
            }

            // Check target reached
            if (agent.X == target.X && agent.Y == target.Y) return true;

            return false;
        }

        static string GetActionName(int action)
        {
            switch (action)
            {
                case 0: return "Up";
                case 1: return "Down";
                case 2: return "Left";
                case 3: return "Right";
                default: return "Idle";
            }
        }

        static void SimulateRuntimeInference(Agent agent, Target target, Obstacle[] obstacles, GridEnvironment env)
        {
            Console.WriteLine("\n--- RUNTIME INFERENCE (LOADED MODEL) ---");
            Console.WriteLine("The NPC now uses the trained policy to navigate dynamically.");
            
            // Reset for demo
            agent.Reset(0, 0);
            env.PrintGrid(agent, target, obstacles);

            // Simulate a few steps using the "Learned" behavior
            // In a real game, the neural network runs every frame.
            int[] learnedPath = new int[] { 0, 0, 3, 3, 3, 3, 1, 1, 1, 1 }; // Hardcoded "optimal" path for demo
            
            foreach(int action in learnedPath)
            {
                agent.PerformAction(action);
                Console.WriteLine($"NPC moves: {GetActionName(action)} -> Pos: ({agent.X}, {agent.Y})");
                if (agent.X == target.X && agent.Y == target.Y) 
                {
                    Console.WriteLine("NPC reached the target!");
                    break;
                }
            }
        }
    }

    // --- CORE CLASSES (SIMULATING ML-AGENTS STRUCTURES) ---

    /// <summary>
    /// Represents the 2D Grid World (Environment).
    /// </summary>
    class GridEnvironment
    {
        public int Width { get; private set; }
        public int Height { get; private set; }

        public GridEnvironment(int width, int height)
        {
            Width = width;
            Height = height;
        }

        // Visualizes the state of the world for the console output
        public void PrintGrid(Agent agent, Target target, Obstacle[] obstacles)
        {
            for (int y = Height - 1; y >= 0; y--)
            {
                for (int x = 0; x < Width; x++)
                {
                    char symbol = '.';

                    if (x == agent.X && y == agent.Y) symbol = 'A'; // Agent
                    else if (x == target.X && y == target.Y) symbol = 'T'; // Target
                    else
                    {
                        foreach (var obs in obstacles)
                        {
                            if (x == obs.X && y == obs.Y)
                            {
                                symbol = 'X'; // Obstacle
                                break;
                            }
                        }
                    }
                    Console.Write(symbol + " ");
                }
                Console.WriteLine();
            }
        }
    }

    /// <summary>
    /// Represents the ML-Agents Agent. 
    /// Handles Observation collection, Action execution, and Reward accumulation.
    /// </summary>
    class Agent
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        private float _episodeReward;

        public Agent(int x, int y)
        {
            X = x;
            Y = y;
            _episodeReward = 0f;
        }

        public void Reset(int x, int y)
        {
            X = x;
            Y = y;
            _episodeReward = 0f;
        }

        /// <summary>
        /// Equivalent to CollectObservations() in Unity.
        /// Converts the state of the world into a float array (VectorSensor).
        /// </summary>
        public float[] CollectObservations(Target target, Obstacle[] obstacles, int width, int height)
        {
            // We use a simple relative coordinate system.
            // In a real CNN, we might use pixel data. Here we use vector data.
            // Size of observation vector = 2 (Target Delta) + 4 (Raycasts) = 6
            
            float[] obs = new float[6];

            // 1. Relative position to target (Normalized)
            obs[0] = (target.X - X) / (float)width;
            obs[1] = (target.Y - Y) / (float)height;

            // 2. Raycasts (Simulated) - Detect obstacles in 4 directions
            // Up
            obs[2] = IsPathClear(X, Y, 0, 1, obstacles) ? 0f : 1f;
            // Down
            obs[3] = IsPathClear(X, Y, 0, -1, obstacles) ? 0f : 1f;
            // Left
            obs[4] = IsPathClear(X, Y, -1, 0, obstacles) ? 0f : 1f;
            // Right
            obs[5] = IsPathClear(X, Y, 1, 0, obstacles) ? 0f : 1f;

            return obs;
        }

        /// <summary>
        /// Simulates the Neural Network.
        /// In ML-Agents, this is handled by the "Brain" (Behavior Parameters).
        /// For this console app, we implement a heuristic or a mock policy to simulate training.
        /// </summary>
        public int RequestDecision(float[] observations)
        {
            // LOGIC: 
            // If we are "training", the agent explores (random actions) or exploits (greedy).
            // If we are "inference" (after training), the agent strictly follows the learned policy.
            
            // SIMULATED NEURAL NETWORK:
            // A simple heuristic to mimic what a trained network would ideally do:
            // 1. If obstacle is close, avoid it.
            // 2. Move towards the target (based on obs[0] and obs[1]).
            
            // Note: In a real RL scenario, this is a matrix multiplication (Weights * Observations).
            // We simulate the output logic here.
            
            Random rand = new Random();
            
            // 20% Exploration (Random Action) during "Training"
            if (rand.NextDouble() < 0.2) 
            {
                return rand.Next(0, 4); // 0-3
            }

            // 80% Exploitation (Greedy Policy)
            // Determine dominant direction based on observations
            // obs[0] > 0 means Target is to the Right
            // obs[1] > 0 means Target is Up
            
            // Simple Priority Logic (Simulating a learned policy)
            if (observations[0] > 0 && observations[5] == 0) return 3; // Move Right
            if (observations[0] < 0 && observations[4] == 0) return 2; // Move Left
            if (observations[1] > 0 && observations[2] == 0) return 0; // Move Up
            if (observations[1] < 0 && observations[3] == 0) return 1; // Move Down

            // Fallback random if stuck
            return rand.Next(0, 4);
        }

        /// <summary>
        /// Applies the action to the physics body (Grid coordinates).
        /// </summary>
        public void PerformAction(int action)
        {
            switch (action)
            {
                case 0: Y += 1; break; // Up
                case 1: Y -= 1; break; // Down
                case 2: X -= 1; break; // Left
                case 3: X += 1; break; // Right
            }
        }

        /// <summary>
        /// Calculates the reward signal.
        /// This is the core of RL: Shaping behavior through feedback.
        /// </summary>
        public float CalculateReward(Agent agent, Target target, Obstacle[] obstacles, int width, int height)
        {
            float reward = 0f;

            // 1. Sparse Reward: Reaching the target
            if (agent.X == target.X && agent.Y == target.Y)
            {
                reward += 1.0f;
            }
            // 2. Dense Reward: Distance heuristic (Encourages moving closer)
            else
            {
                float previousDistance = Math.Abs(agent.X - target.X) + Math.Abs(agent.Y - target.Y);
                // Note: In a real step, we'd compare current vs previous. 
                // Here we just give a small penalty per step to encourage speed.
                reward -= 0.01f; 
            }

            // 3. Penalty: Hitting boundaries or obstacles (Handled in Termination, but can add explicit penalty here)
            if (agent.X < 0 || agent.X >= width || agent.Y < 0 || agent.Y >= height)
            {
                reward -= 0.5f;
            }

            foreach (var obs in obstacles)
            {
                if (agent.X == obs.X && agent.Y == obs.Y)
                {
                    reward -= 0.5f;
                }
            }

            return reward;
        }

        public void AddReward(float reward)
        {
            _episodeReward += reward;
        }

        public float ReturnReward()
        {
            return _episodeReward;
        }

        // Helper for Raycast simulation
        private bool IsPathClear(int startX, int startY, int dx, int dy, Obstacle[] obstacles)
        {
            int checkX = startX + dx;
            int checkY = startY + dy;
            foreach (var obs in obstacles)
            {
                if (obs.X == checkX && obs.Y == checkY) return false;
            }
            return true;
        }
    }

    class Target
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public Target(int x, int y) { X = x; Y = y; }
    }

    class Obstacle
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public Obstacle(int x, int y) { X = x; Y = y; }
    }
}
