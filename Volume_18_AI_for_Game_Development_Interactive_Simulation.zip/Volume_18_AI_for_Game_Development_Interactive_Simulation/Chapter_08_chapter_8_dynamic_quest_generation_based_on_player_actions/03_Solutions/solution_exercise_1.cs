
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

// 1. State Machine Implementation
public enum QuestState { Inactive, Active, Completed, Failed }

[System.Serializable]
public class QuestStep
{
    public string Description;
    public string TargetId; // e.g., "Enemy_Dragon" or "Item_HealingPotion"
    public int TargetCount;
    public int CurrentCount;
    public bool IsCompleted => CurrentCount >= TargetCount;

    public QuestStep(string desc, string targetId, int count)
    {
        Description = desc;
        TargetId = targetId;
        TargetCount = count;
        CurrentCount = 0;
    }
}

[System.Serializable]
public class Quest
{
    public string Id;
    public string Title;
    public List<QuestStep> Steps;
    public int CurrentStepIndex;
    public QuestState State;

    public Quest(string id, string title)
    {
        Id = id;
        Title = title;
        Steps = new List<QuestStep>();
        CurrentStepIndex = 0;
        State = QuestState.Inactive;
    }

    public QuestStep GetCurrentStep() => Steps.Count > 0 ? Steps[CurrentStepIndex] : null;
}

// 2. Context Injection System
[System.Serializable]
public class PlayerContext
{
    public Dictionary<string, int> Inventory;
    public Dictionary<string, int> Reputation;
    public string CurrentLocation;
    public List<string> RecentActions;

    public string ToJson()
    {
        return JsonConvert.SerializeObject(this, Formatting.Indented);
    }
}

public class ContextBuilder
{
    // Mock data sources - in a real game, these would reference actual game managers
    public PlayerContext BuildContext()
    {
        return new PlayerContext
        {
            Inventory = new Dictionary<string, int> { { "HealthPotion", 3 }, { "IronSword", 1 } },
            Reputation = new Dictionary<string, int> { { "TownGuard", 50 }, { "DarkCult", -10 } },
            CurrentLocation = "TownSquare",
            RecentActions = new List<string> { "CollectedHerbs", "TalkedToElder" }
        };
    }
}

// 3. Event-Driven Updates
public interface IQuestEventListener
{
    void OnItemCollected(string itemId, int count);
    void OnEnemyDefeated(string enemyId, int count);
    void OnLocationReached(string zoneId);
}

// 4. LLM Integration Stub
public interface IILLMService
{
    Task<string> GenerateNextObjective(string contextJson);
}

public class MockLLMService : IILLMService
{
    public async Task<string> GenerateNextObjective(string contextJson)
    {
        Debug.Log($"[MockLLM] Received Context:\n{contextJson}");
        
        // Simulate network delay
        await Task.Delay(100); 
        
        // Hardcoded response for demonstration
        return "Go to the Dark Forest and find the lost artifact.";
    }
}

// Main Manager
public class DynamicQuestManager : MonoBehaviour, IQuestEventListener
{
    private Dictionary<string, Quest> _activeQuests = new Dictionary<string, Quest>();
    private ContextBuilder _contextBuilder = new ContextBuilder();
    private IILLMService _llmService = new MockLLMService();

    // Example: Listening to events (In Unity, these could be hooked via EventSystem)
    public void OnItemCollected(string itemId, int count)
    {
        CheckQuestProgress("Item", itemId, count);
    }

    public void OnEnemyDefeated(string enemyId, int count)
    {
        CheckQuestProgress("Enemy", enemyId, count);
    }

    public void OnLocationReached(string zoneId)
    {
        CheckQuestProgress("Location", zoneId, 1);
    }

    private void CheckQuestProgress(string type, string id, int count)
    {
        // Iterate over a copy to allow modification during iteration
        foreach (var quest in _activeQuests.Values.ToList())
        {
            if (quest.State != QuestState.Active) continue;

            var currentStep = quest.GetCurrentStep();
            if (currentStep == null) continue;

            // Logic to match event to step target
            // Simplified: assumes TargetId format is consistent with event IDs
            if (currentStep.TargetId == id)
            {
                currentStep.CurrentCount += count;
                
                if (currentStep.IsCompleted)
                {
                    CompleteStep(quest);
                }
            }
        }
    }

    private async void CompleteStep(Quest quest)
    {
        Debug.Log($"Quest {quest.Id} Step {quest.CurrentStepIndex} completed.");

        // Move to next step or complete quest
        if (quest.CurrentStepIndex < quest.Steps.Count - 1)
        {
            // Generate next step via LLM
            string contextJson = _contextBuilder.BuildContext().ToJson();
            string nextObjective = await _llmService.GenerateNextObjective(contextJson);
            
            // Create new step based on LLM response
            // Note: In a real scenario, parsing the LLM response for TargetId is needed.
            // Here we mock a specific target for the generated text.
            var nextStep = new QuestStep(nextObjective, "Artifact_Lost", 1); 
            quest.Steps.Add(nextStep);
            quest.CurrentStepIndex++;
            
            Debug.Log($"New Objective Generated: {nextObjective}");
        }
        else
        {
            quest.State = QuestState.Completed;
            Debug.Log($"Quest {quest.Id} fully completed!");
            _activeQuests.Remove(quest.Id);
        }
    }

    // Helper to start a quest for testing
    public void StartQuest(string questId, string title)
    {
        var quest = new Quest(questId, title);
        // Initial step (could also be generated by LLM)
        quest.Steps.Add(new QuestStep("Collect 5 Iron Ore", "Item_IronOre", 5));
        quest.State = QuestState.Active;
        _activeQuests[questId] = quest;
    }
}
