
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;

// 2. Reward Database (ScriptableObject)
[CreateAssetMenu(fileName = "RewardDatabase", menuName = "Game/Reward Database")]
public class RewardDatabase : ScriptableObject
{
    [System.Serializable]
    public class RewardItem
    {
        public string ItemID;
        public int BaseValue;
        public int MinLevel;
        public int MaxLevel;
        public Rarity Rarity;
    }

    public enum Rarity { Common, Uncommon, Rare, Legendary }

    public List<RewardItem> Items;

    public List<RewardItem> GetValidItems(int playerLevel, int targetValue)
    {
        // Filter by level and approximate value range (e.g., +/- 20%)
        return Items.Where(i => playerLevel >= i.MinLevel && playerLevel <= i.MaxLevel)
                    .Where(i => i.BaseValue >= targetValue * 0.8f && i.BaseValue <= targetValue * 1.2f)
                    .ToList();
    }
}

// 1. Difficulty Estimation
public class QuestDifficultyAnalyzer
{
    public int EstimateDifficulty(string questDescription)
    {
        // Simple heuristic based on keywords
        string desc = questDescription.ToLower();
        int score = 1; // Base

        if (desc.Contains("dragon") || desc.Contains("boss")) score += 9;
        else if (desc.Contains("goblin") || desc.Contains("rat")) score += 1;
        else if (desc.Contains("fetch") || desc.Contains("collect")) score += 2;
        
        // Clamp between 1 and 10
        return Mathf.Clamp(score, 1, 10);
    }
}

// 3. Balancing Algorithm
public class RewardBalancer
{
    private RewardDatabase _database;
    private QuestDifficultyAnalyzer _analyzer = new QuestDifficultyAnalyzer();

    public RewardBalancer(RewardDatabase db)
    {
        _database = db;
    }

    public struct BalancedReward
    {
        public string ItemId;
        public int Quantity;
        public int Gold;
    }

    public BalancedReward BalanceReward(string questDesc, int playerLevel)
    {
        int difficulty = _analyzer.EstimateDifficulty(questDesc);
        
        // Formula: Difficulty * Player Level * Constant
        int targetValue = difficulty * playerLevel * 10;

        // Check if LLM suggested a specific reward (Mock parsing logic)
        // In a real scenario, we would parse the LLM JSON response here.
        // For this exercise, we assume we are generating from scratch or adjusting a null input.
        
        // Query Database
        var validItems = _database.GetValidItems(playerLevel, targetValue);

        BalancedReward reward = new BalancedReward();

        if (validItems.Count > 0)
        {
            // Select a random valid item
            var selected = validItems[Random.Range(0, validItems.Count)];
            reward.ItemId = selected.ItemID;
            reward.Quantity = 1; // Simplified
            reward.Gold = 0;
        }
        else
        {
            // Fallback to gold if no item matches
            reward.ItemId = null;
            reward.Quantity = 0;
            reward.Gold = targetValue;
        }

        return reward;
    }
}

// 4. Integration (Mocking the DynamicQuestManager modification)
public class RewardSystemIntegration : MonoBehaviour
{
    public RewardDatabase rewardDatabase;
    
    // Simulating the flow
    public void OnQuestGenerated(string llmQuestDescription, int playerLevel)
    {
        // Ensure database is loaded
        if (rewardDatabase == null)
        {
            Debug.LogError("Reward Database missing!");
            return;
        }

        // Run balancing asynchronously to avoid frame drops
        // Using Task.Run to offload calculation
        Task.Run(() => 
        {
            var balancer = new RewardBalancer(rewardDatabase);
            var reward = balancer.BalanceReward(llmQuestDescription, playerLevel);

            // Back to Main Thread to update game state
            // (In Unity, you must use Unity's main thread for game object manipulation)
            UnityMainThreadDispatcher.Instance().Enqueue(() => 
            {
                Debug.Log($"Balanced Reward: {reward.ItemId ?? "Gold"} x{reward.Quantity}{reward.Gold}");
                // Apply reward to quest object here
            });
        });
    }
}

// Helper class for Main Thread dispatching (Standard Unity pattern)
public class UnityMainThreadDispatcher : MonoBehaviour
{
    private static UnityMainThreadDispatcher _instance;
    private readonly System.Collections.Generic.Queue<System.Action> _actionQueue = new System.Collections.Generic.Queue<System.Action>();

    public static UnityMainThreadDispatcher Instance()
    {
        if (_instance == null)
        {
            var obj = new GameObject("MainThreadDispatcher");
            _instance = obj.AddComponent<UnityMainThreadDispatcher>();
            DontDestroyOnLoad(obj);
        }
        return _instance;
    }

    public void Enqueue(System.Action action)
    {
        lock (_actionQueue)
        {
            _actionQueue.Enqueue(action);
        }
    }

    void Update()
    {
        lock (_actionQueue)
        {
            while (_actionQueue.Count > 0)
            {
                _actionQueue.Dequeue().Invoke();
            }
        }
    }
}
