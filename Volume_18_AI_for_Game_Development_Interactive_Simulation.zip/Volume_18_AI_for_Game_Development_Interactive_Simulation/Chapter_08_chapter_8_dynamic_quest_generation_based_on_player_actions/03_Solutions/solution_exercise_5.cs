
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

// 1. Canonical Database (ScriptableObject)
[CreateAssetMenu(fileName = "LoreDatabase", menuName = "Game/Lore Database")]
public class LoreDatabase : ScriptableObject
{
    public List<string> ValidLocations = new List<string> { "Dark Forest", "Town Square", "Astral Observatory" };
    public List<string> ValidNPCs = new List<string> { "Elder Mordin", "Bandit Leader" };
    public List<string> ValidItems = new List<string> { "Iron Sword", "Healing Potion" };
    
    public List<string> LoreKeywords = new List<string> { "Magic", "Ancient", "Forest", "Technology" };
    public List<string> ForbiddenTones = new List<string> { "Sci-Fi", "Modern", "Cyberpunk" }; // e.g., "Laser Gun", "Internet"
}

// 2. Semantic Validation & 3. Correction Mechanism
public class LoreValidator
{
    private LoreDatabase _database;
    private CorrectionStrategy _strategy;

    public enum CorrectionStrategy { Strict, Substitution }

    public LoreValidator(LoreDatabase db, CorrectionStrategy strategy = CorrectionStrategy.Substitution)
    {
        _database = db;
        _strategy = strategy;
    }

    public ValidationResult Validate(string llmText)
    {
        var result = new ValidationResult { IsValid = true, CorrectedText = llmText };

        // 2. Semantic Validation (Fuzzy Matching)
        // Extract potential proper nouns (simple heuristic: Capitalized words not at start of sentence)
        var words = Regex.Matches(llmText, @"\b[A-Z][a-z]+\b")
                         .Cast<Match>()
                         .Select(m => m.Value)
                         .Distinct()
                         .ToList();

        foreach (var word in words)
        {
            bool isKnown = IsKnownTerm(word);
            
            if (!isKnown)
            {
                // Hallucination detected
                if (_strategy == CorrectionStrategy.Strict)
                {
                    result.IsValid = false;
                    result.ErrorMessage = $"Unknown term detected: {word}";
                    return result; // Fail fast
                }
                else
                {
                    // Substitution Strategy
                    string closest = FindClosestMatch(word);
                    if (closest != null)
                    {
                        result.CorrectedText = result.CorrectedText.Replace(word, closest);
                        Debug.Log($"Lore Correction: Replaced '{word}' with '{closest}'");
                    }
                    else
                    {
                        // No close match found, reject in strict mode or remove in loose mode
                        result.IsValid = false; 
                        result.ErrorMessage = $"Unknown term with no match: {word}";
                        return result;
                    }
                }
            }
        }

        // 4. Tone Consistency
        if (!CheckToneConsistency(llmText))
        {
            result.IsValid = false;
            result.ErrorMessage = "Tone violation detected (e.g., Sci-Fi term in Fantasy setting).";
        }

        return result;
    }

    private bool IsKnownTerm(string term)
    {
        return _database.ValidLocations.Contains(term) ||
               _database.ValidNPCs.Contains(term) ||
               _database.ValidItems.Contains(term) ||
               _database.LoreKeywords.Contains(term);
    }

    // Helper for Fuzzy Matching (Simplified Levenshtein logic)
    private string FindClosestMatch(string term)
    {
        // Search in all valid categories
        var allValid = _database.ValidLocations.Concat(_database.ValidNPCs).Concat(_database.ValidItems);
        
        string bestMatch = null;
        int minDistance = int.MaxValue;

        foreach (var valid in allValid)
        {
            int dist = LevenshteinDistance(term, valid);
            if (dist < minDistance)
            {
                minDistance = dist;
                bestMatch = valid;
            }
        }

        // Only return if the match is reasonably close (e.g., distance < 3)
        return minDistance < 3 ? bestMatch : null;
    }

    private bool CheckToneConsistency(string text)
    {
        foreach (var forbidden in _database.ForbiddenTones)
        {
            // In a real scenario, you'd map forbidden tones to specific keywords.
            // Here we assume the ForbiddenTones list contains specific banned words.
            if (text.ToLower().Contains(forbidden.ToLower())) return false;
        }
        return true;
    }

    // Simple Levenshtein Distance Algorithm
    private int LevenshteinDistance(string s, string t)
    {
        int n = s.Length;
        int m = t.Length;
        int[,] d = new int[n + 1, m + 1];

        if (n == 0) return m;
        if (m == 0) return n;

        for (int i = 0; i <= n; d[i, 0] = i++) { }
        for (int j = 0; j <= m; d[0, j] = j++) { }

        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                d[i, j] = Mathf.Min(
                    d[i - 1, j] + 1,      // deletion
                    d[i, j - 1] + 1,      // insertion
                    d[i - 1, j - 1] + cost // substitution
                );
            }
        }
        return d[n, m];
    }
}

public struct ValidationResult
{
    public bool IsValid;
    public string CorrectedText;
    public string ErrorMessage;
}

// 5. Integration
public class LoreGuardIntegration : MonoBehaviour
{
    public LoreDatabase loreDatabase;
    
    public void OnLLMResponseReceived(string rawResponse)
    {
        var validator = new LoreValidator(loreDatabase, CorrectionStrategy.Substitution);
        var result = validator.Validate(rawResponse);

        if (result.IsValid)
        {
            Debug.Log($"Lore Validated. Proceeding with: {result.CorrectedText}");
            // Pass to DynamicQuestManager
        }
        else
        {
            Debug.LogWarning($"Lore Validation Failed: {result.ErrorMessage}");
            // Trigger Re-prompt logic here
            // Example: "The previous generation contained invalid lore. Please regenerate..."
        }
    }
}
