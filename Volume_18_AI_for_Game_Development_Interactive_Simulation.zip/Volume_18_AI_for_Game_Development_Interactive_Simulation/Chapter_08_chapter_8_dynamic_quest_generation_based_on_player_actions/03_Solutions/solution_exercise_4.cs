
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public enum PlayerActionType { QuestCompleted, FactionBetrayal, LocationDiscovered }

[System.Serializable]
public class WorldState
{
    public List<string> ActiveEvents = new List<string>();
    public Dictionary<string, bool> Flags = new Dictionary<string, bool>(); // e.g., "RoadBlocked": true
}

// 1. Action-Event Correlation & 3. State Persistence
public class ReactiveWorldStateManager : MonoBehaviour
{
    private WorldState _currentState = new WorldState();
    private Queue<PlayerActionType> _actionHistory = new Queue<PlayerActionType>();
    private IILLMService _llmService = new MockLLMService(); // Reusing interface
    private ConflictResolver _conflictResolver = new ConflictResolver();

    // Called by game systems when player does something significant
    public void RecordPlayerAction(PlayerActionType action)
    {
        _actionHistory.Enqueue(action);
        if (_actionHistory.Count > 5) _actionHistory.Dequeue(); // Keep last 5

        // Trigger generation immediately for significant actions
        if (action == PlayerActionType.QuestCompleted || action == PlayerActionType.FactionBetrayal)
        {
            GenerateReaction(action);
        }
    }

    private async void GenerateReaction(PlayerActionType triggerAction)
    {
        string prompt = ConstructPrompt(triggerAction);
        
        string llmResponse = await _llmService.GenerateNextObjective(prompt);
        
        // 2. Dynamic Obstacle Generation (Parsing & Application)
        ApplyConsequence(llmResponse);
    }

    private string ConstructPrompt(PlayerActionType action)
    {
        string historyContext = string.Join(", ", _actionHistory.Select(a => a.ToString()));
        string stateContext = string.Join(", ", _currentState.Flags.Select(f => $"{f.Key}:{f.Value}"));
        
        return $"World History: {historyContext}\nCurrent State: {stateContext}\n" +
               $"The player just performed action: {action}. " +
               $"Generate a short environmental change or NPC reaction. " +
               $"Output format: [Description] | [FlagKey:Value]";
    }

    private void ApplyConsequence(string response)
    {
        // Parse response (e.g., "Bandits block the road | RoadBlocked:True")
        var parts = response.Split('|');
        if (parts.Length < 2) return;

        string description = parts[0].Trim();
        string flagData = parts[1].Trim();
        var flagParts = flagData.Split(':');
        
        if (flagParts.Length == 2)
        {
            string key = flagParts[0];
            bool value = bool.Parse(flagParts[1]);

            // 3. Conflict Resolution Check
            if (_conflictResolver.IsConflict(key, value, _currentState))
            {
                Debug.Log($"Conflict detected for {key}. Ignoring event.");
                return;
            }

            // Apply
            _currentState.Flags[key] = value;
            _currentState.ActiveEvents.Add(description);
            
            Debug.Log($"[Reactive World] {description} (Flag: {key} = {value})");
            
            // 4. Visualization (Debug)
            // In a real game, trigger a UI notification here
        }
    }
}

// 3. Conflict Resolver
public class ConflictResolver
{
    public bool IsConflict(string key, bool newValue, WorldState state)
    {
        if (!state.Flags.ContainsKey(key)) return false;

        bool currentValue = state.Flags[key];
        
        // Logic: If the road is already blocked (true), and LLM tries to block it again (true), 
        // it's not a conflict, just redundant. 
        // But if it tries to unblock (false) immediately after blocking, we might want to prevent it
        // depending on game logic. 
        // Example Rule: Cannot toggle state within short timeframe (requires timestamp history, simplified here).
        
        // Simple rule: If the state is exactly the same, return true (redundant) or false (allow).
        // Let's say we prevent redundant updates:
        if (currentValue == newValue) return true; 

        return false;
    }
}

// 4. Visualization (Extension: Notification Popup)
public class WorldEventNotifier : MonoBehaviour
{
    public CanvasGroup notificationPanel;
    public Text notificationText;

    public void ShowNotification(string message)
    {
        notificationText.text = message;
        StartCoroutine(FadeSequence());
    }

    private System.Collections.IEnumerator FadeSequence()
    {
        notificationPanel.alpha = 1;
        yield return new WaitForSeconds(3f);
        while (notificationPanel.alpha > 0)
        {
            notificationPanel.alpha -= Time.deltaTime;
            yield return null;
        }
    }
}
