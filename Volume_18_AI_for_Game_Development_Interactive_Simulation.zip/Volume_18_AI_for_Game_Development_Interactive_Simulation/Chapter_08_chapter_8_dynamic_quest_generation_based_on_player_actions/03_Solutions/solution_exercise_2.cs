
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using UnityEngine.UI;
using System;
using System.Threading.Tasks;

// 1. Prompt Engineering & Data Structures
[System.Serializable]
public class DialogueOption
{
    public string text;
    public string outcome; // e.g., "StartQuest:DarkForest", "Goodbye"
}

[System.Serializable]
public class DialogueTree
{
    public string npcOpening;
    public DialogueOption[] options;
}

public class DialoguePromptBuilder
{
    public string BuildPrompt(string npcName, string npcFaction, PlayerContext context)
    {
        // Constructing a detailed system prompt
        string prompt = $"You are {npcName}, a member of the {npcFaction} faction.\n";
        prompt += "Generate a dialogue response based on the player's context below.\n";
        prompt += "Output ONLY valid JSON with the structure: { \"npcOpening\": \"...\", \"options\": [{ \"text\": \"...\", \"outcome\": \"...\" }] }\n";
        prompt += "Valid outcomes are: StartQuest:[QuestID], Trade, Goodbye, Attack.\n";
        prompt += "DO NOT generate outcomes that give free items or gold without a quest.\n\n";
        
        prompt += $"Player Context:\nLocation: {context.CurrentLocation}\nReputation with {npcFaction}: {context.Reputation.GetValueOrDefault(npcFaction, 0)}\n";
        
        return prompt;
    }
}

// 2. Response Parsing & Validation
public class DialogueParser
{
    public DialogueTree Parse(string json)
    {
        try
        {
            // Attempt to deserialize
            DialogueTree tree = JsonUtility.FromJson<DialogueTree>(json);
            
            // Basic validation
            if (tree == null || string.IsNullOrEmpty(tree.npcOpening) || tree.options == null)
                throw new Exception("Invalid structure");

            return tree;
        }
        catch (Exception e)
        {
            Debug.LogError($"LLM Parse Error: {e.Message}. Returning fallback.");
            return GetFallbackTree();
        }
    }

    private DialogueTree GetFallbackTree()
    {
        return new DialogueTree
        {
            npcOpening = "The NPC seems busy and mutters a generic greeting.",
            options = new DialogueOption[]
            {
                new DialogueOption { text = "Leave", outcome = "Goodbye" }
            }
        };
    }
}

// 3. Stateful Interaction & Command Execution
public class CommandExecutor
{
    public void Execute(string outcome)
    {
        Debug.Log($"Executing Outcome: {outcome}");
        
        if (outcome.StartsWith("StartQuest:"))
        {
            string questId = outcome.Split(':')[1];
            // Hook into DynamicQuestManager (assuming singleton or static access)
            // FindObjectOfType<DynamicQuestManager>().StartQuest(questId, "Generated Quest");
        }
        else if (outcome == "Goodbye")
        {
            // Close UI
        }
        // Add other commands...
    }
}

public class DialogueManager : MonoBehaviour
{
    [Header("UI References")]
    public Text npcText;
    public Button[] optionButtons; // Assuming a pool of 4 buttons
    public GameObject thinkingIndicator;

    private DialogueParser _parser = new DialogueParser();
    private CommandExecutor _executor = new CommandExecutor();
    private IILLMService _llmService = new MockLLMService(); // Reusing mock from Ex 1

    // Mock NPC Data
    private string _currentNpcName = "Elder Mordin";
    private string _currentNpcFaction = "TownGuard";

    // 4. Visualizing the Flow & Latency Handling
    public async void StartDialogue()
    {
        // Show "Thinking..." immediately
        thinkingIndicator.SetActive(true);
        SetButtonsInteractable(false);

        // Build Context
        var context = new ContextBuilder().BuildContext();
        string prompt = new DialoguePromptBuilder().BuildPrompt(_currentNpcName, _currentNpcFaction, context);

        // Call LLM
        string llmResponse = await _llmService.GenerateNextObjective(prompt); // Reusing interface for simplicity
        
        // Parse
        DialogueTree tree = _parser.Parse(llmResponse);

        // Update UI
        thinkingIndicator.SetActive(false);
        DisplayDialogue(tree);
    }

    private void DisplayDialogue(DialogueTree tree)
    {
        npcText.text = $"{_currentNpcName}: {tree.npcOpening}";

        // Reset buttons
        for (int i = 0; i < optionButtons.Length; i++)
        {
            if (i < tree.options.Length)
            {
                optionButtons[i].gameObject.SetActive(true);
                optionButtons[i].GetComponentInChildren<Text>().text = tree.options[i].text;
                
                // Capture the outcome for the closure
                string outcome = tree.options[i].outcome;
                
                // Remove old listeners and add new one
                optionButtons[i].onClick.RemoveAllListeners();
                optionButtons[i].onClick.AddListener(() => OnOptionSelected(outcome));
            }
            else
            {
                optionButtons[i].gameObject.SetActive(false);
            }
        }
        SetButtonsInteractable(true);
    }

    private void OnOptionSelected(string outcome)
    {
        _executor.Execute(outcome);
        // In a real game, this might chain to another dialogue or close the window
        Debug.Log("Option selected: " + outcome);
    }

    private void SetButtonsInteractable(bool interactable)
    {
        foreach (var btn in optionButtons) btn.interactable = interactable;
    }
}
