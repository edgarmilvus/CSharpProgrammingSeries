
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.cs
// Description: Theoretical Foundations
// ==========================================

using System.Collections.Concurrent;
using System.Threading.Tasks;

public class TelemetryDispatcher
{
    private readonly ConcurrentQueue<PlayerGameEvent> _eventQueue = new();
    private readonly int _batchSize = 50;

    // Called from the main game thread
    public void CaptureEvent(PlayerGameEvent gameEvent)
    {
        _eventQueue.Enqueue(gameEvent);
    }

    // Called from a background thread
    public async Task DispatchLoopAsync()
    {
        while (true)
        {
            if (_eventQueue.Count >= _batchSize)
            {
                var batch = new List<PlayerGameEvent>();
                for (int i = 0; i < _batchSize; i++)
                {
                    if (_eventQueue.TryDequeue(out var evt))
                    {
                        batch.Add(evt);
                    }
                }
                // In a real application, this would send the batch to an HTTP endpoint
                await SendToIngestionEndpoint(batch);
            }
            await Task.Delay(1000); // Poll every second
        }
    }

    private async Task SendToIngestionEndpoint(List<PlayerGameEvent> batch)
    {
        // Placeholder for HTTP POST logic
        await Task.CompletedTask;
    }
}
