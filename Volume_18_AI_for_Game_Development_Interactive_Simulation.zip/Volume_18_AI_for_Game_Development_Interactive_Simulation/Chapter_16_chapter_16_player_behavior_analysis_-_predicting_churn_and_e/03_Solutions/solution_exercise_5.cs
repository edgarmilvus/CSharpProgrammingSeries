
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;

// 1. Interfaces for Dependency Injection
public interface ITelemetryService
{
    IObservable<GameEvent> EventStream { get; }
    void Publish(GameEvent evt);
}

public interface IFeatureExtractor
{
    IObservable<float[]> FeatureStream { get; }
}

public interface IModelLoader
{
    // Returns a function that maps features to prediction
    Func<float[], (bool, float)> LoadModel(); 
}

// 2. Reactive Telemetry Service
public class ReactiveTelemetryService : ITelemetryService
{
    private readonly Subject<GameEvent> _subject = new();

    public IObservable<GameEvent> EventStream => _subject.AsObservable();

    public void Publish(GameEvent evt)
    {
        // Push event into the reactive stream
        _subject.OnNext(evt);
    }

    public void Shutdown()
    {
        _subject.OnCompleted();
        _subject.Dispose();
    }
}

// 3. Modular Feature Extractor
public class ReactiveFeatureExtractor : IFeatureExtractor
{
    private readonly Subject<float[]> _featureSubject = new();
    public IObservable<float[]> FeatureStream => _featureSubject.AsObservable();

    public ReactiveFeatureExtractor(ITelemetryService telemetryService)
    {
        // Subscribe to the telemetry stream
        telemetryService.EventStream
            .Buffer(TimeSpan.FromMinutes(5)) // Time-based windowing
            .Subscribe(events =>
            {
                try
                {
                    if (events.Count == 0) return;
                    
                    // Calculate features (using logic from Exercise 2)
                    var features = FeatureEngineeringPipeline.ProcessBatch(events, events[0].PlayerID);
                    _featureSubject.OnNext(features);
                }
                catch (Exception ex)
                {
                    // Error Handling: Emit error but keep stream alive
                    _featureSubject.OnError(ex);
                }
            }, ex => _featureSubject.OnError(ex));
    }
}

// 4. Reactive Churn Predictor
public class ReactiveChurnPredictor
{
    private readonly IModelLoader _modelLoader;
    private readonly Func<float[], (bool, float)> _predictionFunc;

    public ReactiveChurnPredictor(IFeatureExtractor featureExtractor, IModelLoader modelLoader)
    {
        _modelLoader = modelLoader;
        _predictionFunc = _modelLoader.LoadModel();

        // Subscribe to features
        featureExtractor.FeatureStream
            .Subscribe(features =>
            {
                try
                {
                    var (isChurn, probability) = _predictionFunc(features);
                    Console.WriteLine($"Prediction: Churn={isChurn}, Prob={probability:P2}");
                    
                    // Here you would trigger the LLM Strategy (Exercise 4)
                }
                catch (Exception ex)
                {
                    // Global Error Handling Strategy
                    Console.WriteLine($"[Error in Prediction Pipeline]: {ex.Message}");
                    // Stream continues processing next items
                }
            });
    }
}

// 5. Mock Implementations for Testing
public class MockModelLoader : IModelLoader
{
    public Func<float[], (bool, float)> LoadModel()
    {
        // Return a dummy function that simulates model inference
        return features => (features[0] > 0.5f, features[0]); 
    }
}

// Usage / Composition Root
public class SystemComposer
{
    public void Compose()
    {
        // Dependency Injection Composition
        ITelemetryService telemetry = new ReactiveTelemetryService();
        IFeatureExtractor extractor = new ReactiveFeatureExtractor(telemetry);
        IModelLoader loader = new MockModelLoader();
        
        var predictor = new ReactiveChurnPredictor(extractor, loader);

        // Simulate incoming data
        telemetry.Publish(new GameEvent(EventType.PlayerJump, Guid.NewGuid(), "{}"));
    }
}
