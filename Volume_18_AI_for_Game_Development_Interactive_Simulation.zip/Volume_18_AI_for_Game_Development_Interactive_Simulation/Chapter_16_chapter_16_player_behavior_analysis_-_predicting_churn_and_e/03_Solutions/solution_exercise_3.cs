
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Data;

// 1. Data Structures
public class PlayerData
{
    [LoadColumn(0)] public float EventFrequency { get; set; }
    [LoadColumn(1)] public float AvgTimeBetweenActions { get; set; }
    [LoadColumn(2)] public float ActionDiversity { get; set; }
    [LoadColumn(3)] public float CombatRatio { get; set; }
    [LoadColumn(4)] public float SessionDuration { get; set; }
    [LoadColumn(5)] public bool Label { get; set; } // True = Churned
}

public class Prediction
{
    [ColumnName("PredictedLabel")]
    public bool IsChurned { get; set; }
    public float Probability { get; set; }
    public float Score { get; set; }
}

// 2. Training Pipeline
public static class ModelTrainer
{
    public static void TrainAndSave(string dataPath, string modelPath)
    {
        var context = new MLContext(seed: 0);

        // Load Data (Assuming a CSV exists at dataPath, or generate mock data here)
        // For this example, we simulate loading from a file.
        IDataView dataView = context.Data.LoadFromTextFile<PlayerData>(dataPath, separatorChar: ',', hasHeader: true);

        // Split Data
        var trainTestSplit = context.Data.TrainTestSplit(dataView, testFraction: 0.2);

        // Define Pipeline
        var pipeline = context.Transforms.Concatenate("Features", 
                nameof(PlayerData.EventFrequency), 
                nameof(PlayerData.AvgTimeBetweenActions), 
                nameof(PlayerData.ActionDiversity), 
                nameof(PlayerData.CombatRatio), 
                nameof(PlayerData.SessionDuration))
            .Append(context.BinaryClassification.Trainers.SdcaLogisticRegression(
                labelColumnName: "Label", 
                featureColumnName: "Features"));

        // Train
        var model = pipeline.Fit(trainTestSplit.TrainSet);

        // Evaluate
        var predictions = model.Transform(trainTestSplit.TestSet);
        var metrics = context.BinaryClassification.Evaluate(predictions, "Label");

        Console.WriteLine($"Accuracy: {metrics.Accuracy:P2}");
        Console.WriteLine($"Precision: {metrics.PositivePrecision:P2}");
        Console.WriteLine($"Recall: {metrics.PositiveRecall:P2}");
        Console.WriteLine($"F1 Score: {metrics.F1Score:P2}");

        if (metrics.Accuracy < 0.80)
        {
            Console.WriteLine("Warning: Model accuracy is below 80% threshold.");
        }

        // Save
        context.Model.Save(model, dataView.Schema, modelPath);
        Console.WriteLine($"Model saved to {modelPath}");
    }
}

// 3. Thread-Safe Inference Engine
public class ChurnPredictor : IDisposable
{
    private readonly MLContext _mlContext;
    private readonly PredictionEngine<PlayerData, Prediction> _predictionEngine;
    private readonly SemaphoreSlim _semaphore = new(1, 1); // Thread safety lock

    public ChurnPredictor(string modelPath)
    {
        _mlContext = new MLContext();
        
        // Load Model
        var model = _mlContext.Model.Load(modelPath, out var schema);
        _predictionEngine = _mlContext.Model.CreatePredictionEngine<PlayerData, Prediction>(model);
    }

    public (bool IsChurn, float Probability) Predict(float[] features)
    {
        // Acquire lock to ensure thread safety for the PredictionEngine (which is not thread-safe)
        _semaphore.Wait();
        try
        {
            var input = new PlayerData
            {
                EventFrequency = features[0],
                AvgTimeBetweenActions = features[1],
                ActionDiversity = features[2],
                CombatRatio = features[3],
                SessionDuration = features[4]
            };

            var prediction = _predictionEngine.Predict(input);
            
            // Convert Sigmoid score (0-1) to probability
            // ML.NET returns Probability directly if calibrated, otherwise use Score
            return (prediction.IsChurned, prediction.Probability);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    public void Dispose()
    {
        _semaphore?.Dispose();
        _predictionEngine?.Dispose();
    }
}
