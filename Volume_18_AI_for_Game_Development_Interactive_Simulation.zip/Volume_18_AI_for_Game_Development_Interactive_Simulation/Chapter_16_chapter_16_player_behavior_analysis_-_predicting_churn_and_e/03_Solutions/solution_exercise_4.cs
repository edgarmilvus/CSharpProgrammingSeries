
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Text.Json;

// 1. Context Builder
public static class PlayerContextBuilder
{
    public static string BuildContext(float[] features, float churnProbability)
    {
        // Interpret features for the LLM
        string diversityDesc = features[2] > 0.7f ? "high action diversity" : "low action diversity";
        string combatDesc = features[3] < 0.3f ? "avoids combat" : "engages in combat";
        string frequencyDesc = features[0] > 0.5f ? "plays frequently" : "plays rarely";

        return $"Player exhibits {diversityDesc} and {combatDesc}. " +
               $"They {frequencyDesc}. " +
               $"Current churn probability is {churnProbability:P0}.";
    }
}

// 2. Strategy Generator (Simulated LLM)
public class StrategyGenerator
{
    // Mock database of strategies
    private static readonly List<StrategyTemplate> Templates = new()
    {
        new StrategyTemplate("SendGift", "Sword", "You seem adventurous! Here is a legendary sword to aid your journey."),
        new StrategyTemplate("SendGift", "Potion", "Combat is tough. Take these healing potions on us."),
        new StrategyTemplate("SendMessage", null, "Your exploration skills are unmatched! Keep going!"),
        new StrategyTemplate("UnlockArea", "SecretGarden", "You've unlocked a secret area due to your high diversity.")
    };

    public string GenerateStrategyJson(string context)
    {
        // In a real scenario, this would call an API (e.g., OpenAI)
        // For this exercise, we simulate logic based on context keywords
        
        StrategyTemplate selectedTemplate;
        
        if (context.Contains("avoids combat") && context.Contains("high churn"))
        {
            selectedTemplate = Templates[1]; // Give potions
        }
        else if (context.Contains("high action diversity"))
        {
            selectedTemplate = Templates[3]; // Unlock area
        }
        else
        {
            selectedTemplate = Templates[0]; // Default gift
        }

        // Construct the JSON object
        var responseObj = new
        {
            Action = selectedTemplate.Action,
            ItemID = selectedTemplate.ItemId,
            Message = selectedTemplate.Message
        };

        return JsonSerializer.Serialize(responseObj);
    }

    private record StrategyTemplate(string Action, string ItemId, string Message);
}

// 3. Action Dispatcher
public static class ActionDispatcher
{
    public static void Dispatch(string jsonPayload)
    {
        try
        {
            var doc = JsonDocument.Parse(jsonPayload);
            var root = doc.RootElement;

            string action = root.GetProperty("Action").GetString();
            
            // Simulate Game System Calls
            switch (action)
            {
                case "SendGift":
                    string itemId = root.GetProperty("ItemID").GetString();
                    string message = root.GetProperty("Message").GetString();
                    InventorySystem.GiveItem(itemId);
                    ChatSystem.SendMessage(message);
                    break;
                case "UnlockArea":
                    WorldSystem.UnlockZone(root.GetProperty("ItemID").GetString());
                    break;
            }

            // Log for feedback loop
            LogToFile($"Action {action} dispatched. Payload: {jsonPayload}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to dispatch action: {ex.Message}");
        }
    }

    private static void LogToFile(string log)
    {
        // Simulate file I/O
        System.IO.File.AppendAllText("feedback_log.txt", $"{DateTime.Now}: {log}\n");
    }
}

// Mock Systems
public static class InventorySystem { public static void GiveItem(string id) => Console.WriteLine($"Gave item: {id}"); }
public static class ChatSystem { public static void SendMessage(string msg) => Console.WriteLine($"Chat Msg: {msg}"); }
public static class WorldSystem { public static void UnlockZone(string zone) => Console.WriteLine($"Zone Unlocked: {zone}"); }

// Integration Usage Example
public class EngagementOrchestrator
{
    public void RunChurnIntervention(float[] features, float probability)
    {
        // 1. Build Context
        string context = PlayerContextBuilder.BuildContext(features, probability);
        
        // 2. Generate Strategy
        var generator = new StrategyGenerator();
        string strategyJson = generator.GenerateStrategyJson(context);
        
        // 3. Dispatch Action
        ActionDispatcher.Dispatch(strategyJson);
    }
}
