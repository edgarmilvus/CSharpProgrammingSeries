
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

public class SessionAnalyzer
{
    private readonly Queue<GameEvent> _eventWindow = new();
    private readonly TimeSpan _windowDuration = TimeSpan.FromMinutes(30);
    private readonly Guid _playerId;
    
    // Mock configuration for feature calculation
    private const int MaxEventsPerMinute = 60; 
    private const int MaxSessionDurationMinutes = 120;

    public SessionAnalyzer(Guid playerId)
    {
        _playerId = playerId;
    }

    public void AddEvent(GameEvent evt)
    {
        // 1. Maintain Sliding Window
        _eventWindow.Enqueue(evt);
        
        // Remove events older than 30 minutes
        while (_eventWindow.Count > 0 && 
               (DateTime.UtcNow - _eventWindow.Peek().Timestamp) > _windowDuration)
        {
            _eventWindow.Dequeue();
        }
    }

    public float[] CalculateFeatures()
    {
        if (_eventWindow.Count == 0)
        {
            // Edge Case: No data. Return zero vector.
            return new float[5]; 
        }

        var events = _eventWindow.ToArray();
        var now = DateTime.UtcNow;
        
        // 1. Event Frequency (Events per Minute)
        // Total events / Total session time in minutes (clamped to window)
        var sessionDurationMinutes = (float)(now - events.First().Timestamp).TotalMinutes;
        if (sessionDurationMinutes < 0.1f) sessionDurationMinutes = 0.1f; // Avoid div by zero
        
        float eventFrequency = events.Length / sessionDurationMinutes;

        // 2. Average Time Between Actions
        // Calculate time diffs between consecutive events
        var timeDiffs = new List<double>();
        for (int i = 1; i < events.Length; i++)
        {
            timeDiffs.Add((events[i].Timestamp - events[i - 1].Timestamp).TotalSeconds);
        }
        float avgTimeBetweenActions = timeDiffs.Count > 0 ? (float)timeDiffs.Average() : 0f;

        // 3. Diversity of Actions
        var uniqueTypes = events.Select(e => e.Type).Distinct().Count();
        float actionDiversity = (float)uniqueTypes / events.Length;

        // 4. Combat vs Exploration Ratio
        // Mock logic: Combat = CombatEngaged, Exploration = ItemCollected, LevelStart
        int combatCount = events.Count(e => e.Type == EventType.CombatEngaged);
        int explorationCount = events.Count(e => e.Type == EventType.ItemCollected || e.Type == EventType.LevelStart);
        float combatRatio = (combatCount + explorationCount) > 0 ? (float)combatCount / (combatCount + explorationCount) : 0f;

        // 5. Session Duration
        float sessionDuration = (float)(now - events.First().Timestamp).TotalMinutes;

        // Vector Normalization (Scaling 0-1)
        return new float[]
        {
            Normalize(eventFrequency, 0, MaxEventsPerMinute),
            Normalize(avgTimeBetweenActions, 0, 60), // Assume max 60s between actions
            actionDiversity, // Already 0-1
            combatRatio,     // Already 0-1
            Normalize(sessionDuration, 0, MaxSessionDurationMinutes)
        };
    }

    private float Normalize(float value, float min, float max)
    {
        float clamped = Math.Clamp(value, min, max);
        return (clamped - min) / (max - min);
    }
}

// Integration Helper
public static class FeatureEngineeringPipeline
{
    public static float[] ProcessBatch(List<GameEvent> batch, Guid playerId)
    {
        var analyzer = new SessionAnalyzer(playerId);
        foreach (var evt in batch)
        {
            analyzer.AddEvent(evt);
        }
        return analyzer.CalculateFeatures();
    }
}
