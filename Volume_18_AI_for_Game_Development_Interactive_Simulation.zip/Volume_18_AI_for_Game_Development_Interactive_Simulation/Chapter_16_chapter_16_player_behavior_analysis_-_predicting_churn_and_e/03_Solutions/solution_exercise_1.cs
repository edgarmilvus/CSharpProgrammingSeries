
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using System.Text.Json;

// 1. Event Structure: Memory-efficient readonly struct
public readonly struct GameEvent
{
    public readonly EventType Type;
    public readonly DateTime Timestamp;
    public readonly Guid PlayerID;
    public readonly string Payload; // JSON blob or simple string

    public GameEvent(EventType type, Guid playerId, string payload)
    {
        Type = type;
        Timestamp = DateTime.UtcNow;
        PlayerID = playerId;
        Payload = payload;
    }
}

public enum EventType
{
    Login,
    LevelStart,
    PlayerJump,
    ItemCollected,
    CombatEngaged,
    Logout
}

// 2. Static Telemetry Collector
public static class TelemetryCollector
{
    private static readonly ConcurrentQueue<GameEvent> _eventQueue = new();
    private static readonly CancellationTokenSource _cts = new();
    private static bool _isInitialized = false;
    private static readonly object _lock = new();

    // Buffer settings
    private const int BatchSize = 100;
    private const int TransmissionIntervalMs = 10000; // 10 seconds

    public static void Initialize()
    {
        lock (_lock)
        {
            if (_isInitialized) return;
            
            // Start the background transmission task
            Task.Run(() => ProcessQueueAsync(_cts.Token));
            _isInitialized = true;
            Debug.Log("Telemetry Collector Initialized.");
        }
    }

    public static void Enqueue(GameEvent gameEvent)
    {
        if (!_isInitialized) Initialize();
        _eventQueue.Enqueue(gameEvent);
    }

    private static async Task ProcessQueueAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                // Wait for interval or cancellation
                await Task.Delay(TransmissionIntervalMs, token);

                var batch = new List<GameEvent>();
                
                // Dequeue in batch
                while (batch.Count < BatchSize && _eventQueue.TryDequeue(out var evt))
                {
                    batch.Add(evt);
                }

                if (batch.Count > 0)
                {
                    await TransmitBatchAsync(batch);
                }
            }
            catch (OperationCanceledException)
            {
                break; // Graceful shutdown
            }
        }

        // Flush remaining events on shutdown
        Flush();
    }

    private static async Task TransmitBatchAsync(List<GameEvent> batch)
    {
        // Simulate network transmission
        var jsonPayload = JsonSerializer.Serialize(batch);
        
        // Log for demonstration (In production, send via HTTP POST)
        Debug.Log($"[TELEMETRY] Transmitting {batch.Count} events. Payload size: {jsonPayload.Length} bytes.");
        
        // Simulate network latency
        await Task.Delay(100); 
    }

    private static void Flush()
    {
        var remaining = new List<GameEvent>();
        while (_eventQueue.TryDequeue(out var evt))
        {
            remaining.Add(evt);
        }

        if (remaining.Count > 0)
        {
            // Force synchronous send on quit to ensure data integrity
            var jsonPayload = JsonSerializer.Serialize(remaining);
            Debug.Log($"[TELEMETRY] Flushing {remaining.Count} events on quit.");
        }
    }

    public static void Dispose()
    {
        _cts.Cancel();
        _isInitialized = false;
    }
}

// 3. Unity Integration: MonoBehaviour for mock data generation
public class TelemetryMockGenerator : MonoBehaviour
{
    private Guid _currentPlayerId;
    private float _timer = 0f;

    void Start()
    {
        // Simulate a player logging in
        _currentPlayerId = Guid.NewGuid();
        TelemetryCollector.Enqueue(new GameEvent(EventType.Login, _currentPlayerId, "{\"source\": \"main_menu\"}"));
    }

    void Update()
    {
        _timer += Time.deltaTime;
        
        // Generate random events every 2 seconds
        if (_timer > 2.0f)
        {
            _timer = 0f;
            
            // Randomly select an event type
            var types = (EventType[])Enum.GetValues(typeof(EventType));
            var randomType = types[UnityEngine.Random.Range(1, types.Length)]; // Skip Login
            var payload = $"{{\"position\": [{UnityEngine.Random.Range(0, 100)}, {UnityEngine.Random.Range(0, 100)}]}}";

            TelemetryCollector.Enqueue(new GameEvent(randomType, _currentPlayerId, payload));
        }
    }

    void OnApplicationQuit()
    {
        // Ensure cleanup
        TelemetryCollector.Dispose();
    }
}
