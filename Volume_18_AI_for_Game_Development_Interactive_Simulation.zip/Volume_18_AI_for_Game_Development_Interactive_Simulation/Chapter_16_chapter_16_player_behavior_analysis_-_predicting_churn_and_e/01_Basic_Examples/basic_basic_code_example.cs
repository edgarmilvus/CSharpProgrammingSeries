
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PlayerBehaviorAnalysis
{
    // Represents a single gameplay session with raw telemetry data.
    // In a real-world scenario, this would be populated by a telemetry SDK (e.g., Unity Analytics, custom JSON payloads).
    public class PlayerSessionData
    {
        public string PlayerId { get; set; }
        public DateTime SessionStart { get; set; }
        public double SessionDurationMinutes { get; set; }
        public int LevelsCompleted { get; set; }
        public int Deaths { get; set; }
        public int ItemsPurchased { get; set; }
        public bool Churned { get; set; } // Ground truth label (true if player didn't return within 7 days)
    }

    // A lightweight, manually implemented classification model.
    // This simulates a trained model (like a Logistic Regression or a small Decision Tree) without requiring external ML libraries.
    public class ChurnPredictionModel
    {
        // These weights represent the learned importance of each feature.
        // In a real scenario, these would be calculated during a training phase using historical data.
        // Higher positive weight = higher probability of churn.
        // Negative weight = lower probability of churn.
        private readonly double _bias = -2.5;
        private readonly double _weightDuration = -0.05; // Longer sessions usually indicate lower churn.
        private readonly double _weightLevels = -0.2;    // Completing levels usually indicates lower churn.
        private readonly double _weightDeaths = 0.15;    // High deaths can indicate frustration (potential churn).
        private readonly double _weightPurchases = -0.5; // Spending money usually locks a player in.

        // Applies the Sigmoid function to squash a value between 0 and 1.
        // This converts the linear combination of weights into a probability.
        private double Sigmoid(double x)
        {
            return 1.0 / (1.0 + Math.Exp(-x));
        }

        // Predicts the probability of churn (0.0 to 1.0) for a given session.
        public double Predict(PlayerSessionData session)
        {
            // Calculate the linear combination of features and weights
            double linearScore = _bias
                + (_weightDuration * session.SessionDurationMinutes)
                + (_weightLevels * session.LevelsCompleted)
                + (_weightDeaths * session.Deaths)
                + (_weightPurchases * session.ItemsPurchased);

            // Return the probability
            return Sigmoid(linearScore);
        }
    }

    // Represents the structured output of the LLM analysis.
    // This decouples the natural language generation from the structured data used by the game logic.
    public class EngagementStrategy
    {
        public string RecommendationType { get; set; } // e.g., "Incentive", "Notification", "DifficultyAdjustment"
        public string MessageTemplate { get; set; }    // The text sent to the player or displayed to the dev
        public string Rationale { get; set; }          // Why this strategy was chosen (for developer logs)
        public double ConfidenceScore { get; set; }    // Derived from the churn probability
    }

    // Simulates an LLM (like GPT-4) for generating dynamic text based on structured data.
    // In a production environment, this would make an API call to an LLM provider.
    public class LLMService
    {
        // A mock dictionary to simulate prompt engineering and response generation.
        // We map simple logic to specific text outputs.
        public EngagementStrategy GenerateStrategy(double churnProbability, PlayerSessionData session)
        {
            // Define thresholds for decision making
            if (churnProbability > 0.7)
            {
                return new EngagementStrategy
                {
                    RecommendationType = "UrgentRetention",
                    MessageTemplate = $"Hey {session.PlayerId}! We noticed you've been struggling with {session.Deaths} deaths. Here is a free health pack to help you push through!",
                    Rationale = "High churn probability detected (>70%) combined with high death count. Immediate intervention required.",
                    ConfidenceScore = churnProbability
                };
            }
            else if (churnProbability > 0.4)
            {
                return new EngagementStrategy
                {
                    RecommendationType = "Nudge",
                    MessageTemplate = $"Welcome back, {session.PlayerId}! You've completed {session.LevelsCompleted} levels. Keep up the great work!",
                    Rationale = "Moderate churn risk. Positive reinforcement of progress.",
                    ConfidenceScore = churnProbability
                };
            }
            else
            {
                return new EngagementStrategy
                {
                    RecommendationType = "Maintenance",
                    MessageTemplate = null, // No intervention needed
                    Rationale = "Player engagement is healthy. No action taken.",
                    ConfidenceScore = churnProbability
                };
            }
        }
    }

    // The main orchestrator that simulates the flow of data.
    public class AnalyticsPipeline
    {
        private readonly ChurnPredictionModel _model;
        private readonly LLMService _llmService;

        public AnalyticsPipeline()
        {
            _model = new ChurnPredictionModel();
            _llmService = new LLMService();
        }

        public void RunSimulation()
        {
            Console.WriteLine("--- Starting Player Behavior Analysis Simulation ---");

            // 1. Ingest raw data (Simulated Telemetry)
            // In production, this comes from a database or event stream (e.g., Kafka, AWS Kinesis).
            var playerData = new List<PlayerSessionData>
            {
                new PlayerSessionData { PlayerId = "User_101", SessionDurationMinutes = 45, LevelsCompleted = 5, Deaths = 2, ItemsPurchased = 1, Churned = false },
                new PlayerSessionData { PlayerId = "User_102", SessionDurationMinutes = 5, LevelsCompleted = 0, Deaths = 10, ItemsPurchased = 0, Churned = true },
                new PlayerSessionData { PlayerId = "User_103", SessionDurationMinutes = 120, LevelsCompleted = 12, Deaths = 5, ItemsPurchased = 3, Churned = false }
            };

            foreach (var session in playerData)
            {
                Console.WriteLine($"\nProcessing Session: {session.PlayerId}");

                // 2. Feature Engineering & Inference
                // The model takes raw numbers and outputs a probability.
                double churnProb = _model.Predict(session);
                Console.WriteLine($"   -> Churn Probability: {churnProb:P2}");

                // 3. LLM Integration
                // The LLM takes the probability and raw context to generate a human-readable strategy.
                var strategy = _llmService.GenerateStrategy(churnProb, session);

                // 4. Output Actionable Insights
                if (strategy.RecommendationType != "Maintenance")
                {
                    Console.WriteLine($"   -> Strategy: {strategy.RecommendationType}");
                    Console.WriteLine($"   -> Action: {strategy.MessageTemplate}");
                    Console.WriteLine($"   -> Logic: {strategy.Rationale}");
                }
                else
                {
                    Console.WriteLine($"   -> Strategy: {strategy.RecommendationType} (No intervention needed)");
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var pipeline = new AnalyticsPipeline();
            pipeline.RunSimulation();
        }
    }
}
