
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using Unity.Collections;
using UnityEngine.Networking;

/// <summary>
/// A self-contained 'Hello World' example demonstrating how to programmatically 
/// generate a PBR material from a base color texture using generative AI concepts.
/// 
/// CONTEXT: In game development, artists often spend hours creating specific 
/// texture maps (Albedo, Normal, Roughness) for a single asset. Generative AI 
/// promises to automate this. However, raw AI output is usually just a flat image 
/// (Albedo). To create a realistic material, we must mathematically derive the 
/// other PBR maps (Normal, Roughness, Metallic) from that single input.
/// 
/// PROBLEM SOLVED: This script procedurally generates a "Fantasy Stone Wall" 
/// material entirely from code. It simulates the generative process by creating 
/// a base texture, then uses image processing algorithms (Sobel edge detection 
/// for normals, luminance analysis for roughness) to build a complete PBR 
/// material stack without external assets.
/// </summary>
public class ProceduralPBRGenerator : MonoBehaviour
{
    [Header("Generation Settings")]
    [Tooltip("The resolution of the generated textures (e.g., 512, 1024). Higher = more detail but slower.")]
    public int textureResolution = 512;

    [Tooltip("The scale of the noise pattern. Smaller numbers = tighter details.")]
    public float noiseScale = 20f;

    [Tooltip("Contrast of the generated normal map edges.")]
    public float normalIntensity = 1.5f;

    [Header("Output Material")]
    [Tooltip("The Renderer to apply the generated material to.")]
    public MeshRenderer targetRenderer;

    // Internal storage for pixel data to allow high-performance manipulation
    private NativeArray<Color32> _albedoData;
    private NativeArray<Color32> _normalData;
    private NativeArray<Color32> _roughnessData;
    private Texture2D _albedoTexture;
    private Texture2D _normalTexture;
    private Texture2D _roughnessTexture;

    // Unity Lifecycle: Start is called before the first frame update
    async void Start()
    {
        if (targetRenderer == null)
        {
            Debug.LogError("Target Renderer is not assigned. Please assign it in the Inspector.");
            return;
        }

        Debug.Log("Starting Procedural PBR Generation...");

        // 1. Generate the Base Albedo (Color) Texture
        // This simulates the output of a generative image model (e.g., Stable Diffusion)
        await GenerateAlbedoTexture();

        // 2. Derive PBR Maps from Albedo
        // In a real pipeline, these might come from separate AI calls or depth estimation models.
        // Here, we derive them mathematically to create a cohesive material.
        GenerateNormalMap();
        GenerateRoughnessMap();

        // 3. Construct the Material
        ApplyMaterialToGameObject();

        Debug.Log("Generation Complete. Material applied.");
    }

    /// <summary>
    /// Generates a base color texture using Perlin Noise to simulate a stone wall pattern.
    /// This mimics the "creative" output of a generative AI model.
    /// </summary>
    private async Task GenerateAlbedoTexture()
    {
        // Initialize the texture
        _albedoTexture = new Texture2D(textureResolution, textureResolution, TextureFormat.RGBA32, false);
        
        // Allocate native memory for high-performance pixel manipulation
        // NativeArray is faster than standard C# arrays for heavy math operations
        _albedoData = new NativeArray<Color32>(textureResolution * textureResolution, Allocator.Persistent);

        // Run heavy calculation on a background thread to avoid freezing the game
        await Task.Run(() =>
        {
            for (int y = 0; y < textureResolution; y++)
            {
                for (int x = 0; x < textureResolution; x++)
                {
                    // Calculate UV coordinates (0.0 to 1.0)
                    float u = (float)x / textureResolution;
                    float v = (float)y / textureResolution;

                    // Generate Perlin Noise for organic stone pattern
                    float noiseValue = Mathf.PerlinNoise(u * noiseScale, v * noiseScale);

                    // Convert noise to color (Dark grey stones with black mortar)
                    // Thresholding creates the "bricks" or "stones" look
                    byte intensity = (byte)(noiseValue * 255);
                    
                    // Add some color variation (slight brown tint)
                    Color32 pixel = new Color32(
                        (byte)(intensity * 0.8f), // R
                        (byte)(intensity * 0.7f), // G
                        (byte)(intensity * 0.6f), // B
                        255                       // A
                    );

                    // Write to native array
                    int index = y * textureResolution + x;
                    _albedoData[index] = pixel;
                }
            }
        });

        // Apply the pixel data to the texture
        _albedoTexture.SetPixelData(_albedoData, 0);
        _albedoTexture.Apply();
    }

    /// <summary>
    /// Generates a Normal Map by detecting edges in the Albedo texture.
    /// In AI terms, this simulates "Depth Estimation" or "Normal Map Estimation" models.
    /// </summary>
    private void GenerateNormalMap()
    {
        _normalTexture = new Texture2D(textureResolution, textureResolution, TextureFormat.RGBA32, false);
        _normalData = new NativeArray<Color32>(textureResolution * textureResolution, Allocator.Persistent);

        // We need to read the Albedo data to calculate normals
        // Note: In a real app, we might read from the GPU or a file. Here we read from memory.
        // If memory isn't available, we sample the texture (slower but safer).
        // For this example, we assume _albedoData is still valid or we re-calculate the height map.
        
        // To keep this self-contained, we will regenerate the height map logic here
        // (In a real scenario, we would pass the height map directly).
        float[] heightMap = new float[textureResolution * textureResolution];
        
        // Re-calculate height (luminance of albedo) for the kernel
        for (int i = 0; i < _albedoData.Length; i++)
        {
            Color32 c = _albedoData[i];
            heightMap[i] = (c.r + c.g + c.b) / 3f / 255f;
        }

        // Sobel Filter Kernels for X and Y axes
        // These detect horizontal and vertical edges
        float[,] kernelX = { { -1, 0, 1 }, { -2, 0, 2 }, { -1, 0, 1 } };
        float[,] kernelY = { { -1, -2, -1 }, { 0, 0, 0 }, { 1, 2, 1 } };

        for (int y = 1; y < textureResolution - 1; y++)
        {
            for (int x = 1; x < textureResolution - 1; x++)
            {
                float sumX = 0;
                float sumY = 0;

                // Apply 3x3 convolution
                for (int ky = -1; ky <= 1; ky++)
                {
                    for (int kx = -1; kx <= 1; kx++)
                    {
                        int pixelIndex = (y + ky) * textureResolution + (x + kx);
                        float height = heightMap[pixelIndex];
                        
                        sumX += height * kernelX[ky + 1, kx + 1];
                        sumY += height * kernelY[ky + 1, kx + 1];
                    }
                }

                // Calculate Normal Vector
                // X component comes from horizontal gradient, Y from vertical
                // Z is typically 1 (facing camera) adjusted by intensity
                Vector3 normal = new Vector3(-sumX * normalIntensity, -sumY * normalIntensity, 1f).normalized;

                // Convert normal vector (-1 to 1) to RGB color (0 to 1)
                // Standard normal map format: R=X, G=Y, B=Z
                Color normalColor = new Color(
                    normal.x * 0.5f + 0.5f,
                    normal.y * 0.5f + 0.5f,
                    normal.z * 0.5f + 0.5f,
                    1.0f
                );

                int index = y * textureResolution + x;
                _normalData[index] = normalColor;
            }
        }

        _normalTexture.SetPixelData(_normalData, 0);
        _normalTexture.Apply();
        
        // Set wrap mode to repeat for tiling
        _normalTexture.wrapMode = TextureWrapMode.Repeat;
    }

    /// <summary>
    /// Generates a Roughness Map based on the luminance of the Albedo.
    /// Darker areas (mortar/crevices) are rougher; lighter areas (stone faces) are smoother.
    /// </summary>
    private void GenerateRoughnessMap()
    {
        _roughnessTexture = new Texture2D(textureResolution, textureResolution, TextureFormat.RGBA32, false);
        _roughnessData = new NativeArray<Color32>(textureResolution * textureResolution, Allocator.Persistent);

        for (int i = 0; i < _albedoData.Length; i++)
        {
            // Get the brightness of the pixel
            Color32 albedo = _albedoData[i];
            float brightness = (albedo.r + albedo.g + albedo.b) / 3f / 255f;

            // Invert brightness to simulate roughness: 
            // Bright = Smooth (Low Roughness), Dark = Rough (High Roughness)
            // We add a small minimum roughness to avoid perfectly reflective surfaces (0.0)
            float roughnessValue = Mathf.Clamp01(1.0f - brightness + 0.1f);

            byte roughnessByte = (byte)(roughnessValue * 255);

            // Roughness maps are usually grayscale. We set R=roughness, others ignored or set to 0.
            // Note: Unity's Standard Shader uses the G channel for Roughness in Metallic setup if using RGBA32?
            // Actually, Unity's Texture2D import settings usually map R to Metallic and A to Smoothness.
            // To avoid confusion, we will output a standard grayscale image and configure the material later.
            _roughnessData[i] = new Color32(roughnessByte, roughnessByte, roughnessByte, 255);
        }

        _roughnessTexture.SetPixelData(_roughnessData, 0);
        _roughnessTexture.Apply();
        _roughnessTexture.wrapMode = TextureWrapMode.Repeat;
    }

    /// <summary>
    /// Creates a Unity Material using the Standard Shader and assigns the generated textures.
    /// </summary>
    private void ApplyMaterialToGameObject()
    {
        // Create a new material instance based on the Standard Shader
        // Standard Shader supports Metallic/Roughness workflow
        Material material = new Material(Shader.Find("Standard"));

        // Assign Albedo
        material.SetTexture("_MainTex", _albedoTexture);
        
        // Assign Normal Map
        // We must enable the keyword for normal maps to work in Standard Shader
        material.EnableKeyword("_NORMALMAP");
        material.SetTexture("_BumpMap", _normalTexture);
        material.SetFloat("_BumpScale", 1.0f);

        // Assign Roughness/Metallic
        // In Unity's Standard Shader (Metallic setup):
        // R channel = Metallic
        // G channel = Occlusion (optional, we leave it white)
        // A channel = Smoothness (1 - Roughness)
        // To keep it simple, we will use the Roughness map we generated as the source for Smoothness.
        
        // Create a combined Metallic-Roughness texture for Unity's specific workflow
        // Unity prefers: R=Metallic, A=Smoothness. 
        // We will generate a new texture that packs these correctly.
        Texture2D metallicSmoothness = new Texture2D(textureResolution, textureResolution, TextureFormat.RGBA32, false);
        NativeArray<Color32> msData = new NativeArray<Color32>(_roughnessData.Length, Allocator.Temp);

        for (int i = 0; i < msData.Length; i++)
        {
            // We want non-metallic (0.0) stone.
            // Smoothness is 1.0 - Roughness.
            byte roughness = _roughnessData[i].r;
            byte smoothness = (byte)(255 - roughness); // Invert for Unity's Smoothness
            
            msData[i] = new Color32(0, 255, 0, smoothness); // R=0 (Metallic), G=255 (Occlusion dummy), A=Smoothness
        }
        
        metallicSmoothness.SetPixelData(msData, 0);
        metallicSmoothness.Apply();
        msData.Dispose();

        material.SetTexture("_MetallicGlossMap", metallicSmoothness);
        material.EnableKeyword("_METALLICGLOSSMAP");

        // Apply to the target renderer
        targetRenderer.material = material;

        // Cleanup memory
        // Note: We don't dispose _albedoData, _normalData, _roughnessData here 
        // because the Textures still reference them internally in some Unity versions, 
        // but strictly speaking, NativeArrays should be disposed when no longer needed.
        // For this example, we leave them for the session lifetime.
    }

    void OnDestroy()
    {
        // Cleanup native memory to prevent memory leaks
        if (_albedoData.IsCreated) _albedoData.Dispose();
        if (_normalData.IsCreated) _normalData.Dispose();
        if (_roughnessData.IsCreated) _roughnessData.Dispose();
    }
}
