
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.IO;

namespace TextureMaterialGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            // PROBLEM CONTEXT:
            // In a game development pipeline, artists often need to generate variations of a base texture.
            // For example, a "wet mud" texture might need a "dried mud" variant for a dynamic weather system.
            // Instead of manually editing images, we can programmatically generate material properties
            // (Albedo, Normal, Roughness) by manipulating pixel data based on defined rules.
            // This application simulates the "post-processing" step of generative AI workflows where
            // raw outputs are refined into game-ready assets.

            Console.WriteLine("--- Texture & Material Generation Console ---");
            Console.WriteLine("Simulating PBR Material Generation from Base Inputs...\n");

            // 1. Initialize parameters for our material generation.
            // We define a base color (Albedo) and target material properties.
            // In a real engine, these would be loaded from generated AI images.
            // Here, we simulate the data structure of a 512x512 texture.
            const int width = 512;
            const int height = 512;
            
            // Base Albedo Color (R, G, B) - representing "Dry Mud"
            byte baseR = 100;
            byte baseG = 80;
            byte baseB = 60;

            // Target Environmental Factor (0.0 = Dry, 1.0 = Fully Wet)
            float wetnessFactor = 0.7f;

            // 2. Create data structures to hold pixel data for PBR channels.
            // In Unity Standard Shader:
            // Albedo: RGB color
            // Normal: RGB (XYZ coordinates)
            // Roughness: Grayscale (1.0 = rough, 0.0 = smooth)
            byte[] albedoMap = new byte[width * height * 3];
            byte[] normalMap = new byte[width * height * 3];
            byte[] roughnessMap = new byte[width * height * 3];

            // 3. Generate the texture data procedurally.
            // We use nested loops to iterate through every pixel.
            // This simulates the process of converting a flat image into PBR maps.
            Random noiseGen = new Random(12345); // Seeded for reproducibility

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int index = (y * width + x) * 3;

                    // --- A. Generate Albedo (Color) ---
                    // Logic: Blend base color with a noise factor to simulate surface variation.
                    // If wetness is high, darken the color and shift towards blueish tint.
                    float noise = (float)noiseGen.NextDouble() * 0.2f; // 0.0 to 0.2 variation
                    
                    // Calculate Wetness influence
                    float rMod = baseR - (wetnessFactor * 20);
                    float gMod = baseG - (wetnessFactor * 20);
                    float bMod = baseB - (wetnessFactor * 10); // Less dark on blue channel

                    // Apply noise and clamp values
                    albedoMap[index]     = ClampByte(rMod + noise * 255);
                    albedoMap[index + 1] = ClampByte(gMod + noise * 255);
                    albedoMap[index + 2] = ClampByte(bMod + noise * 255);

                    // --- B. Generate Normal Map ---
                    // Logic: A "flat" normal is (0.5, 0.5, 1.0) in tangent space (RGB 127, 127, 255).
                    // We add "bumps" using sine waves to simulate surface roughness.
                    // Wet surfaces appear "smoother" visually, but we keep the geometric normal.
                    // However, we might compress the normal intensity slightly if the surface is flooded.
                    
                    float xCoord = (float)x / width * 10.0f;
                    float yCoord = (float)y / height * 10.0f;
                    
                    // Simple procedural bump pattern
                    float xNormal = (float)Math.Sin(xCoord) * 0.1f;
                    float yNormal = (float)Math.Cos(yCoord) * 0.1f;
                    
                    // Convert -1..1 range to 0..255 range for RGB storage
                    // X component
                    normalMap[index] = (byte)(127 + (xNormal * 127));
                    // Y component
                    normalMap[index + 1] = (byte)(127 + (yNormal * 127));
                    // Z component (always pointing up mostly)
                    normalMap[index + 2] = (byte)(255 - (Math.Abs(xNormal) + Math.Abs(yNormal)) * 50);

                    // --- C. Generate Roughness Map ---
                    // Logic: Roughness determines how light scatters.
                    // Dry mud is rough (High value, e.g., 0.8).
                    // Wet mud is smooth (Low value, e.g., 0.2) due to water filling crevices.
                    // We calculate base roughness and modulate it by the wetness factor.
                    
                    float baseRoughness = 0.8f; 
                    float currentRoughness = baseRoughness - (wetnessFactor * 0.6f);
                    
                    // Add noise to roughness to prevent uniform surfaces
                    currentRoughness += ((float)noiseGen.NextDouble() - 0.5f) * 0.1f;
                    
                    // Clamp between 0 and 1
                    if (currentRoughness < 0.0f) currentRoughness = 0.0f;
                    if (currentRoughness > 1.0f) currentRoughness = 1.0f;

                    byte roughVal = (byte)(currentRoughness * 255);
                    
                    roughnessMap[index] = roughVal;     // R
                    roughnessMap[index + 1] = roughVal; // G
                    roughnessMap[index + 2] = roughVal; // B
                }
            }

            // 4. Export Data
            // In a real scenario, we would write .png or .tga files here.
            // For this console app, we will write the raw byte data to files to demonstrate the structure.
            Console.WriteLine("Generation complete. Writing files...");
            
            WriteRawFile("albedo.raw", albedoMap);
            WriteRawFile("normal.raw", normalMap);
            WriteRawFile("roughness.raw", roughnessMap);

            Console.WriteLine("Files written to disk.");
            Console.WriteLine("Integration Note: Import 'albedo.raw', 'normal.raw', and 'roughness.raw' into Unity.");
            Console.WriteLine("Use the 'Standard' shader and assign these textures to Albedo, Normal Map, and Roughness slots respectively.");
        }

        // Helper method to clamp float to byte (0-255)
        static byte ClampByte(float value)
        {
            if (value < 0) return 0;
            if (value > 255) return 255;
            return (byte)value;
        }

        // Helper method to write raw binary data (simulating image export)
        static void WriteRawFile(string filename, byte[] data)
        {
            try
            {
                File.WriteAllBytes(filename, data);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing {filename}: {ex.Message}");
            }
        }
    }
}
