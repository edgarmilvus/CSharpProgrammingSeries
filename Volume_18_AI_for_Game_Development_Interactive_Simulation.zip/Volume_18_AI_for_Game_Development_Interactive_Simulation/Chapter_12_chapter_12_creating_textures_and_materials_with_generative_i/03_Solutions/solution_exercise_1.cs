
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using UnityEngine;
using UnityEditor;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Generic;

public class PBRTextureGenerator : EditorWindow
{
    private Texture2D inputTexture;
    private Texture2D generatedNormal;
    private Texture2D generatedRoughness;
    private Texture2D generatedMetallic;

    private bool isProcessing = false;
    private Vector2 scrollPos;

    [MenuItem("Tools/Procedural PBR Generator")]
    public static void ShowWindow()
    {
        GetWindow<PBRTextureGenerator>("PBR Generator");
    }

    private void OnGUI()
    {
        scrollPos = EditorGUILayout.BeginScrollView(scrollPos);

        GUILayout.Label("Input Texture", EditorStyles.boldLabel);
        inputTexture = (Texture2D)EditorGUILayout.ObjectField(inputTexture, typeof(Texture2D), false);

        if (GUILayout.Button("Generate PBR Maps") && inputTexture != null && !isProcessing)
        {
            GenerateMapsAsync();
        }

        if (isProcessing)
        {
            GUILayout.Label("Processing...", EditorStyles.helpBox);
        }

        GUILayout.Space(20);
        GUILayout.Label("Generated Maps", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Normal", GUILayout.Width(50));
        generatedNormal = (Texture2D)EditorGUILayout.ObjectField(generatedNormal, typeof(Texture2D), false);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Roughness", GUILayout.Width(50));
        generatedRoughness = (Texture2D)EditorGUILayout.ObjectField(generatedRoughness, typeof(Texture2D), false);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Metallic", GUILayout.Width(50));
        generatedMetallic = (Texture2D)EditorGUILayout.ObjectField(generatedMetallic, typeof(Texture2D), false);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.EndScrollView();
    }

    private async void GenerateMapsAsync()
    {
        isProcessing = true;
        
        // 1. Texture Analysis & Processing
        int width = inputTexture.width;
        int height = inputTexture.height;
        
        // Get raw pixels (CPU read is slow, but necessary for custom algorithms without Compute Shaders)
        Color[] srcPixels = inputTexture.GetPixels();
        Color[] normalPixels = new Color[width * height];
        Color[] roughPixels = new Color[width * height];
        Color[] metalPixels = new Color[width * height];

        // Calculate average luminance for context (Texture Analysis)
        float avgLuminance = 0f;
        await Task.Run(() => 
        {
            Parallel.For(0, srcPixels.Length, i =>
            {
                float lum = srcPixels[i].grayscale;
                System.Threading.Interlocked.Add(ref avgLuminance, lum);
            });
            avgLuminance /= srcPixels.Length;
        });

        // 2. Sobel Filter & Normal Map Generation
        // We process on a separate thread to keep UI responsive
        await Task.Run(() =>
        {
            Parallel.For(1, height - 1, y =>
            {
                for (int x = 1; x < width - 1; x++)
                {
                    int idx = y * width + x;
                    
                    // --- Sobel Filter for Edge Detection ---
                    // Sample surrounding pixels for luminance
                    float tl = srcPixels[(y - 1) * width + (x - 1)].grayscale;
                    float tc = srcPixels[(y - 1) * width + x].grayscale;
                    float tr = srcPixels[(y - 1) * width + (x + 1)].grayscale;
                    float ml = srcPixels[y * width + (x - 1)].grayscale;
                    float mr = srcPixels[y * width + (x + 1)].grayscale;
                    float bl = srcPixels[(y + 1) * width + (x - 1)].grayscale;
                    float bc = srcPixels[(y + 1) * width + x].grayscale;
                    float br = srcPixels[(y + 1) * width + (x + 1)].grayscale;

                    // Convolution kernels
                    float xSobel = (tl * -1) + (ml * -2) + (bl * -1) + (tr * 1) + (mr * 2) + (br * 1);
                    float ySobel = (tl * -1) + (tc * -2) + (tr * -1) + (bl * 1) + (bc * 2) + (br * 1);

                    // Construct Normal Vector
                    // X = -xSobel, Y = -ySobel (Invert for Unity's coordinate system if needed)
                    // Z = 1.0 / smoothness (Higher contrast = flatter surface)
                    float contrast = Mathf.Abs(xSobel) + Mathf.Abs(ySobel);
                    float zChannel = 1.0f - Mathf.Clamp01(contrast * 5.0f); // Scale factor to control intensity

                    Vector3 normal = new Vector3(-xSobel * 2.0f, -ySobel * 2.0f, zChannel).normalized;

                    // Encode to RGB (Standard Normal Map format: X=Red, Y=Green, Z=Blue)
                    normalPixels[idx] = new Color(normal.x * 0.5f + 0.5f, normal.y * 0.5f + 0.5f, normal.z);

                    // --- Heuristic Roughness/Metallic Estimation ---
                    
                    // Roughness: High frequency noise (variance in local area) -> Higher Roughness
                    float localVariance = (Mathf.Pow(xSobel, 2) + Mathf.Pow(ySobel, 2)) * 0.5f;
                    float roughVal = Mathf.Clamp01(localVariance * 10f + (1.0f - srcPixels[idx].grayscale) * 0.2f);
                    roughPixels[idx] = new Color(roughVal, roughVal, roughVal);

                    // Metallic: Heuristic based on saturation and luminance (e.g., Gold/Steel logic)
                    // Desaturated yellows/greys = Metallic
                    float saturation = (Mathf.Max(srcPixels[idx].r, Mathf.Max(srcPixels[idx].g, srcPixels[idx].b)) - 
                                       Mathf.Min(srcPixels[idx].r, Mathf.Min(srcPixels[idx].g, srcPixels[idx].b)));
                    float metalVal = 0f;
                    if (saturation < 0.2f && srcPixels[idx].grayscale > 0.4f) 
                    {
                        metalVal = 0.8f; // Likely metal
                    }
                    else if (srcPixels[idx].r > 0.6f && srcPixels[idx].g > 0.4f && srcPixels[idx].b < 0.2f)
                    {
                        metalVal = 1.0f; // Gold-like
                    }
                    metalPixels[idx] = new Color(metalVal, metalVal, metalVal);
                }
            });
        });

        // 3. Create Textures and Apply Import Settings
        generatedNormal = CreateTexture(width, height, normalPixels, "NormalMap", true); // Linear
        generatedRoughness = CreateTexture(width, height, roughPixels, "RoughnessMap", true); // Linear
        generatedMetallic = CreateTexture(width, height, metalPixels, "MetallicMap", true); // Linear

        isProcessing = false;
        Repaint();
    }

    private Texture2D CreateTexture(int width, int height, Color[] pixels, string suffix, bool linear)
    {
        Texture2D tex = new Texture2D(width, height, TextureFormat.RGBA32, false, linear);
        tex.SetPixels(pixels);
        tex.Apply();

        // Save to disk to make it persistent and importable
        string path = AssetDatabase.GetAssetPath(inputTexture);
        string dir = System.IO.Path.GetDirectoryName(path);
        string fileName = System.IO.Path.GetFileNameWithoutExtension(path);
        
        string savePath = $"{dir}/{fileName}_{suffix}.png";
        System.IO.File.WriteAllBytes(savePath, tex.EncodeToPNG());
        
        AssetDatabase.Refresh();

        // Configure Import Settings
        TextureImporter importer = (TextureImporter)AssetImporter.GetAtPath(savePath);
        if (importer != null)
        {
            importer.textureType = suffix == "NormalMap" ? TextureImporterType.NormalMap : TextureImporterType.Default;
            importer.sRGBTexture = !linear; // Linear for data maps
            importer.filterMode = FilterMode.Bilinear;
            importer.wrapMode = TextureWrapMode.Repeat;
            
            if (suffix == "NormalMap")
            {
                importer.textureShape = TextureImporterShape.Texture2D;
            }

            AssetDatabase.ImportAsset(savePath);
        }

        return AssetDatabase.LoadAssetAtPath<Texture2D>(savePath);
    }
}
