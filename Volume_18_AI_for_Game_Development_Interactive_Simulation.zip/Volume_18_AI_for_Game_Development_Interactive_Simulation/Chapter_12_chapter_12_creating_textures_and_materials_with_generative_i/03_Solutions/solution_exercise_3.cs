
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using UnityEngine;
using UnityEditor;

public class ProceduralMaskGenerator : MonoBehaviour
{
    public Material targetMaterial;
    public string texturePropertyName = "_MaskTexture";
    public int resolution = 512;
    public float noiseScale = 20f;

    [ContextMenu("Generate Perlin Mask")]
    public void GenerateMask()
    {
        if (targetMaterial == null) return;

        Texture2D maskTex = new Texture2D(resolution, resolution, TextureFormat.R8, false);
        maskTex.wrapMode = TextureWrapMode.Repeat;
        maskTex.filterMode = FilterMode.Bilinear;

        Color[] pixels = new Color[resolution * resolution];

        for (int y = 0; y < resolution; y++)
        {
            for (int x = 0; x < resolution; x++)
            {
                // Generate 2D Perlin Noise
                float u = x / (float)resolution;
                float v = y / (float)resolution;
                float noiseVal = Mathf.PerlinNoise(u * noiseScale, v * noiseScale);
                
                // Store in Red channel only
                pixels[y * resolution + x] = new Color(noiseVal, 0, 0, 1);
            }
        }

        maskTex.SetPixels(pixels);
        maskTex.Apply();

        // Assign to material
        targetMaterial.SetTexture(texturePropertyName, maskTex);

        // Save asset for reuse (Optional, but good practice)
        #if UNITY_EDITOR
        string path = $"Assets/Masks/GeneratedMask_{System.DateTime.Now.Ticks}.png";
        System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
        System.IO.File.WriteAllBytes(path, maskTex.EncodeToPNG());
        AssetDatabase.Refresh();
        #endif
    }
}
