
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.AddressableAssets; // Requires Addressables package
using UnityEngine.ResourceManagement.AsyncOperations;

public enum MaterialState { Dry, Wet, Burnt }

[System.Serializable]
public class StateTextures
{
    public MaterialState state;
    public AssetReferenceT<Texture2D> albedoRef;
    public AssetReferenceT<Texture2D> normalRef;
    public AssetReferenceT<Texture2D> roughnessRef;
}

public class DynamicMaterialController : MonoBehaviour
{
    [Header("Configuration")]
    public Material targetMaterial; // Material using a shader that supports texture blending (_TextureBlend)
    public float transitionDuration = 2.0f;
    
    [Header("Texture Sets")]
    public List<StateTextures> textureSets = new List<StateTextures>();

    [Header("State Properties")]
    public float drySmoothness = 0.1f;
    public float wetSmoothness = 0.8f;
    public float dryMetallic = 0.0f;
    public float wetMetallic = 0.1f; // Water adds slight metallic look
    public float normalIntensity = 1.0f;

    private MaterialState currentState;
    private Coroutine transitionCoroutine;
    
    // Event for decoupling
    public delegate void StateChangeHandler(MaterialState newState);
    public event StateChangeHandler OnStateChanged;

    private void Start()
    {
        // Initialize in Dry state
        ChangeState(MaterialState.Dry);
    }

    // Call this method from triggers (e.g., RainTrigger)
    public void ChangeState(MaterialState newState)
    {
        if (currentState == newState) return;

        currentState = newState;
        OnStateChanged?.Invoke(newState);

        // Stop existing transition
        if (transitionCoroutine != null) StopCoroutine(transitionCoroutine);

        // Start new transition
        transitionCoroutine = StartCoroutine(TransitionStateAsync(newState));
    }

    private IEnumerator TransitionStateAsync(MaterialState targetState)
    {
        // 1. Find target textures
        StateTextures targetSet = textureSets.Find(s => s.state == targetState);
        if (targetSet == null) yield break;

        // 2. Async Load Textures (Texture Streaming)
        // Using Addressables for robust loading
        var albedoOp = targetSet.albedoRef.LoadAssetAsync();
        var normalOp = targetSet.normalRef.LoadAssetAsync();
        var roughOp = targetSet.roughnessRef.LoadAssetAsync();

        // Wait for all to load
        yield return albedoOp;
        yield return normalOp;
        yield return roughOp;

        if (albedoOp.Status != AsyncOperationStatus.Succeeded || 
            normalOp.Status != AsyncOperationStatus.Succeeded) 
        {
            Debug.LogError("Failed to load textures.");
            yield break;
        }

        // 3. Apply Textures immediately (to swap state)
        // Note: To prevent "flash", the shader should have a default fallback texture
        targetMaterial.SetTexture("_BaseMap", albedoOp.Result); // URP naming convention
        targetMaterial.SetTexture("_NormalMap", normalOp.Result);
        targetMaterial.SetTexture("_MetallicGlossMap", roughOp.Result); // R channel used for metallic

        // 4. Interpolate Shader Properties
        float startBlend = 0.0f; // Assuming previous state was fully blended out
        float targetBlend = 1.0f;
        
        float elapsed = 0f;
        float startSmooth = targetMaterial.GetFloat("_Smoothness");
        float startMetallic = targetMaterial.GetFloat("_Metallic");
        
        float targetSmooth = (targetState == MaterialState.Wet) ? wetSmoothness : drySmoothness;
        float targetMetal = (targetState == MaterialState.Wet) ? wetMetallic : dryMetallic;

        while (elapsed < transitionDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / transitionDuration);

            // Blend textures (requires shader support for _TextureBlend lerp)
            // Or here we blend properties which is cheaper
            targetMaterial.SetFloat("_Smoothness", Mathf.Lerp(startSmooth, targetSmooth, t));
            targetMaterial.SetFloat("_Metallic", Mathf.Lerp(startMetallic, targetMetal, t));
            
            // If using texture blending in shader:
            // targetMaterial.SetFloat("_TextureBlend", t);

            yield return null;
        }

        // Cleanup
        // Optional: Release Addressables if memory is tight
        // targetSet.albedoRef.ReleaseAsset(); 
    }
    
    // Helper for Editor Testing
    [ContextMenu("Set Wet")]
    public void SetWet() => ChangeState(MaterialState.Wet);
    
    [ContextMenu("Set Dry")]
    public void SetDry() => ChangeState(MaterialState.Dry);
}
