
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using UnityEngine;
using System.Diagnostics;
using System.Threading.Tasks;

public class ComputeTextureGenerator : MonoBehaviour
{
    public ComputeShader noiseShader;
    public int resolution = 1024;
    public float scale = 10f;
    public int octaves = 4;
    
    public Material targetMaterial; // Material to apply the result to

    [ContextMenu("Run Compute Benchmark")]
    public void RunCompute()
    {
        Stopwatch sw = Stopwatch.StartNew();
        
        // 1. Setup RenderTexture
        RenderTexture rt = new RenderTexture(resolution, resolution, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear);
        rt.enableRandomWrite = true;
        rt.Create();

        // 2. Configure Shader
        int kernelHandle = noiseShader.FindKernel("GenerateTexture");
        noiseShader.SetTexture(kernelHandle, "Result", rt);
        noiseShader.SetFloat("Resolution", resolution);
        noiseShader.SetFloat("Scale", scale);
        noiseShader.SetInt("Octaves", octaves);

        // 3. Dispatch
        // Group size is usually 8x8, so divide resolution by 8
        noiseShader.Dispatch(kernelHandle, resolution / 8, resolution / 8, 1);

        sw.Stop();
        Debug.Log($"Compute Shader Time: {sw.ElapsedMilliseconds} ms");

        // Apply to material
        if (targetMaterial != null)
        {
            targetMaterial.SetTexture("_BaseMap", rt); // URP
        }
    }

    [ContextMenu("Run CPU Benchmark")]
    public async void RunCPU()
    {
        Stopwatch sw = Stopwatch.StartNew();
        
        Texture2D cpuTex = new Texture2D(resolution, resolution, TextureFormat.RGBA32, false);
        Color[] pixels = new Color[resolution * resolution];

        await Task.Run(() =>
        {
            // Simple Perlin Noise approximation for CPU comparison
            Parallel.For(0, resolution, y =>
            {
                for (int x = 0; x < resolution; x++)
                {
                    float u = x / (float)resolution * scale;
                    float v = y / (float)resolution * scale;
                    float noise = Mathf.PerlinNoise(u, v); // Note: Unity's Perlin is 2D only
                    
                    // Fake octaves for comparison
                    for(int o = 1; o < octaves; o *= 2)
                    {
                        noise += Mathf.PerlinNoise(u * o, v * o) * 0.5f;
                    }
                    
                    pixels[y * resolution + x] = new Color(noise, noise, noise);
                }
            });
        });
        
        cpuTex.SetPixels(pixels);
        cpuTex.Apply();
        
        sw.Stop();
        Debug.Log($"CPU Time: {sw.ElapsedMilliseconds} ms");
    }
}
