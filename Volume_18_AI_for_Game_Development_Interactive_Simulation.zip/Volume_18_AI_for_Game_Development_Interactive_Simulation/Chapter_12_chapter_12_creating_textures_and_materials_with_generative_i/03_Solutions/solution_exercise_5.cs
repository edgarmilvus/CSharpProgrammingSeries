
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;

// 1. Preset Data Structure
public class MaterialRandomizationPreset : ScriptableObject
{
    public string presetName;
    public Vector2 tilingRange = new Vector2(1, 2);
    public Vector2 smoothnessRange = new Vector2(0.1f, 0.9f);
    public Vector2 normalScaleRange = new Vector2(0.5f, 1.5f);
    public bool restrictHue = false;
    public Color forcedHue = Color.white; 
}

// 2. Metadata Structure for JSON
[System.Serializable]
public class AssetMetadata
{
    public string id;
    public string style;
}

[System.Serializable]
public class MetadataList
{
    public List<AssetMetadata> assets;
}

// 3. Editor Window
public class MaterialRandomizer : EditorWindow
{
    private MaterialRandomizationPreset currentPreset;
    private string jsonPath = "Assets/metadata.json";
    private MetadataList metadataCache;

    [MenuItem("Tools/Material Randomizer")]
    public static void ShowWindow()
    {
        GetWindow<MaterialRandomizer>("Randomizer");
    }

    private void OnGUI()
    {
        GUILayout.Label("Settings", EditorStyles.boldLabel);
        
        currentPreset = (MaterialRandomizationPreset)EditorGUILayout.ObjectField("Preset", currentPreset, typeof(MaterialRandomizationPreset), false);
        
        if (GUILayout.Button("Create New Preset"))
        {
            var path = EditorUtility.SaveFilePanelInProject("Save Preset", "NewPreset", "asset", "Select location");
            if (!string.IsNullOrEmpty(path))
            {
                var preset = CreateInstance<MaterialRandomizationPreset>();
                AssetDatabase.CreateAsset(preset, path);
                currentPreset = preset;
            }
        }

        GUILayout.Space(10);
        GUILayout.Label("Metadata", EditorStyles.boldLabel);
        jsonPath = EditorGUILayout.TextField("JSON Path", jsonPath);

        if (GUILayout.Button("Load Metadata (Async)"))
        {
            LoadMetadataAsync();
        }

        GUILayout.Space(10);
        if (GUILayout.Button("Randomize Selection"))
        {
            RandomizeSelected();
        }
    }

    private async void LoadMetadataAsync()
    {
        if (!File.Exists(jsonPath))
        {
            Debug.LogError("JSON file not found.");
            return;
        }

        // Read file async to avoid freezing UI on large files
        string json = await File.ReadAllTextAsync(jsonPath);
        
        // Parse (Note: JsonUtility requires a wrapper for Lists)
        metadataCache = JsonUtility.FromJson<MetadataList>(json);
        
        Debug.Log($"Loaded metadata for {metadataCache.assets.Count} assets.");
    }

    private void RandomizeSelected()
    {
        if (Selection.gameObjects.Length == 0) return;
        
        // Iterate selection
        foreach (GameObject go in Selection.gameObjects)
        {
            Renderer rend = go.GetComponent<Renderer>();
            if (rend == null) continue;

            // Support multi-material renderers
            foreach (Material mat in rend.sharedMaterials)
            {
                if (mat == null) continue;

                // 2. Material Instancing & Undo
                // We check if the material is an instance or asset. 
                // To support Undo properly, we record the object.
                Undo.RecordObject(mat, "Randomize Material");

                // If we want to avoid modifying the source asset, we can instance it here.
                // However, Undo.RecordObject handles modification of the existing reference.
                
                ApplyRandomization(mat, go.name);
            }
        }
    }

    private void ApplyRandomization(Material mat, string objectName)
    {
        if (currentPreset == null) return;

        // Check Metadata for Constraints
        string style = "default";
        if (metadataCache != null)
        {
            var data = metadataCache.assets.Find(a => a.id == objectName);
            if (data != null) style = data.style;
        }

        // 1. Tiling & Offset
        float tilingX = Random.Range(currentPreset.tilingRange.x, currentPreset.tilingRange.y);
        float tilingY = Random.Range(currentPreset.tilingRange.x, currentPreset.tilingRange.y);
        mat.SetTextureScale("_MainTex", new Vector2(tilingX, tilingY));
        mat.SetTextureOffset("_MainTex", Vector2.zero); // Reset offset

        // 2. Normal Scale
        float nScale = Random.Range(currentPreset.normalScaleRange.x, currentPreset.normalScaleRange.y);
        mat.SetFloat("_NormalScale", nScale);

        // 3. Smoothness
        float smooth = Random.Range(currentPreset.smoothnessRange.x, currentPreset.smoothnessRange.y);
        
        // Style Constraints
        if (style == "sci-fi")
        {
            // Sci-fi: Cool colors, higher metallic, specific smoothness
            mat.SetFloat("_Metallic", 0.8f);
            smooth = Mathf.Clamp(smooth, 0.6f, 0.9f); // Force glossy
            mat.color = Color.Lerp(Color.cyan, Color.blue, Random.value);
        }
        else if (style == "organic")
        {
            mat.SetFloat("_Metallic", 0.0f);
            smooth = Mathf.Clamp(smooth, 0.1f, 0.4f); // Force matte
        }

        mat.SetFloat("_Smoothness", smooth);

        // 4. Albedo Tint (Hue Variation)
        if (currentPreset.restrictHue)
        {
            mat.color = currentPreset.forcedHue;
        }
        else
        {
            // Generate random hue but keep saturation/value roughly similar
            float h, s, v;
            Color.RGBToHSV(mat.color, out h, out s, out v);
            h = Random.Range(0f, 1f);
            mat.color = Color.HSVToRGB(h, s, v);
        }
    }
}
