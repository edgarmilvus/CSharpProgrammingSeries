
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# you can find it on stores: 
# 
# https://www.amazon.com/dp/B0GKJ3NYL6 or https://tinyurl.com/CSharpProgrammingBooks or 
# https://leanpub.com/u/edgarmilvus (quantity discounts)
# 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.cs
# Description: Theoretical Foundations
# ==========================================

// Conceptual representation of a command with compensation logic
public interface IDistributedCommand
{
    Task ExecuteAsync();
    Task CompensateAsync(); // The inverse operation
}

// The Unit of Work coordinates these commands
public class DistributedUnitOfWork
{
    private readonly Stack<IDistributedCommand> _executedCommands = new();

    public async Task CommitAsync()
    {
        try
        {
            // In a real scenario, we might batch these, 
            // but for atomicity, we execute sequentially 
            // and track success.
            foreach (var command in _executedCommands)
            {
                await command.ExecuteAsync();
            }
        }
        catch (Exception ex)
        {
            // If any command fails, trigger compensation
            // for all previously successful commands.
            await RollbackAsync();
            throw new TransactionFailedException("Distributed transaction failed. Changes rolled back.", ex);
        }
    }

    private async Task RollbackAsync()
    {
        while (_executedCommands.Count > 0)
        {
            var command = _executedCommands.Pop();
            try
            {
                await command.CompensateAsync();
            }
            catch (Exception compEx)
            {
                // Log critical error: System is in an inconsistent state.
                // This requires manual intervention or a background reconciliation job.
            }
        }
    }

    public void Enqueue(IDistributedCommand command)
    {
        _executedCommands.Push(command);
    }
}
