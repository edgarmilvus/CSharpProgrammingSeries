
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

// Define a simple enum for ticket urgency
public enum TicketUrgency
{
    Low,
    Medium,
    High,
    Critical
}

// Define a simple enum for ticket intent/category
public enum TicketIntent
{
    GeneralInquiry,
    TechnicalSupport,
    Billing,
    Returns
}

// Represents a customer support ticket
public record SupportTicket(
    string Id,
    string CustomerEmail,
    string Subject,
    string Body
);

// Represents the analyzed result of a ticket
public record AnalyzedTicket(
    string Id,
    TicketUrgency Urgency,
    TicketIntent Intent,
    string SuggestedTeam
);

// The core service that performs the triage logic
public class TriageService
{
    // In a real system, this would be a call to an LLM or a complex NLP model.
    // For this "Hello World" example, we use simple keyword matching.
    public AnalyzedTicket AnalyzeTicket(SupportTicket ticket)
    {
        var fullText = $"{ticket.Subject} {ticket.Body}".ToLower();

        // 1. Determine Urgency
        var urgency = DetermineUrgency(fullText);

        // 2. Determine Intent
        var intent = DetermineIntent(fullText);

        // 3. Map to a team
        var team = MapToTeam(intent, urgency);

        return new AnalyzedTicket(ticket.Id, urgency, intent, team);
    }

    private TicketUrgency DetermineUrgency(string text)
    {
        // Critical keywords indicate immediate, severe issues
        var criticalKeywords = new[] { "refund now", "sue", "lawyer", "broken", "shattered" };
        if (criticalKeywords.Any(k => text.Contains(k)))
            return TicketUrgency.Critical;

        // High urgency keywords indicate strong dissatisfaction or time-sensitive issues
        var highKeywords = new[] { "urgent", "asap", "immediately", "furious", "angry" };
        if (highKeywords.Any(k => text.Contains(k)))
            return TicketUrgency.High;

        // Medium urgency is for standard requests
        var mediumKeywords = new[] { "help", "issue", "problem", "not working" };
        if (mediumKeywords.Any(k => text.Contains(k)))
            return TicketUrgency.Medium;

        // Default to Low urgency
        return TicketUrgency.Low;
    }

    private TicketIntent DetermineIntent(string text)
    {
        // Intent-specific keywords
        if (text.Contains("refund") || text.Contains("return") || text.Contains("exchange"))
            return TicketIntent.Returns;

        if (text.Contains("login") || text.Contains("password") || text.Contains("error"))
            return TicketIntent.TechnicalSupport;

        if (text.Contains("invoice") || text.Contains("charge") || text.Contains("payment"))
            return TicketIntent.Billing;

        // Default to General Inquiry
        return TicketIntent.GeneralInquiry;
    }

    private string MapToTeam(TicketIntent intent, TicketUrgency urgency)
    {
        // Simple mapping logic. In reality, this could be a dynamic routing table.
        if (intent == TicketIntent.Returns && urgency >= TicketUrgency.High)
            return "Tier 2 Returns Team";

        if (intent == TicketIntent.Returns)
            return "Standard Returns Team";

        if (intent == TicketIntent.TechnicalSupport)
            return "Technical Support Team";

        if (intent == TicketIntent.Billing)
            return "Billing Department";

        // General inquiries go to the front line
        return "General Support Queue";
    }
}

// Main program execution
public class Program
{
    public static void Main(string[] args)
    {
        // 1. Simulate an incoming customer ticket (the "Hello World" input)
        var incomingTicket = new SupportTicket(
            Id: "TICKET-7890",
            CustomerEmail: "frustrated.user@example.com",
            Subject: "My new laptop is shattered!",
            Body: "I just received my order and the screen is completely broken. This is unacceptable. I demand a refund immediately or I will contact my lawyer."
        );

        // 2. Instantiate our Triage Service
        var triageService = new TriageService();

        // 3. Process the ticket
        var analyzedResult = triageService.AnalyzeTicket(incomingTicket);

        // 4. Output the results in a structured format (simulating a webhook or API response)
        var jsonOptions = new JsonSerializerOptions { WriteIndented = true };
        string resultJson = JsonSerializer.Serialize(analyzedResult, jsonOptions);

        Console.WriteLine("--- Automated Triage Result ---");
        Console.WriteLine(resultJson);
        Console.WriteLine("-------------------------------");
        Console.WriteLine($"Action: Ticket routed to '{analyzedResult.SuggestedTeam}'.");
    }
}
