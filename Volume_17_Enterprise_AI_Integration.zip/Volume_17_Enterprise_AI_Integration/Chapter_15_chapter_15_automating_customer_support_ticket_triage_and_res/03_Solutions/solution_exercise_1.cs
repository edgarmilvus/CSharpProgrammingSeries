
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.AI.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.AI.OpenAI.ChatCompletion;
using Polly;
using System.Text.Json;
using System.Text.Json.Serialization;

// Strongly typed result model
public record TicketClassificationResult(
    [property: JsonPropertyName("intent")] string Intent, 
    [property: JsonPropertyName("urgency")] string Urgency, 
    [property: JsonPropertyName("rationale")] string Rationale
);

public class TicketContextPlugin
{
    // Simulates a legacy CRM API call
    [KernelFunction("get_user_history")]
    public async Task<string> GetUserHistoryAsync(string userEmail)
    {
        // Simulate network delay
        await Task.Delay(100); 
        
        // Simulate a transient fault (10% chance)
        if (Random.Shared.Next(0, 10) == 0) 
            throw new HttpRequestException("Legacy CRM API timed out.");

        // Mock data
        var history = new[]
        {
            new { id = 101, status = "resolved", category = "billing" },
            new { id = 102, status = "open", category = "technical" }
        };
        
        return JsonSerializer.Serialize(history);
    }
}

public class ClassificationOrchestrator
{
    private readonly IKernel _kernel;
    private readonly ResiliencePipeline _resiliencePipeline;

    public ClassificationOrchestrator(IKernel kernel)
    {
        _kernel = kernel;
        
        // Define resilience policy: Retry 3 times with exponential backoff
        _resiliencePipeline = new ResiliencePipelineBuilder()
            .AddRetry(new Polly.Retry.RetryStrategyOptions 
            { 
                ShouldHandle = new PredicateBuilder().Handle<HttpRequestException>(),
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromMilliseconds(200),
                BackoffType = Polly.DelayType.Exponential
            })
            .Build();
    }

    public async Task<TicketClassificationResult> ClassifyTicket(string rawTicket, string userEmail)
    {
        // 1. Fetch context with resilience
        string historyJson = await _resiliencePipeline.ExecuteAsync(
            async token => await _kernel.Plugins.GetPlugin("TicketContextPlugin")["GetUserHistoryAsync"](userEmail)
        );

        // 2. Construct the semantic prompt
        var prompt = $"""
            Classify the following support ticket.
            
            **User History:** {historyJson}
            **Ticket Content:** {rawTicket}
            
            Valid Intents: Billing Inquiry, Technical Support, Feature Request, Account Suspension.
            Valid Urgency: High, Medium, Low.
            
            Respond strictly in JSON format: {{ "intent": "...", "urgency": "...", "rationale": "..." }}
            """;

        // 3. Invoke LLM
        var result = await _kernel.CreateChatCompletionService().GetChatMessageContentsAsync(
            new ChatHistory(prompt),
            new OpenAIRequestSettings() { MaxTokens = 200 }
        );

        // 4. Parse Result
        try 
        {
            var classification = JsonSerializer.Deserialize<TicketClassificationResult>(result[0].Content);
            return classification;
        }
        catch
        {
            // Fallback if parsing fails
            return new TicketClassificationResult("Manual Review", "Low", "LLM output parsing failed");
        }
    }
}
