
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Polly;
using Polly.CircuitBreaker;
using Polly.Timeout;
using System.Diagnostics;

public class IncomingTicket
{
    public string Id { get; set; }
    public string Body { get; set; }
    public string UserEmail { get; set; }
}

public class TicketProcessingResult
{
    public bool Success { get; set; }
    public string DraftResponse { get; set; }
    public List<string> ActionsTaken { get; set; } = new();
    public string ErrorMessage { get; set; }
}

public class AutomatedSupportService
{
    private readonly IKernel _kernel;
    private readonly KnowledgeBaseRepository _kbRepo;
    private readonly ActionDispatcher _actionDispatcher;
    private readonly LegacyCommandFactory _commandFactory;
    private readonly ILogger<AutomatedSupportService> _logger;
    private readonly ResiliencePipeline _resiliencePipeline;

    public AutomatedSupportService(
        IKernel kernel, 
        KnowledgeBaseRepository kbRepo, 
        ActionDispatcher actionDispatcher, 
        LegacyCommandFactory commandFactory,
        ILogger<AutomatedSupportService> logger)
    {
        _kernel = kernel;
        _kbRepo = kbRepo;
        _actionDispatcher = actionDispatcher;
        _commandFactory = commandFactory;
        _logger = logger;

        // Define comprehensive resilience policy
        _resiliencePipeline = new ResiliencePipelineBuilder()
            .AddTimeout(TimeSpan.FromSeconds(5)) // Global timeout per external call
            .AddRetry(new Polly.Retry.RetryStrategyOptions
            {
                ShouldHandle = new PredicateBuilder()
                    .Handle<TimeoutException>()
                    .Handle<HttpRequestException>()
                    .Handle<SqlException>(),
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromMilliseconds(500),
                BackoffType = Polly.DelayType.Exponential
            })
            .AddCircuitBreaker(new Polly.CircuitBreaker.CircuitBreakerStrategyOptions
            {
                ShouldHandle = new PredicateBuilder().Handle<Exception>(),
                FailureRatio = 0.3, // Break if 30% of calls fail
                MinimumThroughput = 5,
                BreakDuration = TimeSpan.FromSeconds(30)
            })
            .Build();
    }

    public async Task<TicketProcessingResult> ProcessIncomingTicketAsync(IncomingTicket ticket)
    {
        var result = new TicketProcessingResult();
        var stopwatch = Stopwatch.StartNew();

        try
        {
            _logger.LogInformation("Processing ticket {TicketId}", ticket.Id);

            // 1. Classification (wrapped in resilience)
            var classification = await _resiliencePipeline.ExecuteAsync(async token =>
            {
                // Re-use the logic from Exercise 1 (simplified here for brevity)
                var orchestrator = new ClassificationOrchestrator(_kernel);
                return await orchestrator.ClassifyTicket(ticket.Body, ticket.UserEmail);
            });

            _logger.LogInformation("Ticket {TicketId} classified as {Intent} ({Urgency})", 
                ticket.Id, classification.Intent, classification.Urgency);

            // 2. Knowledge Base Retrieval (wrapped in resilience)
            var kbArticles = await _resiliencePipeline.ExecuteAsync(async token =>
            {
                return await _kbRepo.SearchArticlesAsync(ticket.Body, classification.Intent);
            });

            // 3. Draft Generation (wrapped in resilience)
            var contextBuilder = new ContextBuilder();
            var promptContext = contextBuilder.BuildPrompt(ticket.Body, classification, kbArticles);
            
            var draftResult = await _resiliencePipeline.ExecuteAsync(async token =>
            {
                var generator = new DraftGenerator(_kernel);
                return await generator.GenerateDraftResponse(promptContext);
            });

            // 4. Check Confidence
            if (draftResult.Confidence < 0.7)
            {
                result.Success = false;
                result.ErrorMessage = "Low confidence draft generated. Flagged for Human Review.";
                result.ActionsTaken.Add("FlaggedForReview");
                return result;
            }

            result.DraftResponse = draftResult.Response;
            result.ActionsTaken.Add("DraftGenerated");

            // 5. Trigger Legacy Actions (Fire and Forget)
            var command = _commandFactory.CreateCommand(classification, ticket.Body, ticket.UserEmail);
            _actionDispatcher.Dispatch(command);
            result.ActionsTaken.Add($"LegacyCommandDispatched: {command.GetType().Name}");

            result.Success = true;
            _logger.LogInformation("Ticket {TicketId} processed successfully in {ElapsedMs}ms", ticket.Id, stopwatch.ElapsedMilliseconds);
        }
        catch (BrokenCircuitException ex)
        {
            // Circuit breaker is open
            result.Success = false;
            result.ErrorMessage = "External system failure (Circuit Breaker Open). Please try later.";
            _logger.LogError(ex, "Circuit breaker open for ticket {TicketId}", ticket.Id);
        }
        catch (Exception ex)
        {
            // Catch-all for unexpected errors
            result.Success = false;
            result.ErrorMessage = "An unexpected error occurred.";
            _logger.LogError(ex, "Failed to process ticket {TicketId}", ticket.Id);
        }

        return result;
    }
}

// Extension method for DI setup
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddAutomatedSupport(this IServiceCollection services)
    {
        services.AddSingleton<IKernel>(sp => 
        {
            // Configure Kernel
            var kernel = new KernelBuilder()
                .WithAzureChatCompletionService("deployment-name", "endpoint", "api-key")
                .Build();
            
            // Register Plugin
            kernel.ImportPlugin(new TicketContextPlugin(), "TicketContextPlugin");
            return kernel;
        });

        services.AddSingleton<KnowledgeBaseRepository>();
        services.AddSingleton<ActionDispatcher>();
        services.AddSingleton<LegacyCommandFactory>();
        services.AddTransient<AutomatedSupportService>();
        
        return services;
    }
}
