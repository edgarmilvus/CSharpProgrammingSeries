
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Xml.Linq;
using System.Threading.Tasks;
using System.Threading.Channels;

public interface ILegacyCommand
{
    Task ExecuteAsync();
}

// 1. Concrete Commands
public class SuspendAccountCommand : ILegacyCommand
{
    private readonly string _userEmail;
    public SuspendAccountCommand(string userEmail) => _userEmail = userEmail;

    public async Task ExecuteAsync()
    {
        var payload = new XDocument(
            new XElement("Command", 
                new XElement("Action", "Suspend"),
                new XElement("User", _userEmail)
            )
        );
        // Simulate API call
        await Console.Out.WriteLineAsync($"[Legacy ERP] Executing: {payload}");
    }
}

public class PriorityInvoiceLookupCommand : ILegacyCommand
{
    private readonly string _userEmail;
    public PriorityInvoiceLookupCommand(string userEmail) => _userEmail = userEmail;

    public async Task ExecuteAsync()
    {
        var payload = new XDocument(
            new XElement("Command",
                new XElement("Action", "PriorityLookup"),
                new XElement("User", _userEmail)
            )
        );
        await Console.Out.WriteLineAsync($"[Legacy ERP] Executing: {payload}");
    }
}

public class LogFeatureRequestCommand : ILegacyCommand
{
    private readonly string _ticketDetails;
    public LogFeatureRequestCommand(string ticketDetails) => _ticketDetails = ticketDetails;

    public async Task ExecuteAsync()
    {
        var payload = new XDocument(
            new XElement("Command",
                new XElement("Action", "LogFeature"),
                new XElement("Details", _ticketDetails)
            )
        );
        // Simulate long-running legacy call
        await Task.Delay(2000); 
        await Console.Out.WriteLineAsync($"[Legacy ERP] Feature Logged: {payload}");
    }
}

// 2. Factory
public class LegacyCommandFactory
{
    public ILegacyCommand CreateCommand(TicketClassificationResult classification, string rawTicket, string userEmail)
    {
        return classification.Intent switch
        {
            "Account Suspension" => new SuspendAccountCommand(userEmail),
            "Billing Inquiry" when classification.Urgency == "High" => new PriorityInvoiceLookupCommand(userEmail),
            "Feature Request" => new LogFeatureRequestCommand(rawTicket),
            _ => new NoOpCommand() // Handle cases with no specific legacy action
        };
    }
}

public class NoOpCommand : ILegacyCommand
{
    public async Task ExecuteAsync() => await Task.CompletedTask;
}

// 3. Dispatcher with Fire-and-Forget
public class ActionDispatcher
{
    // Channel for safe background processing
    private readonly Channel<ILegacyCommand> _channel = Channel.CreateUnbounded<ILegacyCommand>();

    public ActionDispatcher()
    {
        // Start the background consumer
        _ = Task.Run(ProcessQueueAsync);
    }

    public void Dispatch(ILegacyCommand command)
    {
        // Non-blocking write to channel
        _channel.Writer.TryWrite(command);
    }

    private async Task ProcessQueueAsync()
    {
        await foreach (var command in _channel.Reader.ReadAllAsync())
        {
            try
            {
                // Execute safely in background
                await command.ExecuteAsync();
            }
            catch (Exception ex)
            {
                // Log error, don't crash the background thread
                Console.WriteLine($"Error executing legacy command: {ex.Message}");
            }
        }
    }
}
