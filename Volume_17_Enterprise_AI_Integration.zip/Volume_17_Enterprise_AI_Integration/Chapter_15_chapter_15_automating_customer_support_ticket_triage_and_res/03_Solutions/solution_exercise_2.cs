
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System.Data.SqlClient;
using System.Text;
using Microsoft.SemanticKernel;

public class KnowledgeBaseRepository
{
    // Simulated database data
    private static readonly List<(string Title, string Content)> _articles = new()
    {
        ("Reset Password", "To reset your password, go to Settings > Security."),
        ("Billing Dispute", "Invoices can be disputed within 30 days via the Billing Portal."),
        ("System Outage", "We are currently experiencing a partial outage in the EU region.")
    };

    public async Task<List<string>> SearchArticlesAsync(string query, string intentCategory)
    {
        // Simulate SQL connection latency
        await Task.Delay(50);

        // Simulate vector search via simple text overlap (Jaccard Index simulation)
        var queryWords = new HashSet<string>(query.Split(' ', StringSplitOptions.RemoveEmptyEntries));
        
        var results = _articles
            .Where(a => a.Content.Contains(query, StringComparison.OrdinalIgnoreCase) || 
                        a.Title.Contains(intentCategory, StringComparison.OrdinalIgnoreCase))
            .Select(a => a.Content)
            .ToList();

        return results.Take(3).ToList(); // Return top 3
    }
}

public class ContextBuilder
{
    private const int MaxTokenLimit = 4000; // Simulated limit
    private const int ApproxCharsPerToken = 4;

    public string BuildPrompt(string rawTicket, TicketClassificationResult classification, List<string> kbArticles)
    {
        var sb = new StringBuilder();
        
        sb.AppendLine($"Ticket: {rawTicket}");
        sb.AppendLine($"Intent: {classification.Intent}");
        sb.AppendLine($"Urgency: {classification.Urgency}");
        sb.AppendLine("Relevant Knowledge Base Articles:");
        
        foreach (var article in kbArticles)
        {
            sb.AppendLine($"- {article}");
        }

        var prompt = sb.ToString();

        // Truncate if exceeding simulated token limit
        if (prompt.Length > MaxTokenLimit * ApproxCharsPerToken)
        {
            return prompt.Substring(0, (MaxTokenLimit * ApproxCharsPerToken) - 50) + "... [Truncated]";
        }

        return prompt;
    }
}

public class DraftGenerator
{
    private readonly IKernel _kernel;

    public DraftGenerator(IKernel kernel) => _kernel = kernel;

    public async Task<(string Response, double Confidence)> GenerateDraftResponse(string context)
    {
        var prompt = $"""
            You are a helpful support agent. Use the following context to draft a response.
            
            Context:
            {context}
            
            Provide a helpful response and a confidence score (0.0 to 1.0) on a new line labeled 'Confidence:'.
            """;

        var result = await _kernel.CreateChatCompletionService().GetChatMessageContentsAsync(
            new ChatHistory(prompt),
            new OpenAIRequestSettings() { MaxTokens = 300 }
        );

        var content = result[0].Content;
        
        // Extract confidence score
        double confidence = 0.0;
        var confidenceLine = content.Split('\n').FirstOrDefault(l => l.StartsWith("Confidence:"));
        if (confidenceLine != null && double.TryParse(confidenceLine.Replace("Confidence:", "").Trim(), out var parsedConf))
        {
            confidence = parsedConf;
        }

        return (content, confidence);
    }
}
