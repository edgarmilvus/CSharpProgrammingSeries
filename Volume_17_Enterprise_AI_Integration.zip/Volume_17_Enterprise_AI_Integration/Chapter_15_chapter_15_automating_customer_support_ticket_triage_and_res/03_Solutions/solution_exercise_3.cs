
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Threading.Tasks;

// Interfaces for Dependency Injection
public interface IBillingSystemAdapter 
{
    Task<string> GetInvoiceStatusAsync(string userEmail);
}

public interface IIncidentManagementWorkflow 
{
    Task TriggerOutageProtocolAsync(string ticketDetails);
}

// Mock implementations
public class BillingSystemAdapter : IBillingSystemAdapter 
{
    public async Task<string> GetInvoiceStatusAsync(string userEmail) 
    {
        await Task.Delay(100); 
        return "Paid"; 
    }
}

public class IncidentManagementWorkflow : IIncidentManagementWorkflow 
{
    public async Task TriggerOutageProtocolAsync(string ticketDetails) 
    {
        await Task.Delay(100);
        Console.WriteLine($"[Incident] Outage detected: {ticketDetails}");
    }
}

public class SupportTicketProcessor
{
    private readonly IBillingSystemAdapter _billingAdapter;
    private readonly IIncidentManagementWorkflow _incidentWorkflow;
    // Assume these are injected or available via properties
    private readonly KnowledgeBaseRepository _kbRepo = new(); 
    private readonly OnCallApiService _onCallApi = new();

    public SupportTicketProcessor(IBillingSystemAdapter billingAdapter, IIncidentManagementWorkflow incidentWorkflow)
    {
        _billingAdapter = billingAdapter;
        _incidentWorkflow = incidentWorkflow;
    }

    public async Task<SupportTicketResult> ProcessTicket(string ticketId, string rawTicket, string userEmail)
    {
        // 1. Classification (Assumed from Exercise 1)
        var classification = new TicketClassificationResult("Technical Support", "High", "Simulated");
        
        // 2. Parallel Processing for High Urgency
        if (classification.Urgency == "High")
        {
            // Run KB retrieval and On-Call check in parallel
            var kbTask = _kbRepo.SearchArticlesAsync(rawTicket, classification.Intent);
            var onCallTask = _onCallApi.CheckEscalationAsync(userEmail);

            await Task.WhenAll(kbTask, onCallTask);

            var kbArticles = kbTask.Result;
            var escalationRequired = onCallTask.Result;

            if (escalationRequired)
            {
                // Handle escalation logic
            }
        }
        else 
        {
            // Standard sequential retrieval for non-high urgency
            await _kbRepo.SearchArticlesAsync(rawTicket, classification.Intent);
        }

        // 3. Conditional Branching based on Intent
        switch (classification.Intent)
        {
            case "Billing Inquiry":
                var invoiceStatus = await _billingAdapter.GetInvoiceStatusAsync(userEmail);
                // Append invoice status to context for drafting
                break;

            case "Technical Support":
                if (rawTicket.Contains("outage", StringComparison.OrdinalIgnoreCase))
                {
                    // Fire and forget is risky, but requested. 
                    // Ideally use a background queue. Here we await for safety in this context.
                    await _incidentWorkflow.TriggerOutageProtocolAsync(rawTicket);
                }
                break;
        }

        // 4. Drafting (Simulated)
        return new SupportTicketResult("Draft response generated.");
    }
}

// Helper classes for context
public class OnCallApiService 
{
    public async Task<bool> CheckEscalationAsync(string email) 
    {
        await Task.Delay(50); 
        return true; 
    }
}
public record SupportTicketResult(string Response);
