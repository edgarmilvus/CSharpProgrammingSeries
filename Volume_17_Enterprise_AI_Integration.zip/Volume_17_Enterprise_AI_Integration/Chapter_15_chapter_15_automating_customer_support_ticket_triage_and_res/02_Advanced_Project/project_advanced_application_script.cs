
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace SupportTriageSystem
{
    // Represents the urgency level of a support ticket.
    // Enums are introduced in Chapter 13: Data Structures and Types.
    public enum TicketUrgency
    {
        Low,
        Medium,
        High,
        Critical
    }

    // Represents the category of a support ticket.
    public enum TicketCategory
    {
        TechnicalIssue,
        Billing,
        FeatureRequest,
        GeneralInquiry
    }

    // Represents a raw customer support ticket.
    // Chapter 15 emphasizes using simple classes to model domain data.
    public class SupportTicket
    {
        public int TicketId { get; set; }
        public string CustomerEmail { get; set; }
        public string QueryText { get; set; }
    }

    // Represents a processed ticket with analyzed metadata.
    public class AnalyzedTicket
    {
        public int TicketId { get; set; }
        public string CustomerEmail { get; set; }
        public string QueryText { get; set; }
        public TicketUrgency Urgency { get; set; }
        public TicketCategory Category { get; set; }
        public string DraftResponse { get; set; }
    }

    // Simulates an external LLM (Large Language Model) service.
    // In a real scenario, this would make an HTTP call to an API like Azure OpenAI or AWS Bedrock.
    public class LLMService
    {
        // Simulates sending a prompt to an LLM and getting a structured classification.
        // Chapter 15 discusses prompt engineering for intent classification.
        public void ClassifyTicket(AnalyzedTicket ticket)
        {
            string lowerQuery = ticket.QueryText.ToLower();

            // Basic heuristic simulation of LLM classification logic
            // (In reality, the LLM would handle complex nuances).
            if (lowerQuery.Contains("outage") || lowerQuery.Contains("down") || lowerQuery.Contains("error 500"))
            {
                ticket.Urgency = TicketUrgency.Critical;
                ticket.Category = TicketCategory.TechnicalIssue;
            }
            else if (lowerQuery.Contains("refund") || lowerQuery.Contains("charge") || lowerQuery.Contains("invoice"))
            {
                ticket.Urgency = TicketUrgency.High;
                ticket.Category = TicketCategory.Billing;
            }
            else if (lowerQuery.Contains("feature") || lowerQuery.Contains("suggest"))
            {
                ticket.Urgency = TicketUrgency.Medium;
                ticket.Category = TicketCategory.FeatureRequest;
            }
            else
            {
                ticket.Urgency = TicketUrgency.Low;
                ticket.Category = TicketCategory.GeneralInquiry;
            }
        }

        // Simulates generating a draft response based on the ticket context.
        // Chapter 15 covers RAG (Retrieval-Augmented Generation) concepts.
        public void GenerateDraftResponse(AnalyzedTicket ticket)
        {
            string responseTemplate = "";

            switch (ticket.Category)
            {
                case TicketCategory.TechnicalIssue:
                    if (ticket.Urgency == TicketUrgency.Critical)
                    {
                        responseTemplate = "URGENT ALERT: We have detected a potential system outage. Our engineering team has been automatically notified. Ticket ID: {0}. Please stand by.";
                    }
                    else
                    {
                        responseTemplate = "Thank you for reporting the technical issue. We have logged your error report (ID: {0}) and our support team will investigate.";
                    }
                    break;

                case TicketCategory.Billing:
                    responseTemplate = "Regarding your billing inquiry (ID: {0}), we have retrieved your latest invoice. A billing specialist will review your request for a refund shortly.";
                    break;

                case TicketCategory.FeatureRequest:
                    responseTemplate = "We appreciate your feedback (ID: {0})! We have logged your feature request in our product backlog for the development team to review.";
                    break;

                default:
                    responseTemplate = "Hello, we have received your inquiry (ID: {0}). A support agent will get back to you within 24 hours.";
                    break;
            }

            ticket.DraftResponse = string.Format(responseTemplate, ticket.TicketId);
        }
    }

    // Simulates an internal ticketing platform (e.g., Jira or Zendesk).
    public class TicketingSystem
    {
        // Store tickets in a simple array for this simulation.
        private AnalyzedTicket[] _ticketDatabase = new AnalyzedTicket[10];
        private int _currentIndex = 0;

        // Method to ingest a raw ticket and process it.
        // This represents the main workflow loop described in Chapter 15.
        public void ProcessIncomingTicket(SupportTicket rawTicket)
        {
            Console.WriteLine($"[System] Processing Ticket #{rawTicket.TicketId} from {rawTicket.CustomerEmail}...");

            // 1. Initialize analyzed ticket
            var analyzedTicket = new AnalyzedTicket
            {
                TicketId = rawTicket.TicketId,
                CustomerEmail = rawTicket.CustomerEmail,
                QueryText = rawTicket.QueryText
            };

            // 2. Use LLM Service for classification
            var llmService = new LLMService();
            llmService.ClassifyTicket(analyzedTicket);

            // 3. Generate Draft Response
            llmService.GenerateDraftResponse(analyzedTicket);

            // 4. Store in Database
            if (_currentIndex < _ticketDatabase.Length)
            {
                _ticketDatabase[_currentIndex] = analyzedTicket;
                _currentIndex++;
            }

            // 5. Trigger Backend Workflows based on Urgency
            TriggerWorkflows(analyzedTicket);

            Console.WriteLine($"[System] Ticket #{analyzedTicket.TicketId} Processed. Category: {analyzedTicket.Category}, Urgency: {analyzedTicket.Urgency}");
            Console.WriteLine($"[System] Draft Response: {analyzedTicket.DraftResponse}");
            Console.WriteLine("---------------------------------------------------");
        }

        // Triggers specific backend workflows based on the ticket classification.
        private void TriggerWorkflows(AnalyzedTicket ticket)
        {
            // Chapter 15: Automating workflows based on intent.
            if (ticket.Urgency == TicketUrgency.Critical)
            {
                Console.WriteLine("[Workflow Trigger] ACTION: PagerDuty Alert Sent to Engineering On-Call.");
                Console.WriteLine("[Workflow Trigger] ACTION: Creating High-Priority Jira Ticket.");
            }
            else if (ticket.Category == TicketCategory.Billing)
            {
                Console.WriteLine("[Workflow Trigger] ACTION: Flagging account for Billing Review.");
            }
            else if (ticket.Category == TicketCategory.FeatureRequest)
            {
                Console.WriteLine("[Workflow Trigger] ACTION: Adding item to Product Backlog (Jira).");
            }
            else
            {
                Console.WriteLine("[Workflow Trigger] ACTION: Routing to Tier 1 Support Queue.");
            }
        }

        // Display all processed tickets (Simulation of reporting/dashboard)
        public void GenerateDailyReport()
        {
            Console.WriteLine("\n=== DAILY TRIAGE REPORT ===");
            for (int i = 0; i < _currentIndex; i++)
            {
                AnalyzedTicket t = _ticketDatabase[i];
                Console.WriteLine($"ID: {t.TicketId} | Cat: {t.Category} | Urg: {t.Urgency} | Email: {t.CustomerEmail}");
            }
            Console.WriteLine("===========================\n");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the ticketing system
            TicketingSystem system = new TicketingSystem();

            // Simulate incoming customer tickets
            SupportTicket ticket1 = new SupportTicket
            {
                TicketId = 101,
                CustomerEmail = "alice@example.com",
                QueryText = "My site is down! I am getting a 500 Internal Server Error immediately."
            };

            SupportTicket ticket2 = new SupportTicket
            {
                TicketId = 102,
                CustomerEmail = "bob@example.com",
                QueryText = "I was charged twice for my subscription this month. Please refund the extra charge."
            };

            SupportTicket ticket3 = new SupportTicket
            {
                TicketId = 103,
                CustomerEmail = "charlie@example.com",
                QueryText = "It would be great if you could add a dark mode to the dashboard."
            };

            // Process tickets through the automated triage system
            system.ProcessIncomingTicket(ticket1);
            system.ProcessIncomingTicket(ticket2);
            system.ProcessIncomingTicket(ticket3);

            // Generate end-of-day report
            system.GenerateDailyReport();

            // Keep console open
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
