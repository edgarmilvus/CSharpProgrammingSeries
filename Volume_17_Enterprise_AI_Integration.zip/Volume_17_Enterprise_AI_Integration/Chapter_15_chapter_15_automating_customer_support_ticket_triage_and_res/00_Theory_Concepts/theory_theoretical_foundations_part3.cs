
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

// This service is the "Concierge" that dispatches the work.
public class ActionDispatcher
{
    private readonly IJiraApiClient _jiraClient;
    private readonly ISlackClient _slackClient;
    private readonly IPagerDutyClient _pagerDutyClient;

    // Constructor injection for loose coupling.
    public ActionDispatcher(IJiraApiClient jira, ISlackClient slack, IPagerDutyClient pagerDuty)
    {
        _jiraClient = jira;
        _slackClient = slack;
        _pagerDutyClient = pagerDuty;
    }

    public async Task DispatchAsync(TicketClassification classification, string originalContent)
    {
        // Modern C# switch expressions are perfect for this kind of routing logic.
        var tasks = classification.Urgency switch
        {
            UrgencyLevel.Critical => new[]
            {
                _jiraClient.CreateTicketAsync("P1", originalContent),
                _pagerDutyClient.PageOnCallAsync($"Critical Ticket: {originalContent}"),
                _slackClient.NotifyChannelAsync("#incidents", "New critical ticket has been triaged.")
            },
            UrgencyLevel.High => new[] { _jiraClient.CreateTicketAsync("P2", originalContent) },
            _ => new[] { _jiraClient.CreateTicketAsync("P3", originalContent) } // Low and Medium
        };

        // Execute all required actions concurrently. This is a massive performance win.
        await Task.WhenAll(tasks);
    }
}
