
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace EnterpriseApiIntegration
{
    // Real-World Context: A logistics company needs to monitor the status of shipments.
    // The legacy system uses REST APIs for fetching shipment data, while the new inventory system uses GraphQL.
    // This application simulates a console tool that an operations manager uses to check shipment status
    // and verify inventory availability by consuming both API types securely.

    class Program
    {
        // Main entry point. In a real application, this would handle dependency injection.
        // Here, we instantiate services manually to demonstrate the flow.
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== Enterprise Logistics Monitor ===");
            Console.WriteLine("Initializing API Connections...\n");

            // Configuration: In a production app, these would come from environment variables or config files.
            string restApiBaseUrl = "https://api.logistics-internal.com/v1/";
            string graphQlApiBaseUrl = "https://api.inventory-internal.com/graphql";
            string apiKey = "sk_live_51Mz9200e"; // Mock API Key
            string oauthToken = await GetMockOAuthToken(); // Simulate fetching an OAuth2 token

            // Initialize Service Clients
            var restClient = new ShipmentRestClient(restApiBaseUrl, apiKey);
            var graphQlClient = new InventoryGraphQlClient(graphQlApiBaseUrl, oauthToken);

            // Scenario 1: Fetch a specific shipment details via REST
            Console.WriteLine("--- Fetching Shipment Details (REST) ---");
            string shipmentId = "SHP-99821";
            Shipment shipment = await restClient.GetShipmentByIdAsync(shipmentId);

            if (shipment != null)
            {
                Console.WriteLine($"ID: {shipment.Id}");
                Console.WriteLine($"Status: {shipment.Status}");
                Console.WriteLine($"Destination: {shipment.Destination}");
                Console.WriteLine($"Weight: {shipment.WeightKg}kg");
            }

            // Scenario 2: Check inventory for items in that shipment via GraphQL
            Console.WriteLine("\n--- Checking Inventory (GraphQL) ---");
            if (shipment != null && shipment.ItemIds != null)
            {
                // GraphQL allows fetching specific fields for multiple items in one request.
                string query = @"
                query GetInventoryStatus($itemIds: [String!]!) {
                    items(ids: $itemIds) {
                        id
                        name
                        stockLevel
                        warehouseLocation
                    }
                }";

                var variables = new { itemIds = shipment.ItemIds };
                var inventoryResponse = await graphQlClient.ExecuteQueryAsync(query, variables);

                if (inventoryResponse != null && inventoryResponse.Data != null)
                {
                    foreach (var item in inventoryResponse.Data.Items)
                    {
                        Console.WriteLine($"Item: {item.Name} | Stock: {item.StockLevel} | Loc: {item.WarehouseLocation}");
                    }
                }
            }

            Console.WriteLine("\n=== Operation Complete ===");
        }

        // Simulates an OAuth2 token retrieval process
        static async Task<string> GetMockOAuthToken()
        {
            // In a real scenario, this involves an HTTP POST to the auth server
            // with client credentials (Client ID, Client Secret).
            await Task.Delay(500); // Simulate network latency
            return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.mock.oauth.token";
        }
    }

    // ==================== REST CLIENT IMPLEMENTATION ====================

    public class Shipment
    {
        public string Id { get; set; }
        public string Status { get; set; } // e.g., "In Transit", "Delivered"
        public string Destination { get; set; }
        public double WeightKg { get; set; }
        public string[] ItemIds { get; set; } // Associated inventory items
    }

    public class ShipmentRestClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        private readonly string _apiKey;

        public ShipmentRestClient(string baseUrl, string apiKey)
        {
            _baseUrl = baseUrl.TrimEnd('/');
            _apiKey = apiKey;
            _httpClient = new HttpClient();
            
            // Setup default headers
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<Shipment> GetShipmentByIdAsync(string shipmentId)
        {
            // Construct the REST endpoint URL
            string endpoint = $"{_baseUrl}/shipments/{Uri.EscapeDataString(shipmentId)}";

            // Create the request message
            var request = new HttpRequestMessage(HttpMethod.Get, endpoint);

            // Implement API Key Authentication (Header Injection)
            // This is a common pattern for securing REST APIs.
            request.Headers.Add("X-API-Key", _apiKey);

            try
            {
                // Execute the request
                HttpResponseMessage response = await _httpClient.SendAsync(request);

                // Robust Error Handling: Check status code before processing
                if (!response.IsSuccessStatusCode)
                {
                    HandleHttpError(response);
                    return null;
                }

                // Data Serialization: Deserialize JSON response to C# Object
                string responseBody = await response.Content.ReadAsStringAsync();
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                Shipment shipment = JsonSerializer.Deserialize<Shipment>(responseBody, options);

                return shipment;
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"Network error: {ex.Message}");
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
                return null;
            }
        }

        private void HandleHttpError(HttpResponseMessage response)
        {
            // Logic to handle specific HTTP status codes
            switch ((int)response.StatusCode)
            {
                case 401:
                    Console.WriteLine("Error: Unauthorized. Check API Key.");
                    break;
                case 404:
                    Console.WriteLine("Error: Shipment not found.");
                    break;
                case 429:
                    Console.WriteLine("Error: Rate limit exceeded. Please wait.");
                    break;
                default:
                    Console.WriteLine($"Error: API returned {response.StatusCode}");
                    break;
            }
        }
    }

    // ==================== GRAPHQL CLIENT IMPLEMENTATION ====================

    public class GraphQlResponse
    {
        public GraphQlData Data { get; set; }
    }

    public class GraphQlData
    {
        public InventoryItem[] Items { get; set; }
    }

    public class InventoryItem
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int StockLevel { get; set; }
        public string WarehouseLocation { get; set; }
    }

    public class InventoryGraphQlClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _endpointUrl;
        private readonly string _bearerToken;

        public InventoryGraphQlClient(string endpointUrl, string bearerToken)
        {
            _endpointUrl = endpointUrl;
            _bearerToken = bearerToken;
            _httpClient = new HttpClient();
        }

        // Generic method to execute any GraphQL query
        public async Task<GraphQlResponse> ExecuteQueryAsync(string query, object variables)
        {
            // GraphQL typically uses a single endpoint (POST) regardless of the operation.
            // The payload is a JSON object containing 'query' and 'variables'.
            var payload = new
            {
                query = query,
                variables = variables
            };

            // Serialize the payload manually (avoiding LINQ/Records as per constraints)
            // In a real app, we would use JsonSerializer.Serialize, but for strict adherence 
            // to basic blocks, we construct the JSON string manually or use the built-in serializer 
            // if it's considered a "basic block" of .NET Core. 
            // *Note: Using System.Text.Json is standard for modern C#.*
            string jsonPayload = JsonSerializer.Serialize(payload);

            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            // Implement OAuth2 Authentication (Bearer Token)
            // This is distinct from API Key authentication used in REST.
            content.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);

            try
            {
                // POST is the standard method for GraphQL
                HttpResponseMessage response = await _httpClient.PostAsync(_endpointUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"GraphQL API Error: {response.StatusCode}");
                    return null;
                }

                string responseBody = await response.Content.ReadAsStringAsync();
                
                // Deserialize to the specific response structure
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                return JsonSerializer.Deserialize<GraphQlResponse>(responseBody, options);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GraphQL Execution Failed: {ex.Message}");
                return null;
            }
        }
    }
}
