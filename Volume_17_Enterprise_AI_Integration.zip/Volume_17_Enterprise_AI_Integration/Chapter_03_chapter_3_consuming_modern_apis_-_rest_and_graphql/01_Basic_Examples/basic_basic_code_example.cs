
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EnterpriseAI.Examples
{
    // 1. Define a Data Transfer Object (DTO) to map the JSON response.
    // Using 'record' for immutability and concise syntax (C# 9+).
    public record StockPriceResponse(
        [property: JsonPropertyName("symbol")] string Symbol,
        [property: JsonPropertyName("price")] decimal Price,
        [property: JsonPropertyName("currency")] string Currency,
        [property: JsonPropertyName("timestamp")] DateTime Timestamp
    );

    public class BasicApiConsumer
    {
        // 2. Define the API endpoint and API Key as constants.
        // In a real application, these would be loaded from configuration (e.g., appsettings.json).
        private const string ApiUrl = "https://api.enterprise-internal.com/v1/market/quote";
        private const string ApiKey = "sk_live_1234567890abcdef"; // Placeholder secret

        public static async Task Main(string[] args)
        {
            Console.WriteLine("Attempting to fetch stock price for CE...");

            // 3. Instantiate HttpClient.
            // CRITICAL: In production, reuse HttpClient instances (e.g., via IHttpClientFactory)
            // to avoid socket exhaustion. We use 'using' here for a self-contained console example.
            using HttpClient client = new HttpClient();

            try
            {
                // 4. Add the API Key to the request headers.
                // Most modern APIs use the 'Authorization' header with a Bearer token,
                // or a custom header like 'X-API-Key'. We simulate standard Bearer auth here.
                client.DefaultRequestHeaders.Authorization = 
                    new AuthenticationHeaderValue("Bearer", ApiKey);

                // 5. Send the GET request asynchronously.
                HttpResponseMessage response = await client.GetAsync(ApiUrl);

                // 6. Check if the request was successful (Status Code 200-299).
                // If not, throw an exception to jump to the catch block.
                response.EnsureSuccessStatusCode();

                // 7. Read the response body as a string.
                string responseBody = await response.Content.ReadAsStringAsync();

                // 8. Deserialize the JSON string into our strongly-typed C# object.
                // We use System.Text.Json for performance and modern standards.
                StockPriceResponse? stockData = JsonSerializer.Deserialize<StockPriceResponse>(responseBody);

                // 9. Process the data.
                if (stockData != null)
                {
                    Console.WriteLine($"Success! {stockData.Symbol} is trading at {stockData.Price} {stockData.Currency}.");
                }
                else
                {
                    Console.WriteLine("Error: Failed to parse the response data.");
                }
            }
            catch (HttpRequestException e)
            {
                // 10. Handle network or HTTP error (e.g., 401 Unauthorized, 404 Not Found, 500 Server Error).
                Console.WriteLine($"Network error: {e.Message}");
            }
            catch (JsonException e)
            {
                // 11. Handle JSON parsing error (e.g., malformed data).
                Console.WriteLine($"Data parsing error: {e.Message}");
            }
            catch (Exception e)
            {
                // 12. Handle any other unexpected errors.
                Console.WriteLine($"Unexpected error: {e.Message}");
            }
        }
    }
}
