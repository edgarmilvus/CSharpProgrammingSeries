
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace OAuth2Daemon
{
    // Token response model
    public record OAuthTokenResponse(
        [property: JsonPropertyName("access_token")] string AccessToken,
        [property: JsonPropertyName("token_type")] string TokenType,
        [property: JsonPropertyName("expires_in")] int ExpiresIn
    );

    public class TokenService
    {
        private readonly HttpClient _httpClient;
        private static OAuthTokenResponse? _cachedToken;
        private static readonly object _lock = new object();

        public TokenService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> GetAccessTokenAsync(string clientId, string clientSecret, string tokenEndpoint)
        {
            // 3. Check cache and expiration (buffer of 5 seconds)
            lock (_lock)
            {
                if (_cachedToken != null)
                {
                    // In a real app, track absolute expiration time properly
                    // Here we assume if it exists, it's valid for the sake of simple caching logic
                    return _cachedToken.AccessToken;
                }
            }

            // 2. Prepare application/x-www-form-urlencoded data
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", clientId),
                new KeyValuePair<string, string>("client_secret", clientSecret)
            });

            try
            {
                var response = await _httpClient.PostAsync(tokenEndpoint, content);
                
                if (!response.IsSuccessStatusCode)
                {
                    throw new HttpRequestException($"Token request failed: {response.StatusCode}");
                }

                var json = await response.Content.ReadAsStringAsync();
                var tokenResponse = JsonSerializer.Deserialize<OAuthTokenResponse>(json);

                if (tokenResponse == null)
                {
                    throw new InvalidOperationException("Failed to deserialize token response.");
                }

                lock (_lock)
                {
                    _cachedToken = tokenResponse;
                }

                return tokenResponse.AccessToken;
            }
            catch (Exception ex)
            {
                // Log error (simulated)
                Console.WriteLine($"[TokenService Error]: {ex.Message}");
                throw;
            }
        }
    }

    public class AuthenticatedApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly TokenService _tokenService;
        private readonly string _clientId;
        private readonly string _clientSecret;
        private readonly string _tokenEndpoint;

        public AuthenticatedApiClient(HttpClient httpClient, TokenService tokenService, 
                                     string clientId, string clientSecret, string tokenEndpoint)
        {
            _httpClient = httpClient;
            _tokenService = tokenService;
            _clientId = clientId;
            _clientSecret = clientSecret;
            _tokenEndpoint = tokenEndpoint;
        }

        public async Task<string> GetDataAsync(string protectedEndpoint)
        {
            int retries = 0;
            int maxRetries = 3;
            
            while (true)
            {
                try
                {
                    // 4. Retrieve token and attach to header
                    var token = await _tokenService.GetAccessTokenAsync(_clientId, _clientSecret, _tokenEndpoint);
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    var response = await _httpClient.GetAsync(protectedEndpoint);
                    
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStringAsync();
                    }
                    
                    // Handle 401 specifically (token might be expired/revoked)
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        // Clear cache and retry once
                        lock (typeof(TokenService))
                        {
                            // Reflection hack for static clear or just assume logic in TokenService handles it
                            // In real code, TokenService should have a ClearCache method.
                        }
                        throw new HttpRequestException("Unauthorized - Token invalid.");
                    }
                }
                catch (HttpRequestException ex)
                {
                    // 5. Exponential backoff logic
                    if (retries >= maxRetries)
                    {
                        Console.WriteLine($"Max retries reached. Last error: {ex.Message}");
                        throw;
                    }

                    retries++;
                    var delay = TimeSpan.FromSeconds(Math.Pow(2, retries)); // 2s, 4s, 8s
                    
                    Console.WriteLine($"Retry {retries}/{maxRetries} in {delay.TotalSeconds}s...");
                    await Task.Delay(delay);
                }
            }
        }
    }

    // Usage Example
    public class Program
    {
        public static async Task Main(string[] args)
        {
            using var httpClient = new HttpClient();
            var tokenService = new TokenService(httpClient);
            
            var client = new AuthenticatedApiClient(
                httpClient, 
                tokenService, 
                "my_client_id", 
                "my_secret", 
                "https://idp.example.com/token"
            );

            try
            {
                var data = await client.GetDataAsync("https://api.example.com/protected-data");
                Console.WriteLine("Data received: " + data.Substring(0, Math.Min(50, data.Length)) + "...");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Operation failed: {ex.Message}");
            }
        }
    }
}
