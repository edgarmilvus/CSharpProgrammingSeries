
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace LegacyApiClient
{
    // 1. Define the response model using records and nullable reference types.
    // We use [JsonPropertyName] to map snake_case JSON to PascalCase C# properties.
    public record LegacyApiResponse(
        int Id,
        [property: JsonPropertyName("legacy_name")] string Name,
        string Status,
        [property: JsonPropertyName("metadata")] LegacyMetadata? Metadata // Nullable for safety
    );

    public record LegacyMetadata(
        [property: JsonPropertyName("region")] string? Region
    );

    // 2. Implement a Result pattern to handle success/failure without exceptions.
    public abstract record Result<T>;
    public record Success<T>(T Value) : Result<T>;
    public record Failure<T>(string Error) : Result<T>;

    // 3. Generic ApiClient implementation.
    public class ApiClient<T>
    {
        private readonly HttpClient _httpClient;
        private readonly JsonSerializerOptions _jsonOptions;

        public ApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
            
            // Configure System.Text.Json to be resilient.
            _jsonOptions = new JsonSerializerOptions
            {
                // Ignore unexpected fields (e.g., legacy system adds new fields)
                PropertyNameCaseInsensitive = true,
                ReadCommentHandling = JsonCommentHandling.Skip,
                AllowTrailingCommas = true
            };
        }

        public async Task<Result<T>> GetAsync(string endpoint)
        {
            try
            {
                // Attempt the HTTP request
                var response = await _httpClient.GetAsync(endpoint);

                // Even if status is not 200, we catch it via EnsureSuccessStatusCode
                // or handle it manually. Here we ensure success for simplicity.
                response.EnsureSuccessStatusCode();

                // Read content as string first to inspect raw JSON if needed,
                // or stream directly to deserializer.
                var content = await response.Content.ReadAsStringAsync();

                // Deserialize using System.Text.Json
                var data = JsonSerializer.Deserialize<T>(content, _jsonOptions);

                if (data is null)
                {
                    return new Failure<T>("Deserialization returned null.");
                }

                return new Success<T>(data);
            }
            catch (HttpRequestException ex)
            {
                // Log error (simulated with Console)
                Console.WriteLine($"[Network Error]: {ex.Message}");
                return new Failure<T>($"Network error: {ex.Message}");
            }
            catch (JsonException ex)
            {
                // Handle malformed JSON or type mismatches
                Console.WriteLine($"[JSON Error]: {ex.Message}");
                return new Failure<T>($"Data format error: {ex.Message}");
            }
            catch (Exception ex)
            {
                // Catch-all for unexpected runtime errors
                Console.WriteLine($"[Unexpected Error]: {ex.Message}");
                return new Failure<T>($"Unexpected error: {ex.Message}");
            }
        }
    }

    // 4. Demonstration usage
    public class Program
    {
        public static async Task Main(string[] args)
        {
            // Mocking HttpClient (In production, use IHttpClientFactory)
            using var httpClient = new HttpClient();
            
            // Note: This URL is hypothetical for the exercise context
            var endpoint = "https://api.example.com/v1/legacy-data";
            
            var client = new ApiClient<LegacyApiResponse>(httpClient);
            var result = await client.GetAsync(endpoint);

            // 5. Pattern matching to handle the Result
            switch (result)
            {
                case Success<LegacyApiResponse> success:
                    Console.WriteLine($"Successfully fetched: {success.Value.Name} (Status: {success.Value.Status})");
                    if (success.Value.Metadata is not null)
                    {
                        Console.WriteLine($"Region: {success.Value.Metadata.Region}");
                    }
                    break;

                case Failure<LegacyApiResponse> failure:
                    Console.WriteLine($"Failed to fetch data: {failure.Error}");
                    break;
            }
        }
    }
}
