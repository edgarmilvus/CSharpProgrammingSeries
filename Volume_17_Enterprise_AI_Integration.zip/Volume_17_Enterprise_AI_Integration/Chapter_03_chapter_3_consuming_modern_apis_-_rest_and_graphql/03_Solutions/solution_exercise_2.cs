
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace GraphqlIntegration
{
    // 1. Model for the GraphQL response
    public record User(
        int Id,
        string Username,
        List<string> Permissions
    );

    // Wrapper to match the GraphQL response structure (data + errors)
    public record GraphqlResponse<T>(
        [property: JsonPropertyName("data")] T? Data,
        [property: JsonPropertyName("errors")] List<GraphqlError>? Errors
    );

    public record GraphqlError(
        string Message,
        List<GraphqlErrorLocation>? Locations
    );

    public record GraphqlErrorLocation(int Line, int Column);

    // 2. Dynamic Query Builder
    public class GraphQLQueryBuilder
    {
        private readonly string _typeName;
        private readonly List<string> _fields;

        public GraphQLQueryBuilder(string typeName)
        {
            _typeName = typeName;
            _fields = new List<string>();
        }

        public GraphQLQueryBuilder WithField(string fieldName)
        {
            // 5. Sanitize input: Ensure field names are alphanumeric to prevent injection
            if (fieldName.All(char.IsLetterOrDigit))
            {
                _fields.Add(fieldName);
            }
            else
            {
                throw new ArgumentException($"Invalid field name: {fieldName}");
            }
            return this;
        }

        public string Build()
        {
            if (!_fields.Any())
                throw new InvalidOperationException("No fields selected.");

            // Construct: query { typeName { field1 field2 } }
            var fieldsString = string.Join(" ", _fields);
            return $"query {{ {_typeName} {{ {fieldsString} }} }}";
        }
    }

    public class GraphqlClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _endpoint;

        public GraphqlClient(HttpClient httpClient, string endpoint)
        {
            _httpClient = httpClient;
            _endpoint = endpoint;
        }

        // 3. & 4. Execute query and handle errors
        public async Task<GraphqlResponse<User>> GetUserAsync(List<string> requestedFields)
        {
            var builder = new GraphQLQueryBuilder("user");
            foreach (var field in requestedFields)
            {
                builder.WithField(field);
            }

            var query = builder.Build();
            
            // GraphQL requests are POST
            var request = new { query };
            
            var response = await _httpClient.PostAsJsonAsync(_endpoint, request);
            
            // 4. Read content even if status is not 200, to parse potential GraphQL errors
            var content = await response.Content.ReadAsStringAsync();
            
            // Deserialize strictly
            var result = JsonSerializer.Deserialize<GraphqlResponse<User>>(content);

            // Check standard HTTP errors first
            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"HTTP Error {(int)response.StatusCode}: {response.ReasonPhrase}");
            }

            // Check GraphQL specific errors (HTTP 200 OK but errors present)
            if (result?.Errors != null && result.Errors.Any())
            {
                var errorMsg = string.Join("; ", result.Errors.Select(e => e.Message));
                throw new InvalidOperationException($"GraphQL Errors: {errorMsg}");
            }

            if (result?.Data is null)
            {
                throw new InvalidOperationException("No data returned.");
            }

            return result;
        }
    }

    // Usage Example
    public class Program
    {
        public static async Task Main(string[] args)
        {
            using var client = new HttpClient();
            var graphqlClient = new GraphqlClient(client, "https://api.example.com/graphql");

            try
            {
                // Request specific fields dynamically
                var fields = new List<string> { "id", "username", "permissions" };
                var response = await graphqlClient.GetUserAsync(fields);

                Console.WriteLine($"User: {response.Data.Username} (ID: {response.Data.Id})");
                Console.WriteLine($"Permissions: {string.Join(", ", response.Data.Permissions)}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Integration failed: {ex.Message}");
            }
        }
    }
}
