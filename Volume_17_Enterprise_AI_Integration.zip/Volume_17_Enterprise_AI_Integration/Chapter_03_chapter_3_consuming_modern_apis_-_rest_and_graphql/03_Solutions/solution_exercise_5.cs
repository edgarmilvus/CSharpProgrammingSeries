
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace LegacyDataBridge
{
    // 1. Internal Data Model
    public record TransactionRecord
    {
        [XmlElement("TransactionID")]
        public int Id { get; set; }

        [XmlElement("CustName")]
        public string CustomerName { get; set; } = string.Empty;

        [XmlElement("AmountVal")]
        public decimal Amount { get; set; }

        [XmlElement("StatusFlag")]
        public string Status { get; set; } = string.Empty;
    }

    // Root element wrapper for XML deserialization
    [XmlRoot("TransactionData")]
    public class TransactionList
    {
        [XmlElement("Transaction")]
        public List<TransactionRecord> Transactions { get; set; } = new List<TransactionRecord>();
    }

    public class DataTransformer
    {
        // 2. XML Deserializer
        public List<TransactionRecord> ParseXml(string xmlContent)
        {
            try
            {
                var serializer = new XmlSerializer(typeof(TransactionList));
                using var reader = new StringReader(xmlContent);
                
                // Cast the result
                var result = serializer.Deserialize(reader) as TransactionList;
                return result?.Transactions ?? new List<TransactionRecord>();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"XML Parsing Error: {ex.Message}");
                return new List<TransactionRecord>();
            }
        }

        // 3. CSV Serializer with Quoting
        public string SerializeToCsv(List<TransactionRecord> records)
        {
            if (records == null || !records.Any()) return string.Empty;

            var sb = new StringBuilder();
            
            // Header Row
            sb.AppendLine("ID,CustomerName,Amount,Status");

            foreach (var record in records)
            {
                // Escape fields containing commas or quotes
                var fields = new[]
                {
                    record.Id.ToString(),
                    EscapeCsvField(record.CustomerName),
                    record.Amount.ToString("F2"),
                    EscapeCsvField(record.Status)
                };

                sb.AppendLine(string.Join(",", fields));
            }

            return sb.ToString();
        }

        private string EscapeCsvField(string field)
        {
            if (field.Contains(',') || field.Contains('"') || field.Contains('\n'))
            {
                // Standard CSV escaping: wrap in quotes and double up internal quotes
                return $"\"{field.Replace("\"", "\"\"")}\"";
            }
            return field;
        }

        // 4. Pipeline Method
        public byte[] ProcessPipeline(string rawXml, Func<TransactionRecord, bool> filterPredicate)
        {
            // Step A: Deserialize
            var records = ParseXml(rawXml);

            // Step B: Filter
            var filteredRecords = records.Where(filterPredicate).ToList();

            // Step C: Serialize to CSV
            var csvString = SerializeToCsv(filteredRecords);

            // 5. Encode to UTF-8 with BOM
            // UTF8Encoding(true) includes the BOM
            var encoding = new UTF8Encoding(true);
            return encoding.GetBytes(csvString);
        }
    }

    // Usage Example
    public class Program
    {
        public static void Main(string[] args)
        {
            // Mock XML input (Non-standard structure)
            string mockXml = @"
                <TransactionData>
                    <Transaction>
                        <TransactionID>101</TransactionID>
                        <CustName>John \"The Boss\" Doe</CustName>
                        <AmountVal>150.50</AmountVal>
                        <StatusFlag>Completed</StatusFlag>
                    </Transaction>
                    <Transaction>
                        <TransactionID>102</TransactionID>
                        <CustName>Jane Smith, Inc.</CustName>
                        <AmountVal>200.00</AmountVal>
                        <StatusFlag>Pending</StatusFlag>
                    </Transaction>
                    <Transaction>
                        <TransactionID>103</TransactionID>
                        <CustName>Bob Wright</CustName>
                        <AmountVal>99.99</AmountVal>
                        <StatusFlag>Completed</StatusFlag>
                    </Transaction>
                </TransactionData>";

            var transformer = new DataTransformer();

            // Filter: Only 'Completed' transactions
            var resultBytes = transformer.ProcessPipeline(mockXml, r => r.Status == "Completed");

            // Output verification
            var outputCsv = Encoding.UTF8.GetString(resultBytes);
            Console.WriteLine("Generated CSV (UTF-8 with BOM):");
            Console.WriteLine(outputCsv);
            
            // Verify BOM presence (optional check)
            if (resultBytes[0] == 0xEF && resultBytes[1] == 0xBB && resultBytes[2] == 0xBF)
            {
                Console.WriteLine("BOM detected: Yes");
            }
        }
    }
}
