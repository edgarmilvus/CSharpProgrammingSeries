
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace ResilientClient
{
    // 1. Custom DelegatingHandler for retries
    public class RetryDelegatingHandler : DelegatingHandler
    {
        private readonly int _maxRetries;
        private static readonly HttpStatusCode[] _retryStatusCodes = 
        {
            HttpStatusCode.TooManyRequests, // 429
            HttpStatusCode.InternalServerError, // 500
            HttpStatusCode.ServiceUnavailable // 503
        };

        public RetryDelegatingHandler(HttpMessageHandler innerHandler, int maxRetries = 3) 
            : base(innerHandler)
        {
            _maxRetries = maxRetries;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            int attempt = 0;

            while (true)
            {
                HttpResponseMessage response = null;
                try
                {
                    // Pass the CancellationToken down the chain
                    response = await base.SendAsync(request, cancellationToken);
                    
                    // If success or not a retryable status code, return immediately
                    if (response.IsSuccessStatusCode || !_retryStatusCodes.Contains(response.StatusCode))
                    {
                        return response;
                    }
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    // 4. Handle cancellation gracefully
                    throw new OperationCanceledException("Request cancelled during retry.", null, cancellationToken);
                }
                catch (HttpRequestException)
                {
                    // Network errors are also retryable
                    if (attempt >= _maxRetries) throw;
                }

                attempt++;
                if (attempt > _maxRetries)
                {
                    return response ?? throw new HttpRequestException("Max retries exceeded.");
                }

                // 3. Check for Retry-After header
                TimeSpan delay;
                if (response != null && response.Headers.RetryAfter != null)
                {
                    if (response.Headers.RetryAfter.Delta.HasValue)
                    {
                        delay = response.Headers.RetryAfter.Delta.Value;
                    }
                    else if (response.Headers.RetryAfter.Date.HasValue)
                    {
                        delay = response.Headers.RetryAfter.Date.Value - DateTimeOffset.UtcNow;
                    }
                    else
                    {
                        delay = TimeSpan.FromSeconds(Math.Pow(2, attempt)); // Fallback
                    }
                }
                else
                {
                    // 2. Exponential Backoff
                    delay = TimeSpan.FromSeconds(Math.Pow(2, attempt));
                }

                // Wait before retrying, checking cancellation
                await Task.Delay(delay, cancellationToken);
            }
        }
    }

    // 2. Modified ApiClient (simplified for context)
    public class ApiClient
    {
        private readonly HttpClient _httpClient;

        public ApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // 4. Accept CancellationToken
        public async Task<string> GetDataAsync(string url, CancellationToken cancellationToken)
        {
            // The DelegatingHandler will handle the retries internally
            var response = await _httpClient.GetAsync(url, cancellationToken);
            return await response.Content.ReadAsStringAsync();
        }
    }

    // 4. Interactive Console Application
    public class Program
    {
        public static async Task Main(string[] args)
        {
            // Setup dependency injection manually for demo
            var innerHandler = new HttpClientHandler();
            var retryHandler = new RetryDelegatingHandler(innerHandler, maxRetries: 5);
            var client = new HttpClient(retryHandler) { BaseAddress = new Uri("https://httpbin.org/") };
            
            var apiClient = new ApiClient(client);

            // Create a CancellationTokenSource
            using var cts = new CancellationTokenSource();

            // 4. Interactive Challenge: Allow user to cancel
            Console.CancelKeyPress += (sender, e) =>
            {
                e.Cancel = true; // Prevent immediate termination
                Console.WriteLine("\nCancellation requested. Waiting for active tasks to finish...");
                cts.Cancel();
            };

            Console.WriteLine("Starting burst of 50 requests. Press Ctrl+C to cancel.");

            var tasks = Enumerable.Range(1, 50).Select(async i =>
            {
                try
                {
                    // Simulate some endpoints that might fail/rate limit
                    // Using /status/500 to simulate failure for retry logic
                    var url = $"status/{(i % 3 == 0 ? 500 : 200)}"; 
                    
                    Console.WriteLine($"Request {i} started...");
                    var data = await apiClient.GetDataAsync(url, cts.Token);
                    Console.WriteLine($"Request {i} completed.");
                }
                catch (OperationCanceledException)
                {
                    Console.WriteLine($"Request {i} cancelled gracefully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Request {i} failed: {ex.Message}");
                }
            }).ToList();

            try
            {
                await Task.WhenAll(tasks);
                Console.WriteLine("All requests processed.");
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Main loop cancelled.");
            }
        }
    }
}
