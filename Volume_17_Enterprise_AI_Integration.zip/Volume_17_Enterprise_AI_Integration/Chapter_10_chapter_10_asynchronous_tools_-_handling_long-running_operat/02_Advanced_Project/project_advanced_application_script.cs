
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace EnterpriseAsyncProcessing
{
    // Real-world context: A financial services firm needs to generate daily risk exposure reports.
    // The process involves:
    // 1. Fetching transaction data from a legacy mainframe system (simulated by a slow database call).
    // 2. Calculating risk metrics based on complex algorithms (CPU intensive).
    // 3. Formatting the report (I/O bound).
    // Since these steps can take several minutes, we cannot block the main AI interaction thread.
    // We will implement an asynchronous job queue system with status polling.

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("--- Enterprise Async Report Generator ---");
            Console.WriteLine("Simulating AI Agent requesting a long-running financial report...\n");

            // 1. The AI Agent (or user) submits a request. We receive a Job ID immediately.
            string jobId = ReportService.SubmitReportRequest("Q4 Risk Exposure");

            // 2. The system does not wait. It acknowledges the request.
            Console.WriteLine($"[System] Request accepted. Job ID: {jobId}");
            Console.WriteLine("[System] You can continue other tasks. Checking status in background...\n");

            // 3. Simulate a polling mechanism (like an LLM checking a webhook or status endpoint).
            PollJobStatus(jobId);

            Console.WriteLine("\n--- End of Simulation ---");
        }

        // A polling loop that checks the status of the job periodically.
        // In a real web app, this would be a separate API endpoint or a WebSocket push.
        static void PollJobStatus(string jobId)
        {
            int attempts = 0;
            while (attempts < 20) // Limit iterations to prevent infinite loops in simulation
            {
                attempts++;
                Thread.Sleep(1000); // Simulate network latency/polling interval

                string status = ReportService.GetJobStatus(jobId);
                Console.WriteLine($"[Polling Attempt {attempts}] Status: {status}");

                if (status == "Completed" || status == "Failed")
                {
                    if (status == "Completed")
                    {
                        string report = ReportService.GetReportResult(jobId);
                        Console.WriteLine($"\n[SUCCESS] Report Generated:\n{report}");
                    }
                    else
                    {
                        Console.WriteLine("\n[ERROR] Report generation failed.");
                    }
                    break;
                }
            }
        }
    }

    // Simulates the backend service managing the job queue.
    // In a real architecture, this would be a distributed service like Hangfire, Azure Functions, or RabbitMQ.
    public static class ReportService
    {
        // A simple in-memory store for jobs. 
        // In production, this would be a persistent database (SQL, Redis).
        private static Dictionary<string, ReportJob> _jobQueue = new Dictionary<string, ReportJob>();
        private static readonly object _lock = new object();

        // Step 1: Accept the request and queue the work.
        public static string SubmitReportRequest(string reportName)
        {
            string jobId = Guid.NewGuid().ToString();
            var job = new ReportJob
            {
                Id = jobId,
                Name = reportName,
                Status = "Queued",
                CreatedAt = DateTime.Now
            };

            lock (_lock)
            {
                _jobQueue.Add(jobId, job);
            }

            // Start the background task immediately (Fire and Forget pattern).
            // In a real system, this would push a message to a queue worker.
            Task.Run(() => ProcessReportAsync(jobId));

            return jobId;
        }

        // Step 2: The actual heavy lifting happens here asynchronously.
        // This decouples the execution from the request thread.
        private static async Task ProcessReportAsync(string jobId)
        {
            try
            {
                // Update status to In-Progress
                UpdateJobStatus(jobId, "Generating...");

                // Simulate Phase 1: Fetching data from legacy system (I/O Bound)
                await Task.Delay(2000); 
                
                // Simulate Phase 2: Calculating risk metrics (CPU Bound)
                UpdateJobStatus(jobId, "Calculating Metrics...");
                await Task.Delay(3000);

                // Simulate Phase 3: Formatting (I/O Bound)
                UpdateJobStatus(jobId, "Formatting...");
                await Task.Delay(1000);

                // Store result
                lock (_lock)
                {
                    if (_jobQueue.ContainsKey(jobId))
                    {
                        _jobQueue[jobId].Result = $"Report: {_jobQueue[jobId].Name}\nGenerated: {DateTime.Now}\nContent: Risk exposure is within acceptable limits.";
                        _jobQueue[jobId].Status = "Completed";
                    }
                }
            }
            catch (Exception ex)
            {
                UpdateJobStatus(jobId, "Failed");
                Console.WriteLine($"Error processing job {jobId}: {ex.Message}");
            }
        }

        // Helper to update status safely
        private static void UpdateJobStatus(string jobId, string status)
        {
            lock (_lock)
            {
                if (_jobQueue.ContainsKey(jobId))
                {
                    _jobQueue[jobId].Status = status;
                }
            }
        }

        // Step 3: Expose status for polling
        public static string GetJobStatus(string jobId)
        {
            lock (_lock)
            {
                if (_jobQueue.TryGetValue(jobId, out var job))
                {
                    return job.Status;
                }
                return "Not Found";
            }
        }

        // Step 4: Retrieve result once complete
        public static string GetReportResult(string jobId)
        {
            lock (_lock)
            {
                if (_jobQueue.TryGetValue(jobId, out var job))
                {
                    return job.Result ?? "No result available yet.";
                }
                return "Job ID invalid.";
            }
        }
    }

    // Data structure for the job
    public class ReportJob
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string Result { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
