
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;

// --- Webhook Service Interface ---
public interface IWebhookService
{
    Task SendNotificationAsync(string callbackUrl, string jobId, JobStatus status, CancellationToken cancellationToken);
}

// --- Webhook Service Implementation ---
public class WebhookService : IWebhookService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<WebhookService> _logger;

    public WebhookService(IHttpClientFactory httpClientFactory, ILogger<WebhookService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public async Task SendNotificationAsync(string callbackUrl, string jobId, JobStatus status, CancellationToken cancellationToken)
    {
        // Security Comment: 
        // To secure the webhook, we should generate an HMAC signature of the payload 
        // using a shared secret key. The client verifies this signature.
        // Example: var signature = HMACSHA256.Hash(secretKey, payloadJson);
        // Request.Headers.Add("X-Signature", signature);

        var client = _httpClientFactory.CreateClient();
        var payload = new { JobId = jobId, Status = status, Timestamp = DateTime.UtcNow };

        // Resilience: Simple Exponential Backoff
        int retryCount = 0;
        int maxRetries = 3;
        TimeSpan delay = TimeSpan.FromSeconds(2);

        while (retryCount < maxRetries)
        {
            try
            {
                var response = await client.PostAsJsonAsync(callbackUrl, payload, cancellationToken);
                
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Webhook sent successfully to {Url}", callbackUrl);
                    return;
                }
                
                _logger.LogWarning("Webhook failed (Attempt {Retry}): {StatusCode}", retryCount + 1, response.StatusCode);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Webhook exception (Attempt {Retry})", retryCount + 1);
            }

            retryCount++;
            if (retryCount < maxRetries)
            {
                await Task.Delay(delay * retryCount, cancellationToken); // Exponential backoff
            }
        }

        _logger.LogError("Failed to send webhook to {Url} after {MaxRetries} attempts. Sending to DLQ.", callbackUrl, maxRetries);
        
        // Logic to push to DLQ would go here (e.g., _dlqWriter.WriteAsync(failedPayload))
    }
}

// --- Updated Consumer (Integration) ---
public class ReportProcessorService : BackgroundService
{
    // ... (Previous fields) ...
    private readonly IWebhookService _webhookService;

    public ReportProcessorService(
        Channel<ReportRequest> channel, 
        IJobStatusService statusService, 
        IWebhookService webhookService, 
        ILogger<ReportProcessorService> logger)
    {
        // ... (Assignments) ...
        _webhookService = webhookService;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (await _channelReader.WaitToReadAsync(stoppingToken))
        {
            while (_channelReader.TryRead(out var request))
            {
                try
                {
                    // Processing logic (Task.Delay)
                    await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);

                    // If CallbackUrl is provided, trigger webhook
                    if (!string.IsNullOrEmpty(request.CallbackUrl))
                    {
                        await _webhookService.SendNotificationAsync(
                            request.CallbackUrl, 
                            request.JobId, // Assuming JobId is in the request
                            JobStatus.Completed, 
                            stoppingToken);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error in processor.");
                }
            }
        }
    }
}
