
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System.Threading.Channels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

// --- Models ---
public record ReportRequest(int ReportId, string UserId, string Priority = "Low");

// --- Channel Configuration (DI) ---
public static class ChannelConfiguration
{
    public static IServiceCollection AddReportChannel(this IServiceCollection services)
    {
        // Bounded channel to prevent memory overflow under high load.
        // FullMode.Wait blocks the producer when capacity is reached, providing backpressure.
        var options = new BoundedChannelOptions(capacity: 100)
        {
            FullMode = BoundedChannelFullMode.Wait
        };

        // Registered as Singleton so both the Controller (Producer) and 
        // BackgroundService (Consumer) share the same instance.
        services.AddSingleton(_ => Channel.CreateBounded<ReportRequest>(options));
        return services;
    }
}

// --- Producer (API Controller) ---
[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    private readonly ChannelWriter<ReportRequest> _channelWriter;
    private readonly ILogger<ReportController> _logger;

    public ReportController(Channel<ReportRequest> channel, ILogger<ReportController> logger)
    {
        _channelWriter = channel.Writer;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> CreateReport([FromBody] ReportRequest request)
    {
        // Generate a unique JobId for tracking
        var jobId = Guid.NewGuid().ToString();
        
        _logger.LogInformation("Received report request for User: {UserId}. Job ID: {JobId}", request.UserId, jobId);

        // Write to the channel. If the channel is full (capacity 100), 
        // this await will block until space is available (Backpressure).
        await _channelWriter.WriteAsync(request);

        // Immediately return 202 Accepted to free up the HTTP thread.
        return Accepted(new { JobId = jobId, Message = "Report request queued for processing." });
    }
}

// --- Consumer (Background Service) ---
public class ReportProcessorService : BackgroundService
{
    private readonly ChannelReader<ReportRequest> _channelReader;
    private readonly ILogger<ReportProcessorService> _logger;

    public ReportProcessorService(Channel<ReportRequest> channel, ILogger<ReportProcessorService> logger)
    {
        _channelReader = channel.Reader;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Report Processor Service is starting.");

        // Loop until the channel is closed and empty, or cancellation is requested.
        while (await _channelReader.WaitToReadAsync(stoppingToken))
        {
            // Try to read an item non-blockingly
            while (_channelReader.TryRead(out var request))
            {
                try
                {
                    _logger.LogInformation("Processing report for ReportId: {ReportId}", request.ReportId);

                    // Simulate long-running operation
                    await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);

                    _logger.LogInformation("Report generation complete for Job ID associated with ReportId: {ReportId}", request.ReportId);
                }
                catch (OperationCanceledException)
                {
                    _logger.LogWarning("Processing cancelled for ReportId: {ReportId}", request.ReportId);
                    break; // Exit the inner loop
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error processing ReportId: {ReportId}", request.ReportId);
                }
            }
        }

        _logger.LogInformation("Report Processor Service is stopping.");
    }
}
