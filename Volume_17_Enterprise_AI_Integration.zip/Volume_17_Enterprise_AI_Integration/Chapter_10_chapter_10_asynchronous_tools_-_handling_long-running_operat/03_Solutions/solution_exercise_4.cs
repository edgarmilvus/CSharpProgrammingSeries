
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Collections.Concurrent;

// --- Updated Controller with Cancellation ---
[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    // Store CancellationTokenSources to control specific jobs
    private static readonly ConcurrentDictionary<string, CancellationTokenSource> _jobCancellationSources = new();
    
    // ... (Other fields) ...

    [HttpPost]
    public async Task<IActionResult> CreateReport([FromBody] ReportRequest request)
    {
        var jobId = Guid.NewGuid().ToString();
        var cts = new CancellationTokenSource();
        
        // Store the CTS so we can cancel it later via the Cancel endpoint
        _jobCancellationSources.TryAdd(jobId, cts);

        // Pass the token to the channel writer logic if needed, 
        // or store it in the request model for the consumer to use.
        request.JobId = jobId; 
        request.CancellationToken = cts.Token; // Assuming model updated

        _statusService.CreateJob(jobId);
        await _channelWriter.WriteAsync(request);
        
        return Accepted(new { JobId = jobId });
    }

    [HttpPost("{jobId}/cancel")]
    public IActionResult CancelReport(string jobId)
    {
        if (_jobCancellationSources.TryGetValue(jobId, out var cts))
        {
            // Check status first (logic omitted for brevity)
            // If status is Queued, we can cancel.
            cts.Cancel();
            _statusService.UpdateStatus(jobId, JobStatus.Cancelled);
            _jobCancellationSources.TryRemove(jobId, out _);
            return Ok(new { Message = "Cancellation requested." });
        }
        return NotFound();
    }
}

// --- Updated Consumer with Timeout & Cancellation ---
public class ReportProcessorService : BackgroundService
{
    // ... (Fields) ...

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (await _channelReader.WaitToReadAsync(stoppingToken))
        {
            while (_channelReader.TryRead(out var request))
            {
                // 1. Check if the job was cancelled before processing started
                if (request.CancellationToken.IsCancellationRequested)
                {
                    _logger.LogInformation("Job {JobId} cancelled before processing started.", request.JobId);
                    continue;
                }

                try
                {
                    // 2. Enforce a hard timeout on the processing logic (e.g., 10 seconds)
                    using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(
                        request.CancellationToken, 
                        stoppingToken);
                    timeoutCts.CancelAfter(TimeSpan.FromSeconds(10));

                    _logger.LogInformation("Processing Job {JobId}...", request.JobId);

                    // Simulate long work
                    await Task.Delay(TimeSpan.FromSeconds(5), timeoutCts.Token);

                    _logger.LogInformation("Job {JobId} completed.", request.JobId);
                }
                catch (OperationCanceledException)
                {
                    if (request.CancellationToken.IsCancellationRequested)
                    {
                        _logger.LogWarning("Job {JobId} cancelled by user.", request.JobId);
                    }
                    else
                    {
                        _logger.LogError("Job {JobId} timed out (exceeded 10s).", request.JobId);
                        _statusService.UpdateStatus(request.JobId, JobStatus.Failed);
                    }
                }
            }
        }
    }
}
