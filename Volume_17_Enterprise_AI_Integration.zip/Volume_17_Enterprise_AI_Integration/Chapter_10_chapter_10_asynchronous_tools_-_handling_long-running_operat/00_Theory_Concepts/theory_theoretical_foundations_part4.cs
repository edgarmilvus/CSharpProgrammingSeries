
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.cs
// Description: Theoretical Foundations
// ==========================================

// The abstraction that allows swapping infrastructure
public interface INotificationService
{
    Task SendStatusUpdateAsync(string userId, string jobId, JobStatus status);
}

// Implementation for WebSocket (Real-time UI)
public class WebSocketNotificationService : INotificationService { /* ... */ }

// Implementation for Email (Delayed notification)
public class EmailNotificationService : INotificationService { /* ... */ }

// The AI Agent or Controller only knows the interface
public class AiAgent
{
    private readonly INotificationService _notifier;

    public AiAgent(INotificationService notifier)
    {
        _notifier = notifier;
    }

    public async Task ProcessRequest(string request)
    {
        // Logic to determine long-running op
        var jobId = await _queue.EnqueueAsync(request);
        await _notifier.SendStatusUpdateAsync("user123", jobId, JobStatus.Queued);
    }
}
