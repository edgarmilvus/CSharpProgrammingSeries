
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;

// 1. Define the data structure for our long-running operation
public record JobRequest(string CustomerId, string ReportType);

// 2. Define the status of the job
public enum JobStatus { Pending, Processing, Completed, Failed }
public record JobResult(Guid JobId, JobStatus Status, string? Output = null, string? Error = null);

// 3. The "Job Store" - In-memory storage for job states (Replace with Redis/SQL in production)
public class JobStore
{
    private readonly ConcurrentDictionary<Guid, JobResult> _store = new();

    public void Update(JobResult result) => _store[result.JobId] = result;

    public JobResult? Get(Guid jobId) => _store.TryGetValue(jobId, out var result) ? result : null;
}

// 4. The Background Worker - Simulates the long-running process
public class ReportGenerationWorker(ILogger<ReportGenerationWorker> logger, JobStore jobStore) 
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // In a real app, this would listen to a message queue (e.g., RabbitMQ, Azure Service Bus).
        // For this demo, we simulate polling an internal queue.
        while (!stoppingToken.IsCancellationRequested)
        {
            // Find a pending job (simplified logic for demo)
            var pendingJob = jobStore.Get(Guid.Empty); // Placeholder logic
            
            // Simulate work delay
            await Task.Delay(2000, stoppingToken); 
            
            // In a real implementation, we would dequeue a job here.
            // Since we don't have a queue in this simple example, we will 
            // rely on the API endpoint to create the job and the worker to process it 
            // if we had a queue. 
            // For this specific "Hello World", the processing is triggered 
            // directly in the API endpoint below to keep the flow linear for the reader,
            // but the architecture supports the BackgroundService for scalability.
        }
    }
    
    // Public method to simulate processing a job immediately for this demo
    public async Task ProcessJobAsync(Guid jobId)
    {
        logger.LogInformation("Worker: Starting processing for Job {JobId}", jobId);
        
        // Update status to Processing
        jobStore.Update(new JobResult(jobId, JobStatus.Processing));
        
        // Simulate the heavy lifting (e.g., calling an external API, DB crunching)
        await Task.Delay(3000); // 3 seconds delay
        
        // Update status to Completed
        jobStore.Update(new JobResult(jobId, JobStatus.Completed, "Report Data: Q1 Revenue $1M"));
        logger.LogInformation("Worker: Finished processing for Job {JobId}", jobId);
    }
}

// 5. The API Controller - The entry point for the AI (or user)
public class JobController : Microsoft.AspNetCore.Mvc.ControllerBase
{
    private readonly JobStore _jobStore;
    private readonly IServiceProvider _serviceProvider; // To resolve the worker

    public JobController(JobStore jobStore, IServiceProvider serviceProvider)
    {
        _jobStore = jobStore;
        _serviceProvider = serviceProvider;
    }

    [Microsoft.AspNetCore.Mvc.HttpPost("api/jobs")]
    public IActionResult CreateJob([Microsoft.AspNetCore.MvcFromBody] JobRequest request)
    {
        var jobId = Guid.NewGuid();
        
        // 1. Immediately return the Job ID to the caller (LLM)
        _jobStore.Update(new JobResult(jobId, JobStatus.Pending));
        
        // 2. Trigger the background process (In a real app, push to queue. Here, we start it).
        // We resolve the worker from the DI container to invoke the logic.
        var worker = _serviceProvider.GetRequiredService<ReportGenerationWorker>();
        _ = Task.Run(() => worker.ProcessJobAsync(jobId)); // Fire and forget

        return Accepted(new { JobId = jobId, Message = "Job accepted. Poll status using the Job ID." });
    }

    [Microsoft.AspNetCore.Mvc.HttpGet("api/jobs/{jobId}")]
    public IActionResult GetStatus(Guid jobId)
    {
        var result = _jobStore.Get(jobId);
        if (result == null) return NotFound();
        
        return Ok(result);
    }
}

// 6. Main Application Setup
public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        
        // Register services
        builder.Services.AddSingleton<JobStore>();
        builder.Services.AddSingleton<ReportGenerationWorker>(); // Singleton to maintain state
        builder.Services.AddHostedService(p => p.GetRequiredService<ReportGenerationWorker>());
        builder.Services.AddControllers();

        var app = builder.Build();
        app.MapControllers();
        
        // 7. Simulate an AI Client calling the API
        Console.WriteLine("=== Simulating AI Client Request ===");
        SimulateAiClient(app.Services).Wait();
        
        app.Run(); 
    }

    private static async Task SimulateAiClient(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var jobStore = scope.ServiceProvider.GetRequiredService<JobStore>();
        var worker = scope.ServiceProvider.GetRequiredService<ReportGenerationWorker>();

        // Step A: AI sends request
        var jobId = Guid.NewGuid();
        Console.WriteLine($"[AI] Sending request to generate report for Job ID: {jobId}");
        
        // Step B: System acknowledges immediately
        jobStore.Update(new JobResult(jobId, JobStatus.Pending));
        Console.WriteLine($"[System] Job accepted. ID: {jobId}. Status: Pending");

        // Step C: System starts processing (Simulating the background worker)
        Console.WriteLine("[System] Background worker picked up the job...");
        await worker.ProcessJobAsync(jobId);

        // Step D: AI (or User) polls for status after some time
        await Task.Delay(1000); // Simulate time passing
        var status = jobStore.Get(jobId);
        Console.WriteLine($"[AI] Polling status for {jobId}...");
        Console.WriteLine($"[System] Status: {status?.Status}, Output: {status?.Output}");
    }
}
