
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace AiAgentLegacyIntegration
{
    // 1. Data Models
    // Represents the data structure we expect back from the legacy system.
    public record InventoryItem(
        [property: JsonPropertyName("id")] int Id,
        [property: JsonPropertyName("name")] string Name,
        [property: JsonPropertyName("stock_level")] int StockLevel
    );

    // 2. The Legacy System API (Simulated)
    // In the real world, this is an external service. We simulate it here to make the example runnable.
    public class LegacyInventoryApi : IDisposable
    {
        private readonly HttpListener _listener;
        private const string ExpectedApiKey = "LEGACY_KEY_12345";
        private const string ExpectedHeaderName = "X-Legacy-API-Key";

        public LegacyInventoryApi(string url)
        {
            _listener = new HttpListener();
            _listener.Prefixes.Add(url);
        }

        public void Start() => _listener.Start();
        public void Stop() => _listener.Stop();

        // Simulates the backend logic: Validate Key -> Return Data
        public async Task ListenAsync()
        {
            while (_listener.IsListening)
            {
                var context = await _listener.GetContextAsync();
                var request = context.Request;
                var response = context.Response;

                // Check for the specific API Key Header
                string? apiKey = request.Headers[ExpectedHeaderName];

                if (apiKey != ExpectedApiKey)
                {
                    response.StatusCode = 401; // Unauthorized
                    var errorBytes = Encoding.UTF8.GetBytes("Invalid API Key");
                    await response.OutputStream.WriteAsync(errorBytes, 0, errorBytes.Length);
                }
                else
                {
                    // Return mock JSON data
                    response.StatusCode = 200;
                    response.ContentType = "application/json";
                    
                    var mockData = new InventoryItem(101, "Enterprise Server X1", 42);
                    var json = JsonSerializer.Serialize(mockData);
                    var buffer = Encoding.UTF8.GetBytes(json);
                    
                    await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                }
                response.Close();
            }
        }

        public void Dispose() => _listener.Close();
    }

    // 3. The AI Agent / Client
    // This class represents the LLM backend wrapper that handles authentication.
    public class AiAgentClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;

        public AiAgentClient(string baseAddress, string apiKey)
        {
            _httpClient = new HttpClient { BaseAddress = new Uri(baseAddress) };
            _apiKey = apiKey;
        }

        public async Task<string> QueryInventoryAsync(string query)
        {
            Console.WriteLine($"[AI Agent] Thinking about: '{query}'...");
            
            // 4. Authentication Logic
            // We attach the API Key to the request headers.
            // This is the "Credential Injection" step.
            _httpClient.DefaultRequestHeaders.Remove("X-Legacy-API-Key");
            _httpClient.DefaultRequestHeaders.Add("X-Legacy-API-Key", _apiKey);

            Console.WriteLine($"[AI Agent] Authenticating with Legacy System using Key: {_apiKey[..5]}...");

            try 
            {
                // 5. Execution
                var response = await _httpClient.GetAsync("/api/v1/inventory");
                
                if (!response.IsSuccessStatusCode)
                {
                    return $"Error: Legacy system returned {response.StatusCode}. Check API Key validity.";
                }

                var content = await response.Content.ReadAsStringAsync();
                var item = JsonSerializer.Deserialize<InventoryItem>(content);
                
                return $"Success: Found '{item.Name}' with stock level {item.StockLevel}.";
            }
            catch (Exception ex)
            {
                return $"Connection failed: {ex.Message}";
            }
        }
    }

    // 6. Main Orchestrator
    public class Program
    {
        // Using a local loopback address for the simulation
        private const string LegacyApiUrl = "http://localhost:5000/";

        public static async Task Main(string[] args)
        {
            // Start the simulated Legacy System in the background
            using var legacyApi = new LegacyInventoryApi(LegacyApiUrl);
            legacyApi.Start();
            _ = legacyApi.ListenAsync(); // Fire and forget listener

            Console.WriteLine("--- Enterprise AI Integration: API Key Auth Demo ---");

            // SCENARIO 1: Failed Authentication
            Console.WriteLine("\n[Scenario 1] Attempting connection with WRONG key...");
            var badAgent = new AiAgentClient(LegacyApiUrl, "WRONG_KEY");
            var result1 = await badAgent.QueryInventoryAsync("Check stock for Server X1");
            Console.WriteLine($"Result: {result1}");

            // SCENARIO 2: Successful Authentication
            Console.WriteLine("\n[Scenario 2] Attempting connection with CORRECT key...");
            var goodAgent = new AiAgentClient(LegacyApiUrl, "LEGACY_KEY_12345");
            var result2 = await goodAgent.QueryInventoryAsync("Check stock for Server X1");
            Console.WriteLine($"Result: {result2}");
            
            legacyApi.Stop();
        }
    }
}
