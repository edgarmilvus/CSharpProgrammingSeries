
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Runtime.InteropServices;
using System.Security;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.RateLimit;

namespace EnterpriseAuthSolutions.Exercise3
{
    public interface ISecureKeyStore
    {
        Task<string> RetrieveKeyAsync(string scope);
        Task RotateKeyAsync(string scope);
    }

    // Mock implementation of the secure store
    public class MockSecureKeyStore : ISecureKeyStore
    {
        public async Task<string> RetrieveKeyAsync(string scope)
        {
            await Task.Delay(100); // Simulate network latency
            return $"Key_{scope}_{Guid.NewGuid()}";
        }

        public async Task RotateKeyAsync(string scope)
        {
            await Task.Delay(100); // Simulate rotation process
        }
    }

    public class ApiKeyVaultService
    {
        private readonly ISecureKeyStore _keyStore;
        private readonly ILogger<ApiKeyVaultService> _logger;
        private readonly AsyncRateLimitPolicy _rateLimitPolicy;

        public ApiKeyVaultService(ISecureKeyStore keyStore, ILogger<ApiKeyVaultService> logger)
        {
            _keyStore = keyStore;
            _logger = logger;

            // 5. Rate Limiting: Max 10 calls per minute to protect the vault
            _rateLimitPolicy = Policy.RateLimitAsync(10, TimeSpan.FromMinutes(1));
        }

        // 3. Scoping: Returns an IDisposable wrapper that handles the lifecycle of the key
        public async Task<SecureKeySession> GetKeySessionAsync(string scope)
        {
            // Audit Log (without the key)
            _logger.LogInformation("Audit: Requesting key for scope '{Scope}'", scope);

            // Retrieve key using rate limiter
            string plainKey = await _rateLimitPolicy.ExecuteAsync(async () => 
                await _keyStore.RetrieveKeyAsync(scope));

            // 2. Memory Security: Convert to SecureString immediately
            var secureString = new SecureString();
            foreach (char c in plainKey)
            {
                secureString.AppendChar(c);
            }
            secureString.MakeReadOnly();

            // Clear the plain string from memory asap (relying on GC, but explicit is better)
            // Note: In .NET, strings are immutable and cannot be forcibly zeroed immediately, 
            // but we can overwrite the char array if we constructed it differently. 
            // SecureString encrypts in memory, providing the required protection.

            return new SecureKeySession(secureString, this, scope);
        }

        // 6. Key Rotation Handling
        public async Task<string> ExecuteWithKeyAsync(string scope, Func<string, Task<string>> operation)
        {
            try
            {
                using var session = await GetKeySessionAsync(scope);
                // Decrypt SecureString for use
                string key = session.GetKey();
                
                return await operation(key);
            }
            catch (UnauthorizedAccessException) // Assuming operation throws this on 401
            {
                _logger.LogWarning("401 Unauthorized detected. Triggering key rotation for {Scope}", scope);
                
                // Rotate
                await _keyStore.RotateKeyAsync(scope);
                
                // Retry once
                using var session = await GetKeySessionAsync(scope);
                string key = session.GetKey();
                return await operation(key);
            }
        }
    }

    // 3. Scoping: IDisposable pattern for safe key usage
    public class SecureKeySession : IDisposable
    {
        private readonly SecureString _secureKey;
        private readonly ApiKeyVaultService _parentService;
        private readonly string _scope;
        private bool _disposed;

        public SecureKeySession(SecureString secureKey, ApiKeyVaultService parentService, string scope)
        {
            _secureKey = secureKey;
            _parentService = parentService;
            _scope = scope;
        }

        public string GetKey()
        {
            // Decrypt SecureString to use it
            IntPtr ptr = Marshal.SecureStringToBSTR(_secureKey);
            try
            {
                return Marshal.PtrToStringBSTR(ptr);
            }
            finally
            {
                // Security: Immediately zero out the memory
                Marshal.ZeroFreeBSTR(ptr);
            }
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                // SecureString is immutable and encrypted, but we ensure references are cleared
                // In a real scenario, we might also invalidate any cached references.
                _disposed = true;
            }
        }
    }
}
