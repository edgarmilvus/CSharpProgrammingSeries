
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.CircuitBreaker;
using Polly.RateLimit;

namespace EnterpriseAuthSolutions.Exercise5
{
    public class EnterpriseApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly AuthenticationOrchestrator _orchestrator;
        private readonly ILogger<EnterpriseApiClient> _logger;
        private readonly AsyncCircuitBreakerPolicy<HttpResponseMessage> _circuitBreakerPolicy;
        private readonly AsyncRateLimitPolicy _rateLimitPolicy;

        public EnterpriseApiClient(HttpClient httpClient, AuthenticationOrchestrator orchestrator, ILogger<EnterpriseApiClient> logger)
        {
            _httpClient = httpClient;
            _orchestrator = orchestrator;
            _logger = logger;

            // 4. Circuit Breaker: Breaks after 5 consecutive failures, waits 30s before trying again
            _circuitBreakerPolicy = Policy<HttpResponseMessage>
                .Handle<HttpRequestException>()
                .OrResult(r => r.StatusCode == System.Net.HttpStatusCode.InternalServerError || 
                               r.StatusCode == System.Net.HttpStatusCode.BadGateway)
                .CircuitBreakerAsync(
                    exceptionsAllowedBeforeBreaking: 5,
                    durationOfBreak: TimeSpan.FromSeconds(30),
                    onBreak: (ex, breakDelay) => _logger.LogError("Circuit Breaker opened for {Delay}s", breakDelay),
                    onReset: () => _logger.LogInformation("Circuit Breaker closed")
                );

            // Interactive Challenge: Throttling for high throughput
            // Limit to 20 concurrent requests to avoid overwhelming the target
            _rateLimitPolicy = Policy.RateLimitAsync(20, TimeSpan.FromSeconds(1));
        }

        // 6. Idempotency: Helper to generate keys
        private string GenerateIdempotencyKey() => Guid.NewGuid().ToString();

        public async Task<string> SendRequestAsync(string targetUrl, HttpMethod method, string? payload = null)
        {
            // 5. Telemetry: Stopwatch for latency
            var stopwatch = Stopwatch.StartNew();

            // 1. & 2. Request Pipeline: Construct and Authenticate
            // Note: In a real scenario, we might pass payload to PrepareRequestAsync
            var request = await _orchestrator.PrepareRequestAsync(targetUrl, method);
            
            if (payload != null)
            {
                request.Content = new StringContent(payload, System.Text.Encoding.UTF8, "application/json");
                
                // Idempotency for non-GET requests
                if (method != HttpMethod.Get)
                {
                    request.Headers.Add("Idempotency-Key", GenerateIdempotencyKey());
                }
            }

            try
            {
                // 3. Transmission with Circuit Breaker and Resilience
                var response = await _circuitBreakerPolicy.ExecuteAsync(async () =>
                {
                    // Enforce rate limit
                    return await _rateLimitPolicy.ExecuteAsync(async () =>
                    {
                        _logger.LogDebug("Sending request to {Url}", targetUrl);
                        return await _httpClient.SendAsync(request);
                    });
                });

                stopwatch.Stop();

                // 4. Enterprise Error Handling
                if (!response.IsSuccessStatusCode)
                {
                    await HandleEnterpriseErrors(response);
                }

                // 5. Telemetry: Log success
                _logger.LogInformation("Request to {Url} succeeded in {Ms}ms", targetUrl, stopwatch.ElapsedMilliseconds);

                return await response.Content.ReadAsStringAsync();
            }
            catch (BrokenCircuitException)
            {
                _logger.LogError("Circuit breaker is open. Request blocked to protect downstream system.");
                throw new Exception("Service temporarily unavailable due to high error rate.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Request failed.");
                throw;
            }
        }

        // Interactive Challenge: Async Batch Processing
        public async Task<List<string>> SendAsyncBatch(List<string> targetUrls, int maxConcurrency)
        {
            var results = new List<string>();
            
            // Semaphore to throttle concurrency manually if needed, or use ParallelOptions
            var options = new ParallelOptions { MaxDegreeOfParallelism = maxConcurrency };

            await Parallel.ForEachAsync(targetUrls, options, async (url, ct) =>
            {
                try
                {
                    var result = await SendRequestAsync(url, HttpMethod.Get);
                    lock (results) { results.Add(result); }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Batch request failed for {Url}", url);
                }
            });

            return results;
        }

        private async Task HandleEnterpriseErrors(HttpResponseMessage response)
        {
            // Check for specific headers
            if (response.Headers.TryGetValues("X-RateLimit-Reset", out var resetValues))
            {
                _logger.LogWarning("Rate limit hit. Reset at: {Reset}", resetValues.First());
            }

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                // Trigger orchestrator fallback or refresh
                _logger.LogWarning("401 detected. Auth token might be expired.");
                throw new UnauthorizedAccessException("Authentication failed.");
            }
            
            if (response.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                _logger.LogError("403 Forbidden. Insufficient permissions.");
                throw new AccessViolationException("Access denied by target system.");
            }

            // Ensure non-success is thrown as exception if not handled specifically
            response.EnsureSuccessStatusCode();
        }
    }
}
