
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace EnterpriseAuthSolutions.Exercise4
{
    // Configuration Schema
    // {
    //   "targets": {
    //     "https://api.crm.internal": { "authType": "OAuth2", "clientId": "...", "scope": "read" },
    //     "https://legacy-soap.internal": { "authType": "mTLS", "certThumbprint": "..." },
    //     "https://partner-api.com": { "authType": "ApiKey", "headerName": "X-API-Key" }
    //   }
    // }

    public class AuthMetadata
    {
        public string AuthType { get; set; } = string.Empty;
        public Dictionary<string, string> Parameters { get; set; } = new();
    }

    // Strategy Interface
    public interface IAuthStrategy
    {
        Task ApplyAuthenticationAsync(HttpRequestMessage request, AuthMetadata metadata);
    }

    // Concrete Strategies (Stubs for brevity)
    public class OAuth2Strategy : IAuthStrategy
    {
        // Inject TokenService here in real implementation
        public async Task ApplyAuthenticationAsync(HttpRequestMessage request, AuthMetadata metadata)
        {
            // Simulate token retrieval
            string token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."; 
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            await Task.CompletedTask;
        }
    }

    public class ApiKeyStrategy : IAuthStrategy
    {
        public async Task ApplyAuthenticationAsync(HttpRequestMessage request, AuthMetadata metadata)
        {
            if (metadata.Parameters.TryGetValue("headerName", out var headerName))
            {
                // Retrieve key securely (using Exercise 3 logic ideally)
                string apiKey = "secret_key_value";
                request.Headers.Add(headerName, apiKey);
            }
            await Task.CompletedTask;
        }
    }

    public class mTLSStrategy : IAuthStrategy
    {
        // Note: mTLS requires modifying HttpClientHandler, not just HttpRequestMessage.
        // For this exercise, we simulate attaching metadata or assuming the handler is pre-configured.
        // In a real orchestrator, this might return a specific Handler configuration.
        public async Task ApplyAuthenticationAsync(HttpRequestMessage request, AuthMetadata metadata)
        {
            // In a pure HttpRequestMessage context, mTLS is handled by the client handler.
            // We can log or tag the request context here.
            request.Headers.Add("X-Client-Cert-Thumbprint", metadata.Parameters.GetValueOrDefault("certThumbprint", "unknown"));
            await Task.CompletedTask;
        }
    }

    public class AuthenticationOrchestrator
    {
        private readonly IConfiguration _configuration;
        private readonly IServiceProvider _serviceProvider;
        private readonly Dictionary<string, IAuthStrategy> _strategies;

        public AuthenticationOrchestrator(IConfiguration configuration, IServiceProvider serviceProvider)
        {
            _configuration = configuration;
            _serviceProvider = serviceProvider;
            
            // Strategy Factory registration
            _strategies = new Dictionary<string, IAuthStrategy>
            {
                { "OAuth2", new OAuth2Strategy() },
                { "ApiKey", new ApiKeyStrategy() },
                { "mTLS", new mTLSStrategy() }
            };
        }

        public async Task<HttpRequestMessage> PrepareRequestAsync(string targetUrl, HttpMethod method, HttpContent? content = null)
        {
            // 1. Config Lookup
            var targetConfig = _configuration.GetSection($"Targets:{targetUrl}");
            if (!targetConfig.Exists())
            {
                throw new InvalidOperationException($"No auth configuration found for {targetUrl}");
            }

            var metadata = new AuthMetadata
            {
                AuthType = targetConfig["AuthType"] ?? "None"
            };
            
            // Bind parameters
            foreach (var child in targetConfig.GetSection("Parameters").GetChildren())
            {
                metadata.Parameters[child.Key] = child.Value!;
            }

            // 2. Strategy Selection
            if (!_strategies.TryGetValue(metadata.AuthType, out var strategy))
            {
                throw new NotSupportedException($"Auth type {metadata.AuthType} is not supported.");
            }

            // 3. Context Handling
            var request = new HttpRequestMessage(method, targetUrl);
            if (content != null) request.Content = content;

            // Apply Auth
            await strategy.ApplyAuthenticationAsync(request, metadata);

            return request;
        }

        // 4. Fallback Mechanism (Basic implementation)
        public async Task<HttpResponseMessage> SendWithFallbackAsync(HttpClient client, string targetUrl, HttpMethod method)
        {
            var request = await PrepareRequestAsync(targetUrl, method);
            
            try
            {
                var response = await client.SendAsync(request);
                
                // If 401, try to refresh token or rotate key and retry once
                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    // Logic to refresh token/cert would go here
                    // For this exercise, we assume the strategy handles internal state or retries
                    // Re-prepare request (which might fetch a new token)
                    request = await PrepareRequestAsync(targetUrl, method);
                    response = await client.SendAsync(request);
                }
                
                return response;
            }
            catch (Exception ex)
            {
                // Log and rethrow or handle
                throw new Exception($"Request failed after fallback attempts: {ex.Message}", ex);
            }
        }
    }
}
