
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;

namespace EnterpriseAuthSolutions.Exercise1
{
    // Strongly-typed configuration for OAuth2 settings
    public class OAuth2Options
    {
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
        public string TokenEndpoint { get; set; } = string.Empty;
        public string Scope { get; set; } = string.Empty;
    }

    // DTO for the token response
    public class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = string.Empty;
    }

    public class OAuth2TokenService : IDisposable
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<OAuth2TokenService> _logger;
        private readonly OAuth2Options _options;
        private readonly AsyncRetryPolicy _retryPolicy;

        // State for caching and synchronization
        private string? _cachedToken;
        private DateTime _tokenExpiry;
        private readonly SemaphoreSlim _semaphore = new(1, 1);
        private readonly TimeSpan _expirationBuffer = TimeSpan.FromMinutes(5);

        public OAuth2TokenService(HttpClient httpClient, ILogger<OAuth2TokenService> logger, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _logger = logger;
            
            // Bind configuration
            _options = new OAuth2Options();
            configuration.GetSection("OAuth2").Bind(_options);

            // 1. Implement retry logic with exponential backoff
            // Handles 429 (Too Many Requests) and 5xx Server Errors
            _retryPolicy = Policy
                .Handle<HttpRequestException>()
                .OrResult<HttpResponseMessage>(r => r.StatusCode == System.Net.HttpStatusCode.TooManyRequests || 
                                                    (int)r.StatusCode >= 500)
                .WaitAndRetryAsync(
                    retryCount: 3,
                    sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                    onRetry: (outcome, timespan, retryCount, context) =>
                    {
                        _logger.LogWarning("Retry {RetryCount} after {Delay}s due to {StatusCode}", 
                            retryCount, timespan.TotalSeconds, outcome.Result?.StatusCode ?? "Exception");
                    });
        }

        public async Task<string> GetAccessTokenAsync(CancellationToken cancellationToken = default)
        {
            // 2. Check cache first (Double-checked locking pattern simplified with semaphore)
            if (!string.IsNullOrEmpty(_cachedToken) && DateTime.UtcNow < _tokenExpiry)
            {
                _logger.LogDebug("Token retrieved from cache.");
                return _cachedToken;
            }

            // 3. Thread Safety: Use semaphore to prevent concurrent token requests
            await _semaphore.WaitAsync(cancellationToken);
            try
            {
                // Check again inside the lock
                if (!string.IsNullOrEmpty(_cachedToken) && DateTime.UtcNow < _tokenExpiry)
                {
                    return _cachedToken;
                }

                _logger.LogInformation("Acquiring new token from Auth Server...");

                // 4. Execute Client Credentials Flow with Retry Policy
                var response = await _retryPolicy.ExecuteAsync(async () =>
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, _options.TokenEndpoint);
                    
                    // Client Credentials Grant: Send credentials as form-urlencoded
                    var content = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("grant_type", "client_credentials"),
                        new KeyValuePair<string, string>("client_id", _options.ClientId),
                        new KeyValuePair<string, string>("client_secret", _options.ClientSecret),
                        new KeyValuePair<string, string>("scope", _options.Scope)
                    });
                    
                    request.Content = content;

                    return await _httpClient.SendAsync(request, cancellationToken);
                });

                if (response.IsSuccessStatusCode)
                {
                    var tokenData = await response.Content.ReadFromJsonAsync<TokenResponse>(cancellationToken: cancellationToken);
                    
                    if (tokenData != null)
                    {
                        // Apply expiration buffer (e.g., expire 5 minutes early)
                        _cachedToken = tokenData.AccessToken;
                        _tokenExpiry = DateTime.UtcNow.AddSeconds(tokenData.ExpiresIn).Subtract(_expirationBuffer);
                        
                        _logger.LogInformation("Token acquired successfully. Expires at {Expiry}", _tokenExpiry);
                        return _cachedToken;
                    }
                }

                throw new Exception($"Failed to retrieve token. Status: {response.StatusCode}");
            }
            finally
            {
                _semaphore.Release();
            }
        }

        public void Dispose()
        {
            _semaphore.Dispose();
        }
    }
}
