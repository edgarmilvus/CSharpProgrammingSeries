
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Net.Http;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace EnterpriseAuthSolutions.Exercise2
{
    public class SecureSoapClient : IDisposable
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<SecureSoapClient> _logger;
        
        // Hardcoded whitelist for simulation (in production, load from config)
        private readonly string[] _allowedServerThumbprints = { "A1B2C3D4E5F6..." }; 

        public SecureSoapClient(HttpClient httpClient, ILogger<SecureSoapClient> logger, X509Certificate2 clientCertificate)
        {
            _httpClient = httpClient;
            _logger = logger;

            // 1. Configure HttpClientHandler to enforce TLS 1.2 and Client Cert
            // Note: In modern .NET, SslProtocols is configured on the handler
            var handler = new HttpClientHandler();
            
            // Enforce TLS 1.2 specifically
            handler.SslProtocols = SslProtocols.Tls12;

            // 3. Attach Client Certificate (mTLS)
            handler.ClientCertificates = new X509CertificateCollection { clientCertificate };

            // 4. Custom Server Certificate Validation
            handler.ServerCertificateCustomValidationCallback = (request, cert, chain, errors) =>
            {
                if (cert == null) return false;

                // Log validation details
                _logger.LogDebug("Validating Server Certificate: {Subject}, Thumbprint: {Thumbprint}", 
                    cert.Subject, cert.Thumbprint);

                // Check expiration
                if (cert.NotAfter < DateTime.Now)
                {
                    _logger.LogError("Server certificate expired.");
                    return false;
                }

                // Strict Whitelist Check
                if (Array.Exists(_allowedServerThumbprints, t => t.Equals(cert.Thumbprint, StringComparison.OrdinalIgnoreCase)))
                {
                    _logger.LogInformation("Server certificate thumbprint allowed.");
                    return true;
                }

                _logger.LogError("Server certificate thumbprint not in whitelist.");
                return false;
            };
        }

        public async Task<string> SendSoapRequestAsync(string endpoint, string soapBody)
        {
            // 5. Legacy Constraints: Headers
            var request = new HttpRequestMessage(HttpMethod.Post, endpoint);
            request.Headers.Add("User-Agent", "LegacySoapClient/1.0");
            request.Headers.Add("SOAPAction", "http://tempuri.org/Execute"); // Example SOAP Action
            
            request.Content = new StringContent(soapBody, System.Text.Encoding.UTF8, "text/xml");

            _logger.LogInformation("Sending SOAP request to {Endpoint}", endpoint);

            try
            {
                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SOAP Request failed.");
                throw;
            }
        }

        public void Dispose()
        {
            _httpClient?.Dispose();
        }
    }

    // 6. IHttpClientFactory Integration (Usage in DI container)
    public static class SecureSoapClientFactory
    {
        public static IServiceCollection AddSecureSoapClient(this IServiceCollection services, string certPath, string certPassword)
        {
            services.AddTransient<X509Certificate2>(provider => 
                new X509Certificate2(certPath, certPassword));

            services.AddHttpClient<SecureSoapClient>(client =>
            {
                // Base address if needed
            })
            .ConfigurePrimaryHttpMessageHandler(() =>
            {
                var handler = new HttpClientHandler();
                handler.SslProtocols = SslProtocols.Tls12;
                // Note: Cert loading logic would be injected here via DI
                return handler;
            });

            return services;
        }
    }
}
