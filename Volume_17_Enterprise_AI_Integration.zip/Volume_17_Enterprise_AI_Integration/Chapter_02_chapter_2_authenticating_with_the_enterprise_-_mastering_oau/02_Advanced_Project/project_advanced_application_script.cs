
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace EnterpriseAuthOrchestrator
{
    // Real-World Context:
    // A manufacturing company needs to automate inventory tracking. An AI Agent (LLM) must:
    // 1. Authenticate as a user to the legacy ERP system (OAuth2) to fetch purchase orders.
    // 2. Securely transmit sensitive order data to a secure warehouse API (mTLS).
    // 3. Log the transaction into a generic internal audit system (API Key).
    // This application orchestrates these three distinct authentication methods.

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== Enterprise AI Integration: Authentication Orchestrator ===\n");

            // Configuration Simulation
            // In a real scenario, these would be loaded from secure environment variables or a vault.
            var config = new AuthConfig
            {
                OAuthTokenUrl = "https://auth.legacy-erp.com/token",
                OAuthClientId = "ai-agent-client-id",
                OAuthClientSecret = "super-secret-value",
                MtlsApiUrl = "https://secure-warehouse.internal/api/v1/inventory",
                ApiKeyHeaderName = "X-API-Key",
                ApiKeyValue = "audit-log-key-12345"
            };

            // Step 1: Obtain User Delegation via OAuth2 (Client Credentials Flow)
            // The AI Agent acts on behalf of a service account.
            string oauthToken = await AuthenticateWithOAuthAsync(config);
            if (string.IsNullOrEmpty(oauthToken))
            {
                Console.WriteLine("Critical Failure: Authentication failed. Aborting workflow.");
                return;
            }

            // Step 2: Secure Data Transmission via mTLS
            // We generate a client certificate to prove the AI Agent's identity to the warehouse.
            // NOTE: In a real app, the PFX would be loaded from a secure store, not generated on the fly.
            X509Certificate2 clientCertificate = GenerateSelfSignedCertificate();
            string inventoryData = await FetchInventoryViaMtlsAsync(config, clientCertificate, oauthToken);

            // Step 3: Audit Logging via API Key
            // We log the successful transaction to a generic internal system.
            bool logSuccess = await LogTransactionAsync(config, inventoryData);

            // Final Output
            Console.WriteLine(logSuccess 
                ? "\nWorkflow Complete: Authenticated, Retrieved, and Logged." 
                : "\nWorkflow Partially Failed: Logging failed.");
        }

        // --- Method 1: OAuth2 Implementation ---
        static async Task<string> AuthenticateWithOAuthAsync(AuthConfig config)
        {
            Console.WriteLine("[1] Initiating OAuth2 Client Credentials Flow...");

            using (var client = new HttpClient())
            {
                try
                {
                    // Construct the form-urlencoded body
                    var parameters = new List<string>
                    {
                        $"grant_type=client_credentials",
                        $"client_id={config.OAuthClientId}",
                        $"client_secret={config.OAuthClientSecret}"
                    };
                    var content = new StringContent(string.Join("&", parameters), Encoding.UTF8, "application/x-www-form-urlencoded");

                    // Simulate network request
                    // In production, use IHttpClientFactory and resilience policies (Polly)
                    var response = await client.PostAsync(config.OAuthTokenUrl, content);
                    
                    if (response.IsSuccessStatusCode)
                    {
                        // Simulate parsing JSON response (avoiding complex JSON libraries for this exercise)
                        // Real response: {"access_token": "xyz", "expires_in": 3600}
                        string responseBody = "{\"access_token\": \"mock-jwt-token-xyz\", \"expires_in\": 3600}";
                        Console.WriteLine("   > Token received successfully.");
                        return "mock-jwt-token-xyz"; 
                    }
                    else
                    {
                        Console.WriteLine($"   > Error: {response.StatusCode}");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   > Network Exception: {ex.Message}");
                    return null;
                }
            }
        }

        // --- Method 2: mTLS Implementation ---
        static async Task<string> FetchInventoryViaMtlsAsync(AuthConfig config, X509Certificate2 clientCert, string bearerToken)
        {
            Console.WriteLine("\n[2] Establishing mTLS Connection for Secure Data Transfer...");

            // The critical component for mTLS: A custom certificate validation callback.
            // This ensures the SERVER certificate is trusted (e.g., issued by internal CA).
            // For this demo, we accept any certificate, but in production, strict validation is required.
            HttpClientHandler handler = new HttpClientHandler
            {
                ClientCertificateOptions = ClientCertificateOption.Manual,
                ClientCertificates = { clientCert },
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) =>
                {
                    if (sslPolicyErrors == SslPolicyErrors.None) return true;
                    // In a real internal network, you might check the chain against a specific Root CA
                    Console.WriteLine("   > [Warning] Server cert validation skipped for demo purposes.");
                    return true; 
                }
            };

            using (var client = new HttpClient(handler))
            {
                try
                {
                    // Add the OAuth2 Bearer Token to the header
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", bearerToken);

                    var response = await client.GetAsync(config.MtlsApiUrl);
                    
                    if (response.IsSuccessStatusCode)
                    {
                        string data = "{\"item_id\": \"A-100\", \"quantity\": 500, \"location\": \"Zone B\"}";
                        Console.WriteLine("   > Secure data retrieved via mTLS.");
                        return data;
                    }
                    else
                    {
                        Console.WriteLine($"   > mTLS Request Failed: {response.StatusCode}");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   > mTLS Connection Error: {ex.Message}");
                    return null;
                }
            }
        }

        // --- Method 3: API Key Implementation ---
        static async Task<bool> LogTransactionAsync(AuthConfig config, string data)
        {
            Console.WriteLine("\n[3] Logging Transaction via API Key...");

            using (var client = new HttpClient())
            {
                try
                {
                    // Add the API Key to the custom header
                    client.DefaultRequestHeaders.Add(config.ApiKeyHeaderName, config.ApiKeyValue);

                    // Simulate sending a POST request with the inventory data
                    var payload = new StringContent($"{{\"log\": \"Processed inventory: {data}\"}}", Encoding.UTF8, "application/json");
                    
                    // Simulate endpoint
                    var response = await client.PostAsync("https://audit-system.internal/log", payload);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("   > Transaction logged successfully.");
                        return true;
                    }
                    else
                    {
                        Console.WriteLine($"   > Logging Failed: {response.StatusCode}");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   > Logging Error: {ex.Message}");
                    return false;
                }
            }
        }

        // --- Helper: Certificate Generation (Simulating mTLS Identity) ---
        // In a real scenario, this certificate is provisioned via PKI (e.g., Active Directory Certificate Services).
        static X509Certificate2 GenerateSelfSignedCertificate()
        {
            Console.WriteLine("   > Generating temporary client certificate for mTLS...");
            
            using (RSA rsa = RSA.Create(2048))
            {
                var request = new CertificateRequest(
                    "CN=ai-agent-service, O=ManufacturingCorp, C=US",
                    rsa,
                    HashAlgorithmName.SHA256,
                    RSASignaturePadding.Pkcs1);

                // Create a self-signed certificate valid for 1 day
                var certificate = request.CreateSelfSigned(
                    DateTimeOffset.Now,
                    DateTimeOffset.Now.AddDays(1));

                // Export as PFX (includes private key)
                return new X509Certificate2(certificate.Export(X509ContentType.Pfx));
            }
        }
    }

    // Configuration Class (Basic Structure)
    public class AuthConfig
    {
        public string OAuthTokenUrl { get; set; }
        public string OAuthClientId { get; set; }
        public string OAuthClientSecret { get; set; }
        public string MtlsApiUrl { get; set; }
        public string ApiKeyHeaderName { get; set; }
        public string ApiKeyValue { get; set; }
    }
}
