
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.cs
// Description: Theoretical Foundations
// ==========================================

// Program.cs (Configuration)

// 1. Client for a legacy system requiring mTLS
services.AddHttpClient("LegacySystemClient", client => 
    {
        client.BaseAddress = new Uri("https://legacy.enterprise.internal");
    })
    .AddClientCertificate(() => LoadCertificateFromStore("LegacySystemThumbprint"));

// 2. Client for a user-facing API requiring OAuth
services.AddHttpClient("UserApiClient", client =>
    {
        client.BaseAddress = new Uri("https://api.enterprise.internal");
    })
    .AddHttpMessageHandler<OAuthTokenHandler>(); // Custom handler injecting Bearer tokens

// 3. Client for a simple utility service
services.AddHttpClient("UtilityClient", client =>
    {
        client.BaseAddress = new Uri("https://utils.enterprise.internal");
    })
    .AddHttpMessageHandler<ApiKeyHandler>();
