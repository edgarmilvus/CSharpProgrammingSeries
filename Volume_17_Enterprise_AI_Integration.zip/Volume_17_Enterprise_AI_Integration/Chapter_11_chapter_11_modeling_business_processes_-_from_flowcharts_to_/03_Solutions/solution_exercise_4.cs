
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;

namespace PartialShipmentFSM
{
    // 1. State Expansion: New state 'PartiallyShipped'
    public abstract record OrderState;
    public record New : OrderState;
    public record PaymentReceived : OrderState;
    public record Fulfillment : OrderState;
    public record PartiallyShipped : OrderState;
    public record Shipped : OrderState;

    // 2. Order Entity: Using record struct for value semantics
    public record struct OrderEntity
    {
        public required int TotalQuantity { get; init; }
        public int ShippedQuantity { get; private set; }

        public void Ship(int qty)
        {
            if (ShippedQuantity + qty > TotalQuantity) 
                throw new InvalidOperationException("Cannot ship more than total.");
            ShippedQuantity += qty;
        }

        public bool IsComplete => ShippedQuantity == TotalQuantity;
    }

    public class OrderStateMachine
    {
        public OrderState CurrentState { get; private set; } = new New();
        public OrderEntity Order { get; private set; }

        public void SetOrder(OrderEntity order) => Order = order;

        public void Process(string action, int quantity = 0)
        {
            try 
            {
                // Pattern matching on State and Action
                var nextState = (CurrentState, action) switch
                {
                    // Standard Flow
                    (New, "Pay") => new PaymentReceived(),
                    (PaymentReceived, "StartFulfillment") => new Fulfillment(),

                    // Partial Shipment Logic
                    (Fulfillment, "Ship") => HandleShipment(quantity),
                    (PartiallyShipped, "Ship") => HandleShipment(quantity),
                    
                    // Loop Prevention: PartiallyShipped -> Fulfillment (to pick more)
                    (PartiallyShipped, "ResumeFulfillment") => new Fulfillment(),
                    
                    // Constraint: Cannot go back to PaymentReceived
                    (PartiallyShipped, "Refund") => throw new InvalidOperationException("Cannot refund partially shipped order automatically."),

                    _ => throw new InvalidOperationException("Invalid Action for current State")
                };

                CurrentState = nextState;
                Console.WriteLine($"Action: {action}. New State: {CurrentState}, Shipped: {Order.ShippedQuantity}/{Order.TotalQuantity}");
            }
            catch (Exception ex) { Console.WriteLine($"Error: {ex.Message}"); }
        }

        private OrderState HandleShipment(int qty)
        {
            Order.Ship(qty);
            
            if (Order.IsComplete)
            {
                return new Shipped();
            }
            else
            {
                // If not complete, we are partially shipped
                return new PartiallyShipped();
            }
        }
    }
    
    // 3. Visualization (DOT Graph)
    /*
    digraph OrderProcess {
        node [shape=box];
        New -> PaymentReceived [label="Pay"];
        PaymentReceived -> Fulfillment [label="StartFulfillment"];
        
        // The Loop
        Fulfillment -> PartiallyShipped [label="Ship (Partial)"];
        PartiallyShipped -> Fulfillment [label="ResumeFulfillment"];
        
        // Completion
        Fulfillment -> Shipped [label="Ship (Full)"];
        PartiallyShipped -> Shipped [label="Ship (Remainder)"];
        
        // Constraints (Visualized)
        Fulfillment -> Cancelled [style="dashed", color="red", label="Cancel (Blocked)"];
    }
    */
}
