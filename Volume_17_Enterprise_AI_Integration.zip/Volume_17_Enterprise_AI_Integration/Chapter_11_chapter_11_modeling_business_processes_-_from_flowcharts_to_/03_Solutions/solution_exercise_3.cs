
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Threading.Tasks;

namespace LoanApplicationRiskEngine
{
    // 1. Event Payloads: Records to hold input data
    public record struct LoanData(int CreditScore, decimal Amount);
    
    // 2. State Definitions
    public enum AppState
    {
        DataEntry,
        RiskReview,
        DocumentVerification,
        AutoApproval,
        ManualUnderwriting,
        Approved,
        Rejected
    }

    public class LoanMachine
    {
        public AppState CurrentState { get; private set; } = AppState.DataEntry;
        private LoanData _currentData;

        // 3. Interactive Loop Logic
        public void ProcessInput(string input)
        {
            // Switch Expression for command parsing
            var result = input.Split(' ');
            var command = result[0].ToLower();

            // State Transition Logic
            switch (CurrentState)
            {
                case AppState.DataEntry:
                    if (command == "submit" && result.Length == 3)
                    {
                        if (int.TryParse(result[1], out int score) && decimal.TryParse(result[2], out decimal amount))
                        {
                            HandleDataEntry(score, amount);
                        }
                        else Console.WriteLine("Invalid numbers.");
                    }
                    else Console.WriteLine("Usage: submit <score> <amount>");
                    break;

                case AppState.RiskReview:
                    if (command == "upload")
                    {
                        Console.WriteLine("Documents uploaded. Moving to Verification...");
                        CurrentState = AppState.DocumentVerification;
                    }
                    else if (command == "reconsider" && result.Length == 3)
                    {
                        if (int.TryParse(result[1], out int score) && decimal.TryParse(result[2], out decimal amount))
                        {
                            Console.WriteLine("Reconsideration submitted. Re-evaluating...");
                            // Re-evaluate based on new data
                            HandleDataEntry(score, amount);
                        }
                    }
                    else Console.WriteLine("Commands: upload, reconsider <score> <amount>");
                    break;

                case AppState.DocumentVerification:
                    Console.WriteLine("Verification complete. Approved based on documents.");
                    CurrentState = AppState.Approved;
                    break;
                
                default:
                    Console.WriteLine($"Current State: {CurrentState}. No further actions available.");
                    break;
            }
        }

        private void HandleDataEntry(int score, decimal amount)
        {
            _currentData = new LoanData(score, amount);
            
            // 4. Data-Driven Branching
            if (score > 700)
            {
                if (amount < 50000)
                {
                    CurrentState = AppState.AutoApproval;
                    Console.WriteLine("Auto-Approved!");
                }
                else
                {
                    CurrentState = AppState.ManualUnderwriting;
                    Console.WriteLine("Sent to Manual Underwriting.");
                }
            }
            else
            {
                CurrentState = AppState.RiskReview;
                Console.WriteLine("Sent to Risk Review.");
            }
        }
    }

    public class Program
    {
        public static async Task Main()
        {
            var machine = new LoanMachine();
            Console.WriteLine("Loan Engine Started. Commands: submit <score> <amount>, upload, reconsider <score> <amount>, exit");

            while (true)
            {
                Console.Write("> ");
                var input = Console.ReadLine();
                if (input == "exit") break;

                if (!string.IsNullOrWhiteSpace(input))
                {
                    machine.ProcessInput(input);
                }
            }
        }
    }
}
