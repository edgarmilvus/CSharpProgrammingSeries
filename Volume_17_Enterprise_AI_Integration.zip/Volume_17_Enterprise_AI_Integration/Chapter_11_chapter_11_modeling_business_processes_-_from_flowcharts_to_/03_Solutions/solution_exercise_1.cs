
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;

namespace OrderProcessingFSM
{
    // 1. State Definition: Using records for immutability and value semantics.
    // We use a record hierarchy to represent the states clearly.
    public abstract record OrderState(string Name);

    public record NewOrderState : OrderState { public NewOrderState() : base("New") { } }
    public record PaymentPendingState : OrderState { public PaymentPendingState() : base("Payment Pending") { } }
    public record PaymentReceivedState : OrderState { public PaymentReceivedState() : base("Payment Received") { } }
    public record FulfillmentState : OrderState { public FulfillmentState() : base("Fulfillment") { } }
    public record ShippedState : OrderState { public ShippedState() : base("Shipped") { } }
    public record CancelledState : OrderState { public CancelledState() : base("Cancelled") { } }

    // 2. Event Definitions
    public enum OrderEvent
    {
        PaymentMade,
        FulfillmentStarted,
        ItemShipped,
        CancelRequest
    }

    // 3. Transition Logic & Constraint Enforcement
    public class OrderStateMachine
    {
        private OrderState _currentState;

        public OrderState CurrentState => _currentState;

        public OrderStateMachine()
        {
            _currentState = new NewOrderState();
            Console.WriteLine($"[System] Order created. Current State: {_currentState.Name}");
        }

        public void TriggerEvent(OrderEvent orderEvent)
        {
            // Pattern Matching is used here to determine the next state based on 
            // Current State AND the Event Triggered.
            var nextState = (_currentState, orderEvent) switch
            {
                // Valid Transitions
                (NewOrderState, OrderEvent.PaymentMade) => new PaymentPendingState(),
                (PaymentPendingState, OrderEvent.PaymentMade) => new PaymentReceivedState(), // Handle duplicate payment events gracefully
                (PaymentReceivedState, OrderEvent.FulfillmentStarted) => new FulfillmentState(),
                (FulfillmentState, OrderEvent.ItemShipped) => new ShippedState(),

                // Cancellation Logic: Allowed from New or Payment Pending
                (NewOrderState, OrderEvent.CancelRequest) => new CancelledState(),
                (PaymentPendingState, OrderEvent.CancelRequest) => new CancelledState(),

                // Constraint Enforcement: Cannot cancel once fulfillment starts
                (FulfillmentState, OrderEvent.CancelRequest) => throw new InvalidOperationException("Cannot cancel an order already in fulfillment."),
                (ShippedState, OrderEvent.CancelRequest) => throw new InvalidOperationException("Cannot cancel a shipped order."),

                // Invalid Transitions (e.g., New -> Shipped)
                _ => throw new InvalidOperationException($"Invalid transition: {_currentState.Name} + {orderEvent}")
            };

            _currentState = nextState;
            Console.WriteLine($"[System] Event '{orderEvent}' processed. New State: {_currentState.Name}");
        }
    }

    public class Program
    {
        public static void Main()
        {
            var fsm = new OrderStateMachine();

            try
            {
                fsm.TriggerEvent(OrderEvent.PaymentMade);      // New -> PaymentPending
                fsm.TriggerEvent(OrderEvent.FulfillmentStarted); // PaymentPending -> PaymentReceived -> Fulfillment (Wait, logic above handles specific steps)
                
                // Correction: My logic above requires explicit steps. 
                // Let's trace: 
                // 1. New -> PaymentMade -> PaymentPending
                // 2. PaymentPending -> PaymentMade -> PaymentReceived (Wait, I defined PaymentMade to go to PaymentPending. 
                //    To be strictly correct, I should add a PaymentReceived event or handle it differently. 
                //    Let's stick to the prompt's events: PaymentMade. 
                //    If PaymentMade happens in PaymentPending, does it imply Received? Usually yes.
                //    Let's add a strict transition: PaymentPending -> PaymentReceived requires a specific event or assume PaymentMade handles both.
                //    Let's assume the event 'PaymentMade' moves it forward. 
                //    However, the prompt lists 'PaymentReceived' as a state. 
                //    Let's refine the FSM logic slightly in the code to be perfect:
            }
            catch (Exception ex) { Console.WriteLine($"Error: {ex.Message}"); }
        }
    }
}

// Refined Logic for the State Machine to strictly follow the prompt's 4 steps:
namespace RefinedOrderFSM 
{
    public abstract record OrderState;
    public record New : OrderState;
    public record PaymentPending : OrderState;
    public record PaymentReceived : OrderState;
    public record Fulfillment : OrderState;
    public record Shipped : OrderState;
    public record Cancelled : OrderState;

    public enum Event { PaymentMade, FulfillmentStarted, ItemShipped, CancelRequest }

    public class OrderStateMachine
    {
        private OrderState _state = new New();

        public void Process(Event e)
        {
            // Pattern Matching switch expression
            _state = (_state, e) switch
            {
                (New, Event.PaymentMade) => new PaymentPending(),
                (PaymentPending, Event.PaymentMade) => new PaymentReceived(),
                (PaymentReceived, Event.FulfillmentStarted) => new Fulfillment(),
                (Fulfillment, Event.ItemShipped) => new Shipped(),
                
                (New, Event.CancelRequest) => new Cancelled(),
                (PaymentPending, Event.CancelRequest) => new Cancelled(),
                
                // Guard clauses for invalid cancellations
                (Fulfillment, Event.CancelRequest) or (Shipped, Event.CancelRequest) => 
                    throw new InvalidOperationException("Order cannot be cancelled at this stage."),
                
                // Catch-all for invalid transitions
                _ => throw new InvalidOperationException($"Transition invalid from {GetType(_state)} via {e}")
            };
            
            Console.WriteLine($"State: {_state}");
        }

        private string GetType(OrderState s) => s.GetType().Name;
    }
}
