
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Threading;
using System.Threading.Tasks;

namespace ApiRetryFSM
{
    public enum ApiState
    {
        Idle,
        Pending,
        RetryPending,
        RateLimited,
        Completed,
        Failed
    }

    public class ApiRequestMachine
    {
        public ApiState CurrentState { get; private set; } = ApiState.Idle;
        private int _retryCount = 0;
        private readonly int _maxRetries = 3;
        private readonly TimeSpan _rateLimitDuration = TimeSpan.FromSeconds(2);

        // 1. Time-Driven Transitions: Using async method
        public async Task ExecuteRequestAsync(Func<CancellationToken, Task<bool>> apiCall, CancellationToken ct)
        {
            // Loop until terminal state
            while (true)
            {
                switch (CurrentState)
                {
                    case ApiState.Idle:
                        CurrentState = ApiState.Pending;
                        Console.WriteLine($"[State: {CurrentState}] Sending request...");
                        break;

                    case ApiState.Pending:
                        try
                        {
                            // Simulate API Call
                            bool success = await apiCall(ct);
                            
                            if (success)
                            {
                                CurrentState = ApiState.Completed;
                                Console.WriteLine("[State: Completed] Success!");
                                return;
                            }
                            else
                            {
                                // Simulate generic error
                                Console.WriteLine("[State: Pending] Error received.");
                                HandleError();
                            }
                        }
                        catch (RateLimitException)
                        {
                            Console.WriteLine("[State: Pending] Rate Limited (429).");
                            CurrentState = ApiState.RateLimited;
                        }
                        catch (OperationCanceledException)
                        {
                            HandleCancellation();
                            return;
                        }
                        break;

                    case ApiState.RetryPending:
                        // 2. Time-Driven: Wait for backoff
                        Console.WriteLine($"[State: RetryPending] Waiting {_rateLimitDuration.TotalSeconds}s...");
                        await Task.Delay(_rateLimitDuration, ct);
                        CurrentState = ApiState.Pending; // Go back to Pending to retry
                        break;

                    case ApiState.Failed:
                        Console.WriteLine("[State: Failed] Max retries exceeded or cancelled.");
                        return;
                }

                // Check cancellation token periodically
                if (ct.IsCancellationRequested)
                {
                    HandleCancellation();
                    return;
                }
            }
        }

        private void HandleError()
        {
            _retryCount++;
            if (_retryCount > _maxRetries)
            {
                CurrentState = ApiState.Failed;
            }
            else
            {
                CurrentState = ApiState.RetryPending;
            }
        }

        private void HandleCancellation()
        {
            CurrentState = ApiState.Failed; // Or a specific Cancelled state
            Console.WriteLine("[State: Failed] Cancelled by user.");
        }
    }

    // Mock Exceptions
    public class RateLimitException : Exception { }

    public class Program
    {
        public static async Task Main()
        {
            var machine = new ApiRequestMachine();
            var cts = new CancellationTokenSource();

            // Simulate an API call that fails twice then succeeds
            int attempt = 0;
            Func<CancellationToken, Task<bool>> mockApi = async (ct) =>
            {
                attempt++;
                // Simulate network delay
                await Task.Delay(500, ct); 
                
                if (attempt < 3) return false; // Fail first two times
                return true; // Succeed third time
            };

            // Run the machine
            var task = machine.ExecuteRequestAsync(mockApi, cts.Token);

            // Optional: Cancel after some time (simulating user cancellation)
            // await Task.Delay(1000); cts.Cancel(); 

            await task;
        }
    }
}
