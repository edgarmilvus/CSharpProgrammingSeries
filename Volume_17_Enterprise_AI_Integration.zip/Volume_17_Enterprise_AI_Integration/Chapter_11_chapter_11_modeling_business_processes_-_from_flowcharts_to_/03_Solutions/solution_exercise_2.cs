
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace SupportTicketStatechart
{
    // 1. Hierarchy Implementation: Abstract base class
    public abstract record TicketState
    {
        public abstract bool CanTransitionTo(TicketState target);
    }

    // 2. Parent State: Open
    // Using primary constructor syntax (C# 12)
    public record OpenState(string StatusMessage = "Ticket is active") : TicketState
    {
        public override bool CanTransitionTo(TicketState target) => true; // Can transition to Escalated or Closed (via guards)
    }

    // 3. Sub-states of Open
    public record AwaitingCustomerState : OpenState
    {
        // 4. State Payloads: Storing data relevant to the state
        public required DateTime LastInteraction { get; init; }
        
        public override bool CanTransitionTo(TicketState target)
        {
            // Guard Clause: Check inactivity
            if (target is ClosedState)
            {
                if (DateTime.UtcNow - LastInteraction > TimeSpan.FromHours(48))
                    return true; // Allowed due to inactivity
                return false; // Guard failed
            }
            return true;
        }
    }

    public record AwaitingEngineeringState : OpenState
    {
        public required List<string> EngineeringTags { get; init; }
    }

    // 4. Sibling State: Escalated
    // This is a sibling to Open, but effectively a parallel track
    public record EscalatedState : TicketState 
    {
        public required string Reason { get; init; }
        public override bool CanTransitionTo(TicketState target) => target is ClosedState;
    }

    // 5. Top-level State: Closed
    public record ClosedState : TicketState 
    {
        public required string Resolution { get; init; }
        public override bool CanTransitionTo(TicketState target) => false; // Terminal
    }

    public class TicketMachine
    {
        public TicketState CurrentState { get; private set; }

        public TicketMachine(TicketState initial) => CurrentState = initial;

        public void TransitionTo(TicketState target)
        {
            // Check hierarchy: If current is OpenState (parent) and target is Escalated, allow.
            // If current is OpenState (parent) and target is Closed, check specific sub-state if applicable.
            
            // However, the requirement says: "Parent/Child Transitions: Allow Open -> Escalated regardless of sub-state".
            // Since C# records are flat types, we check if CurrentState is an 'OpenState' (base class).
            
            bool isCurrentOpen = CurrentState is OpenState;
            bool isTargetEscalated = target is EscalatedState;

            // Specific Guard Clause logic
            if (!CurrentState.CanTransitionTo(target))
            {
                throw new InvalidOperationException($"Guard clause prevented transition to {target.GetType().Name}");
            }

            // Hierarchy Logic: If current is Open (any sub) and target is Escalated, allow.
            if (isCurrentOpen && isTargetEscalated)
            {
                CurrentState = target;
                Console.WriteLine($"Transitioned to Escalated (from Open hierarchy)");
                return;
            }

            // Standard Transition
            if (CurrentState.CanTransitionTo(target))
            {
                CurrentState = target;
                Console.WriteLine($"Transitioned to {target.GetType().Name}");
            }
            else
            {
                throw new InvalidOperationException("Invalid transition");
            }
        }
    }

    public class Program
    {
        public static void Main()
        {
            // Example Usage
            var awaitingCust = new AwaitingCustomerState { LastInteraction = DateTime.UtcNow.AddHours(50) }; // Inactive
            var machine = new TicketMachine(awaitingCust);

            try
            {
                // 1. Test Hierarchy: Open -> Escalated (Valid)
                machine.TransitionTo(new EscalatedState { Reason = "Customer unresponsive" });

                // 2. Test Guard: Escalated -> Closed (Valid)
                machine.TransitionTo(new ClosedState { Resolution = "Resolved via escalation" });
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }
    }
}
