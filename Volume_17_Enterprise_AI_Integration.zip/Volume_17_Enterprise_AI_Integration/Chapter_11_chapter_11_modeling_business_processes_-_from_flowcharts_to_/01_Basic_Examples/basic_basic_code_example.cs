
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;

// A simple Finite State Machine (FSM) to model a document approval workflow.
// This example demonstrates how to represent business process states and transitions
// in a way that is deterministic and easily interpretable by code (or an AI agent).
public class DocumentWorkflowFSM
{
    // Enum defining the distinct states a document can be in.
    // Using an enum ensures type safety and prevents invalid state names.
    public enum DocumentState
    {
        Draft,          // Initial state: Document is being written
        InReview,       // Document is with a manager for approval
        Approved,       // Manager approved it
        Rejected,       // Manager rejected it
        Archived        // Final state: Document is stored (terminal state)
    }

    // Enum defining the valid events (triggers) that cause state transitions.
    public enum WorkflowEvent
    {
        Submit,         // Author submits the draft for review
        Approve,        // Manager approves the document
        Reject,         // Manager rejects the document
        Archive         // Admin archives the document
    }

    // The current state of the document instance.
    private DocumentState _currentState;

    // A dictionary mapping a combination of (Current State, Event) to the Next State.
    // This is the core logic table of the FSM.
    private readonly Dictionary<(DocumentState, WorkflowEvent), DocumentState> _transitionTable;

    public DocumentWorkflowFSM()
    {
        // Initialize in the Draft state (the starting point of the process).
        _currentState = DocumentState.Draft;

        // Define the valid state transitions.
        // Key: (Current State, Event)
        // Value: Next State
        _transitionTable = new Dictionary<(DocumentState, WorkflowEvent), DocumentState>
        {
            // From Draft state
            { (DocumentState.Draft, WorkflowEvent.Submit), DocumentState.InReview },

            // From InReview state
            { (DocumentState.InReview, WorkflowEvent.Approve), DocumentState.Approved },
            { (DocumentState.InReview, WorkflowEvent.Reject), DocumentState.Rejected },

            // From Approved state
            { (DocumentState.Approved, WorkflowEvent.Archive), DocumentState.Archived }
            
            // Note: Rejected documents might be moved back to Draft in a complex system,
            // but we keep this simple for the "Hello World" example.
        };
    }

    // Method to process an event and transition the state.
    public void ProcessEvent(WorkflowEvent trigger)
    {
        Console.WriteLine($"Attempting to process event: {trigger} while in state: {_currentState}");

        // Check if the transition is valid based on our defined rules.
        if (_transitionTable.TryGetValue((_currentState, trigger), out DocumentState nextState))
        {
            // Transition is valid: Update state and log success.
            _currentState = nextState;
            Console.WriteLine($"SUCCESS: State transitioned to {_currentState}.");
        }
        else
        {
            // Transition is invalid: Log error and stay in current state.
            Console.WriteLine($"ERROR: Invalid transition! Cannot perform {trigger} in state {_currentState}.");
        }
    }

    // Helper method to check current status (useful for external systems or UI).
    public DocumentState GetCurrentState() => _currentState;
}

// Main program to simulate the workflow execution.
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Starting Document Approval Workflow Simulation ---");
        
        // 1. Instantiate the FSM.
        var workflow = new DocumentWorkflowFSM();

        // 2. Simulate a valid happy path: Draft -> InReview -> Approved -> Archived
        workflow.ProcessEvent(WorkflowEvent.Submit);  // Valid: Draft -> InReview
        workflow.ProcessEvent(WorkflowEvent.Approve); // Valid: InReview -> Approved
        workflow.ProcessEvent(WorkflowEvent.Archive); // Valid: Approved -> Archived

        Console.WriteLine();

        // 3. Simulate an invalid path: Try to submit an already archived document.
        // This demonstrates the FSM's ability to enforce business rules strictly.
        workflow.ProcessEvent(WorkflowEvent.Submit);  // Invalid: Archived -> (No Transition)

        Console.WriteLine();

        // 4. Reset and simulate a rejection scenario.
        var newWorkflow = new DocumentWorkflowFSM(); // Start fresh
        Console.WriteLine("--- Starting New Workflow for Rejection Test ---");
        newWorkflow.ProcessEvent(WorkflowEvent.Submit);  // Valid
        newWorkflow.ProcessEvent(WorkflowEvent.Reject);  // Valid: InReview -> Rejected
        
        // Attempt an invalid move from Rejected state directly to Archived.
        newWorkflow.ProcessEvent(WorkflowEvent.Archive); // Invalid: Rejected -> (No Transition)
    }
}
