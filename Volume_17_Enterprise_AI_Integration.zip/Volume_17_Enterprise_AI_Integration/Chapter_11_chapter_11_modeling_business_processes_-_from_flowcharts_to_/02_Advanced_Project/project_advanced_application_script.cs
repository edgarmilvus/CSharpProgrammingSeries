
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

// Enterprise AI Integration & Process Automation
// Chapter 11: Modeling Business Processes - From Flowcharts to State Machines
// Subsection: 3/5 - "Advanced Application Script"

// PROBLEM CONTEXT:
// Large enterprises often deal with complex, long-running processes that are not simple linear flows.
// Consider a "High-Value Customer Onboarding" process. A simple flowchart fails to capture the 
// complexity because:
// 1. The process can be in multiple states simultaneously (e.g., "Compliance Check" running while "Credit Assessment" is pending).
// 2. External events (e.g., "Fraud Alert", "Manual Override") can occur at any time, changing the state unexpectedly.
// 3. The process has a lifecycle that requires memory of past events (e.g., if a document was rejected twice, trigger a different path).
//
// This application implements a "Statechart" (an advanced Finite State Machine) to manage this lifecycle.
// It demonstrates how an AI Agent would interpret a rigid state model to execute business logic reliably.

namespace EnterpriseProcessAutomation
{
    // Represents the external events that can occur in the system
    public enum ProcessEvent
    {
        None,
        SubmissionReceived,
        DocumentsVerified,
        DocumentsRejected,
        CreditApproved,
        CreditRejected,
        ComplianceCleared,
        ComplianceFlagged,
        ManualOverride,
        Timeout
    }

    // Represents the internal states of the onboarding process
    public enum ProcessState
    {
        Init,
        AwaitingDocs,
        AwaitingCredit,
        AwaitingCompliance,
        ManualReview,
        Approved,
        Rejected
    }

    // The Statechart Engine. 
    // Unlike a basic FSM, this maintains context (history) and handles complex transitions.
    public class OnboardingStatechart
    {
        // Current State of the instance
        public ProcessState CurrentState { get; private set; }

        // Context Data (Memory)
        // We use basic fields instead of advanced types to adhere to constraints.
        public int DocumentRejectionCount = 0;
        public bool IsHighRiskDetected = false;

        // Event Queue to simulate asynchronous external events
        private List<ProcessEvent> eventQueue = new List<ProcessEvent>();

        public OnboardingStatechart()
        {
            CurrentState = ProcessState.Init;
        }

        // Method to inject external events into the system
        public void RaiseEvent(ProcessEvent e)
        {
            eventQueue.Add(e);
        }

        // The Core Logic Loop. 
        // In a real AI integration, the LLM would call this method to "step" the process.
        public void Run()
        {
            // Process all pending events
            while (eventQueue.Count > 0)
            {
                ProcessEvent currentEvent = eventQueue[0];
                eventQueue.RemoveAt(0);

                ProcessTransition(currentEvent);
            }
        }

        // This method encapsulates the State Transition Logic.
        // It acts as the "Brain" that maps Events + Current State -> New State + Actions.
        private void ProcessTransition(ProcessEvent e)
        {
            // LOGGING: Essential for debugging AI behavior
            Console.WriteLine($"[State: {CurrentState}] -> Event Triggered: {e}");

            // STATE TRANSITION LOGIC
            // We use a switch statement on the CURRENT STATE to determine valid transitions.
            // This is more robust than a simple flowchart because it prevents invalid transitions
            // (e.g., you cannot approve credit if you haven't assessed it yet).

            switch (CurrentState)
            {
                case ProcessState.Init:
                    if (e == ProcessEvent.SubmissionReceived)
                    {
                        Console.WriteLine("   Action: Requesting Documents.");
                        CurrentState = ProcessState.AwaitingDocs;
                    }
                    break;

                case ProcessState.AwaitingDocs:
                    if (e == ProcessEvent.DocumentsVerified)
                    {
                        Console.WriteLine("   Action: Documents OK. Proceeding to Credit Check.");
                        CurrentState = ProcessState.AwaitingCredit;
                    }
                    else if (e == ProcessEvent.DocumentsRejected)
                    {
                        DocumentRejectionCount++;
                        if (DocumentRejectionCount >= 3)
                        {
                            Console.WriteLine("   Action: Too many rejections. Sending to Manual Review.");
                            CurrentState = ProcessState.ManualReview;
                        }
                        else
                        {
                            Console.WriteLine($"   Action: Rejected (Count: {DocumentRejectionCount}). Requesting Resubmission.");
                            // State remains AwaitingDocs
                        }
                    }
                    break;

                case ProcessState.AwaitingCredit:
                    if (e == ProcessEvent.CreditApproved)
                    {
                        Console.WriteLine("   Action: Credit Good. Proceeding to Compliance.");
                        CurrentState = ProcessState.AwaitingCompliance;
                    }
                    else if (e == ProcessEvent.CreditRejected)
                    {
                        Console.WriteLine("   Action: Credit Bad. Rejecting Application.");
                        CurrentState = ProcessState.Rejected;
                    }
                    break;

                case ProcessState.AwaitingCompliance:
                    if (e == ProcessEvent.ComplianceCleared)
                    {
                        Console.WriteLine("   Action: All checks passed. APPROVED.");
                        CurrentState = ProcessState.Approved;
                    }
                    else if (e == ProcessEvent.ComplianceFlagged)
                    {
                        IsHighRiskDetected = true;
                        Console.WriteLine("   Action: Risk Flagged. Moving to Manual Review.");
                        CurrentState = ProcessState.ManualReview;
                    }
                    break;

                case ProcessState.ManualReview:
                    if (e == ProcessEvent.ManualOverride)
                    {
                        Console.WriteLine("   Action: Human Agent Approved. APPROVED.");
                        CurrentState = ProcessState.Approved;
                    }
                    else if (e == ProcessEvent.SubmissionReceived) // Re-submission after review
                    {
                        Console.WriteLine("   Action: Resubmission received. Restarting Checks.");
                        CurrentState = ProcessState.AwaitingDocs;
                    }
                    else if (e == ProcessEvent.Timeout)
                    {
                        Console.WriteLine("   Action: Review Timed Out. REJECTED.");
                        CurrentState = ProcessState.Rejected;
                    }
                    break;

                case ProcessState.Approved:
                case ProcessState.Rejected:
                    // Terminal states. 
                    // In a complex system, we might allow "Re-opening" here, but for this script, we lock it.
                    Console.WriteLine("   Action: Process is closed. No further transitions allowed.");
                    break;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Enterprise AI: Statechart Process Simulator ===\n");

            // 1. Instantiate the Statechart Engine
            OnboardingStatechart process = new OnboardingStatechart();

            // 2. Simulate a Complex Scenario
            // Scenario: User submits, documents are bad twice, fixed on third try, 
            // credit passes, compliance flags risk, human overrides.
            
            Console.WriteLine("--- Scenario Start ---");
            
            // Step 1: User submits application
            process.RaiseEvent(ProcessEvent.SubmissionReceived);
            process.Run();

            // Step 2: User submits bad documents (Attempt 1)
            process.RaiseEvent(ProcessEvent.DocumentsRejected);
            process.Run();

            // Step 3: User submits bad documents (Attempt 2)
            process.RaiseEvent(ProcessEvent.DocumentsRejected);
            process.Run();

            // Step 4: User submits good documents (Attempt 3)
            // Note: We check the context (DocumentRejectionCount) in the logic
            process.RaiseEvent(ProcessEvent.DocumentsVerified);
            process.Run();

            // Step 5: Credit check passes
            process.RaiseEvent(ProcessEvent.CreditApproved);
            process.Run();

            // Step 6: Compliance detects high risk (e.g., sanctions list match)
            process.RaiseEvent(ProcessEvent.ComplianceFlagged);
            process.Run();

            // Step 7: Manual Agent reviews and overrides the risk
            process.RaiseEvent(ProcessEvent.ManualOverride);
            process.Run();

            // Step 8: Try to submit again (Should be blocked because process is closed)
            process.RaiseEvent(ProcessEvent.SubmissionReceived);
            process.Run();

            Console.WriteLine("\n=== Simulation Complete ===");
            Console.WriteLine($"Final State: {process.CurrentState}");
            Console.WriteLine($"Total Document Rejections: {process.DocumentRejectionCount}");
        }
    }
}
