
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections;
using System.Reflection;
using System.Text;

namespace OpenAPIGeneratorApp
{
    // ==========================================
    // 1. LEGACY SYSTEM SIMULATION
    // ==========================================
    // We simulate a legacy inventory system with methods that need to be exposed.
    // These classes represent internal business logic that currently lacks API documentation.

    public class InventoryItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int StockLevel { get; set; }
        public decimal Price { get; set; }
    }

    public class LegacyInventoryService
    {
        // Simulates a legacy method returning a complex object
        [Route("GET", "/inventory/{id}")]
        public InventoryItem GetItemById(int id)
        {
            // In a real scenario, this would query a database
            return new InventoryItem { Id = id, Name = "Legacy Widget", StockLevel = 100, Price = 9.99m };
        }

        // Simulates a method with multiple parameters and a return type
        [Route("POST", "/inventory/search")]
        public InventoryItem[] SearchInventory(string keyword, int minStock)
        {
            // Returns an array of items
            return new InventoryItem[]
            {
                new InventoryItem { Id = 1, Name = keyword, StockLevel = minStock, Price = 5.00m }
            };
        }

        // Simulates a void method (no return type)
        [Route("PUT", "/inventory/update")]
        public void UpdateStock(int id, int newQuantity)
        {
            // Updates the stock in the legacy database
            Console.WriteLine($"Updating item {id} to quantity {newQuantity}");
        }
    }

    // Custom Attribute to define routes manually since we aren't using ASP.NET Core attributes
    [AttributeUsage(AttributeTargets.Method)]
    public class RouteAttribute : Attribute
    {
        public string Method { get; }
        public string Path { get; }

        public RouteAttribute(string method, string path)
        {
            Method = method;
            Path = path;
        }
    }

    // ==========================================
    // 2. OPENAPI GENERATOR LOGIC
    // ==========================================
    // This class handles the reflection and JSON construction logic.

    public class OpenApiGenerator
    {
        // Main entry point to generate the spec for a given service type
        public static string GenerateSpec(Type serviceType)
        {
            var sb = new StringBuilder();
            var serviceName = serviceType.Name;

            // Start the OpenAPI JSON object
            sb.AppendLine("{");
            sb.AppendLine($"  \"openapi\": \"3.0.0\",");
            sb.AppendLine($"  \"info\": {{ \"title\": \"{serviceName} API\", \"version\": \"1.0.0\" }},");
            sb.AppendLine($"  \"paths\": {{");

            // Use Reflection to inspect the service class
            MethodInfo[] methods = serviceType.GetMethods(BindingFlags.Public | BindingFlags.Instance);
            bool firstMethod = true;

            foreach (var method in methods)
            {
                // Check if the method has our custom Route attribute
                var routeAttr = method.GetCustomAttribute<RouteAttribute>();
                if (routeAttr == null) continue;

                if (!firstMethod) sb.AppendLine(",");
                firstMethod = false;

                // Generate the path definition
                sb.AppendLine($"    \"{routeAttr.Path}\": {{");

                // Generate the HTTP method definition (e.g., "get", "post")
                sb.AppendLine($"      \"{routeAttr.Method.ToLower()}\": {{");
                sb.AppendLine($"        \"summary\": \"Invokes {method.Name}\",");
                sb.AppendLine($"        \"operationId\": \"{method.Name}\",");

                // 2.1 Parameter Generation Logic
                sb.AppendLine($"        \"parameters\": [");
                var parameters = method.GetParameters();
                bool firstParam = true;

                foreach (var param in parameters)
                {
                    if (!firstParam) sb.AppendLine(",");
                    firstParam = false;

                    // Determine parameter location (Query for GET, Body for POST/PUT usually, 
                    // but for this simulation, we'll treat simple types as query params for GET and body for POST)
                    string paramLocation = (routeAttr.Method == "GET") ? "query" : "body";
                    string required = "true"; // Simplified: all params required for this demo

                    sb.Append($"          {{ \"name\": \"{param.Name}\", \"in\": \"{paramLocation}\", \"required\": {required}, \"schema\": {{ \"type\": \"{MapTypeToSchema(param.ParameterType)}\" }} }}");
                }
                sb.AppendLine();
                sb.AppendLine("        ],");

                // 2.2 Response Generation Logic
                sb.AppendLine($"        \"responses\": {{");
                sb.AppendLine($"          \"200\": {{");
                sb.AppendLine($"            \"description\": \"Successful operation\",");
                
                // Handle return types (Void, Primitive, Complex Object, Array)
                Type returnType = method.ReturnType;
                if (returnType == typeof(void))
                {
                    sb.AppendLine($"            \"content\": {{ \"application/json\": {{ \"schema\": {{ \"type\": \"object\" }} }} }}");
                }
                else
                {
                    // Check if it's an array
                    bool isArray = returnType.IsArray;
                    Type elementType = isArray ? returnType.GetElementType() : returnType;
                    
                    sb.AppendLine($"            \"content\": {{ \"application/json\": {{ \"schema\": {{");

                    if (isArray)
                    {
                        sb.AppendLine($"              \"type\": \"array\",");
                        sb.AppendLine($"              \"items\": {{");
                        GenerateObjectSchema(sb, elementType, 14); // Recursive schema generation
                        sb.AppendLine($"              }}");
                    }
                    else
                    {
                        GenerateObjectSchema(sb, elementType, 14);
                    }

                    sb.AppendLine($"            }} }} }}");
                }
                sb.AppendLine($"          }}");
                sb.AppendLine($"        }}");
                sb.Append($"      }}"); // End HTTP method
            }

            sb.AppendLine();
            sb.AppendLine($"    }}"); // End Paths
            sb.AppendLine($"  }}"); // End Root

            return sb.ToString();
        }

        // Helper to map C# types to OpenAPI types
        private static string MapTypeToSchema(Type type)
        {
            if (type == typeof(int) || type == typeof(long)) return "integer";
            if (type == typeof(decimal) || type == typeof(double)) return "number";
            if (type == typeof(bool)) return "boolean";
            if (type == typeof(string)) return "string";
            return "object";
        }

        // Helper to recursively generate JSON schema for complex objects
        private static void GenerateObjectSchema(StringBuilder sb, Type type, int indentLevel)
        {
            string indent = new string(' ', indentLevel);
            sb.AppendLine($"\"type\": \"object\",");
            sb.AppendLine($"{indent}\"properties\": {{");

            var properties = type.GetProperties();
            bool firstProp = true;

            foreach (var prop in properties)
            {
                if (!firstProp) sb.AppendLine(",");
                firstProp = false;

                sb.Append($"{indent}  \"{prop.Name}\": {{ \"type\": \"{MapTypeToSchema(prop.PropertyType)}\" }}");
            }
            sb.AppendLine();
            sb.Append($"{indent}}}");
        }
    }

    // ==========================================
    // 3. CONSOLE APPLICATION EXECUTION
    // ==========================================
    // This simulates the AI Agent requesting the spec to understand how to call the service.

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Enterprise AI Integration: Dynamic OpenAPI Spec Generation ===");
            Console.WriteLine("Target System: LegacyInventoryService\n");

            // 1. Generate the specification dynamically
            Type targetType = typeof(LegacyInventoryService);
            string openApiJson = OpenApiGenerator.GenerateSpec(targetType);

            // 2. Output the generated JSON (Simulating the file generation)
            Console.WriteLine("--- Generated OpenAPI Specification ---");
            Console.WriteLine(openApiJson);

            // 3. Simulate AI Agent Consumption
            Console.WriteLine("\n--- AI Agent Simulation ---");
            Console.WriteLine("Agent receives JSON. Parsing endpoints...");
            
            // Simple string parsing to demonstrate how an AI would read this
            if (openApiJson.Contains("GET") && openApiJson.Contains("/inventory/{id}"))
            {
                Console.WriteLine("✓ Discovered endpoint: GET /inventory/{id}");
                Console.WriteLine("  - Required Parameter: 'id' (integer)");
                Console.WriteLine("  - Expected Response: Object containing Id, Name, StockLevel, Price");
            }

            if (openApiJson.Contains("POST") && openApiJson.Contains("/inventory/search"))
            {
                Console.WriteLine("✓ Discovered endpoint: POST /inventory/search");
                Console.WriteLine("  - Required Parameters: 'keyword' (string), 'minStock' (integer)");
                Console.WriteLine("  - Expected Response: Array of InventoryItem objects");
            }

            Console.WriteLine("\nAgent is now capable of constructing valid HTTP requests to the legacy system.");
        }
    }
}
