
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Text.Json;
using System.Collections.Generic;

public class ProductSearch
{
    [Description("The unique identifier of the product")]
    [Range(1, 10000)]
    public int Id { get; set; }

    [Description("Search query string")]
    [RegularExpression(@"^[a-zA-Z0-9\s]+$")]
    public string Query { get; set; }

    [Description("Maximum price filter")]
    [Range(0.0, 10000.0)]
    public decimal MaxPrice { get; set; }
}

public static class OpenApiGenerator
{
    public static string GenerateComplexParameterSchema(Type dtoType)
    {
        var properties = dtoType.GetProperties();
        var schemaProperties = new Dictionary<string, object>();

        foreach (var prop in properties)
        {
            var propSchema = new Dictionary<string, object>();
            
            // 1. Determine Type and Handle Nullables
            var propType = prop.PropertyType;
            var underlyingType = Nullable.GetUnderlyingType(propType) ?? propType;
            
            string typeStr = MapType(underlyingType);
            propSchema["type"] = typeStr;

            // Handle Nullable flag
            if (Nullable.GetUnderlyingType(propType) != null)
            {
                propSchema["nullable"] = true;
            }

            // 2. Extract Description
            var descAttr = prop.GetCustomAttribute<DescriptionAttribute>();
            if (descAttr != null)
            {
                propSchema["description"] = descAttr.Description;
            }

            // 3. Extract Range (Min/Max)
            var rangeAttr = prop.GetCustomAttribute<RangeAttribute>();
            if (rangeAttr != null)
            {
                // Range can apply to numbers or strings (length), but here we assume numeric based on context
                if (underlyingType == typeof(decimal) || underlyingType == typeof(int) || 
                    underlyingType == typeof(double) || underlyingType == typeof(float))
                {
                    propSchema["minimum"] = Convert.ToDouble(rangeAttr.Minimum);
                    propSchema["maximum"] = Convert.ToDouble(rangeAttr.Maximum);
                }
            }

            // 4. Extract Pattern (for strings)
            if (underlyingType == typeof(string))
            {
                var regexAttr = prop.GetCustomAttribute<RegularExpressionAttribute>();
                if (regexAttr != null)
                {
                    propSchema["pattern"] = regexAttr.Pattern;
                }
            }

            schemaProperties[prop.Name.ToLower()] = propSchema;
        }

        var finalSchema = new
        {
            type = "object",
            properties = schemaProperties
        };

        return JsonSerializer.Serialize(finalSchema, new JsonSerializerOptions { WriteIndented = true });
    }

    private static string MapType(Type type)
    {
        if (type == typeof(int) || type == typeof(long) || type == typeof(short)) return "integer";
        if (type == typeof(string)) return "string";
        if (type == typeof(bool)) return "boolean";
        if (type == typeof(double) || type == typeof(decimal) || type == typeof(float)) return "number";
        return "string"; // Default
    }
}

public class Program
{
    public static void Main()
    {
        string json = OpenApiGenerator.GenerateComplexParameterSchema(typeof(ProductSearch));
        Console.WriteLine(json);
    }
}
