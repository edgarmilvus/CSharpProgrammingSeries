
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Reflection;
using System.Text.Json;

public static class OpenApiGenerator
{
    /// <summary>
    /// Generates an OpenAPI parameters array JSON string for a given method.
    /// </summary>
    public static string GenerateParameterSchema(MethodInfo method)
    {
        var parameters = method.GetParameters();
        var parameterObjects = new object[parameters.Length];

        for (int i = 0; i < parameters.Length; i++)
        {
            var param = parameters[i];
            var openApiType = MapTypeToOpenApi(param.ParameterType);

            parameterObjects[i] = new
            {
                name = param.Name,
                @in = "query", // As per requirement 5
                required = !param.ParameterType.IsGenericType || param.ParameterType.GetGenericTypeDefinition() != typeof(Nullable<>),
                schema = new { type = openApiType }
            };
        }

        return JsonSerializer.Serialize(parameterObjects, new JsonSerializerOptions { WriteIndented = true });
    }

    private static string MapTypeToOpenApi(Type type)
    {
        // Handle nullable types (e.g., int?)
        var underlyingType = Nullable.GetUnderlyingType(type) ?? type;

        if (underlyingType == typeof(int) || underlyingType == typeof(long) || underlyingType == typeof(short))
            return "integer";
        if (underlyingType == typeof(string))
            return "string";
        if (underlyingType == typeof(bool))
            return "boolean";
        if (underlyingType == typeof(double) || underlyingType == typeof(decimal) || underlyingType == typeof(float))
            return "number";

        // Default to string for unknown types
        return "string";
    }
}

public class Program
{
    public static void Main()
    {
        // Demonstrate on the specified method signature
        MethodInfo methodInfo = typeof(Program).GetMethod(nameof(Calculate));
        string json = OpenApiGenerator.GenerateParameterSchema(methodInfo);
        Console.WriteLine(json);
    }

    public static string Calculate(int a, int b, string operation)
    {
        return "Result";
    }
}
