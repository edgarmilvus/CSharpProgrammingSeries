
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Linq;
using System.Reflection;
using System.Text.Json;

// --- Custom Attributes to Simulate ASP.NET Core ---
[AttributeUsage(AttributeTargets.Method)]
public class HttpGetAttribute : Attribute { public string Route { get; set; } }

[AttributeUsage(AttributeTargets.Method)]
public class HttpPostAttribute : Attribute { public string Route { get; set; } }

[AttributeUsage(AttributeTargets.Parameter)]
public class FromBodyAttribute : Attribute { }

// --- DTO and Controller ---
public class ItemDto
{
    public string Name { get; set; }
    public int Quantity { get; set; }
}

public class InventoryController
{
    [HttpGet("/api/items/{id}")]
    public string GetItem(int id) => null;

    [HttpPost("/api/items")]
    public string CreateItem([FromBody] ItemDto dto) => null;
}

// --- Generator Logic ---
public static class EndpointGenerator
{
    public static string GenerateEndpointDefinition(MethodInfo method)
    {
        string httpVerb = "";
        string route = "";

        // 1. Identify HTTP Verb and Route
        var getAttr = method.GetCustomAttribute<HttpGetAttribute>();
        if (getAttr != null)
        {
            httpVerb = "get";
            route = getAttr.Route;
        }

        var postAttr = method.GetCustomAttribute<HttpPostAttribute>();
        if (postAttr != null)
        {
            httpVerb = "post";
            route = postAttr.Route;
        }

        // 2. Analyze Parameters
        var parameters = method.GetParameters();
        var queryParams = parameters.Where(p => p.GetCustomAttribute<FromBodyAttribute>() == null).ToList();
        var bodyParams = parameters.Where(p => p.GetCustomAttribute<FromBodyAttribute>() != null).ToList();

        // 3. Build OpenAPI Structure
        var endpointDefinition = new
        {
            route = new
            {
                [httpVerb] = new
                {
                    parameters = queryParams.Select(p => new
                    {
                        name = p.Name,
                        @in = "query", // Simple assumption for this exercise
                        required = !p.ParameterType.IsValueType || Nullable.GetUnderlyingType(p.ParameterType) != null,
                        schema = new { type = "integer" } // Simplified mapping for int
                    }).ToArray(),
                    requestBody = bodyParams.FirstOrDefault() != null ? new
                    {
                        required = true,
                        content = new
                        {
                            ["application/json"] = new
                            {
                                schema = new { $ref = "#/components/schemas/ItemDto" } // Reference to schema
                            }
                        }
                    } : null,
                    responses = new
                    {
                        ["200"] = new { description = "Success" }
                    }
                }
            }
        };

        // We need to restructure the output to match the specific JSON format requested in the prompt
        // The prompt asks for: { "/api/items/{id}": { "get": { ... } } }
        var finalOutput = new
        {
            [route] = endpointDefinition.route
        };

        return JsonSerializer.Serialize(finalOutput, new JsonSerializerOptions { WriteIndented = true });
    }
}

public class Program
{
    public static void Main()
    {
        // Test GetItem
        var getMethod = typeof(InventoryController).GetMethod(nameof(InventoryController.GetItem));
        Console.WriteLine("--- GetItem Endpoint ---");
        Console.WriteLine(EndpointGenerator.GenerateEndpointDefinition(getMethod));

        // Test CreateItem
        var postMethod = typeof(InventoryController).GetMethod(nameof(InventoryController.CreateItem));
        Console.WriteLine("\n--- CreateItem Endpoint ---");
        Console.WriteLine(EndpointGenerator.GenerateEndpointDefinition(postMethod));
    }
}
