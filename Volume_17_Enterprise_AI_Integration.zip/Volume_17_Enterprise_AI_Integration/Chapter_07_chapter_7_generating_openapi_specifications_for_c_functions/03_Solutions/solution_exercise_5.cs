
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Text.Json;
using System.Text.Json.Nodes;

public static class LlmToolConverter
{
    public static string ConvertToLlmToolDefinition(string openApiSchemaJson, string functionName, string description)
    {
        // Parse the OpenAPI JSON
        var openApiNode = JsonNode.Parse(openApiSchemaJson);

        // Extract the properties from the OpenAPI 'object' schema
        // Structure expected: { "type": "object", "properties": { ... } }
        var propertiesNode = openApiNode?["properties"];
        
        if (propertiesNode == null)
        {
            throw new InvalidOperationException("Invalid OpenAPI schema format: missing 'properties'.");
        }

        // Construct the LLM Tool Definition
        var llmTool = new
        {
            type = "function",
            function = new
            {
                name = functionName,
                description = description,
                parameters = new
                {
                    type = "object",
                    properties = propertiesNode, // Directly map the properties
                    required = new string[] { "id", "query", "maxPrice" } // Hardcoded for this exercise, or derive from OpenAPI required array
                }
            }
        };

        return JsonSerializer.Serialize(llmTool, new JsonSerializerOptions { WriteIndented = true });
    }
}

public class Program
{
    public static void Main()
    {
        // 1. Generate the OpenAPI Schema for ProductSearch (Re-using logic from Exercise 2)
        string openApiSchema = OpenApiGenerator.GenerateComplexParameterSchema(typeof(ProductSearch));
        
        // 2. Convert to LLM Tool Definition
        string llmDefinition = LlmToolConverter.ConvertToLlmToolDefinition(
            openApiSchema, 
            "search_products", 
            "Finds products by ID and query string"
        );

        Console.WriteLine(llmDefinition);
    }
}

// Re-using ProductSearch and OpenApiGenerator from Exercise 2 for context
public class ProductSearch
{
    [System.ComponentModel.Description("The unique identifier of the product")]
    [System.ComponentModel.DataAnnotations.Range(1, 10000)]
    public int Id { get; set; }

    [System.ComponentModel.Description("Search query string")]
    [System.ComponentModel.DataAnnotations.RegularExpression(@"^[a-zA-Z0-9\s]+$")]
    public string Query { get; set; }

    [System.ComponentModel.Description("Maximum price filter")]
    [System.ComponentModel.DataAnnotations.Range(0.0, 10000.0)]
    public decimal MaxPrice { get; set; }
}
