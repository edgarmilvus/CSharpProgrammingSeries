
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text.Json;

// --- Mock Domain Models for Testing ---
public enum ProductStatus { Active, Inactive, Discontinued }

public class Address
{
    public string Street { get; set; }
    public string City { get; set; }
}

public class User
{
    public string Name { get; set; }
    public Address HomeAddress { get; set; } // Nested object
    public ProductStatus Status { get; set; } // Enum
}

// --- Refactored Generator with Recursion and References ---
public static class AdvancedSchemaGenerator
{
    // Registry to store generated schemas for components
    private static readonly Dictionary<string, object> _schemaRegistry = new Dictionary<string, object>();

    public static string GenerateFullSchema(Type rootType)
    {
        _schemaRegistry.Clear();
        var visited = new HashSet<Type>();
        
        // Generate the root schema and populate the registry
        GenerateSchemaRecursive(rootType, visited);

        return JsonSerializer.Serialize(new { components = new { schemas = _schemaRegistry } }, 
            new JsonSerializerOptions { WriteIndented = true });
    }

    private static object GenerateSchemaRecursive(Type type, HashSet<Type> visited)
    {
        // 1. Handle Nullable Types
        var underlyingType = Nullable.GetUnderlyingType(type);
        bool isNullable = underlyingType != null;
        Type targetType = underlyingType ?? type;

        // 2. Primitive Mapping
        if (IsPrimitive(targetType))
        {
            var schema = new { type = MapType(targetType), nullable = isNullable ? (bool?)true : null };
            return schema;
        }

        // 3. Enum Support
        if (targetType.IsEnum)
        {
            var names = Enum.GetNames(targetType);
            return new { type = "string", @enum = names };
        }

        // 4. Circular Reference Detection
        if (visited.Contains(targetType))
        {
            // Circular reference detected: return generic object or reference
            return new { type = "object", description = "Circular reference detected" };
        }

        // 5. Complex Object Handling (Recursive)
        visited.Add(targetType);
        
        // Define Schema Name (e.g., "User", "Address")
        string schemaName = targetType.Name;
        
        // Check if already processed
        if (!_schemaRegistry.ContainsKey(schemaName))
        {
            var properties = targetType.GetProperties();
            var propDict = new Dictionary<string, object>();

            foreach (var prop in properties)
            {
                // Recursively generate schema for property type
                propDict[prop.Name.ToLower()] = GenerateSchemaRecursive(prop.PropertyType, visited);
            }

            // Add to registry
            _schemaRegistry[schemaName] = new { type = "object", properties = propDict };
        }

        visited.Remove(targetType); // Backtrack

        // Return Reference to the stored schema
        return new { $ref = $"#/components/schemas/{schemaName}" };
    }

    private static bool IsPrimitive(Type type)
    {
        return type.IsPrimitive || type == typeof(string) || type == typeof(decimal) || type == typeof(DateTime);
    }

    private static string MapType(Type type)
    {
        if (type == typeof(int) || type == typeof(long) || type == typeof(short)) return "integer";
        if (type == typeof(string)) return "string";
        if (type == typeof(bool)) return "boolean";
        if (type == typeof(double) || type == typeof(decimal) || type == typeof(float)) return "number";
        return "string";
    }
}

public class Program
{
    public static void Main()
    {
        // Test with User which contains Address (nested) and ProductStatus (enum)
        string json = AdvancedSchemaGenerator.GenerateFullSchema(typeof(User));
        Console.WriteLine(json);
    }
}
