
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;

public class Program
{
    public static void Main()
    {
        // 1. Identify the target method to inspect
        // In a real scenario, this might be discovered dynamically or loaded from an assembly.
        MethodInfo targetMethod = typeof(OrderService).GetMethod(nameof(OrderService.CreateOrder));

        if (targetMethod == null)
        {
            Console.WriteLine("Method not found.");
            return;
        }

        // 2. Generate the OpenAPI Path Item Object for this method
        var pathItem = OpenApiGenerator.GeneratePathItem(targetMethod);

        // 3. Serialize the result to JSON for visualization
        var options = new JsonSerializerOptions { WriteIndented = true };
        string jsonOutput = JsonSerializer.Serialize(pathItem, options);

        // 4. Output the generated specification
        Console.WriteLine("Generated OpenAPI Path Definition:");
        Console.WriteLine(jsonOutput);
    }
}

// --- Domain Models ---

public class CreateOrderRequest
{
    [JsonPropertyName("product_id")]
    public int ProductId { get; set; }

    [JsonPropertyName("quantity")]
    public int Quantity { get; set; }
}

public class OrderResponse
{
    [JsonPropertyName("order_id")]
    public Guid OrderId { get; set; }
    
    [JsonPropertyName("status")]
    public string Status { get; set; }
}

// --- Legacy Business Logic (The Target) ---

public class OrderService
{
    /// <summary>
    /// Creates a new order in the legacy system.
    /// </summary>
    /// <param name="request">The order details.</param>
    /// <returns>The newly created order ID.</returns>
    [EndpointMetadata(Method = "POST", Route = "/api/orders")]
    public OrderResponse CreateOrder(CreateOrderRequest request)
    {
        // Simulate legacy logic
        return new OrderResponse { OrderId = Guid.NewGuid(), Status = "Pending" };
    }
}

// --- Reflection & OpenAPI Generation Logic ---

[AttributeUsage(AttributeTargets.Method)]
public class EndpointMetadataAttribute : Attribute
{
    public string Method { get; set; }
    public string Route { get; set; }
}

public static class OpenApiGenerator
{
    public static Dictionary<string, object> GeneratePathItem(MethodInfo method)
    {
        var pathItem = new Dictionary<string, object>();
        
        // 1. Extract HTTP metadata from custom attributes
        var endpointAttr = method.GetCustomAttribute<EndpointMetadataAttribute>();
        if (endpointAttr == null) return pathItem;

        string httpMethod = endpointAttr.Method.ToLower();
        
        // 2. Build the Operation Object (e.g., "post")
        var operation = new Dictionary<string, object>
        {
            ["summary"] = method.Name,
            ["description"] = method.GetDocumentation() ?? "No description available.",
            ["parameters"] = ExtractParameters(method),
            ["requestBody"] = ExtractRequestBody(method),
            ["responses"] = ExtractResponses(method)
        };

        pathItem[httpMethod] = operation;
        return pathItem;
    }

    private static List<object> ExtractParameters(MethodInfo method)
    {
        // Simplified: In a real OpenAPI spec, path/query params would be extracted here.
        // For this example, we focus on the body parameter.
        return new List<object>(); 
    }

    private static Dictionary<string, object> ExtractRequestBody(MethodInfo method)
    {
        var parameters = method.GetParameters();
        if (parameters.Length == 0) return null;

        // Assuming the first parameter is the request body (common in API controllers)
        var param = parameters[0];
        var paramType = param.ParameterType;

        return new Dictionary<string, object>
        {
            ["required"] = true,
            ["content"] = new Dictionary<string, object>
            {
                ["application/json"] = new Dictionary<string, object>
                {
                    ["schema"] = GenerateJsonSchema(paramType)
                }
            }
        };
    }

    private static Dictionary<string, object> ExtractResponses(MethodInfo method)
    {
        var returnType = method.ReturnType;
        
        // Handle Task<T> or async wrappers
        if (returnType.IsGenericType && returnType.GetGenericTypeDefinition() == typeof(Task<>))
        {
            returnType = returnType.GetGenericArguments()[0];
        }

        var responses = new Dictionary<string, object>();
        
        // 200 OK Response
        var okResponse = new Dictionary<string, object>
        {
            ["description"] = "Success",
            ["content"] = new Dictionary<string, object>
            {
                ["application/json"] = new Dictionary<string, object>
                {
                    ["schema"] = GenerateJsonSchema(returnType)
                }
            }
        };

        responses["200"] = okResponse;
        return responses;
    }

    private static Dictionary<string, object> GenerateJsonSchema(Type type)
    {
        var schema = new Dictionary<string, object>
        {
            ["type"] = "object",
            ["properties"] = new Dictionary<string, object>()
        };

        // Use System.Text.Json reflection to inspect properties
        foreach (var prop in type.GetProperties())
        {
            var jsonNameAttr = prop.GetCustomAttribute<JsonPropertyNameAttribute>();
            string propertyName = jsonNameAttr?.Name ?? prop.Name;

            var propSchema = new Dictionary<string, object>
            {
                ["type"] = MapTypeToOpenApiType(prop.PropertyType)
            };

            // Add description if available (via XML docs or custom attributes)
            // Omitted for brevity in this basic example

            ((Dictionary<string, object>)schema["properties"])[propertyName] = propSchema;
        }

        return schema;
    }

    private static string MapTypeToOpenApiType(Type type)
    {
        // Simple type mapping logic
        if (type == typeof(int) || type == typeof(long)) return "integer";
        if (type == typeof(string)) return "string";
        if (type == typeof(bool)) return "boolean";
        if (type == typeof(DateTime)) return "string"; // Often formatted as date-time
        if (type.IsEnum) return "string";
        
        // Recursively handle complex types
        return "object";
    }
}

// Helper extension for documentation (Mock implementation)
public static class ReflectionExtensions
{
    public static string GetDocumentation(this MethodInfo method)
    {
        // In a real app, use XML documentation loading (e.g., via Microsoft.XmlSerializer.Generator)
        // or custom attributes.
        return "Creates a new order.";
    }
}
