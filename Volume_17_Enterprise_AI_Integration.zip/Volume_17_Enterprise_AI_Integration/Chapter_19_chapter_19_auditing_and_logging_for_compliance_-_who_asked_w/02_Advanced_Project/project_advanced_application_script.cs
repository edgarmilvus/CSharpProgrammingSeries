
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace EnterpriseAIComplianceAudit
{
    // Real-world context: A healthcare AI assistant that processes patient data.
    // Compliance Requirement: HIPAA mandates strict access logs and immutable records of 
    // who accessed what data and when. We cannot simply overwrite log files; we must append 
    // to an immutable ledger.

    class Program
    {
        static void Main(string[] args)
        {
            // 1. Setup the Audit Service
            // In a real scenario, this might write to a secure database or WORM drive.
            // Here we simulate a file append.
            AuditService auditService = new AuditService("audit_ledger.txt");

            // 2. Simulate a User Session (The "Who")
            UserIdentity currentUser = new UserIdentity("Dr. Sarah Bennett", "doctor_bennett", "Cardiology");

            // 3. Simulate the AI Interaction Lifecycle
            // Step A: User Prompt
            string userPrompt = "Retrieve latest ECG results for Patient ID: 45992.";
            
            // Log the INCOMING request immediately
            auditService.LogEvent(currentUser, "PROMPT_RECEIVED", userPrompt);

            // Step B: AI Processing (Internal Logic)
            // The AI decides to call a legacy system function.
            auditService.LogEvent(currentUser, "AI_REASONING", "Intent detected: 'Retrieve ECG'. Accessing Legacy EHR API.");

            // Step C: Action Execution (The "What Did the AI Do")
            // We wrap the action in a try-catch to log success or failure (Critical for compliance)
            try
            {
                // Simulate connecting to a legacy API
                LegacyEHRSystem ehrSystem = new LegacyEHRSystem();
                string resultData = ehrSystem.FetchEcgData("45992");

                // Log successful data retrieval
                auditService.LogEvent(currentUser, "DATA_ACCESS_SUCCESS", $"Retrieved 3 data points for Patient 45992.");

                // Log the specific action taken (e.g., displaying to user)
                auditService.LogEvent(currentUser, "ACTION_TAKEN", "Sent ECG graph to user interface.");
            }
            catch (Exception ex)
            {
                // Log failure for audit trail
                auditService.LogEvent(currentUser, "ERROR_ACCESS_DENIED", ex.Message);
            }

            // 4. Demonstrate Immutability Check
            // In a real audit, we verify the log hasn't been tampered with.
            auditService.VerifyLedgerIntegrity();

            Console.WriteLine("\nAudit cycle complete. Ledger sealed.");
        }
    }

    // --- Domain Entities ---

    public class UserIdentity
    {
        public string FullName { get; private set; }
        public string EmployeeId { get; private set; }
        public string Role { get; private set; }

        public UserIdentity(string name, string id, string role)
        {
            FullName = name;
            EmployeeId = id;
            Role = role;
        }
    }

    // --- Core Logic ---

    public class AuditService
    {
        private string _filePath;
        private string _ledgerHash; // Simulating a blockchain-style hash for integrity

        public AuditService(string filePath)
        {
            _filePath = filePath;
            _ledgerHash = "GENESIS_HASH"; // Initial state
            
            // Clear previous run for demo purposes
            if (File.Exists(_filePath)) File.Delete(_filePath);
        }

        // Requirement: Granular Metadata Capture
        public void LogEvent(UserIdentity user, string eventType, string details)
        {
            // 1. Capture Granular Metadata
            string timestamp = DateTime.UtcNow.ToString("o"); // ISO 8601 format
            string logEntryId = Guid.NewGuid().ToString();

            // 2. Construct Immutable Record
            // Format: [TIMESTAMP] | [USER] | [ROLE] | [EVENT] | [DETAILS] | [PREV_HASH]
            string immutableRecord = $"[{timestamp}] | {user.FullName} ({user.Role}) | {eventType} | {details} | PrevHash: {_ledgerHash}";

            // 3. Write to persistent storage (Append Mode)
            // This ensures we do not overwrite history.
            using (StreamWriter writer = new StreamWriter(_filePath, true))
            {
                writer.WriteLine(immutableRecord);
            }

            // 4. Update the Chain (Simulating Blockchain integrity)
            // The next entry will reference the hash of this entry.
            _ledgerHash = CalculateSimpleHash(immutableRecord);

            Console.WriteLine($"AUDIT LOGGED: {eventType}");
        }

        // Requirement: Data Integrity Verification
        public void VerifyLedgerIntegrity()
        {
            Console.WriteLine("\n--- Running Integrity Check ---");
            if (!File.Exists(_filePath))
            {
                Console.WriteLine("CRITICAL: Ledger file missing!");
                return;
            }

            string[] lines = File.ReadAllLines(_filePath);
            string currentHash = "GENESIS_HASH";
            int validCount = 0;

            foreach (string line in lines)
            {
                // In a real system, we would re-calculate the hash of the line 
                // and compare it to the stored hash in the next line.
                // Here we simulate the verification logic.
                
                if (line.Contains($"PrevHash: {currentHash}"))
                {
                    validCount++;
                    // Update current hash to the hash of this line for the next iteration check
                    currentHash = CalculateSimpleHash(line);
                }
                else
                {
                    Console.WriteLine($"WARNING: Chain broken at entry: {line.Substring(0, 50)}...");
                    return; // Tampering detected
                }
            }

            Console.WriteLine($"SUCCESS: Ledger is immutable. {validCount} entries verified.");
        }

        // Helper for simple hashing simulation
        private string CalculateSimpleHash(string input)
        {
            // Using basic string manipulation to simulate a hash for this exercise
            // In reality, use SHA256
            int hash = 0;
            foreach (char c in input) hash = (hash * 31) + c;
            return Math.Abs(hash).ToString("X");
        }
    }

    // --- Legacy System Simulation ---

    public class LegacyEHRSystem
    {
        // Simulates a connection to a brittle, on-premise API
        public string FetchEcgData(string patientId)
        {
            // Simulate network latency or legacy processing
            System.Threading.Thread.Sleep(100); 
            
            if (patientId == "45992")
            {
                return "ECG_Data_Payload_12Leads";
            }
            throw new UnauthorizedAccessException("Legacy System rejected ID: " + patientId);
        }
    }
}
