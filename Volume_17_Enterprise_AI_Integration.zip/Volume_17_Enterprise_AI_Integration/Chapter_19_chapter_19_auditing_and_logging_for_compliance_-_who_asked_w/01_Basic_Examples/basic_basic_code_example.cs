
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

// Real-world context: A financial services company needs to audit every AI interaction
// for regulatory compliance (SOX, GDPR). When an employee asks the AI to "summarize Q3 earnings",
// we must log: who asked, what they asked, what the AI did, and any data it accessed.
// This ensures accountability and traceability.

// --- Domain Models ---
public record AuditEvent(
    string EventId,
    string UserId,
    string UserEmail,
    DateTime Timestamp,
    string Action,
    string ResourceType,
    string ResourceId,
    string Details,
    string Status
);

public record UserRequest(
    string UserId,
    string UserEmail,
    string Query
);

// --- Core Auditing Service ---
public class ComplianceAuditor
{
    private readonly string _logFilePath;
    private readonly JsonSerializerOptions _jsonOptions;

    public ComplianceAuditor(string logFilePath)
    {
        _logFilePath = logFilePath;
        _jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            Converters = { new JsonStringEnumConverter() }
        };
    }

    // Method 1: Log the incoming request (Who asked what?)
    public async Task LogUserRequestAsync(UserRequest request)
    {
        var auditEvent = new AuditEvent(
            EventId: Guid.NewGuid().ToString(),
            UserId: request.UserId,
            UserEmail: request.UserEmail,
            Timestamp: DateTime.UtcNow,
            Action: "AI_QUERY_INITIATED",
            ResourceType: "AI_SERVICE",
            ResourceId: "LLM_ENDPOINT_V1",
            Details: JsonSerializer.Serialize(new { request.Query }, _jsonOptions),
            Status: "STARTED"
        );

        await AppendToAuditLogAsync(auditEvent);
    }

    // Method 2: Log the AI's action (What did the AI do?)
    public async Task LogAiResponseAsync(string eventId, string actionType, string details, string status = "COMPLETED")
    {
        // In a real system, we'd fetch the original user context from a request scope
        // For this example, we simulate retrieving the user ID associated with the event
        var simulatedUserId = "USER_12345"; 
        var simulatedUserEmail = "jane.doe@enterprise.com";

        var auditEvent = new AuditEvent(
            EventId: eventId,
            UserId: simulatedUserId,
            UserEmail: simulatedUserEmail,
            Timestamp: DateTime.UtcNow,
            Action: actionType,
            ResourceType: "AI_GENERATED_CONTENT",
            ResourceId: $"RESPONSE_{eventId}",
            Details: details,
            Status: status
        );

        await AppendToAuditLogAsync(auditEvent);
    }

    // Method 3: Log data modification (What data changed?)
    public async Task LogDataModificationAsync(string eventId, string resourceId, string operation, string changeDetails)
    {
        var auditEvent = new AuditEvent(
            EventId: eventId,
            UserId: "SYSTEM_AI_AGENT", // Or the user who triggered the automation
            UserEmail: "ai-agent@enterprise.com",
            Timestamp: DateTime.UtcNow,
            Action: operation,
            ResourceType: "DATABASE_RECORD",
            ResourceId: resourceId,
            Details: changeDetails,
            Status: "EXECUTED"
        );

        await AppendToAuditLogAsync(auditEvent);
    }

    // Critical: Immutable logging mechanism (Append-Only)
    private async Task AppendToAuditLogAsync(AuditEvent auditEvent)
    {
        var logEntry = JsonSerializer.Serialize(auditEvent, _jsonOptions);
        
        // In a real enterprise system, this would write to:
        // 1. A Write-Once-Read-Many (WORM) storage
        // 2. A secured SIEM (Security Information and Event Management) system
        // 3. A blockchain ledger for ultimate immutability
        
        // For this example, we append to a local file with thread-safety
        using var stream = new FileStream(
            _logFilePath, 
            FileMode.Append, 
            FileAccess.Write, 
            FileShare.None, 
            4096, 
            true
        );
        
        var bytes = Encoding.UTF8.GetBytes(logEntry + Environment.NewLine);
        await stream.WriteAsync(bytes, 0, bytes.Length);
    }
}

// --- Simulation of an AI Workflow ---
public class AiWorkflowSimulator
{
    private readonly ComplianceAuditor _auditor;

    public AiWorkflowSimulator(ComplianceAuditor auditor)
    {
        _auditor = auditor;
    }

    public async Task RunWorkflowAsync()
    {
        // 1. User initiates request
        var userRequest = new UserRequest(
            UserId: "USER_12345",
            UserEmail: "jane.doe@enterprise.com",
            Query: "Summarize the Q3 financial report and update the dashboard."
        );

        await _auditor.LogUserRequestAsync(userRequest);
        var eventId = Guid.NewGuid().ToString(); // Correlation ID for this session

        // 2. AI processes request (Simulated)
        await Task.Delay(100); // Simulating LLM latency
        
        // 3. AI generates content
        var aiSummary = "Q3 Earnings: Revenue up 15%, Expenses down 2%. Market outlook positive.";
        await _auditor.LogAiResponseAsync(eventId, "GENERATE_SUMMARY", aiSummary);

        // 4. AI invokes function call (Simulated legacy system integration)
        var legacyApiCall = "PATCH /api/v1/dashboards/financial-q3 - Payload: { 'summary': '...' }";
        await _auditor.LogAiResponseAsync(eventId, "INVOKE_LEGACY_API", legacyApiCall);

        // 5. Data modification occurs
        var dbChange = "Updated table 'FinancialDashboards' ID: 550e8400-e29b-41d4-a716-446655440000";
        await _auditor.LogDataModificationAsync(eventId, "DB_REC_550e8400", "UPDATE", dbChange);
    }
}

// --- Entry Point ---
public class Program
{
    public static async Task Main(string[] args)
    {
        // Initialize the auditor with a compliance-mandated log path
        var logPath = "audit_trail.jsonl"; // JSON Lines format is ideal for structured logs
        var auditor = new ComplianceAuditor(logPath);
        
        // Run the AI workflow simulation
        var simulator = new AiWorkflowSimulator(auditor);
        await simulator.RunWorkflowAsync();

        Console.WriteLine($"Audit trail generated at: {Path.GetFullPath(logPath)}");
        Console.WriteLine("Compliance check: PASS");
    }
}
