
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace AuditSystem
{
    public class LogAggregatorService : BackgroundService
    {
        private readonly Channel<AiAuditEntry> _channel;
        private readonly ConcurrentBag<string> _storage; // Simulated database
        private readonly int _batchSize = 100;
        private readonly TimeSpan _batchTimeWindow = TimeSpan.FromMilliseconds(500);

        public LogAggregatorService()
        {
            // Unbounded channel to prevent backpressure blocking the AI inference
            _channel = Channel.CreateUnbounded<AiAuditEntry>();
            _storage = new ConcurrentBag<string>();
        }

        public async Task LogAsync(AiAuditEntry entry)
        {
            // Non-blocking write to the channel
            await _channel.Writer.WriteAsync(entry);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var batch = new List<AiAuditEntry>(_batchSize);
            var timer = new PeriodicTimer(_batchTimeWindow);

            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    // Wait for either the timer or batch size
                    var waitTask = timer.WaitForNextTickAsync(stoppingToken).AsTask();
                    var readTask = _channel.Reader.ReadAsync(stoppingToken).AsTask();

                    var completedTask = await Task.WhenAny(waitTask, readTask);

                    if (completedTask == readTask)
                    {
                        // We successfully read an entry
                        batch.Add(await readTask);

                        // Check if we hit the batch size limit
                        if (batch.Count >= _batchSize)
                        {
                            await FlushToStorage(batch);
                            batch.Clear();
                        }
                    }
                    else
                    {
                        // Timer ticked - flush whatever we have
                        if (batch.Count > 0)
                        {
                            await FlushToStorage(batch);
                            batch.Clear();
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // Graceful shutdown
            }
            finally
            {
                // Flush remaining items on shutdown
                if (batch.Count > 0)
                {
                    await FlushToStorage(batch);
                }
                _channel.Writer.Complete();
            }
        }

        private async Task FlushToStorage(List<AiAuditEntry> batch)
        {
            // Simulate async I/O (e.g., SQL Bulk Insert)
            await Task.Delay(10); 

            foreach (var entry in batch)
            {
                // In a real scenario, this would be a DB insert command
                _storage.Add(entry.SerializeToImmutableJson());
            }
            Console.WriteLine($"[LogAggregator] Flushed {batch.Count} entries to storage.");
        }
    }
}
