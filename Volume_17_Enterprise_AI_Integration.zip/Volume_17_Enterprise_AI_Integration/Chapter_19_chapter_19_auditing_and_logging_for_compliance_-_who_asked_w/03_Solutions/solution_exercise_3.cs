
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace AuditSystem
{
    // 1. Context Provider using AsyncLocal
    public static class CorrelationContext
    {
        private static readonly AsyncLocal<Guid?> _correlationId = new();

        public static Guid? Current => _correlationId.Value;

        public static void SetCorrelationId(Guid? id)
        {
            _correlationId.Value = id;
        }

        // Interactive Challenge: Hierarchical Tracing
        private static readonly AsyncLocal<Guid?> _parentSpanId = new();
        public static Guid? ParentSpanId => _parentSpanId.Value;

        public static IDisposable CreateChildScope(Guid newCorrelationId)
        {
            var parent = Current;
            _correlationId.Value = newCorrelationId;
            _parentSpanId.Value = parent;

            return new CorrelationScope();
        }

        private class CorrelationScope : IDisposable
        {
            public void Dispose()
            {
                // Reset to null or previous value depending on implementation requirements
                // Here we simply clear the async local context
                _correlationId.Value = null;
                _parentSpanId.Value = null;
            }
        }
    }

    // 2. Interface for Audit Logging
    public interface IAuditLogger
    {
        void Log(AiAuditEntry entry);
    }

    // 3. Implementation with Enrichment
    public class ConsoleAuditLogger : IAuditLogger
    {
        public void Log(AiAuditEntry entry)
        {
            // Simulate Enrichment: Inject CorrelationId if available in context
            var contextId = CorrelationContext.Current;
            
            // In a real structured logger (Serilog), we would add properties here.
            // For this exercise, we format a string to demonstrate the injection.
            Console.WriteLine($"[Audit] Correlation: {contextId} | User: {entry.UserId} | Action: {entry.ActionType}");
        }
    }

    public class Simulation
    {
        public static async Task Run()
        {
            var logger = new ConsoleAuditLogger();

            // 4. Simulate concurrent tasks
            var task1 = Task.Run(async () =>
            {
                using (CorrelationContext.CreateChildScope(Guid.NewGuid()))
                {
                    // Simulate work
                    await Task.Delay(50);
                    var entry = new AiAuditEntry(
                        Guid.NewGuid(), CorrelationContext.Current!.Value, "UserA", 
                        DateTimeOffset.UtcNow, "Prompt A", "ModelX", 10, "Gen");
                    logger.Log(entry);
                }
            });

            var task2 = Task.Run(async () =>
            {
                using (CorrelationContext.CreateChildScope(Guid.NewGuid()))
                {
                    // Simulate work
                    await Task.Delay(50);
                    var entry = new AiAuditEntry(
                        Guid.NewGuid(), CorrelationContext.Current!.Value, "UserB", 
                        DateTimeOffset.UtcNow, "Prompt B", "ModelY", 20, "Gen");
                    logger.Log(entry);
                }
            });

            await Task.WhenAll(task1, task2);
        }
    }
}
