
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Text.RegularExpressions;
using System.Collections.Immutable;
using System.Linq;

namespace AuditSystem
{
    // 1. Transformer Interface
    public interface IAuditTransformer
    {
        AiAuditEntry Transform(AiAuditEntry entry);
    }

    // 2. PII Redaction Transformer
    public class PiiRedactionTransformer : IAuditTransformer
    {
        private static readonly Regex EmailRegex = new Regex(@"(?<=\b)[^@\s]+@[^@\s]+\.[^@\s]+(?=\b)", RegexOptions.Compiled);
        private static readonly Regex CreditCardRegex = new Regex(@"\b(?:\d[ -]*?){13,16}\b", RegexOptions.Compiled);

        public AiAuditEntry Transform(AiAuditEntry entry)
        {
            var redactedPrompt = EmailRegex.Replace(entry.PromptSnippet, m => 
            {
                var email = m.Value;
                var atIdx = email.IndexOf('@');
                return $"{email[0]}***@{email.Substring(atIdx + 1)}";
            });

            redactedPrompt = CreditCardRegex.Replace(redactedPrompt, "****-****-****-****");

            // Return a new record with modified properties
            return entry with { PromptSnippet = redactedPrompt };
        }
    }

    // 3. Retention Tag Transformer
    public class RetentionTagTransformer : IAuditTransformer
    {
        public AiAuditEntry Transform(AiAuditEntry entry)
        {
            // Add a retention tag. 
            // Since Tags is an ImmutableList, we use Add to create a new list.
            var newTags = (entry.Tags ?? ImmutableList<string>.Empty).Add("RETENTION_1YR");

            return entry with { Tags = newTags };
        }
    }

    // 4. Pipeline Orchestrator
    public class LogPipeline
    {
        private readonly ImmutableList<IAuditTransformer> _transformers;

        public LogPipeline(IEnumerable<IAuditTransformer> transformers)
        {
            _transformers = transformers.ToImmutableList();
        }

        public AiAuditEntry Process(AiAuditEntry entry)
        {
            var current = entry;
            foreach (var transformer in _transformers)
            {
                current = transformer.Transform(current);
            }
            return current;
        }
    }

    public class PipelineDemo
    {
        public static void Run()
        {
            // Input with PII
            var rawEntry = new AiAuditEntry(
                Guid.NewGuid(), Guid.NewGuid(), "admin@corp.com", 
                DateTimeOffset.UtcNow, 
                "User email is john.doe@example.com and card is 1234-5678-9012-3456", 
                "gpt-4", 50, "Gen");

            var pipeline = new LogPipeline(new IAuditTransformer[]
            {
                new PiiRedactionTransformer(),
                new RetentionTagTransformer()
            });

            var processedEntry = pipeline.Process(rawEntry);

            Console.WriteLine($"Original: {rawEntry.PromptSnippet}");
            Console.WriteLine($"Redacted: {processedEntry.PromptSnippet}");
            Console.WriteLine($"Tags: {string.Join(", ", processedEntry.Tags)}");
        }
    }
}
