
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Collections.Immutable;

namespace AuditSystem
{
    // Custom converter to ensure ISO 8601 format with timezone designator
    public class DateTimeOffsetIso8601Converter : JsonConverter<DateTimeOffset>
    {
        public override DateTimeOffset Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateTimeOffset.Parse(reader.GetString()!);
        }

        public override void Write(Utf8JsonWriter writer, DateTimeOffset value, JsonSerializerOptions options)
        {
            // Explicitly format to ISO 8601 with 'Z' for UTC
            writer.WriteStringValue(value.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
        }
    }

    // The immutable record
    public record AiAuditEntry(
        Guid EntryId,
        Guid CorrelationId,
        string UserId,
        DateTimeOffset Timestamp,
        string PromptSnippet,
        string ModelName,
        int TokensUsed,
        string ActionType,
        object? Payload = null, // Generic payload for structured data
        ImmutableList<string>? Tags = null // For Exercise 4 compliance tags
    );

    public static class AuditExtensions
    {
        public static string SerializeToImmutableJson(this AiAuditEntry entry)
        {
            // Configure options for deterministic output (sorted keys) and timestamp handling
            var options = new JsonSerializerOptions
            {
                WriteIndented = false, // Compact for hashing
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                Converters = { new DateTimeOffsetIso8601Converter() }
            };

            // System.Text.Json serializes objects in definition order for records, 
            // but to ensure strict determinism for hashing (Exercise 5), we rely on
            // the fact that records preserve parameter order. 
            // Note: For complex nested objects, a custom converter ensuring sorted property names would be needed.
            
            return JsonSerializer.Serialize(entry, options);
        }
    }

    public class Program
    {
        public static void Main()
        {
            // 1. Create instance with a generic Payload (Dictionary for flexibility)
            var payload = new Dictionary<string, string>
            {
                { "Function", "GetWeather" },
                { "Location", "New York" }
            };

            var entry = new AiAuditEntry(
                EntryId: Guid.NewGuid(),
                CorrelationId: Guid.NewGuid(),
                UserId: "user_123",
                Timestamp: DateTimeOffset.UtcNow, // Will be converted by custom converter
                PromptSnippet: "What is the weather in NY?",
                ModelName: "gpt-4-turbo",
                TokensUsed: 150,
                ActionType: "FunctionCall",
                Payload: payload
            );

            // 2. Serialize
            string json = entry.SerializeToImmutableJson();
            
            Console.WriteLine("Serialized JSON (Deterministic):");
            Console.WriteLine(json);
            
            // 3. Demonstrate null payload handling
            var entryNoPayload = entry with { Payload = null };
            string jsonNoPayload = entryNoPayload.SerializeToImmutableJson();
            Console.WriteLine("\nSerialized JSON (Null Payload Ignored):");
            Console.WriteLine(jsonNoPayload);
        }
    }
}
