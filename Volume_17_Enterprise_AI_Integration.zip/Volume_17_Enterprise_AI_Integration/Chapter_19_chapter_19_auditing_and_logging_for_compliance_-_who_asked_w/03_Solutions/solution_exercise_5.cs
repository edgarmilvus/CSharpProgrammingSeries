
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace AuditSystem
{
    public class SecureAuditTrail
    {
        // Internal structure to store entry + hash
        private record SecureEntry(AiAuditEntry AuditEntry, string Hash);

        private readonly List<SecureEntry> _chain = new();
        private byte[] _lastHash = Array.Empty<byte>();
        
        // Thread safety for concurrent appends
        private readonly SemaphoreSlim _lock = new(1, 1);

        public async Task AppendAsync(AiAuditEntry entry)
        {
            await _lock.WaitAsync();
            try
            {
                // 1. Serialize canonically
                string json = entry.SerializeToImmutableJson();
                
                // 2. Compute hash: SHA256(LastHash + CurrentJson)
                using var sha256 = SHA256.Create();
                
                // Combine bytes
                byte[] jsonBytes = Encoding.UTF8.GetBytes(json);
                byte[] combinedBytes = new byte[_lastHash.Length + jsonBytes.Length];
                
                Buffer.BlockCopy(_lastHash, 0, combinedBytes, 0, _lastHash.Length);
                Buffer.BlockCopy(jsonBytes, 0, combinedBytes, _lastHash.Length, jsonBytes.Length);

                byte[] hashBytes = sha256.ComputeHash(combinedBytes);
                string currentHash = Convert.ToBase64String(hashBytes);

                // 3. Update chain
                _chain.Add(new SecureEntry(entry, currentHash));
                _lastHash = hashBytes; // Update for next iteration

                Console.WriteLine($"Appended. Block Hash: {currentHash}");
            }
            finally
            {
                _lock.Release();
            }
        }

        public bool Verify()
        {
            _lock.Wait();
            try
            {
                byte[] previousHash = Array.Empty<byte>(); // Genesis block check

                for (int i = 0; i < _chain.Count; i++)
                {
                    var secureEntry = _chain[i];
                    string json = secureEntry.AuditEntry.SerializeToImmutableJson();
                    
                    using var sha256 = SHA256.Create();
                    byte[] jsonBytes = Encoding.UTF8.GetBytes(json);
                    
                    byte[] combinedBytes = new byte[previousHash.Length + jsonBytes.Length];
                    Buffer.BlockCopy(previousHash, 0, combinedBytes, 0, previousHash.Length);
                    Buffer.BlockCopy(jsonBytes, 0, combinedBytes, previousHash.Length, jsonBytes.Length);

                    byte[] computedHash = sha256.ComputeHash(combinedBytes);
                    string computedHashString = Convert.ToBase64String(computedHash);

                    if (computedHashString != secureEntry.Hash)
                    {
                        Console.WriteLine($"Verification Failed at index {i}.");
                        return false;
                    }

                    previousHash = computedHash;
                }
                Console.WriteLine("Verification Successful: Chain intact.");
                return true;
            }
            finally
            {
                _lock.Release();
            }
        }
    }

    // Interactive Challenge: Integration with Async System
    // (Conceptual usage in a high-throughput scenario)
    public class SecureLogService
    {
        private readonly SecureAuditTrail _trail = new();

        public async Task LogConcurrentlyAsync(IEnumerable<AiAuditEntry> entries)
        {
            var tasks = entries.Select(e => _trail.AppendAsync(e));
            await Task.WhenAll(tasks); // Safe due to SemaphoreSlim inside SecureAuditTrail
        }
    }
}
