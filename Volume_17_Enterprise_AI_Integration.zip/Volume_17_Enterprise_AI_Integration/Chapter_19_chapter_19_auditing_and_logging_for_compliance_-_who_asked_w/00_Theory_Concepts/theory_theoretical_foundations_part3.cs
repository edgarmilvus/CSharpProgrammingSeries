
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

using System.Diagnostics;

// Define a source specifically for our AI operations
public static class AiDiagnostics
{
    public static readonly ActivitySource Source = new("EnterpriseAI.Orchestrator", "1.0.0");
}

// Usage in a pipeline
public async Task<AiResponse> ProcessRequestAsync(AiRequest request)
{
    // Start a new Activity (span)
    using var activity = AiDiagnostics.Source.StartActivity("AI-Request-Processing");
    
    // Enrich the activity with baggage (metadata that travels with the trace)
    activity?.SetTag("user.id", request.UserId);
    activity?.SetTag("ai.model", request.ModelName);
    
    // The trace ID is automatically generated and propagated here.
    // If we call a Vector DB or an external API, the context is passed automatically
    // via W3C Trace Context headers.
    
    var result = await _orchestrator.SendAsync(request);
    
    activity?.SetStatus(ActivityStatusCode.Ok);
    return result;
}
