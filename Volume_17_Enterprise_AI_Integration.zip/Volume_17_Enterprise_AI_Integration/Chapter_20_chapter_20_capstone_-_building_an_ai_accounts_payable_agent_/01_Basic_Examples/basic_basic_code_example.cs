
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace InvoiceProcessingAgent
{
    // ---------------------------------------------------------
    // 1. Domain Models (The "What")
    // ---------------------------------------------------------
    // In a real-world scenario, these classes would map to database
    // tables or external API schemas. We use records for immutability
    // and value equality, which is crucial for audit trails.
    
    public record Invoice(
        string Id,
        string VendorName,
        decimal TotalAmount,
        string Currency,
        DateTime DueDate,
        List<InvoiceLineItem> LineItems
    );

    public record InvoiceLineItem(
        string Description,
        int Quantity,
        decimal UnitPrice
    );

    public record ProcurementContract(
        string VendorName,
        decimal NegotiatedRate,
        int AllowedQuantity
    );

    // ---------------------------------------------------------
    // 2. The AI Agent Logic (The "How")
    // ---------------------------------------------------------
    public class InvoiceAgent
    {
        // In a production system, these would be external API clients or Database contexts.
        // For this "Hello World" example, we simulate them with in-memory data.
        private readonly List<ProcurementContract> _contracts;

        public InvoiceAgent()
        {
            // Seed data: Simulating an internal procurement database.
            _contracts = new List<ProcurementContract>
            {
                new ProcurementContract("Office Supplies Inc.", 15.00m, 100),
                new ProcurementContract("Cloud Hosting Co.", 500.00m, 1)
            };
        }

        /// <summary>
        /// Orchestrates the extraction, validation, and scheduling of an invoice.
        /// This represents the core agentic workflow.
        /// </summary>
        public async Task<ProcessingResult> ProcessInvoiceAsync(string rawInvoiceJson)
        {
            Console.WriteLine($"[Agent] Starting processing cycle for raw input...");

            // Step 1: Extraction (LLM Simulation)
            Invoice? invoice = ExtractInvoiceData(rawInvoiceJson);
            if (invoice == null)
            {
                return new ProcessingResult { Status = "Failed", Error = "Invalid Invoice Format" };
            }

            // Step 2: Validation (Business Logic)
            bool isValid = await ValidateInvoiceAgainstContractsAsync(invoice);
            if (!isValid)
            {
                return new ProcessingResult { Status = "Failed", Error = "Validation Failed: Contract mismatch" };
            }

            // Step 3: Scheduling (Legacy System Integration)
            string paymentId = await SchedulePaymentInErpAsync(invoice);

            // Step 4: Audit Logging
            Console.WriteLine($"[Audit] Transaction {paymentId} committed for {invoice.VendorName}.");

            return new ProcessingResult
            {
                Status = "Success",
                InvoiceId = invoice.Id,
                PaymentScheduleId = paymentId,
                ProcessedAt = DateTime.UtcNow
            };
        }

        /// <summary>
        /// Simulates an LLM's ability to extract structured data from unstructured text (JSON).
        /// In reality, this would involve calling an LLM API with a specific prompt schema.
        /// </summary>
        private Invoice? ExtractInvoiceData(string rawJson)
        {
            try
            {
                // We use System.Text.Json for parsing.
                // In a real LLM wrapper, we would parse the LLM's string output into this object.
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                return JsonSerializer.Deserialize<Invoice>(rawJson, options);
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"[LLM-Error] Extraction failed: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Connects to internal APIs to validate line items against active contracts.
        /// </summary>
        private async Task<bool> ValidateInvoiceAgainstContractsAsync(Invoice invoice)
        {
            // Simulate network latency for API call
            await Task.Delay(100);

            Console.WriteLine($"[API] Validating {invoice.LineItems.Count} items against procurement DB...");

            foreach (var item in invoice.LineItems)
            {
                // Find matching contract
                var contract = _contracts.FirstOrDefault(c => c.VendorName == invoice.VendorName);
                
                if (contract == null)
                {
                    Console.WriteLine($"[Validation] No contract found for vendor: {invoice.VendorName}");
                    return false;
                }

                // Business Rule: Price must not exceed negotiated rate
                if (item.UnitPrice > contract.NegotiatedRate)
                {
                    Console.WriteLine($"[Validation] Price mismatch for {item.Description}. " +
                                      $"Expected: {contract.NegotiatedRate}, Actual: {item.UnitPrice}");
                    return false;
                }

                // Business Rule: Quantity must be within allowed limits
                if (item.Quantity > contract.AllowedQuantity)
                {
                    Console.WriteLine($"[Validation] Quantity limit exceeded for {item.Description}.");
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Simulates writing to a legacy ERP system (e.g., SAP, Oracle).
        /// </summary>
        private async Task<string> SchedulePaymentInErpAsync(Invoice invoice)
        {
            // Simulate legacy system interaction (often slow, XML-based, or SOAP)
            await Task.Delay(150);

            // Generate a mock ERP Transaction ID
            string erpId = $"ERP-{Guid.NewGuid().ToString().Substring(0, 8)}";
            
            Console.WriteLine($"[ERP] Legacy System Updated. Payment ID: {erpId} for ${invoice.TotalAmount} due {invoice.DueDate.ToShortDateString()}.");
            
            return erpId;
        }
    }

    // ---------------------------------------------------------
    // 3. Result Structure
    // ---------------------------------------------------------
    public class ProcessingResult
    {
        public string Status { get; set; } = string.Empty;
        public string? InvoiceId { get; set; }
        public string? PaymentScheduleId { get; set; }
        public DateTime? ProcessedAt { get; set; }
        public string? Error { get; set; }
    }

    // ---------------------------------------------------------
    // 4. Execution Entry Point
    // ---------------------------------------------------------
    class Program
    {
        static async Task Main(string[] args)
        {
            // Real-world context: An invoice arrives via email or API in JSON format.
            // It contains unstructured data that needs to be parsed and validated.
            string incomingInvoice = @"
            {
                ""Id"": ""INV-2023-001"",
                ""VendorName"": ""Office Supplies Inc."",
                ""TotalAmount"": 450.00,
                ""Currency"": ""USD"",
                ""DueDate"": ""2023-12-15"",
                ""LineItems"": [
                    { ""Description"": ""Laptop Stand"", ""Quantity"": 10, ""UnitPrice"": 15.00 },
                    { ""Description"": ""Wireless Mouse"", ""Quantity"": 20, ""UnitPrice"": 12.50 }
                ]
            }";

            // Instantiate the agent
            var agent = new InvoiceAgent();

            // Execute the workflow
            ProcessingResult result = await agent.ProcessInvoiceAsync(incomingInvoice);

            // Output final status
            Console.WriteLine("\n--- Final Report ---");
            Console.WriteLine($"Status: {result.Status}");
            if (result.Status == "Success")
            {
                Console.WriteLine($"Invoice ID: {result.InvoiceId}");
                Console.WriteLine($"ERP Payment ID: {result.PaymentScheduleId}");
                Console.WriteLine($"Processed At: {result.ProcessedAt}");
            }
            else
            {
                Console.WriteLine($"Error: {result.Error}");
            }
        }
    }
}
