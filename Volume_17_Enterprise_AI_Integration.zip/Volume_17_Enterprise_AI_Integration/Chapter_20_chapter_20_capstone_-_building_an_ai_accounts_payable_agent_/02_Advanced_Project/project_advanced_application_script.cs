
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnterpriseAIAgent
{
    // ==========================================
    // DATA MODELS
    // ==========================================
    // Represents an invoice received from a vendor. In a real scenario, this 
    // would be populated by an OCR (Optical Character Recognition) model or 
    // extracted from a PDF using an LLM.
    public class Invoice
    {
        public string InvoiceId { get; set; }
        public string VendorName { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsVerified { get; set; } = false;
    }

    // Represents a Purchase Order (PO) stored in the internal procurement system.
    // The agent must validate the invoice against these records.
    public class PurchaseOrder
    {
        public string PoNumber { get; set; }
        public string VendorName { get; set; }
        public decimal ApprovedAmount { get; set; }
        public bool IsActive { get; set; }
    }

    // ==========================================
    // MOCK EXTERNAL SYSTEMS (STUBS)
    // ==========================================
    // Simulates a legacy ERP system (e.g., SAP, Oracle) that handles 
    // actual fund transfers. Note the "Outbox" pattern simulation for audit.
    public static class LegacyERPSystem
    {
        public static List<string> PaymentOutbox = new List<string>();

        public static bool SchedulePayment(string invoiceId, string vendorName, decimal amount, DateTime date)
        {
            // Simulate connection latency or failure
            if (amount > 50000) 
            {
                Console.WriteLine($"   [ERP ERROR] Payment of {amount:C} exceeds automated limit. Requires manual override.");
                return false;
            }

            string transactionId = Guid.NewGuid().ToString().Substring(0, 8);
            string record = $"TXN:{transactionId} | VENDOR:{vendorName} | AMT:{amount:C} | DUE:{date.ToShortDateString()}";
            PaymentOutbox.Add(record);
            Console.WriteLine($"   [ERP SUCCESS] Payment scheduled. Ref: {transactionId}");
            return true;
        }
    }

    // Simulates the internal Procurement API that stores Purchase Orders.
    public static class ProcurementAPI
    {
        private static readonly List<PurchaseOrder> _database = new List<PurchaseOrder>
        {
            new PurchaseOrder { PoNumber = "PO-1001", VendorName = "Acme Corp", ApprovedAmount = 1500.00m, IsActive = true },
            new PurchaseOrder { PoNumber = "PO-1002", VendorName = "Globex Inc", ApprovedAmount = 45000.00m, IsActive = true },
            new PurchaseOrder { PoNumber = "PO-1003", VendorName = "Stark Ind", ApprovedAmount = 2000.00m, IsActive = false } // Inactive PO
        };

        public static PurchaseOrder GetPoByVendor(string vendorName)
        {
            foreach (var po in _database)
            {
                if (po.VendorName == vendorName)
                {
                    return po;
                }
            }
            return null;
        }
    }

    // ==========================================
    // CORE AGENT LOGIC
    // ==========================================
    public class AccountsPayableAgent
    {
        // The "Brain" of the agent. In a production system, this would be an 
        // LLM API call (e.g., Azure OpenAI) that performs Named Entity Recognition.
        // Here, we simulate the extraction logic.
        public Invoice ExtractInvoiceData(string rawText)
        {
            Console.WriteLine("\n[AGENT] Step 1: Extracting data from raw text using LLM...");
            
            // Simulated LLM Output parsing
            // In reality: await _llmService.Completion(prompt);
            
            var invoice = new Invoice
            {
                InvoiceId = "INV-2023-999",
                VendorName = "Acme Corp", 
                TotalAmount = 1500.00m,
                DueDate = DateTime.Now.AddDays(15)
            };

            Console.WriteLine($"   [LLM EXTRACTION] Found Vendor: {invoice.VendorName}, Amount: {invoice.TotalAmount:C}");
            return invoice;
        }

        // Orchestrates the validation against internal APIs
        public bool ValidateAgainstProcurement(Invoice invoice)
        {
            Console.WriteLine("\n[AGENT] Step 2: Validating against Procurement API...");
            
            // 1. Fetch Data
            PurchaseOrder po = ProcurementAPI.GetPoByVendor(invoice.VendorName);

            // 2. Logic Checks (Edge Case Handling)
            if (po == null)
            {
                Console.WriteLine($"   [VALIDATION FAIL] No active Purchase Order found for {invoice.VendorName}.");
                return false;
            }

            if (!po.IsActive)
            {
                Console.WriteLine($"   [VALIDATION FAIL] Purchase Order {po.PoNumber} is inactive.");
                return false;
            }

            if (invoice.TotalAmount != po.ApprovedAmount)
            {
                Console.WriteLine($"   [VALIDATION FAIL] Invoice amount ({invoice.TotalAmount:C}) does not match PO amount ({po.ApprovedAmount:C}).");
                // In a real agent, this might trigger a "Discrepancy Resolution" sub-agent
                return false;
            }

            Console.WriteLine($"   [VALIDATION PASS] Matched against {po.PoNumber}.");
            invoice.IsVerified = true;
            return true;
        }

        // Orchestrates the payment scheduling with safeguards
        public void ExecutePayment(Invoice invoice)
        {
            Console.WriteLine("\n[AGENT] Step 3: Scheduling Payment...");

            if (!invoice.IsVerified)
            {
                Console.WriteLine("   [CRITICAL] Attempted to pay unverified invoice. Halting.");
                return;
            }

            // Human-in-the-loop simulation
            // In production, this would be a "Approval Request" sent to a Slack/Teams channel
            if (invoice.TotalAmount > 10000)
            {
                Console.WriteLine($"   [HUMAN REVIEW REQUIRED] Amount {invoice.TotalAmount:C} exceeds threshold. Routing to Manager.");
                return;
            }

            bool success = LegacyERPSystem.SchedulePayment(invoice.InvoiceId, invoice.VendorName, invoice.TotalAmount, invoice.DueDate);

            if (!success)
            {
                Console.WriteLine("   [AGENT] Payment failed. Logging to audit trail.");
                // Log to audit database...
            }
        }
    }

    // ==========================================
    // MAIN PROGRAM EXECUTION
    // ==========================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=================================================");
            Console.WriteLine("  ENTERPRISE AI AP AGENT - INITIALIZATION");
            Console.WriteLine("=================================================");

            // 1. Simulation of incoming unstructured data (e.g., email body or PDF text)
            string rawInvoiceText = "INVOICE: INV-2023-999. VENDOR: Acme Corp. AMOUNT: $1500.00. DUE: 2023-12-01.";

            // 2. Instantiate the Agent
            var agent = new AccountsPayableAgent();

            // 3. Execute Agentic Workflow
            try
            {
                // A. Extraction Phase
                Invoice extractedInvoice = agent.ExtractInvoiceData(rawInvoiceText);

                // B. Validation Phase
                bool isValid = agent.ValidateAgainstProcurement(extractedInvoice);

                // C. Execution Phase
                if (isValid)
                {
                    agent.ExecutePayment(extractedInvoice);
                }
                else
                {
                    Console.WriteLine("\n[WORKFLOW] Validation failed. Stopping pipeline.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n[SYSTEM ERROR] An unexpected error occurred: {ex.Message}");
            }

            // 4. Display Audit Trail (Simulated ERP Outbox)
            Console.WriteLine("\n=================================================");
            Console.WriteLine("  SYSTEM AUDIT TRAIL (ERP OUTBOX)");
            Console.WriteLine("=================================================");
            if (LegacyERPSystem.PaymentOutbox.Count == 0)
            {
                Console.WriteLine("No payments scheduled.");
            }
            else
            {
                foreach (var record in LegacyERPSystem.PaymentOutbox)
                {
                    Console.WriteLine(record);
                }
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
