
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace AP_Agent_Solutions.Exercise4
{
    // 1. State Management
    public enum InvoiceState
    {
        Received,
        Extracted,
        Validated,
        PendingApproval,
        Approved,
        Rejected,
        Scheduled
    }

    // 2. Audit Entity
    public class AuditLog
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public DateTimeOffset Timestamp { get; set; } = DateTimeOffset.Now;
        public string Actor { get; set; } // "AI_Agent" or "Human_User"
        public string Action { get; set; }
        public string Details { get; set; }
        public Guid CorrelationId { get; set; } // Maps to InvoiceId
    }

    // 3. HITL Service
    public interface IApprovalService
    {
        Task<bool> RequestApprovalAsync(Invoice invoice, string reason, CancellationToken ct = default);
    }

    public class MockApprovalService : IApprovalService
    {
        public async Task<bool> RequestApprovalAsync(Invoice invoice, string reason, CancellationToken ct = default)
        {
            Console.WriteLine($"[HITL] Approval Requested for Invoice {invoice.Header.InvoiceId}. Reason: {reason}");
            Console.WriteLine("[HITL] Simulating User Decision (Press Enter to Approve, any key to Reject)...");
            
            // For automated testing, we can simulate random approval
            // await Task.Delay(1000); 
            // return new Random().Next(0, 2) == 0;

            // For interactive console:
            var key = Console.ReadKey(intercept: true);
            return key.Key == ConsoleKey.Enter;
        }
    }

    // 4. Audit Logger (Decorator Pattern)
    public class AuditLogger
    {
        private readonly ConcurrentQueue<AuditLog> _logs = new();

        public void Log(Guid correlationId, string actor, string action, object details)
        {
            var log = new AuditLog
            {
                CorrelationId = correlationId,
                Actor = actor,
                Action = action,
                Details = JsonSerializer.Serialize(details)
            };
            _logs.Enqueue(log);
            Console.WriteLine($"[AUDIT] {log.Timestamp:HH:mm:ss} | {actor} | {action} | Inv: {correlationId}");
        }

        public IEnumerable<AuditLog> GetLogs() => _logs;
    }

    // 5. Workflow Orchestrator with Channels
    public class ApWorkflowEngine : BackgroundService
    {
        private readonly Channel<InvoiceContext> _extractionChannel;
        private readonly Channel<InvoiceContext> _validationChannel;
        private readonly Channel<InvoiceContext> _approvalChannel;
        private readonly Channel<InvoiceContext> _publishChannel;
        
        private readonly AuditLogger _auditLogger;
        private readonly IApprovalService _approvalService;

        public ApWorkflowEngine(AuditLogger auditLogger, IApprovalService approvalService)
        {
            _auditLogger = auditLogger;
            _approvalService = approvalService;
            
            // Create bounded channels to handle backpressure
            _extractionChannel = Channel.CreateBounded<InvoiceContext>(10);
            _validationChannel = Channel.CreateBounded<InvoiceContext>(10);
            _approvalChannel = Channel.CreateBounded<InvoiceContext>(10);
            _publishChannel = Channel.CreateBounded<InvoiceContext>(10);
        }

        public async Task SubmitInvoiceAsync(Invoice invoice)
        {
            var context = new InvoiceContext(invoice);
            await _extractionChannel.Writer.WriteAsync(context);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // Start background workers for each stage
            var extractionTask = ProcessExtraction(stoppingToken);
            var validationTask = ProcessValidation(stoppingToken);
            var approvalTask = ProcessApproval(stoppingToken);
            var publishTask = ProcessPublishing(stoppingToken);

            await Task.WhenAll(extractionTask, validationTask, approvalTask, publishTask);
        }

        private async Task ProcessExtraction(CancellationToken ct)
        {
            await foreach (var context in _extractionChannel.Reader.ReadAllAsync(ct))
            {
                // Simulate Extraction
                context.Invoice = new Invoice(new InvoiceHeader(Guid.NewGuid(), "Vendor", DateTime.Now, DateTime.Now.AddDays(30), 12000m), new List<LineItem>()); // High value for HITL
                context.State = InvoiceState.Extracted;
                _auditLogger.Log(context.Invoice.Header.InvoiceId, "AI_Agent", "Extracted", context.Invoice);
                
                await _validationChannel.Writer.WriteAsync(context, ct);
            }
        }

        private async Task ProcessValidation(CancellationToken ct)
        {
            await foreach (var context in _validationChannel.Reader.ReadAllAsync(ct))
            {
                // Simulate Validation
                context.State = InvoiceState.Validated;
                _auditLogger.Log(context.Invoice.Header.InvoiceId, "AI_Agent", "Validated", context.Invoice);
                
                // Check for HITL requirement
                if (context.Invoice.Header.TotalAmount > 10000)
                {
                    await _approvalChannel.Writer.WriteAsync(context, ct);
                }
                else
                {
                    await _publishChannel.Writer.WriteAsync(context, ct);
                }
            }
        }

        private async Task ProcessApproval(CancellationToken ct)
        {
            await foreach (var context in _approvalChannel.Reader.ReadAllAsync(ct))
            {
                context.State = InvoiceState.PendingApproval;
                _auditLogger.Log(context.Invoice.Header.InvoiceId, "System", "PendingApproval", "High Value Check");

                bool isApproved = await _approvalService.RequestApprovalAsync(context.Invoice, "High value invoice", ct);

                if (isApproved)
                {
                    context.State = InvoiceState.Approved;
                    _auditLogger.Log(context.Invoice.Header.InvoiceId, "Human_User", "Approved", "Manual Override");
                    await _publishChannel.Writer.WriteAsync(context, ct);
                }
                else
                {
                    context.State = InvoiceState.Rejected;
                    _auditLogger.Log(context.Invoice.Header.InvoiceId, "Human_User", "Rejected", "Manual Override");
                    // Pipeline ends here
                }
            }
        }

        private async Task ProcessPublishing(CancellationToken ct)
        {
            await foreach (var context in _publishChannel.Reader.ReadAllAsync(ct))
            {
                // Simulate Publishing to ERP
                context.State = InvoiceState.Scheduled;
                _auditLogger.Log(context.Invoice.Header.InvoiceId, "AI_Agent", "Scheduled", "Payment Queued");
            }
        }
    }

    // Context Wrapper
    public class InvoiceContext
    {
        public Invoice Invoice { get; set; }
        public InvoiceState State { get; set; }

        public InvoiceContext(Invoice invoice)
        {
            Invoice = invoice;
            State = InvoiceState.Received;
        }
    }

    // Mock Models
    public record Invoice(InvoiceHeader Header, List<LineItem> LineItems);
    public record InvoiceHeader(Guid InvoiceId, string VendorName, DateTime InvoiceDate, DateTime DueDate, decimal TotalAmount);
    public record LineItem(string Sku, string Description, int Quantity, decimal UnitPrice);
}
