
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Hosting;

namespace AP_Agent_Solutions.Exercise3
{
    // 1. Message Contract
    public class PaymentScheduleMessage
    {
        public Guid InvoiceId { get; set; }
        public string VendorId { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime DueDate { get; set; }
        public string PayloadHash { get; set; }
    }

    // 2. Producer Service
    public interface IErpPublisher
    {
        Task PublishAsync(Invoice validatedInvoice, CancellationToken ct = default);
    }

    public class AzureServiceBusPublisher : IErpPublisher
    {
        private readonly ServiceBusSender _sender;

        public AzureServiceBusPublisher(ServiceBusClient client)
        {
            _sender = client.CreateSender("erp-payment-queue");
        }

        public async Task PublishAsync(Invoice validatedInvoice, CancellationToken ct = default)
        {
            var messagePayload = new PaymentScheduleMessage
            {
                InvoiceId = validatedInvoice.Header.InvoiceId,
                VendorId = validatedInvoice.Header.VendorName, // Simplified
                TotalAmount = validatedInvoice.Header.TotalAmount,
                DueDate = validatedInvoice.Header.DueDate,
                PayloadHash = ComputeHash(JsonSerializer.Serialize(validatedInvoice))
            };

            var body = JsonSerializer.Serialize(messagePayload);
            var message = new ServiceBusMessage(Encoding.UTF8.GetBytes(body));
            
            // Ensure message is not duplicate
            message.MessageId = messagePayload.InvoiceId.ToString(); 

            await _sender.SendMessageAsync(message, ct);
        }

        private string ComputeHash(string input)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            return Convert.ToBase64String(bytes);
        }
    }

    // 3. Consumer Service & 4. DLQ Logic
    public class ErpConsumerService : IHostedService
    {
        private readonly ServiceBusProcessor _processor;
        private readonly ConcurrentDictionary<Guid, bool> _processedIds; // Idempotency store
        private readonly ConcurrentQueue<string> _outbox; // Transactional Outbox simulation

        public ErpConsumerService(ServiceBusClient client, ConcurrentDictionary<Guid, bool> processedIds, ConcurrentQueue<string> outbox)
        {
            _processedIds = processedIds;
            _outbox = outbox;
            
            _processor = client.CreateProcessor("erp-payment-queue", new ServiceBusProcessorOptions
            {
                MaxConcurrentCalls = 1, // Process one at a time for transaction safety
                AutoCompleteMessages = false // Manual settlement
            });

            _processor.ProcessMessageAsync += ProcessMessageAsync;
            _processor.ProcessErrorAsync += args => Task.CompletedTask;
        }

        private async Task ProcessMessageAsync(ProcessMessageEventArgs args)
        {
            var body = args.Message.Body.ToString();
            var message = JsonSerializer.Deserialize<PaymentScheduleMessage>(body);

            // 4. Idempotency Check
            if (_processedIds.ContainsKey(message.InvoiceId))
            {
                Console.WriteLine($"Duplicate detected for Invoice {message.InvoiceId}. Acknowledging.");
                await args.CompleteMessageAsync(args.Message);
                return;
            }

            try
            {
                // Verify Hash
                var calculatedHash = ComputeHash(body); // Simplified; ideally re-serialize payload
                // (Skipping strict hash check for brevity in this simulation)

                // 3. Simulate ERP Insertion Attempt (Random Failure)
                if (new Random().Next(0, 10) < 3) 
                {
                    throw new InvalidOperationException("Simulated DB Constraint Violation");
                }

                // 5. Transactional Outbox Pattern Simulation
                // Instead of direct ERP call, write to local Outbox
                _outbox.Enqueue(body);
                _processedIds.TryAdd(message.InvoiceId, true);

                // Acknowledge message immediately (Message is safe in Outbox)
                await args.CompleteMessageAsync(args.Message);
                Console.WriteLine($"Invoice {message.InvoiceId} moved to Outbox.");
            }
            catch (Exception ex)
            {
                // Dead Letter Queue Logic
                // Service Bus handles MaxDeliveryCount automatically. 
                // If we fail here, the message returns to queue. 
                // After MaxDeliveryCount (default 10), it goes to DLQ.
                // To manually dead-letter:
                await args.DeadLetterMessageAsync(args.Message, $"Processing failed: {ex.Message}");
                Console.WriteLine($"Invoice {message.InvoiceId} moved to DLQ.");
            }
        }

        private string ComputeHash(string input)
        {
            using var sha256 = SHA256.Create();
            return Convert.ToBase64String(sha256.ComputeHash(Encoding.UTF8.GetBytes(input)));
        }

        public async Task StartAsync(CancellationToken cancellationToken) => await _processor.StartProcessingAsync(cancellationToken);
        public async Task StopAsync(CancellationToken cancellationToken) => await _processor.StopProcessingAsync(cancellationToken);
    }

    // 5. Background Worker for Outbox Processing
    public class OutboxProcessorService : BackgroundService
    {
        private readonly ConcurrentQueue<string> _outbox;
        private readonly IServiceProvider _serviceProvider;

        public OutboxProcessorService(ConcurrentQueue<string> outbox, IServiceProvider serviceProvider)
        {
            _outbox = outbox;
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                if (_outbox.TryDequeue(out string messageBody))
                {
                    try
                    {
                        // Simulate pushing to ERP
                        Console.WriteLine("Outbox Worker: Pushing to ERP System...");
                        await Task.Delay(1000, stoppingToken); // Simulate ERP latency
                        
                        // If success, log. If fail, re-enqueue (or implement retry policy)
                        Console.WriteLine("Outbox Worker: ERP Push Successful.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Outbox Worker: ERP Push Failed. Re-enqueuing. Error: {ex.Message}");
                        _outbox.Enqueue(messageBody);
                    }
                }
                else
                {
                    // Wait before polling again
                    await Task.Delay(5000, stoppingToken);
                }
            }
        }
    }

    // Mock definitions
    public record Invoice(InvoiceHeader Header);
    public record InvoiceHeader(Guid InvoiceId, string VendorName, DateTime DueDate, decimal TotalAmount);
}
