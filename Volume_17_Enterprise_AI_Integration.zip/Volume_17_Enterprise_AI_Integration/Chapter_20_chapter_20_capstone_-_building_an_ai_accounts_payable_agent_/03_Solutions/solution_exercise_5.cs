
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.CircuitBreaker;

namespace AP_Agent_Solutions.Exercise5
{
    // 1. Circuit Breaker Implementation
    // We define resilience strategies using Polly
    public static class ResiliencePolicies
    {
        public static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
        {
            return Policy<HttpResponseMessage>
                .Handle<HttpRequestException>()
                .OrTransientHttpStatusCode()
                .CircuitBreakerAsync(
                    exceptionsAllowedBeforeBreaking: 5,
                    durationOfBreak: TimeSpan.FromSeconds(30),
                    onBreak: (ex, breakDelay) => 
                        Console.WriteLine($"[Circuit Breaker] Opening for {breakDelay.TotalSeconds}s due to {ex.Exception?.Message}"),
                    onReset: () => Console.WriteLine("[Circuit Breaker] Resetting"),
                    onHalfOpen: () => Console.WriteLine("[Circuit Breaker] Half-Open")
                );
        }
    }

    // 2. Saga Pattern Implementation
    public enum SagaState
    {
        NotStarted,
        InvoiceExtracted,
        LineItemsValidated,
        PaymentScheduled,
        Failed,
        Compensated
    }

    public class PaymentProcessingSaga
    {
        public Guid SagaId { get; } = Guid.NewGuid();
        public Guid InvoiceId { get; set; }
        public SagaState CurrentState { get; private set; } = SagaState.NotStarted;
        
        // Durable Store Mock (Persistent)
        private static readonly ConcurrentDictionary<Guid, PaymentProcessingSaga> _store = new();

        public async Task ExecuteAsync(Invoice invoice, IServiceProvider services)
        {
            try
            {
                // Transition 1: Extraction
                var extractor = services.GetRequiredService<IInvoiceExtractor>();
                // Simulate extraction...
                CurrentState = SagaState.InvoiceExtracted;
                await SaveStateAsync();

                // Transition 2: Validation
                var validator = services.GetRequiredService<IProcurementApiClient>();
                // Simulate validation...
                CurrentState = SagaState.LineItemsValidated;
                await SaveStateAsync();

                // Transition 3: Publishing (High Risk)
                var publisher = services.GetRequiredService<IErpPublisher>();
                // Simulate failure
                if (new Random().Next(0, 10) < 4) throw new HttpRequestException("ERP Connection Lost");
                
                CurrentState = SagaState.PaymentScheduled;
                await SaveStateAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Saga] Failure detected: {ex.Message}. Triggering Compensation.");
                await CompensateAsync();
            }
        }

        private async Task CompensateAsync()
        {
            // Compensating Actions
            // We cannot "un-extract", but we can log for manual intervention
            if (CurrentState >= SagaState.InvoiceExtracted)
            {
                Console.WriteLine($"[Compensation] Log manual intervention required for Invoice {InvoiceId}");
            }
            
            CurrentState = SagaState.Compensated;
            await SaveStateAsync();
        }

        private async Task SaveStateAsync()
        {
            // Simulate Database Write
            _store.AddOrUpdate(SagaId, this, (k, v) => this);
            await Task.Delay(10); // Simulate IO
        }

        // 5. Replay Mechanism Logic
        public static async Task RecoverStuckSagas(IServiceProvider services)
        {
            Console.WriteLine("[Recovery] Scanning for stuck sagas...");
            foreach (var saga in _store.Values.Where(s => s.CurrentState != SagaState.PaymentScheduled && s.CurrentState != SagaState.Compensated))
            {
                Console.WriteLine($"[Recovery] Resuming Saga {saga.SagaId} from state {saga.CurrentState}");
                // In a real app, we would reload the full entity and re-run the workflow
                // await saga.ExecuteAsync(...); 
            }
        }
    }

    // 3. & 4. End-to-End Test Harness & Observability
    public class PipelineOrchestrator
    {
        private readonly IInvoiceExtractor _extractor;
        private readonly IProcurementApiClient _procurementClient;
        private readonly IErpPublisher _erpPublisher;
        private readonly IAsyncPolicy<HttpResponseMessage> _circuitBreaker;

        public PipelineOrchestrator(
            IInvoiceExtractor extractor, 
            IProcurementApiClient procurementClient, 
            IErpPublisher erpPublisher)
        {
            _extractor = extractor;
            _procurementClient = procurementClient;
            _erpPublisher = erpPublisher;
            _circuitBreaker = ResiliencePolicies.GetCircuitBreakerPolicy();
        }

        public async Task RunFullPipeline(Invoice invoice)
        {
            // Observability: ActivitySource
            using var activity = ActivitySourceProvider.Source.StartActivity("FullPipeline");
            
            try
            {
                // Step 1: Extraction (Wrapped in Circuit Breaker logic simulation)
                // Note: Polly policies wrap execution delegates
                var extractedInvoice = await _extractor.ExtractAsync("path", "{}");
                activity?.AddEvent(new ActivityEvent("InvoiceExtracted"));

                // Step 2: Validation (External API Call)
                // Simulate wrapping the HTTP call with Circuit Breaker
                // In real code: await _circuitBreaker.ExecuteAsync(() => _procurementClient.CheckSkuAsync(...));
                activity?.AddEvent(new ActivityEvent("LineItemsValidated"));

                // Step 3: Saga Init
                var saga = new PaymentProcessingSaga { InvoiceId = extractedInvoice.Header.InvoiceId };
                await saga.ExecuteAsync(extractedInvoice, GetServiceProvider());

                activity?.AddEvent(new ActivityEvent("SagaCompleted"));
                Console.WriteLine($"[Pipeline] Completed Saga for Invoice {invoice.Header.InvoiceId}");
            }
            catch (BrokenCircuitException)
            {
                Console.WriteLine("[Pipeline] Circuit is Open. Failing fast.");
                activity?.SetStatus(ActivityStatusCode.Error, "Circuit Breaker Open");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Pipeline] Critical Error: {ex.Message}");
                activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            }
        }

        private IServiceProvider GetServiceProvider() 
        {
            // Helper to mock DI container for this exercise
            var services = new ServiceCollection();
            // Register services...
            return services.BuildServiceProvider();
        }
    }

    // Observability Helper
    public static class ActivitySourceProvider
    {
        public static readonly ActivitySource Source = new("AP.Agent.Pipeline", "1.0.0");
    }

    // Mock Models
    public record Invoice(InvoiceHeader Header);
    public record InvoiceHeader(Guid InvoiceId, string VendorName, DateTime DueDate, decimal TotalAmount);
    
    // Interfaces (reused from previous exercises)
    public interface IInvoiceExtractor { Task<Invoice> ExtractAsync(string path, string schema); }
    public interface IProcurementApiClient { }
    public interface IErpPublisher { }
}
