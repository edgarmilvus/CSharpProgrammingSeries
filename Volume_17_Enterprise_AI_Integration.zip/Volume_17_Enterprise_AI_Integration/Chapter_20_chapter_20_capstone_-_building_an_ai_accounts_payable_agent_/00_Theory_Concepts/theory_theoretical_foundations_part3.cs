
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

// Abstraction that decouples the AI agent from the specific validation logic.
public interface IProcurementValidator
{
    Task<ValidationResult> ValidateVendorAsync(string vendorName);
    Task<ValidationResult> ValidatePurchaseOrderAsync(string poNumber, decimal amount);
}

// Implementation for a legacy REST API.
public class RestProcurementValidator : IProcurementValidator
{
    private readonly HttpClient _httpClient;

    public RestProcurementValidator(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<ValidationResult> ValidateVendorAsync(string vendorName)
    {
        // Calls internal API to check if vendor exists and is active.
        var response = await _httpClient.GetAsync($"api/vendors/{Uri.EscapeDataString(vendorName)}");
        return new ValidationResult(response.IsSuccessStatusCode, "Vendor not found");
    }

    // ... implementation for PO validation
}

public record ValidationResult(bool IsValid, string ErrorMessage);
