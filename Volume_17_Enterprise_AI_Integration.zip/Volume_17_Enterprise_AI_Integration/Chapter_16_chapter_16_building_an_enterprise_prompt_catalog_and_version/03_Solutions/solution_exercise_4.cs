
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;

// 1. Audit Event Model
public record AuditEvent(
    Guid EventId,
    string EventType,
    Guid EntityId,
    string UserId,
    DateTimeOffset Timestamp,
    string Payload,
    string? CorrelationId = null);

// 2. Storage Interface
public interface IAuditStore
{
    Task StoreAsync(AuditEvent auditEvent);
    Task<IEnumerable<AuditEvent>> GetEventsByEntityAsync(Guid entityId);
}

// In-Memory Store
public class InMemoryAuditStore : IAuditStore
{
    private readonly ConcurrentBag<AuditEvent> _events = new();
    public Task StoreAsync(AuditEvent auditEvent)
    {
        _events.Add(auditEvent);
        return Task.CompletedTask;
    }

    public Task<IEnumerable<AuditEvent>> GetEventsByEntityAsync(Guid entityId)
    {
        return Task.FromResult(_events.Where(e => e.EntityId == entityId).OrderBy(e => e.Timestamp));
    }
}

// 3. Decorator Pattern Implementation
public class AuditablePromptRepository : IPromptRepository
{
    private readonly IPromptRepository _innerRepository;
    private readonly IAuditStore _auditStore;
    private readonly ILogger<AuditablePromptRepository> _logger;
    private readonly IHttpContextAccessor _contextAccessor; // To get User/CorrelationId

    public AuditablePromptRepository(
        IPromptRepository innerRepository, 
        IAuditStore auditStore, 
        ILogger<AuditablePromptRepository> logger,
        IHttpContextAccessor contextAccessor)
    {
        _innerRepository = innerRepository;
        _auditStore = auditStore;
        _logger = logger;
        _contextAccessor = contextAccessor;
    }

    private string GetUserId() => _contextAccessor.HttpContext?.User.Identity?.Name ?? "System";
    private string? GetCorrelationId() => _contextAccessor.HttpContext?.TraceIdentifier;

    private async Task LogAudit(string eventType, Guid entityId, object? payload)
    {
        var auditEvent = new AuditEvent(
            Guid.NewGuid(),
            eventType,
            entityId,
            GetUserId(),
            DateTimeOffset.UtcNow,
            JsonSerializer.Serialize(payload),
            GetCorrelationId());

        // Structured Logging
        _logger.LogInformation("Audit Event: {EventType} on {EntityId} by {UserId}", 
            eventType, entityId, GetUserId());

        await _auditStore.StoreAsync(auditEvent);
    }

    public async Task AddVersionAsync(PromptVersion version)
    {
        await LogAudit("AddVersion", version.TemplateId, version);
        await _innerRepository.AddVersionAsync(version);
    }

    public async Task<IEnumerable<PromptVersion>> GetTemplateHistoryAsync(Guid templateId)
    {
        await LogAudit("ReadHistory", templateId, null);
        return await _innerRepository.GetTemplateHistoryAsync(templateId);
    }

    // Other methods (GetTemplateAsync, SaveChangesAsync) would follow the same pattern...
    public Task<PromptTemplateEntity?> GetTemplateAsync(Guid id, bool includeDeleted = false) 
        => _innerRepository.GetTemplateAsync(id, includeDeleted);
    
    public Task SaveChangesAsync() => _innerRepository.SaveChangesAsync();
    
    public Task<IEnumerable<PromptTemplateEntity>> GetInactiveTemplatesAsync(int daysInactive) 
        => _innerRepository.GetInactiveTemplatesAsync(daysInactive);
}

// 4. Replay Capability (State Reconstruction)
public class AuditReplayService
{
    private readonly IAuditStore _auditStore;

    public AuditReplayService(IAuditStore auditStore) => _auditStore = auditStore;

    public async Task<PromptVersion?> ReplayEvents(Guid templateId, DateTimeOffset targetTime)
    {
        var events = await _auditStore.GetEventsByEntityAsync(templateId);
        var relevantEvents = events.Where(e => e.Timestamp <= targetTime);

        PromptVersion? currentState = null;

        foreach (var evt in relevantEvents)
        {
            if (evt.EventType == "AddVersion")
            {
                // Deserialize payload back to domain object
                var version = JsonSerializer.Deserialize<PromptVersion>(evt.Payload);
                if (version != null) currentState = version;
            }
            // Handle other events (Updates, Deletes) if necessary
        }

        return currentState;
    }
}
