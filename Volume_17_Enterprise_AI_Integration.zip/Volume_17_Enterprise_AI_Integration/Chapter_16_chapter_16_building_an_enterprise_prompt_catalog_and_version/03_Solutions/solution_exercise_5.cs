
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System.Text.RegularExpressions;

// 1. Rendered Result Object
public class RenderedPrompt
{
    public string Content { get; set; } = string.Empty;
    public int TokenCount { get; set; }
    public PromptVersion Version { get; set; }
    public DateTimeOffset RenderedAt { get; set; }
}

// 2. Middleware Interface
public interface IRenderMiddleware
{
    Task<string> InvokeAsync(string prompt, Func<Task<string>> next);
}

// 3. Concrete Middlewares
public class TokenLimitMiddleware : IRenderMiddleware
{
    private readonly int _maxTokens;

    public TokenLimitMiddleware(int maxTokens) => _maxTokens = maxTokens;

    public async Task<string> InvokeAsync(string prompt, Func<Task<string>> next)
    {
        var estimatedTokens = prompt.Length / 4; // Rough estimate
        if (estimatedTokens > _maxTokens)
            throw new InvalidOperationException($"Prompt exceeds token limit: {estimatedTokens} > {_maxTokens}");
        
        return await next();
    }
}

public class ProfanityFilterMiddleware : IRenderMiddleware
{
    public async Task<string> InvokeAsync(string prompt, Func<Task<string>> next)
    {
        // Simple regex redaction
        var filteredPrompt = Regex.Replace(prompt, @"\b(badword|profanity)\b", "***", RegexOptions.IgnoreCase);
        return await next(); // In a real app, we'd pass 'filteredPrompt' down, but here we modify the string before passing to next
    }
}

public class PiiRedactionMiddleware : IRenderMiddleware
{
    public async Task<string> InvokeAsync(string prompt, Func<Task<string>> next)
    {
        // Redact Email addresses
        var redactedPrompt = Regex.Replace(prompt, @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", "[REDACTED_EMAIL]");
        return await next();
    }
}

public class LoggingMiddleware : IRenderMiddleware
{
    private readonly ILogger<LoggingMiddleware> _logger;

    public LoggingMiddleware(ILogger<LoggingMiddleware> logger) => _logger = logger;

    public async Task<string> InvokeAsync(string prompt, Func<Task<string>> next)
    {
        var sw = Stopwatch.StartNew();
        var result = await next();
        sw.Stop();
        _logger.LogInformation("Prompt processed in {ElapsedMs}ms", sw.ElapsedMilliseconds);
        return result;
    }
}

// 4. Rendering Engine with Middleware Pipeline
public class PromptRenderer
{
    private readonly IEnumerable<IRenderMiddleware> _middlewares;
    private readonly ILogger<PromptRenderer> _logger;

    public PromptRenderer(IEnumerable<IRenderMiddleware> middlewares, ILogger<PromptRenderer> logger)
    {
        _middlewares = middlewares;
        _logger = logger;
    }

    public async Task<RenderedPrompt> RenderAsync(PromptVersion version, Dictionary<string, string> variables)
    {
        // 1. Initial Substitution (Mustache-like)
        string prompt = version.Content; // In real app, get content from Template linked to version
        foreach (var variable in variables)
        {
            prompt = prompt.Replace($"{{{{{variable.Key}}}}}", variable.Value);
        }

        // 2. Build Middleware Chain
        Func<Task<string>> pipeline = () => Task.FromResult(prompt);
        
        // Reverse middlewares to execute in registration order (A -> B -> C -> Result -> B -> A)
        // Actually, standard pipeline is usually: Request -> M1 -> M2 -> Handler -> M2 -> M1 -> Response
        // For this exercise, we process the string forward.
        
        foreach (var middleware in _middlewares.Reverse())
        {
            var next = pipeline;
            pipeline = () => middleware.InvokeAsync(prompt, next);
        }

        string finalContent;
        try
        {
            finalContent = await pipeline();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Middleware pipeline failed");
            throw;
        }

        return new RenderedPrompt
        {
            Content = finalContent,
            TokenCount = finalContent.Length / 4,
            Version = version,
            RenderedAt = DateTimeOffset.UtcNow
        };
    }

    // 5. Integration Simulation
    public async Task<string> ExecutePrompt(RenderedPrompt renderedPrompt)
    {
        // Simulate LLM API Call
        _logger.LogInformation("Sending prompt to LLM with {TokenCount} tokens", renderedPrompt.TokenCount);
        await Task.Delay(200); // Network call
        
        // Return dummy response
        return "LLM Response: This is a generated answer based on your prompt.";
    }
}
