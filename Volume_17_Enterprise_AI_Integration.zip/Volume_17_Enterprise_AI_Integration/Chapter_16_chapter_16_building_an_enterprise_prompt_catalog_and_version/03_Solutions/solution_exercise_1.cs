
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

// Domain Models
public record ModelParameters(
    double Temperature = 0.7,
    int MaxTokens = 1000,
    double TopP = 1.0,
    double FrequencyPenalty = 0.0,
    double PresencePenalty = 0.0);

public record PromptTemplate(
    Guid Id,
    string Name,
    string Content,
    Dictionary<string, string> Metadata);

public record PromptVersion(
    Guid TemplateId,
    string Version,
    string CommitHash,
    DateTimeOffset CreatedAt,
    ModelParameters Parameters,
    Dictionary<string, string> Metadata,
    string? Branch = null);

// Custom Exceptions
public class VersioningException : Exception
{
    public VersioningException(string message) : base(message) { }
}

// Thread-Safe Catalog with Branching Support
public class PromptCatalog
{
    private readonly ConcurrentDictionary<string, PromptTemplate> _templates = new();
    private readonly ConcurrentDictionary<string, List<PromptVersion>> _versions = new();
    private readonly object _versionLock = new object();

    // Helper to generate commit hash
    private static string GenerateHash() => Guid.NewGuid().ToString()[..8];

    public PromptTemplate CreateTemplate(string name, string content, Dictionary<string, string>? metadata = null)
    {
        var template = new PromptTemplate(
            Guid.NewGuid(),
            name,
            content,
            metadata ?? new Dictionary<string, string>());

        if (!_templates.TryAdd(name, template))
            throw new VersioningException($"Template '{name}' already exists.");

        var initialVersion = new PromptVersion(
            template.Id,
            "0.0.1",
            GenerateHash(),
            DateTimeOffset.UtcNow,
            new ModelParameters(),
            new Dictionary<string, string>(template.Metadata));

        _versions[name] = new List<PromptVersion> { initialVersion };
        return template;
    }

    public PromptVersion UpdateTemplate(string name, string? newContent = null, ModelParameters? newParams = null)
    {
        lock (_versionLock)
        {
            if (!_templates.TryGetValue(name, out var template))
                throw new VersioningException($"Template '{name}' not found.");

            var currentVersion = _versions[name].OrderByDescending(v => v.CreatedAt).First();
            
            // Idempotency Check
            var contentToUpdate = newContent ?? template.Content;
            var paramsToUpdate = newParams ?? currentVersion.Parameters;
            
            if (contentToUpdate == template.Content && 
                JsonSerializer.Serialize(paramsToUpdate) == JsonSerializer.Serialize(currentVersion.Parameters))
            {
                return currentVersion; // No changes, return existing
            }

            // Update Template Content (Immutable update)
            var updatedTemplate = template with { Content = contentToUpdate };
            _templates[name] = updatedTemplate;

            // Bump Patch Version
            var versionParts = currentVersion.Version.Split('.');
            var patch = int.Parse(versionParts[2]) + 1;
            var newVersionStr = $"{versionParts[0]}.{versionParts[1]}.{patch}";

            var newVersion = new PromptVersion(
                updatedTemplate.Id,
                newVersionStr,
                GenerateHash(),
                DateTimeOffset.UtcNow,
                paramsToUpdate,
                new Dictionary<string, string>(updatedTemplate.Metadata));

            _versions[name].Add(newVersion);
            return newVersion;
        }
    }

    public PromptVersion? GetVersion(string name, string version)
    {
        if (!_versions.TryGetValue(name, out var history)) return null;
        return history.FirstOrDefault(v => v.Version == version);
    }

    public IEnumerable<PromptVersion> ListVersions(string name, string? branch = null)
    {
        if (!_versions.TryGetValue(name, out var history)) return Enumerable.Empty<PromptVersion>();
        
        var query = history.AsEnumerable().OrderByDescending(v => v.CreatedAt);
        return branch != null ? query.Where(v => v.Branch == branch) : query;
    }

    // --- Branching Logic ---

    public PromptVersion Branch(string templateName, string sourceVersion, string newBranchName)
    {
        lock (_versionLock)
        {
            if (!_versions.TryGetValue(templateName, out var history))
                throw new VersioningException($"Template '{templateName}' not found.");

            var source = history.FirstOrDefault(v => v.Version == sourceVersion)
                ?? throw new VersioningException($"Version '{sourceVersion}' not found.");

            // Increment Minor version for branches
            var versionParts = source.Version.Split('.');
            var minor = int.Parse(versionParts[1]) + 1;
            var newVersionStr = $"{versionParts[0]}.{minor}.0";

            var branchMetadata = new Dictionary<string, string>(source.Metadata)
            {
                ["BranchSource"] = sourceVersion,
                ["BranchName"] = newBranchName
            };

            var newVersion = new PromptVersion(
                source.TemplateId,
                newVersionStr,
                GenerateHash(),
                DateTimeOffset.UtcNow,
                source.Parameters,
                branchMetadata,
                Branch: newBranchName);

            _versions[templateName].Add(newVersion);
            return newVersion;
        }
    }

    public void Merge(string sourceBranch, string targetBranch, string templateName)
    {
        lock (_versionLock)
        {
            if (!_versions.TryGetValue(templateName, out var history))
                throw new VersioningException($"Template '{templateName}' not found.");

            // Get latest versions from both branches
            var sourceVersion = history.Where(v => v.Branch == sourceBranch).OrderByDescending(v => v.CreatedAt).FirstOrDefault();
            var targetVersion = history.Where(v => v.Branch == targetBranch || v.Branch == null).OrderByDescending(v => v.CreatedAt).FirstOrDefault();

            if (sourceVersion == null) throw new VersioningException($"Source branch '{sourceBranch}' not found.");
            if (targetVersion == null) throw new VersioningException($"Target branch '{targetBranch}' not found.");

            // Conflict Detection (Simple content comparison)
            var sourceTemplate = _templates[templateName]; // Note: In real app, templates might branch too. Keeping simple here.
            
            // In this simplified model, we merge by creating a new Main version based on Source
            // Real merge would require 3-way merge logic.
            if (sourceVersion.CommitHash == targetVersion.CommitHash) return; // Already synced

            // Promote source to target lineage
            var mergedVersion = new PromptVersion(
                sourceVersion.TemplateId,
                targetVersion.Version, // Keep target versioning logic or bump? Let's bump Patch for merge
                GenerateHash(),
                DateTimeOffset.UtcNow,
                sourceVersion.Parameters,
                sourceVersion.Metadata,
                Branch: null // Merged to main
            );
            
            // For this exercise, we simply add the merged version to history
            _versions[templateName].Add(mergedVersion);
        }
    }
}
