
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Text.RegularExpressions;

// 1. Enums and Results
public enum PromotionStatus { Pending, ValidationFailed, Approved, Deployed }

public class ValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
}

// Custom Exception
public class PromotionValidationException : Exception
{
    public List<string> Errors { get; }
    public PromotionValidationException(string message, List<string> errors) : base(message) => Errors = errors;
}

// 2. Strategy Interfaces
public interface IContentValidator { ValidationResult Validate(PromptVersion version); }
public interface ISyntaxValidator { ValidationResult Validate(PromptVersion template); }
public interface ICostValidator { ValidationResult Validate(PromptVersion version); }

// 3. Concrete Strategies
public class ForbiddenWordsValidator : IContentValidator
{
    private static readonly List<string> ForbiddenWords = new() { "SSN", "password", "credit_card" };

    public ValidationResult Validate(PromptVersion version)
    {
        var result = new ValidationResult { IsValid = true };
        // Assuming we have access to the template content via some lookup or passing it in. 
        // For this exercise, let's assume PromptVersion.Metadata contains a snippet or we pass Template separately.
        // Simulating check on metadata or content string.
        var content = JsonSerializer.Serialize(version.Metadata); // Checking metadata for demo
        
        foreach (var word in ForbiddenWords)
        {
            if (content.Contains(word, StringComparison.OrdinalIgnoreCase))
            {
                result.IsValid = false;
                result.Errors.Add($"Forbidden word detected: {word}");
            }
        }
        return result;
    }
}

public class MustacheSyntaxValidator : ISyntaxValidator
{
    public ValidationResult Validate(PromptVersion version)
    {
        var result = new ValidationResult { IsValid = true };
        // Simple regex to find unmatched {{ or }}
        // A real implementation would parse the structure.
        var content = "Mock content for syntax check"; // In real app, pass Template content
        if (Regex.IsMatch(content, @"\{\{[^}]+$") || Regex.IsMatch(content, @"^[^{]*\}\}"))
        {
            result.IsValid = false;
            result.Errors.Add("Unbalanced Mustache placeholders detected.");
        }
        return result;
    }
}

public class CostValidator : ICostValidator
{
    private readonly double _costThreshold;

    public CostValidator(double costThreshold) => _costThreshold = costThreshold;

    public ValidationResult Validate(PromptVersion version)
    {
        var result = new ValidationResult { IsValid = true };
        
        // Estimate tokens (approx 4 chars per token)
        int estimatedTokens = 250; // Mock value
        double cost = (estimatedTokens / 1000.0) * 0.05; // $0.05 per 1k tokens

        if (cost > _costThreshold)
        {
            result.IsValid = false;
            result.Errors.Add($"Estimated cost ${cost:F4} exceeds threshold ${_costThreshold}");
        }
        return result;
    }
}

// 4. Pipeline Service (Strategy Pattern)
public class PipelineService
{
    private readonly IEnumerable<IContentValidator> _contentValidators;
    private readonly IEnumerable<ISyntaxValidator> _syntaxValidators;
    private readonly IEnumerable<ICostValidator> _costValidators;

    public PipelineService(
        IEnumerable<IContentValidator> contentValidators,
        IEnumerable<ISyntaxValidator> syntaxValidators,
        IEnumerable<ICostValidator> costValidators)
    {
        _contentValidators = contentValidators;
        _syntaxValidators = syntaxValidators;
        _costValidators = costValidators;
    }

    public PromotionStatus RunValidation(PromptVersion version)
    {
        var errors = new List<string>();

        // Execute Strategies
        foreach (var validator in _contentValidators.Concat(_syntaxValidators.Cast<dynamic>()).Concat(_costValidators.Cast<dynamic>()))
        {
            var result = validator.Validate(version);
            if (!result.IsValid)
                errors.AddRange(result.Errors);
        }

        if (errors.Any())
            throw new PromotionValidationException("Validation Failed", errors);

        return PromotionStatus.Approved;
    }
}

// 5. Interactive Challenge: Async Delegate Pipeline
public class AsyncPipelineService
{
    public async Task<PromotionStatus> RunAsync(PromptVersion version, params Func<PromptVersion, Task<ValidationResult>>[] steps)
    {
        var errors = new List<string>();

        foreach (var step in steps)
        {
            var result = await step(version);
            if (!result.IsValid)
            {
                errors.AddRange(result.Errors);
                break; // Short-circuit
            }
        }

        if (errors.Any())
            throw new PromotionValidationException("Async Validation Failed", errors);

        return PromotionStatus.Approved;
    }

    // Simulated External Safety API Step
    public async Task<ValidationResult> ExternalSafetyCheck(PromptVersion version)
    {
        await Task.Delay(100); // Simulate network latency
        // Mock logic
        bool isSafe = true; 
        return new ValidationResult 
        { 
            IsValid = isSafe, 
            Errors = isSafe ? new() : new() { "External API flagged content as unsafe" } 
        };
    }
}
