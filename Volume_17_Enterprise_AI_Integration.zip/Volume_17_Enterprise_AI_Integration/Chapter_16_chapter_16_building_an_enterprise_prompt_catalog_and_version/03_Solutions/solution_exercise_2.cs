
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.Text.Json;

// 1. EF Core Entities
public class PromptTemplateEntity
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string MetadataJson { get; set; } = "{}"; // Serialized JSON
    
    // Soft Delete
    public bool IsDeleted { get; set; }
    public DateTimeOffset? DeletedAt { get; set; }
    
    // Navigation
    public List<PromptVersionEntity> Versions { get; set; } = new();
}

public class PromptVersionEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TemplateId { get; set; }
    public PromptTemplateEntity? Template { get; set; }
    public string Version { get; set; } = "0.0.1";
    public string CommitHash { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; }
    public string ParametersJson { get; set; } = "{}"; // Serialized ModelParameters
    public string MetadataJson { get; set; } = "{}";
}

// 2. DbContext
public class PromptCatalogDbContext : DbContext
{
    public DbSet<PromptTemplateEntity> PromptTemplates { get; set; }
    public DbSet<PromptVersionEntity> PromptVersions { get; set; }

    public PromptCatalogDbContext(DbContextOptions<PromptCatalogDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configure Relationships
        modelBuilder.Entity<PromptTemplateEntity>()
            .HasMany(t => t.Versions)
            .WithOne(v => v.Template)
            .HasForeignKey(v => v.TemplateId)
            .OnDelete(DeleteBehavior.Cascade);

        // Configure JSON Serialization using ValueConverter
        var jsonConverter = new ValueConverter<Dictionary<string, string>, string>(
            v => JsonSerializer.Serialize(v, (JsonSerializerOptions)null!),
            v => JsonSerializer.Deserialize<Dictionary<string, string>>(v, (JsonSerializerOptions)null!) ?? new Dictionary<string, string>());

        modelBuilder.Entity<PromptTemplateEntity>().Property(t => t.MetadataJson).HasConversion(jsonConverter);
        modelBuilder.Entity<PromptVersionEntity>().Property(v => v.ParametersJson).HasConversion(jsonConverter);
        modelBuilder.Entity<PromptVersionEntity>().Property(v => v.MetadataJson).HasConversion(jsonConverter);

        // Indexing Strategy
        modelBuilder.Entity<PromptTemplateEntity>()
            .HasIndex(t => t.Name)
            .IsUnique(); // Fast lookup by name

        modelBuilder.Entity<PromptVersionEntity>()
            .HasIndex(v => new { v.TemplateId, v.CreatedAt }); // Optimized for GetTemplateHistoryAsync sorting
    }
}

// 3. Repository Interface
public interface IPromptRepository
{
    Task<PromptTemplateEntity?> GetTemplateAsync(Guid id, bool includeDeleted = false);
    Task AddVersionAsync(PromptVersion version); // Accepts domain object
    Task<IEnumerable<PromptVersion>> GetTemplateHistoryAsync(Guid templateId);
    Task SaveChangesAsync();
    Task<IEnumerable<PromptTemplateEntity>> GetInactiveTemplatesAsync(int daysInactive);
}

// 4. Repository Implementation
public class EfPromptRepository : IPromptRepository
{
    private readonly PromptCatalogDbContext _context;

    public EfPromptRepository(PromptCatalogDbContext context)
    {
        _context = context;
    }

    public async Task<PromptTemplateEntity?> GetTemplateAsync(Guid id, bool includeDeleted = false)
    {
        var query = _context.PromptTemplates.AsQueryable();
        if (!includeDeleted) query = query.Where(t => !t.IsDeleted);
        return await query.FirstOrDefaultAsync(t => t.Id == id);
    }

    public async Task AddVersionAsync(PromptVersion version)
    {
        // Map Domain to Entity
        var entity = new PromptVersionEntity
        {
            TemplateId = version.TemplateId,
            Version = version.Version,
            CommitHash = version.CommitHash,
            CreatedAt = version.CreatedAt,
            ParametersJson = JsonSerializer.Serialize(version.Parameters),
            MetadataJson = JsonSerializer.Serialize(version.Metadata)
        };
        
        await _context.PromptVersions.AddAsync(entity);
    }

    public async Task<IEnumerable<PromptVersion>> GetTemplateHistoryAsync(Guid templateId)
    {
        var entities = await _context.PromptVersions
            .Where(v => v.TemplateId == templateId)
            .OrderByDescending(v => v.CreatedAt)
            .ToListAsync();

        // Map back to Domain (Simplified mapping)
        return entities.Select(e => new PromptVersion(
            e.TemplateId,
            e.Version,
            e.CommitHash,
            e.CreatedAt,
            JsonSerializer.Deserialize<ModelParameters>(e.ParametersJson) ?? new ModelParameters(),
            JsonSerializer.Deserialize<Dictionary<string, string>>(e.MetadataJson) ?? new Dictionary<string, string>()
        ));
    }

    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();

    // 6. Performance: LINQ query for inactive templates
    public async Task<IEnumerable<PromptTemplateEntity>> GetInactiveTemplatesAsync(int daysInactive)
    {
        var cutoffDate = DateTimeOffset.UtcNow.AddDays(-daysInactive);
        
        return await _context.PromptTemplates
            .Where(t => !t.IsDeleted)
            .Where(t => !t.Versions.Any(v => v.CreatedAt > cutoffDate)) // Subquery check
            .ToListAsync();
    }
}
