
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

using System.Collections.Generic;
using System.Collections.Immutable;

// Using 'record' for value-based equality and immutability.
// This ensures that once a prompt version is created, it cannot be altered,
// preserving the integrity of the audit trail.
public record PromptVersion(
    string VersionId, 
    string Template, 
    PromptMetadata Metadata, 
    ModelParameters Parameters
);

// A nested record for metadata, grouping related data.
public record PromptMetadata(
    string AuthorId, 
    System.DateTimeOffset CreatedAt, 
    string Description, 
    IImmutableList<string> Tags
);

// A record for model configuration parameters.
public record ModelParameters(
    double Temperature, 
    int MaxTokens, 
    string ModelName
);

// A dictionary-based approach for dynamic input variables is often used,
// but for strict type safety in enterprise apps, we might use a generic interface.
public interface IPromptInput
{
    // Marker interface for type-safe input validation
}
