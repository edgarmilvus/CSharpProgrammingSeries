
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

// 1. Define the Domain Model
// Represents a single entry in our Prompt Catalog.
public record class PromptEntry
{
    // 'required' ensures we never create a prompt without an identifier.
    public required string Id { get; init; }

    // Stores the actual template text. Uses 'init' so it can only be set during creation.
    public required string Template { get; init; }

    // Semantic versioning helps us track changes safely.
    public required string Version { get; init; }

    // Metadata for auditing and billing.
    public required string Author { get; init; }
}

// 2. Define the Versioned Catalog
// Simulates a database or a Git repository where prompts are stored and versioned.
public class PromptCatalog
{
    // We use a Dictionary to simulate a key-value store (like Redis or a NoSQL DB).
    // Key: Prompt ID, Value: A list of versions (history) of that prompt.
    private readonly Dictionary<string, List<PromptEntry>> _storage = new();

    // Adds a new prompt or a new version of an existing prompt.
    public void UpsertPrompt(PromptEntry entry)
    {
        if (!_storage.ContainsKey(entry.Id))
        {
            _storage[entry.Id] = new List<PromptEntry>();
        }

        // In a real system, we would check if the version number is incremented correctly.
        // For this example, we just append to the history.
        _storage[entry.Id].Add(entry);
        Console.WriteLine($"[Catalog] Stored: {entry.Id} v{entry.Version}");
    }

    // Retrieves the LATEST version of a prompt for runtime usage.
    public PromptEntry? GetLatestVersion(string id)
    {
        if (_storage.TryGetValue(id, out var versions) && versions.Any())
        {
            // Assuming versions are added in order, the last one is the latest.
            return versions.Last();
        }
        return null;
    }

    // Retrieves a specific historical version (Audit capability).
    public PromptEntry? GetSpecificVersion(string id, string version)
    {
        if (_storage.TryGetValue(id, out var versions))
        {
            return versions.FirstOrDefault(v => v.Version == version);
        }
        return null;
    }
}

// 3. The Application (Runtime)
// This represents the internal tool or service that consumes the prompts.
public class ReportingTool
{
    private readonly PromptCatalog _catalog;

    public ReportingTool(PromptCatalog catalog)
    {
        _catalog = catalog;
    }

    public void GenerateReport(string promptId, string customerData)
    {
        // Fetch the prompt dynamically at runtime.
        var promptEntry = _catalog.GetLatestVersion(promptId);

        if (promptEntry == null)
        {
            Console.WriteLine($"Error: Prompt '{promptId}' not found.");
            return;
        }

        // "Render" the template. In a real app, this would be a complex templating engine.
        // Here, we just replace a placeholder.
        string finalPrompt = promptEntry.Template.Replace("{{DATA}}", customerData);

        Console.WriteLine("\n--- Generating Report ---");
        Console.WriteLine($"Using Prompt Version: {promptEntry.Version} (Author: {promptEntry.Author})");
        Console.WriteLine($"Final Prompt: {finalPrompt}");
        Console.WriteLine("-------------------------\n");
    }
}

public class Program
{
    public static void Main()
    {
        // Initialize the catalog (simulating our database)
        var catalog = new PromptCatalog();

        // SCENARIO 1: Initial Development
        // Developer creates the first version of the prompt.
        Console.WriteLine(">>> PHASE 1: Initial Development");
        catalog.UpsertPrompt(new PromptEntry
        {
            Id = "weekly_feedback_summary",
            Version = "1.0.0",
            Author = "Dev_Alice",
            Template = "Summarize the following customer feedback into a list of issues: {{DATA}}"
        });

        // The reporting tool runs using the current prompt.
        var tool = new ReportingTool(catalog);
        tool.GenerateReport("weekly_feedback_summary", "User 1: Login broken. User 2: Slow app.");

        // SCENARIO 2: The Business Requirement Change
        // Marketing wants to focus on "positive sentiment" instead of "issues".
        // No code change in the ReportingTool is needed!
        Console.WriteLine("\n>>> PHASE 2: Business Update (No Redeploy)");
        catalog.UpsertPrompt(new PromptEntry
        {
            Id = "weekly_feedback_summary",
            Version = "1.1.0", // Incremented version
            Author = "Analyst_Bob",
            Template = "Analyze sentiment. Highlight positive feedback: {{DATA}}" // Changed text
        });

        // The tool automatically picks up the new version.
        tool.GenerateReport("weekly_feedback_summary", "User 1: Loved the new UI. User 2: Fast app.");

        // SCENARIO 3: Audit / Rollback
        // We realize v1.1.0 was too vague. We need to see what v1.0.0 looked like to revert.
        Console.WriteLine("\n>>> PHASE 3: Audit / Rollback Check");
        var oldVersion = catalog.GetSpecificVersion("weekly_feedback_summary", "1.0.0");
        if (oldVersion != null)
        {
            Console.WriteLine($"[Audit] Retrieved Old Version: {oldVersion.Template}");
        }
    }
}
