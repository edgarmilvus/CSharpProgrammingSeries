
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EnterpriseAI.SemanticKernel.PluginArchitecture
{
    /// <summary>
    /// Represents the status of a financial transaction.
    /// </summary>
    public enum TransactionStatus
    {
        Pending,
        Approved,
        Rejected,
        Error
    }

    /// <summary>
    /// Represents a legacy financial transaction record.
    /// This mimics a data structure returned by a legacy mainframe API.
    /// </summary>
    public class LegacyTransaction
    {
        public string TransactionId { get; set; }
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string OriginAccount { get; set; }
        public string DestinationAccount { get; set; }
        public TransactionStatus Status { get; set; }
        public string Timestamp { get; set; }

        public LegacyTransaction(string id, decimal amt, string cur, string orig, string dest, TransactionStatus stat, string time)
        {
            TransactionId = id;
            Amount = amt;
            Currency = cur;
            OriginAccount = orig;
            DestinationAccount = dest;
            Status = stat;
            Timestamp = time;
        }
    }

    /// <summary>
    /// Simulates a connection to a legacy banking system (e.g., IBM Mainframe via COBOL copybook).
    /// In a real scenario, this would use TCP sockets, MQ Series, or an ODBC driver.
    /// </summary>
    public class LegacyBankingSystemAdapter
    {
        // Internal in-memory store to simulate a database
        private List<LegacyTransaction> _transactionStore;

        public LegacyBankingSystemAdapter()
        {
            _transactionStore = new List<LegacyTransaction>();
            // Seed with dummy data to simulate existing legacy records
            _transactionStore.Add(new LegacyTransaction("TXN-1001", 500.00m, "USD", "ACCT-A", "ACCT-B", TransactionStatus.Approved, "2023-10-01T09:00:00Z"));
            _transactionStore.Add(new LegacyTransaction("TXN-1002", 1200.50m, "USD", "ACCT-C", "ACCT-D", TransactionStatus.Pending, "2023-10-01T10:15:00Z"));
            _transactionStore.Add(new LegacyTransaction("TXN-1003", 99.99m, "USD", "ACCT-E", "ACCT-F", TransactionStatus.Rejected, "2023-10-01T11:30:00Z"));
        }

        /// <summary>
        /// Simulates a legacy API call to retrieve transaction details.
        /// </summary>
        public LegacyTransaction GetTransactionById(string transactionId)
        {
            foreach (LegacyTransaction txn in _transactionStore)
            {
                if (txn.TransactionId == transactionId)
                {
                    return txn;
                }
            }
            return null;
        }

        /// <summary>
        /// Simulates a legacy API call to update a transaction status.
        /// </summary>
        public bool UpdateTransactionStatus(string transactionId, TransactionStatus newStatus)
        {
            for (int i = 0; i < _transactionStore.Count; i++)
            {
                if (_transactionStore[i].TransactionId == transactionId)
                {
                    // Create a new instance to simulate immutability or proper update logic
                    var updatedTxn = new LegacyTransaction(
                        _transactionStore[i].TransactionId,
                        _transactionStore[i].Amount,
                        _transactionStore[i].Currency,
                        _transactionStore[i].OriginAccount,
                        _transactionStore[i].DestinationAccount,
                        newStatus,
                        DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ")
                    );
                    _transactionStore[i] = updatedTxn;
                    return true;
                }
            }
            return false;
        }
    }

    /// <summary>
    /// The Plugin Context Manager handles the lifecycle of a plugin execution.
    /// It ensures that the legacy system connection is managed securely and that
    /// execution state (like transaction locks or audit logs) is maintained.
    /// </summary>
    public class PluginContextManager
    {
        private LegacyBankingSystemAdapter _adapter;
        private List<string> _auditLog;

        public PluginContextManager(LegacyBankingSystemAdapter adapter)
        {
            _adapter = adapter;
            _auditLog = new List<string>();
        }

        /// <summary>
        /// Initializes the context (e.g., authentication, connection pooling).
        /// </summary>
        public void InitializeContext(string userToken)
        {
            // Simulate authentication against legacy system
            if (string.IsNullOrEmpty(userToken))
            {
                throw new UnauthorizedAccessException("Invalid user token provided to legacy system.");
            }
            LogAudit($"Context initialized for user token: {userToken}");
        }

        /// <summary>
        /// Logs an action to the audit trail.
        /// </summary>
        public void LogAudit(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            _auditLog.Add($"[{timestamp}] {message}");
        }

        /// <summary>
        /// Retrieves the legacy adapter instance.
        /// </summary>
        public LegacyBankingSystemAdapter GetAdapter()
        {
            return _adapter;
        }

        /// <summary>
        /// Prints the audit trail.
        /// </summary>
        public void PrintAuditTrail()
        {
            Console.WriteLine("\n--- Audit Trail ---");
            foreach (string log in _auditLog)
            {
                Console.WriteLine(log);
            }
            Console.WriteLine("-------------------\n");
        }
    }

    /// <summary>
    /// Represents a single executable unit within the Semantic Kernel Plugin Architecture.
    /// This encapsulates the logic required to bridge the LLM's intent with the legacy system.
    /// </summary>
    public class TransactionPlugin
    {
        private PluginContextManager _contextManager;

        public TransactionPlugin(PluginContextManager contextManager)
        {
            _contextManager = contextManager;
        }

        /// <summary>
        /// Function: Get Transaction Details.
        /// This function is intended to be called by the Semantic Kernel Orchestrator.
        /// </summary>
        [KernelFunction("GetTransactionDetails")]
        public string GetTransactionDetails(string transactionId)
        {
            _contextManager.LogAudit($"Executing GetTransactionDetails for ID: {transactionId}");

            if (string.IsNullOrEmpty(transactionId))
            {
                _contextManager.LogAudit("Error: Transaction ID is empty.");
                return "Error: Transaction ID is empty.";
            }

            var adapter = _contextManager.GetAdapter();
            var transaction = adapter.GetTransactionById(transactionId);

            if (transaction == null)
            {
                _contextManager.LogAudit($"Transaction {transactionId} not found.");
                return $"Transaction {transactionId} not found in legacy system.";
            }

            // Format the output for the LLM (Natural Language)
            string result = $"Transaction ID: {transaction.TransactionId}\n" +
                            $"Amount: {transaction.Amount} {transaction.Currency}\n" +
                            $"From: {transaction.OriginAccount} To: {transaction.DestinationAccount}\n" +
                            $"Status: {transaction.Status}\n" +
                            $"Timestamp: {transaction.Timestamp}";
            
            return result;
        }

        /// <summary>
        /// Function: Update Transaction Status.
        /// This function performs a state change in the legacy system.
        /// </summary>
        [KernelFunction("UpdateTransactionStatus")]
        public string UpdateTransactionStatus(string transactionId, string status)
        {
            _contextManager.LogAudit($"Executing UpdateTransactionStatus for ID: {transactionId} to Status: {status}");

            if (string.IsNullOrEmpty(transactionId) || string.IsNullOrEmpty(status))
            {
                return "Error: Missing transaction ID or status.";
            }

            // Parse the status string to the Enum
            TransactionStatus newStatus;
            try
            {
                newStatus = (TransactionStatus)Enum.Parse(typeof(TransactionStatus), status, true);
            }
            catch
            {
                return $"Error: Invalid status '{status}'. Valid options are: Pending, Approved, Rejected.";
            }

            var adapter = _contextManager.GetAdapter();
            bool success = adapter.UpdateTransactionStatus(transactionId, newStatus);

            if (success)
            {
                _contextManager.LogAudit($"Successfully updated {transactionId} to {newStatus}.");
                return $"Transaction {transactionId} updated to {newStatus}.";
            }
            else
            {
                _contextManager.LogAudit($"Failed to update {transactionId}. Record not found.");
                return $"Error: Transaction {transactionId} not found.";
            }
        }
    }

    /// <summary>
    /// The Orchestrator simulates the Semantic Kernel's core logic.
    /// It receives a user request, determines which plugin function to call,
    /// and manages the data flow between the user, the plugin, and the legacy system.
    /// </summary>
    public class KernelOrchestrator
    {
        private TransactionPlugin _plugin;

        public KernelOrchestrator(TransactionPlugin plugin)
        {
            _plugin = plugin;
        }

        /// <summary>
        /// Processes a natural language request by mapping it to a specific plugin function.
        /// </summary>
        public async Task<string> ProcessRequest(string userRequest)
        {
            Console.WriteLine($"\n[Orchestrator] Received Request: \"{userRequest}\"");

            // Simulate basic intent recognition (in reality, this would be done by the LLM)
            if (userRequest.StartsWith("Get details for"))
            {
                // Extract ID (Simple parsing for demo purposes)
                string[] parts = userRequest.Split(' ');
                string id = parts[parts.Length - 1];
                
                // Call the plugin function
                return _plugin.GetTransactionDetails(id);
            }
            else if (userRequest.StartsWith("Update status"))
            {
                // Extract ID and Status (Simple parsing for demo purposes)
                // Format: "Update status for TXN-1002 to Approved"
                string[] parts = userRequest.Split(' ');
                string id = parts[3];
                string status = parts[5];

                // Call the plugin function
                return _plugin.UpdateTransactionStatus(id, status);
            }

            return "I could not determine the intent of the request. Please ask to 'Get details for [ID]' or 'Update status for [ID] to [Status]'.";
        }
    }

    /// <summary>
    /// Main Application Entry Point.
    /// </summary>
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== Enterprise AI Integration: Semantic Kernel Plugin Architecture Demo ===\n");

            // 1. Initialize the Legacy System Adapter (The "External World")
            var legacySystem = new LegacyBankingSystemAdapter();

            // 2. Initialize the Context Manager (Security & Lifecycle)
            var contextManager = new PluginContextManager(legacySystem);
            
            // Simulate Authentication
            try 
            {
                contextManager.InitializeContext("USER_TOKEN_XYZ_123");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Critical Security Error: {ex.Message}");
                return;
            }

            // 3. Initialize the Plugin (The Bridge)
            var transactionPlugin = new TransactionPlugin(contextManager);

            // 4. Initialize the Orchestrator (The Brain)
            var orchestrator = new KernelOrchestrator(transactionPlugin);

            // --- Simulation of Real-World Workflow ---

            // Scenario A: Retrieving data from legacy system
            string request1 = "Get details for TXN-1002";
            string response1 = await orchestrator.ProcessRequest(request1);
            Console.WriteLine($"\n[Response]:\n{response1}");

            // Scenario B: Modifying state in legacy system
            string request2 = "Update status for TXN-1002 to Approved";
            string response2 = await orchestrator.ProcessRequest(request2);
            Console.WriteLine($"\n[Response]:\n{response2}");

            // Scenario C: Verifying the change
            string request3 = "Get details for TXN-1002";
            string response3 = await orchestrator.ProcessRequest(request3);
            Console.WriteLine($"\n[Response]:\n{response3}");

            // Scenario D: Error handling (Invalid ID)
            string request4 = "Get details for TXN-9999";
            string response4 = await orchestrator.ProcessRequest(request4);
            Console.WriteLine($"\n[Response]:\n{response4}");

            // 5. Final Audit Review
            contextManager.PrintAuditTrail();
        }
    }

    // Attribute definition for demonstration purposes
    [AttributeUsage(AttributeTargets.Method)]
    public class KernelFunctionAttribute : Attribute
    {
        public string Name { get; }
        public KernelFunctionAttribute(string name)
        {
            Name = name;
        }
    }
}
