
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using System.ComponentModel;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

// 1. LEGACY SYSTEM MOCKS
// In a real enterprise, these would be HTTP clients or database connectors.
// We mock them here to represent "Black Box" legacy APIs.
public static class LegacyCrmSystem
{
    // Simulates a legacy CRM lookup. Returns a JSON string because the legacy system 
    // doesn't share C# models with our new app.
    public static string GetCustomerByName(string name)
    {
        // Simulating a database hit
        if (name.Equals("John Doe", StringComparison.OrdinalIgnoreCase))
        {
            return JsonSerializer.Serialize(new { id = 101, name = "John Doe", tier = "Gold" });
        }
        return "{}";
    }
}

public static class LegacyLogisticsSystem
{
    // Simulates a logistics API. Expects a primitive ID, returns a complex status object.
    public static OrderStatus GetOrderStatus(int customerId)
    {
        if (customerId == 101)
        {
            return new OrderStatus { IsShipped = true, TrackingNumber = "TRK-998877" };
        }
        return new OrderStatus { IsShipped = false };
    }
}

public class OrderStatus
{
    public bool IsShipped { get; set; }
    public string? TrackingNumber { get; set; }
}

// 2. THE PLUGIN
// This class acts as the bridge between the Semantic Kernel and the legacy systems.
public class SupportAgentPlugin
{
    // The [KernelFunction] attribute marks this method as callable by the LLM.
    // The [Description] helps the LLM understand WHEN to use this function.
    [KernelFunction, Description("Retrieves the shipping status for a specific customer by their full name.")]
    public async Task<string> GetCustomerShippingStatusAsync(
        [Description("The full name of the customer")] string customerName)
    {
        // Step A: Call Legacy System 1 (CRM)
        // We parse the string result into a usable object.
        string crmJson = LegacyCrmSystem.GetCustomerByName(customerName);
        
        if (string.IsNullOrEmpty(crmJson) || crmJson == "{}")
        {
            return "Customer not found.";
        }

        using JsonDocument doc = JsonDocument.Parse(crmJson);
        int customerId = doc.RootElement.GetProperty("id").GetInt32();

        // Step B: Call Legacy System 2 (Logistics)
        // We use the ID from System 1 to query System 2.
        // Note: We are orchestrating two different contexts here.
        OrderStatus status = LegacyLogisticsSystem.GetOrderStatus(customerId);

        // Step C: Format Output
        // The result must be a string for the LLM to consume naturally.
        return status.IsShipped 
            ? $"Shipped! Tracking #: {status.TrackingNumber}" 
            : "Order is currently being processed.";
    }
}

// 3. ORCHESTRATION (The Main Application)
public class Program
{
    public static async Task Main(string[] args)
    {
        // Setup: Initialize the Kernel. 
        // NOTE: In a real app, you would use builder.Services.AddAzureOpenAIChatCompletion...
        // For this standalone example, we will simulate the Kernel execution locally 
        // to avoid requiring external API keys, but the logic remains identical.
        
        var plugin = new SupportAgentPlugin();
        
        // Simulate the LLM deciding to call our plugin based on user input
        Console.WriteLine("User Request: \"Hey, what's the shipping status for John Doe?\"\n");
        
        // The Semantic Kernel automatically handles the mapping of arguments 
        // from the natural language request to the method parameters.
        string result = await plugin.GetCustomerShippingStatusAsync("John Doe");
        
        Console.WriteLine($"[Plugin Executed]: {result}");
    }
}
