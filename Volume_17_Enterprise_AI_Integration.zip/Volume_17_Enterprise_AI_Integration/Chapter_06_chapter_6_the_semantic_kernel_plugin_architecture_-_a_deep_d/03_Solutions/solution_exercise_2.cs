
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Plugins.OpenApi;

// 1. Custom Delegating Handler for Auth and Correlation
public class CorrelationHeaderHandler : DelegatingHandler
{
    private string _bearerToken;
    private int _requestCount = 0;

    public CorrelationHeaderHandler(string initialToken)
    {
        _bearerToken = initialToken;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        // 2. Inject Correlation ID
        var correlationId = Guid.NewGuid().ToString();
        request.Headers.Remove("X-Internal-Correlation-ID");
        request.Headers.Add("X-Internal-Correlation-ID", correlationId);

        // 3. Inject Authorization
        ApplyAuthHeader(request);

        // 4. Simulate Token Expiration Logic (Interactive Challenge)
        _requestCount++;
        if (_requestCount > 3)
        {
            // Simulate expired token
            _bearerToken = "EXPIRED_TOKEN";
        }

        var response = await base.SendAsync(request, cancellationToken);

        // 5. Token Refresh Mechanism (Interactive Challenge)
        if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
        {
            // Attempt refresh
            var newToken = await RefreshTokenAsync();
            if (!string.IsNullOrEmpty(newToken))
            {
                _bearerToken = newToken;
                
                // Clone request to retry
                var retryRequest = await CloneRequest(request);
                ApplyAuthHeader(retryRequest); // Re-apply new token
                
                // Retry once
                return await base.SendAsync(retryRequest, cancellationToken);
            }
        }

        return response;
    }

    private void ApplyAuthHeader(HttpRequestMessage request)
    {
        if (request.Headers.Authorization == null)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _bearerToken);
        }
    }

    private async Task<string> RefreshTokenAsync()
    {
        // Mock token refresh call
        await Task.Delay(100); 
        return "NEW_ACCESS_TOKEN_" + Guid.NewGuid().ToString().Substring(0, 8);
    }

    private async Task<HttpRequestMessage> CloneRequest(HttpRequestMessage request)
    {
        var clone = new HttpRequestMessage(request.Method, request.RequestUri);
        
        // Copy content
        if (request.Content != null)
        {
            var content = await request.Content.ReadAsStringAsync();
            clone.Content = new StringContent(content, System.Text.Encoding.UTF8, request.Content.Headers.ContentType?.MediaType);
        }

        // Copy headers
        foreach (var header in request.Headers)
        {
            clone.Headers.TryAddWithoutValidation(header.Key, header.Value);
        }

        return clone;
    }
}

// 6. Resilience Strategy (Comments only as per requirements)
/*
To handle 429 (Too Many Requests), we would integrate Polly.
Strategy:
1. Define a WaitAndRetry policy: e.g., retry 3 times with exponential backoff 
   (wait 2s, 4s, 8s).
2. Wrap the HTTP client execution in this policy.
Code Sketch:
var retryPolicy = Policy<HttpResponseMessage>
    .HandleResult(r => r.StatusCode == HttpStatusCode.TooManyRequests)
    .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

await retryPolicy.ExecuteAsync(() => base.SendAsync(request, cancellationToken));
*/

// Integration Example
public class LeaveApiIntegration
{
    public static async Task ConfigurePluginAsync()
    {
        var kernel = Kernel.CreateBuilder()
            .AddOpenAIChatCompletion("gpt-4", "key")
            .Build();

        var handler = new CorrelationHeaderHandler("INITIAL_TOKEN");
        var httpClient = new HttpClient(handler);
        
        // In a real scenario, you would load leave-api.yaml
        // var plugin = await kernel.ImportPluginFromOpenApiAsync("LeavePlugin", new Uri("http://localhost/leave-api.yaml"), 
        //    new OpenApiFunctionExecutionParameters { HttpClient = httpClient });
    }
}
