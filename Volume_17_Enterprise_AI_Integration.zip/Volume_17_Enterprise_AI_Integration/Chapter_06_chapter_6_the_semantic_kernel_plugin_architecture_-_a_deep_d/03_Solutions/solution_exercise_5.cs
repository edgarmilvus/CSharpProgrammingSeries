
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.SemanticKernel;
using Polly;
using Polly.Retry;

// 1. Existing Core Logic (Unchanged)
public class FinancialTransactionPlugin
{
    private readonly BankingClient _client;

    public FinancialTransactionPlugin(BankingClient client)
    {
        _client = client;
    }

    [KernelFunction("ProcessPayment")]
    public async Task<PaymentResult> ProcessPayment(string transactionId, decimal amount)
    {
        // Pure business logic
        return await _client.SendPayment(transactionId, amount);
    }
}

// Mocks for dependencies
public class BankingClient {
    public async Task<PaymentResult> SendPayment(string id, decimal amt) {
        await Task.Delay(100); 
        return new PaymentResult { Status = "Success", TransactionId = id };
    }
}
public class PaymentResult { public string Status { get; set; } public string TransactionId { get; set; } }

// 2. The Decorator / Wrapper (ResilientPluginWrapper)
public class ResilientPluginWrapper<T> where T : class
{
    private readonly T _innerPlugin;
    private readonly IMemoryCache _cache;
    private readonly AsyncRetryPolicy _retryPolicy;

    public ResilientPluginWrapper(T innerPlugin, IMemoryCache cache)
    {
        _innerPlugin = innerPlugin;
        _cache = cache;
        
        // 3. Resilience Strategy (Polly)
        _retryPolicy = Policy
            .Handle<HttpRequestException>()
            .OrResult<PaymentResult>(r => r.Status == "Failed") // Simulating 5xx or failure
            .WaitAndRetryAsync(2, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    Console.WriteLine($"Retry {retryCount} after {timespan.TotalSeconds}s due to: {outcome.Exception?.Message ?? outcome.Result.Status}");
                });
    }

    // Dynamic Proxy-like method to intercept calls
    public async Task<PaymentResult> ProcessPayment(string transactionId, decimal amount)
    {
        // 4. Idempotency Check
        if (_cache.TryGetValue(transactionId, out PaymentResult? cachedResult))
        {
            Console.WriteLine($"Returning cached result for {transactionId}");
            return cachedResult!;
        }

        // Context Logging
        Console.WriteLine($"[Context] Executing ProcessPayment. TxId: {transactionId}, Amt: {amount}");

        // Execute with Resilience
        var result = await _retryPolicy.ExecuteAsync(async () => 
        {
            // We assume the inner method is the one we want to protect
            // Since we cannot easily intercept method calls without AOP libraries,
            // we cast the inner object to dynamic or known interface if available.
            // Here we assume T is FinancialTransactionPlugin and we know the method signature.
            
            if (_innerPlugin is FinancialTransactionPlugin plugin)
            {
                return await plugin.ProcessPayment(transactionId, amount);
            }
            throw new InvalidOperationException("Plugin type mismatch.");
        });

        // Cache successful result
        if (result.Status == "Success")
        {
            _cache.Set(transactionId, result, TimeSpan.FromMinutes(10));
        }

        return result;
    }
}

// 5. Integration / Usage
public class PaymentDemo
{
    public static async Task Run()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var bankingClient = new BankingClient();
        
        // Create the core plugin
        var corePlugin = new FinancialTransactionPlugin(bankingClient);
        
        // Wrap it
        var resilientWrapper = new ResilientPluginWrapper<FinancialTransactionPlugin>(corePlugin, cache);

        // In a real kernel setup, you would likely register the wrapper as a plugin 
        // or use the wrapper in a custom function invocation.
        // For this exercise, we demonstrate the wrapper directly:
        
        string txId = Guid.NewGuid().ToString();
        
        // First call (goes through)
        var r1 = await resilientWrapper.ProcessPayment(txId, 100.0m);
        Console.WriteLine($"Result 1: {r1.Status}");

        // Second call with same ID (Cached)
        var r2 = await resilientWrapper.ProcessPayment(txId, 100.0m);
        Console.WriteLine($"Result 2: {r2.Status}");
    }
}
