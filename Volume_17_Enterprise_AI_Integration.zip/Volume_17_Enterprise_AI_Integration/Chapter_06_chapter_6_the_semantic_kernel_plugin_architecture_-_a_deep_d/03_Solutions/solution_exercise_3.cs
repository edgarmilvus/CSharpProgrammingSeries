
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.ComponentModel;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;

// 1. Mock Plugins
public class AccountPlugin
{
    [KernelFunction("Provision")]
    [Description("Creates a user account.")]
    public bool Provision([Description("Email address")] string email)
    {
        // Simulate logic
        Console.WriteLine($"Provisioning account for {email}...");
        return !string.IsNullOrEmpty(email) && email.Contains("@");
    }
}

public class HardwarePlugin
{
    [KernelFunction("Assign")]
    [Description("Assigns hardware to a user.")]
    public string Assign([Description("User ID")] string userId)
    {
        Console.WriteLine($"Assigning laptop to user {userId}...");
        return $"Laptop-{Guid.NewGuid().ToString().Substring(0, 4)}";
    }
}

public class EmailPlugin
{
    [KernelFunction("Send")]
    [Description("Sends a welcome email.")]
    public bool Send([Description("Recipient")] string email, [Description("Hardware ID")] string hardwareId)
    {
        Console.WriteLine($"Sending email to {email} with hardware {hardwareId}...");
        return true;
    }
}

// 2. State Management
public record OnboardingState(string UserEmail, bool IsAccountCreated, string? UserId = null, string? HardwareId = null);

// 3. Explicit Orchestration Logic
public class OnboardingWorkflow
{
    public async Task RunOnboardingWorkflow(Kernel kernel, string userEmail)
    {
        var state = new OnboardingState(userEmail, IsAccountCreated: false);
        
        // Step 1: Provision Account
        var accountResult = await kernel.InvokeAsync<bool>("AccountPlugin", "Provision", new KernelArguments { ["email"] = userEmail });
        state = state with { IsAccountCreated = accountResult };

        // Step 2: Conditional Hardware Assignment
        if (state.IsAccountCreated)
        {
            // Assume UserId is returned or generated here
            state = state with { UserId = $"USER-{userEmail.GetHashCode()}" };
            
            var hardwareResult = await kernel.InvokeAsync<string>("HardwarePlugin", "Assign", new KernelArguments { ["userId"] = state.UserId! });
            state = state with { HardwareId = hardwareResult };
        }
        else
        {
            Console.WriteLine("Warning: Account creation failed. Skipping hardware assignment.");
        }

        // Step 3: Send Email (Conditional on Account Existence)
        if (state.IsAccountCreated)
        {
            await kernel.InvokeAsync("EmailPlugin", "Send", new KernelArguments 
            { 
                ["email"] = state.UserEmail, 
                ["hardwareId"] = state.HardwareId ?? "Standard" 
            });
        }
    }
}

// 4. Planner Approach (Conceptual Comparison)
/*
To use a Planner (e.g., FunctionCallingStepwisePlanner), you would not write the if-statements manually.
Instead, you provide a goal:

Goal: "Provision an account for {email}. If successful, assign hardware. Finally, send a welcome email containing the hardware details."

The Planner would:
1. Analyze available functions (Provision, Assign, Send).
2. Generate a plan: Call Provision -> Check Result -> Call Assign -> Call Send.
3. Execute the plan.

Comparison (Instructor's Analysis Section below).
*/
