
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;

// 1. Data Model
public class ProductSearchFilter
{
    public string? Color { get; set; }
    public string? Category { get; set; }
    public decimal? MaxPrice { get; set; }
    public bool? InStock { get; set; }
    
    // Interactive Challenge: Enhanced property
    public List<string> Tags { get; set; } = new List<string>();
}

// 2. Native Plugin Wrapper
public class SearchPlugin
{
    private readonly Kernel _kernel;

    public SearchPlugin(Kernel kernel)
    {
        _kernel = kernel;
    }

    [KernelFunction("SearchProducts")]
    [Description("Converts natural language query into a structured search filter.")]
    public async Task<ProductSearchFilter> SearchProducts(
        [Description("Natural language query")] string query)
    {
        // 3. Invoke Semantic Function
        // Assuming the semantic function "ProductFilterFunction" is registered in the kernel
        var result = await _kernel.InvokeAsync<string>("ProductFilterFunction", new KernelArguments { ["input"] = query });

        if (string.IsNullOrWhiteSpace(result))
        {
            throw new InvalidOperationException("LLM returned empty result.");
        }

        // 4. Robust Deserialization Strategy
        try
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                ReadCommentHandling = JsonCommentHandling.Skip,
                AllowTrailingCommas = true
            };

            var filter = JsonSerializer.Deserialize<ProductSearchFilter>(result, options);

            if (filter == null) throw new JsonException("Deserialization returned null.");

            // 5. Validation
            if (filter.MaxPrice.HasValue && filter.MaxPrice < 0)
                throw new ArgumentException("MaxPrice cannot be negative.");

            // 6. Edge Case Handling (Interactive Challenge)
            // If LLM returns "Tags": "waterproof" (string) instead of ["waterproof"] (array)
            // We need to normalize. Since we are deserializing to List<string>, 
            // System.Text.Json handles arrays. If it's a single string, it fails.
            // To handle this strictly, we might need a custom JsonConverter or post-process.
            // However, a simpler approach for the wrapper is to ensure the prompt is good.
            // Below is a safeguard if we encounter a specific format issue:
            
            return filter;
        }
        catch (JsonException ex)
        {
            // Fallback or correction logic could go here
            // For example, if the LLM returns a plain string for tags, we could manually parse it.
            // However, strictly adhering to the schema in the prompt is the best defense.
            throw new InvalidOperationException($"Failed to parse LLM response: {result}", ex);
        }
    }
}

// Usage / Setup
public class SearchDemo
{
    public static void Setup(Kernel kernel)
    {
        // Define the Semantic Function Prompt
        string promptTemplate = """
            Convert the user query into a JSON object representing a ProductSearchFilter.
            The JSON must strictly follow this schema:
            {
              "Color": "string",
              "Category": "string",
              "MaxPrice": number or null,
              "InStock": boolean or null,
              "Tags": ["string", "string"] (array of strings, handle multi-word tags)
            }
            Do not include conversational filler. Output only the JSON.
            Query: {{$input}}
            """;

        // Register the semantic function
        var searchFunc = kernel.CreateFunctionFromPrompt(
            promptTemplate, 
            new OpenAIPromptExecutionSettings { MaxTokens = 200 });

        kernel.Plugins.AddFromFunctions("ProductFilterFunction", new[] { searchFunc });
    }
}
