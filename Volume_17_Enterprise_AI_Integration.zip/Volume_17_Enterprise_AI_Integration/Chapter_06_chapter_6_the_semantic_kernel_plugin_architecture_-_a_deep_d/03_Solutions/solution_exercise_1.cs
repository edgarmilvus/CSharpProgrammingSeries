
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;

// 1. Legacy Service Mock (As provided in requirements)
public class LegacyInventoryService
{
    public InventoryResult UpdateStock(Guid productId, int quantity)
    {
        // Simulate logic (e.g., database call)
        if (productId == Guid.Empty) throw new ArgumentException("Product ID cannot be empty.");
        if (quantity < 0) throw new ArgumentOutOfRangeException(nameof(quantity), "Quantity cannot be negative.");
        
        return new InventoryResult { Success = true, NewStockLevel = quantity };
    }
}

public class InventoryResult
{
    public bool Success { get; set; }
    public int NewStockLevel { get; set; }
}

// 2. Output Data Modeling (Public contract)
public record InventoryUpdateResponse(bool Success, int NewStockLevel, string? ErrorMessage = null);

public record BatchInventoryUpdateResponse(
    int TotalItems, 
    int SuccessfulUpdates, 
    int FailedUpdates, 
    List<InventoryUpdateResponse> Details
);

// 3. Plugin Implementation
public class InventoryPlugin
{
    private readonly LegacyInventoryService _legacyService;

    public InventoryPlugin(LegacyInventoryService legacyService)
    {
        _legacyService = legacyService;
    }

    [KernelFunction("UpdateInventory")]
    [Description("Updates the stock level for a specific product ID.")]
    public InventoryUpdateResponse UpdateInventory(
        [Description("The product ID as a string (GUID format)")] string productId,
        [Description("The quantity to add or remove")] int quantity)
    {
        try
        {
            // 4. Input Modeling & Validation
            if (!Guid.TryParse(productId, out var productGuid))
            {
                throw new ArgumentException($"Invalid GUID format provided: {productId}");
            }

            // Call legacy service
            var result = _legacyService.UpdateStock(productGuid, quantity);

            // 5. Output Modeling (Map internal result to public record)
            return new InventoryUpdateResponse(result.Success, result.NewStockLevel);
        }
        catch (Exception ex)
        {
            // 6. Error Handling
            // Log the exception in a real app
            return new InventoryUpdateResponse(false, 0, ex.Message);
        }
    }

    [KernelFunction("UpdateInventoryBatch")]
    [Description("Updates stock levels for multiple products. Processes all items even if some fail.")]
    public BatchInventoryUpdateResponse UpdateInventoryBatch(
        [Description("List of items to update")] string itemsJson)
    {
        // Deserialize input (assuming JSON string for complex input in Kernel Functions)
        var items = JsonSerializer.Deserialize<List<(string productId, int quantity)>>(itemsJson) 
                    ?? new List<(string, int)>();

        var results = new List<InventoryUpdateResponse>();
        int successCount = 0;

        foreach (var (productId, quantity) in items)
        {
            // Reuse the logic from the single update, or call internal logic directly
            // For this example, we simulate the logic here to avoid double-serialization
            try
            {
                if (!Guid.TryParse(productId, out var productGuid))
                {
                    results.Add(new InventoryUpdateResponse(false, 0, $"Invalid GUID: {productId}"));
                    continue;
                }

                var legacyResult = _legacyService.UpdateStock(productGuid, quantity);
                results.Add(new InventoryUpdateResponse(true, legacyResult.NewStockLevel));
                successCount++;
            }
            catch (Exception ex)
            {
                results.Add(new InventoryUpdateResponse(false, 0, ex.Message));
            }
        }

        return new BatchInventoryUpdateResponse(
            items.Count,
            successCount,
            items.Count - successCount,
            results
        );
    }
}

// Usage Example (for context)
public class InventoryDemo
{
    public static void Run()
    {
        var kernel = Kernel.CreateBuilder()
            .AddOpenAIChatCompletion("gpt-4", "key") // Placeholder
            .Build();

        var legacyService = new LegacyInventoryService();
        var plugin = new InventoryPlugin(legacyService);
        
        kernel.Plugins.AddFromObject(plugin, "Inventory");
    }
}
