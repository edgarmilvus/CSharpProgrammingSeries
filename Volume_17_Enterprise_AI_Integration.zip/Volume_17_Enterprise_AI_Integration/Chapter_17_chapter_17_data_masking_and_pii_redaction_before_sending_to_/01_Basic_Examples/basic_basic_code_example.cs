
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EnterpriseDataSanitization
{
    // Represents a raw, unstructured log entry or message from a legacy system.
    // In a real scenario, this could be a database record, an API request payload, or a log file line.
    public class RawDataPacket
    {
        public Guid Id { get; set; }
        public string Content { get; set; }
        public DateTime Timestamp { get; set; }
    }

    // Represents the sanitized version of the data ready for LLM processing.
    public class SanitizedDataPacket
    {
        public Guid Id { get; set; }
        public string Content { get; set; }
        public Dictionary<string, string> MaskedValues { get; set; } // Maps original PII types to their masked tokens (e.g., "SSN" -> "REDACTED_SSN_1")
        public DateTime Timestamp { get; set; }
    }

    // The core engine for identifying and masking PII.
    // Uses a hybrid approach: Regex for structured patterns and simple keyword matching for context.
    public class PiiSanitizer
    {
        private readonly List<Regex> _piiPatterns;
        private readonly Dictionary<string, string> _piiKeywords;
        private int _redactionCounter;

        public PiiSanitizer()
        {
            _piiPatterns = new List<Regex>();
            _piiKeywords = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            _redactionCounter = 0;
            InitializePatterns();
        }

        private void InitializePatterns()
        {
            // 1. Credit Card Numbers (Visa, Mastercard, Amex, generic 16-digit)
            // Note: This is a simplified regex for demonstration. Production systems use Luhn algorithm validation.
            _piiPatterns.Add(new Regex(@"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12})\b", RegexOptions.Compiled));

            // 2. US Social Security Numbers (SSN)
            // Matches patterns like 123-45-6789 or 123 45 6789
            _piiPatterns.Add(new Regex(@"\b\d{3}[- ]?\d{2}[- ]?\d{4}\b", RegexOptions.Compiled));

            // 3. Email Addresses
            _piiPatterns.Add(new Regex(@"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", RegexOptions.Compiled));

            // 4. US Phone Numbers (Simplified)
            _piiPatterns.Add(new Regex(@"\b\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b", RegexOptions.Compiled));

            // Initialize keyword dictionary for context-based redaction (e.g., "SSN:", "CreditCard:")
            // In a real system, this would be loaded from a configuration file or database.
            _piiKeywords.Add("SSN", "SSN");
            _piiKeywords.Add("Social Security", "SSN");
            _piiKeywords.Add("Credit Card", "CreditCard");
            _piiKeywords.Add("Card Number", "CreditCard");
            _piiKeywords.Add("Password", "Password");
            _piiKeywords.Add("Secret", "Secret");
        }

        public SanitizedDataPacket Sanitize(RawDataPacket rawData)
        {
            string content = rawData.Content;
            var maskedValues = new Dictionary<string, string>();

            // Step 1: Pattern Matching (Regex)
            // We iterate through defined patterns and replace matches with tokens.
            // We process the content string immutably to avoid index shifting issues during iteration.
            foreach (var pattern in _piiPatterns)
            {
                content = pattern.Replace(content, match =>
                {
                    string typeName = DeterminePiiType(match.Value);
                    string token = GenerateRedactionToken(typeName);
                    maskedValues[typeName] = token; // Store mapping for audit logs
                    return token;
                });
            }

            // Step 2: Keyword Context Redaction
            // This looks for specific keywords (e.g., "SSN: 123-45-6789") and redacts the value immediately following them.
            // This handles cases where regex might be too broad or specific formats vary.
            foreach (var keyword in _piiKeywords)
            {
                // Simple heuristic: Find keyword, then find the next "word" or "phrase" after it.
                // In production, this requires NLP or more complex parsing logic.
                string pattern = $@"({Regex.Escape(keyword.Key)})\s*[:\-]?\s*(\S+)";
                content = Regex.Replace(content, pattern, match =>
                {
                    string typeName = keyword.Value;
                    string token = GenerateRedactionToken(typeName);
                    maskedValues[typeName] = token;
                    return $"{match.Groups[1].Value}: {token}";
                }, RegexOptions.IgnoreCase);
            }

            return new SanitizedDataPacket
            {
                Id = rawData.Id,
                Content = content,
                MaskedValues = maskedValues,
                Timestamp = rawData.Timestamp
            };
        }

        private string DeterminePiiType(string value)
        {
            // Heuristic logic to determine the specific type of PII based on format
            if (Regex.IsMatch(value, @"^\d{3}[- ]?\d{2}[- ]?\d{4}$")) return "SSN";
            if (Regex.IsMatch(value, @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$")) return "Email";
            if (value.Length >= 13 && value.Length <= 16 && Regex.IsMatch(value, @"^\d+$")) return "CreditCard";
            if (Regex.IsMatch(value, @"^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$")) return "Phone";
            return "PII";
        }

        private string GenerateRedactionToken(string typeName)
        {
            _redactionCounter++;
            // Using a deterministic token format helps in debugging and consistency.
            // Example: [REDACTED_SSN_1]
            return $"[REDACTED_{typeName.ToUpper()}_{_redactionCounter}]";
        }
    }

    // The API Gateway or Middleware component.
    // This simulates the entry point where data enters the system before being sent to an LLM.
    public class LlmGateway
    {
        private readonly PiiSanitizer _sanitizer;

        public LlmGateway()
        {
            _sanitizer = new PiiSanitizer();
        }

        // Simulates receiving a request from a legacy system or internal API.
        public async Task<SanitizedDataPacket> ProcessIncomingRequestAsync(RawDataPacket rawData)
        {
            Console.WriteLine($"[Gateway] Received Raw Data ID: {rawData.Id}");
            
            // CRITICAL SECURITY STEP: Sanitize before any processing.
            var sanitizedData = _sanitizer.Sanitize(rawData);

            Console.WriteLine($"[Gateway] Sanitized Data ID: {sanitizedData.Id}");
            Console.WriteLine($"[Gateway] Masked Values: {JsonSerializer.Serialize(sanitizedData.MappedValues)}");

            // In a real scenario, sanitizedData.Content is now sent to the LLM API.
            await SendToLlmAsync(sanitizedData);

            return sanitizedData;
        }

        private async Task SendToLlmAsync(SanitizedDataPacket data)
        {
            // Simulate network latency
            await Task.Delay(100);
            Console.WriteLine($"[LLM API] Processing sanitized content: '{data.Content}'...");
            // Simulate LLM response generation
            Console.WriteLine("[LLM API] Response generated successfully.");
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("--- Enterprise Data Sanitization Demo ---\n");

            // 1. Setup the Gateway
            var gateway = new LlmGateway();

            // 2. Simulate Raw Data Ingestion (Legacy System Logs)
            var rawLog1 = new RawDataPacket
            {
                Id = Guid.NewGuid(),
                Timestamp = DateTime.Now,
                Content = "User John Doe (john.doe@example.com) called support. SSN: 123-45-6789. He reported issues with card 4111-1111-1111-1111."
            };

            var rawLog2 = new RawDataPacket
            {
                Id = Guid.NewGuid(),
                Timestamp = DateTime.Now,
                Content = "New account created. Password: SuperSecret123! Contact: 555-0199."
            };

            // 3. Process Data
            Console.WriteLine("Processing Log 1...");
            await gateway.ProcessIncomingRequestAsync(rawLog1);
            Console.WriteLine("\nProcessing Log 2...");
            await gateway.ProcessIncomingRequestAsync(rawLog2);

            Console.WriteLine("\n--- Demo Complete ---");
        }
    }
}
