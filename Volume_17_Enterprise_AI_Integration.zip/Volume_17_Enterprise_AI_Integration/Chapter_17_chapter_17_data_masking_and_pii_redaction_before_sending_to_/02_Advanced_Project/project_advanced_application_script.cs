
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace EnterpriseLLMSecurity
{
    // Main entry point for the application
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Enterprise Data Sanitization Pipeline ===");
            Console.WriteLine("Processing inbound customer support ticket...\n");

            // 1. Simulate raw, sensitive data entering the system from a legacy CRM
            string rawTicket = @"
                Customer Name: Johnathan Doe
                Email: j.doe@example.com
                Phone: (555) 123-4567
                SSN: 000-12-3456
                Credit Card: 4111 1111 1111 1111
                Issue: I cannot access my account. My password is 'SuperSecret123'.
                IP Address: 192.168.1.55
                Location: 40.7128° N, 74.0060° W
            ";

            // 2. Initialize the Redaction Engine
            // In a real scenario, this would be a Singleton or DI service
            var redactionEngine = new SecureRedactionEngine();

            // 3. Process the data
            // We use StringBuilder for efficient string manipulation (Chapter 16 concept: Memory Management)
            StringBuilder logBuilder = new StringBuilder();
            logBuilder.AppendLine($"Original Length: {rawTicket.Length} characters");

            string sanitizedTicket = redactionEngine.SanitizeData(rawTicket);

            logBuilder.AppendLine($"Sanitized Length: {sanitizedTicket.Length} characters");
            logBuilder.AppendLine("------------------------------------------------");
            logBuilder.AppendLine("SANITIZED OUTPUT:");
            logBuilder.AppendLine(sanitizedTicket);
            logBuilder.AppendLine("------------------------------------------------");

            // 4. Output results to console (Simulating secure logging)
            Console.WriteLine(logBuilder.ToString());

            // 5. Demonstrate the LLM Interaction
            SimulateLLMCall(sanitizedTicket);
        }

        // Simulates sending the sanitized data to an LLM
        static void SimulateLLMCall(string safeContext)
        {
            Console.WriteLine("\n[SYSTEM] Sending sanitized context to LLM API...");
            
            // Mock LLM Response generation based on safe context
            // In reality, this would be an HTTP POST request
            string llmPrompt = $"Analyze the following support ticket and suggest a resolution:\n{safeContext}";
            string llmResponse = "Based on the ticket, it appears the user is having login issues. " +
                                 "Since the password was redacted, please advise the user to use the 'Forgot Password' feature. " +
                                 "No sensitive data was processed.";

            Console.WriteLine("[LLM RESPONSE]: " + llmResponse);
            Console.WriteLine("\n=== Process Complete ===");
        }
    }

    /// <summary>
    /// Core engine responsible for identifying and masking PII.
    /// Implements pattern matching and rule-based logic.
    /// </summary>
    public class SecureRedactionEngine
    {
        // Configuration for redaction markers
        private const string REDACTION_MASK = "[REDACTED]";
        private const string EMAIL_MASK = "[EMAIL_REDACTED]";
        private const string SSN_MASK = "[SSN_REDACTED]";
        private const string CC_MASK = "[CC_REDACTED]";

        // Dictionary to store dynamic mappings (e.g., masking specific keywords)
        private Dictionary<string, string> _sensitiveKeywords;

        public SecureRedactionEngine()
        {
            // Initialize sensitive keywords list
            _sensitiveKeywords = new Dictionary<string, string>
            {
                { "password", "[SECRET_REDACTED]" },
                { "secret", "[SECRET_REDACTED]" },
                { "confidential", "[SECRET_REDACTED]" }
            };
        }

        /// <summary>
        /// Orchestrates the redaction process.
        /// </summary>
        public string SanitizeData(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            // Step 1: Pattern-based Redaction (Regex)
            // We process these first to handle structured data formats
            string step1 = ApplyRegexRedactions(input);

            // Step 2: Named Entity Recognition (NER) Simulation
            // Heuristic approach to find names and locations based on context
            string step2 = ApplyHeuristicRedactions(step1);

            // Step 3: Keyword/Context Redaction
            // Redact specific sensitive words regardless of format
            string step3 = ApplyKeywordRedactions(step2);

            return step3;
        }

        /// <summary>
        /// Uses Regular Expressions to find structured PII patterns.
        /// </summary>
        private string ApplyRegexRedactions(string input)
        {
            StringBuilder output = new StringBuilder(input);

            // 1. Email Redaction
            // Pattern: [word chars] + @ + [domain]
            string emailPattern = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}";
            output = ReplacePattern(output, emailPattern, EMAIL_MASK);

            // 2. SSN Redaction (Standard US format)
            // Pattern: 3 digits - 2 digits - 4 digits
            string ssnPattern = @"\b\d{3}-\d{2}-\d{4}\b";
            output = ReplacePattern(output, ssnPattern, SSN_MASK);

            // 3. Credit Card Redaction (Simple 16-digit pattern with spaces/dashes)
            // Pattern: 4 groups of 4 digits separated by space or dash
            string ccPattern = @"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b";
            output = ReplacePattern(output, ccPattern, CC_MASK);

            // 4. Phone Number Redaction
            // Pattern: (XXX) XXX-XXXX or XXX-XXX-XXXX
            string phonePattern = @"\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}";
            output = ReplacePattern(output, phonePattern, REDACTION_MASK);

            return output.ToString();
        }

        /// <summary>
        /// Helper method to apply Regex replacements safely.
        /// </summary>
        private StringBuilder ReplacePattern(StringBuilder input, string pattern, string mask)
        {
            // Regex options: Compiled for performance in high-throughput scenarios
            Regex regex = new Regex(pattern, RegexOptions.Compiled);
            string result = regex.Replace(input.ToString(), mask);
            return new StringBuilder(result);
        }

        /// <summary>
        /// Simulates Named Entity Recognition (NER) using heuristic logic.
        /// Identifies names and locations based on keywords and capitalization.
        /// </summary>
        private string ApplyHeuristicRedactions(string input)
        {
            // Split input into lines to process contextually
            string[] lines = input.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            StringBuilder processedOutput = new StringBuilder();

            foreach (string line in lines)
            {
                string processedLine = line;

                // Heuristic 1: Identify Names
                // Look for "Name:" prefix followed by capitalized words
                if (processedLine.Contains("Name:") || processedLine.Contains("Customer:"))
                {
                    // Simple heuristic: Assume the text after the colon is a name
                    int colonIndex = processedLine.IndexOf(':');
                    if (colonIndex != -1 && colonIndex < processedLine.Length - 1)
                    {
                        string namePart = processedLine.Substring(colonIndex + 1).Trim();
                        // Check if it looks like a name (starts with capital, contains space)
                        if (namePart.Length > 0 && char.IsUpper(namePart[0]) && namePart.Contains(" "))
                        {
                            processedLine = processedLine.Replace(namePart, REDACTION_MASK);
                        }
                    }
                }

                // Heuristic 2: Identify Locations (Lat/Long)
                // Look for coordinate patterns (e.g., 40.7128° N)
                if (processedLine.Contains("°"))
                {
                    // This is a crude but effective way to catch coordinate data in text
                    processedLine = processedLine.Replace(processedLine, REDACTION_MASK + " [COORDINATES]");
                }

                processedOutput.AppendLine(processedLine);
            }

            return processedOutput.ToString();
        }

        /// <summary>
        /// Redacts specific sensitive keywords found in the text.
        /// </summary>
        private string ApplyKeywordRedactions(string input)
        {
            StringBuilder output = new StringBuilder(input);
            
            // Iterate through the dictionary of sensitive keywords
            foreach (var kvp in _sensitiveKeywords)
            {
                string keyword = kvp.Key;
                string mask = kvp.Value;

                // Case-insensitive replacement
                // Note: In a real system, we would use a more robust string replacement algorithm
                // to handle word boundaries correctly.
                string pattern = @"\b" + Regex.Escape(keyword) + @"\b";
                Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
                output = new StringBuilder(regex.Replace(output.ToString(), mask));
            }

            return output.ToString();
        }
    }
}
