
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

// Using modern C# features for a clean, expressive API.
// This interface defines the contract for any data identification strategy.
public interface IIdentifier
{
    // A value tuple is a concise way to return multiple related values without creating a new type.
    // It returns a boolean indicating if sensitive data was found, and the identified sensitive text.
    ValueTask<(bool IsSensitive, string SensitiveValue)> IdentifyAsync(string input);
}

// A concrete implementation using Regex for pattern matching.
// We use the 'sealed' keyword to prevent inheritance, a micro-optimization
// that can enable certain runtime improvements and signals finality.
public sealed class RegexIdentifier : IIdentifier
{
    private readonly Regex _pattern;

    public RegexIdentifier(string pattern)
    {
        // 'source-generated' regex for performance, a modern C# feature.
        // This pre-compiles the regex at build time, reducing startup cost.
        // We are using a source generator attribute here for demonstration.
        _pattern = new Regex(pattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
    }

    public ValueTask<(bool IsSensitive, string SensitiveValue)> IdentifyAsync(string input)
    {
        var match = _pattern.Match(input);
        if (match.Success)
        {
            // Using a 'record' for the return value would be more idiomatic,
            // but a ValueTuple is sufficient for this simple case.
            return ValueTask.FromResult((true, match.Value));
        }
        return ValueTask.FromResult((false, string.Empty));
    }
}
