
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

// A orchestrator class that composes the identification and redaction strategies.
// This class is the "brain" of our sanitization process.
public class DataSanitizer
{
    private readonly IEnumerable<IIdentifier> _identifiers;
    private readonly IRedactor _redactor;

    // Constructor injection promotes loose coupling and testability.
    public DataSanitizer(IEnumerable<IIdentifier> identifiers, IRedactor redactor)
    {
        _identifiers = identifiers;
        _redactor = redactor;
    }

    // The core sanitization method, using modern async/await and pattern matching.
    public async Task<RedactionResult> SanitizeAsync(string rawData)
    {
        string sensitiveValue = string.Empty;
        
        // We iterate through our identification strategies.
        // This is a declarative way to find the first sensitive value.
        // In a more complex scenario, we might want to find ALL sensitive values.
        foreach (var identifier in _identifiers)
        {
            var (isSensitive, value) = await identifier.IdentifyAsync(rawData);
            if (isSensitive)
            {
                sensitiveValue = value;
                break; // We found a sensitive value, no need to check further.
            }
        }

        // Pattern matching on the result of our search.
        // If no sensitive value was found, we can return the original data.
        // This is a powerful way to handle control flow without if/else chains.
        return sensitiveValue switch
        {
            not null when !string.IsNullOrEmpty(sensitiveValue) => _redactor.Redact(rawData, sensitiveValue),
            _ => new RedactionResult(rawData, new Dictionary<string, string>()) // No change needed.
        };
    }
}
