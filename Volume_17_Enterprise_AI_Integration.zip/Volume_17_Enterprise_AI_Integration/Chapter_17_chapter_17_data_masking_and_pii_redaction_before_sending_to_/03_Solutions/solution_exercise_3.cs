
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace TokenizationService
{
    public class TokenizationService
    {
        // Simulating a secure store with TTL
        private readonly ConcurrentDictionary<string, (string Value, DateTime Expiry)> _tokenStore = new();
        private readonly TimeSpan _defaultTtl = TimeSpan.FromMinutes(30);

        // Deterministic token generation (simple hash simulation)
        public string Tokenize(string sensitiveValue)
        {
            if (string.IsNullOrEmpty(sensitiveValue)) return sensitiveValue;

            // In production, use a cryptographic hash or HMAC
            string token = $"tok_{Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sensitiveValue))[..16]}";
            
            _tokenStore[token] = (sensitiveValue, DateTime.UtcNow.Add(_defaultTtl));
            return token;
        }

        public string Detokenize(string token)
        {
            if (_tokenStore.TryGetValue(token, out var entry))
            {
                if (entry.Expiry > DateTime.UtcNow)
                {
                    return entry.Value;
                }
                else
                {
                    _tokenStore.TryRemove(token, out _); // Cleanup expired
                }
            }
            return token; // Return original if not found (or throw exception depending on policy)
        }

        public async Task<string> TokenizeJsonAsync(string jsonInput, List<string> fieldsToTokenize)
        {
            // Parse JSON into a mutable DOM
            var node = JsonNode.Parse(jsonInput);
            
            await TraverseAndTokenize(node, fieldsToTokenize);
            
            return node.ToJsonString();
        }

        private async Task TraverseAndTokenize(JsonNode node, List<string> fields)
        {
            if (node is JsonObject obj)
            {
                foreach (var kvp in obj.ToList()) // ToList to allow modification during iteration
                {
                    if (fields.Contains(kvp.Key))
                    {
                        // Tokenize the value
                        if (kvp.Value != null)
                        {
                            // Simulate async I/O if backing store was remote
                            await Task.Yield(); 
                            obj[kvp.Key] = Tokenize(kvp.Value.ToString());
                        }
                    }
                    else
                    {
                        // Recurse
                        await TraverseAndTokenize(kvp.Value, fields);
                    }
                }
            }
            else if (node is JsonArray arr)
            {
                for (int i = 0; i < arr.Count; i++)
                {
                    await TraverseAndTokenize(arr[i], fields);
                }
            }
        }

        // --- FPE Simulation ---
        public string TokenizeFpe(string value, char maskChar = '*')
        {
            if (string.IsNullOrEmpty(value)) return value;

            // Simple logic: Keep first and last char, mask middle. 
            // For emails, preserve @ and . structure.
            
            if (value.Length <= 2) return new string(maskChar, value.Length);

            // Heuristic for email structure
            if (value.Contains('@'))
            {
                var parts = value.Split('@');
                if (parts.Length == 2)
                {
                    string local = parts[0];
                    string domain = parts[1];
                    string maskedLocal = local[0] + new string(maskChar, Math.Max(0, local.Length - 2)) + local[^1];
                    return $"{maskedLocal}@{domain}";
                }
            }

            // Generic FPE simulation
            return value[0] + new string(maskChar, value.Length - 2) + value[^1];
        }
    }
}
