
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RedactionPipeline
{
    // Interface for dynamic rule registration
    public interface IRedactionRule
    {
        string Pattern { get; }
        string ReplacementToken { get; }
        RegexOptions Options { get; }
    }

    // Concrete implementation of a rule
    public class CreditCardRule : IRedactionRule
    {
        public string Pattern => @"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b";
        public string ReplacementToken => "[REDACTED_CC]";
        public RegexOptions Options => RegexOptions.Compiled;
    }

    public class RedactionEngine
    {
        // Thread-safe collection for dynamic rules
        private readonly ConcurrentBag<IRedactionRule> _rules;
        
        // Static regex cache to avoid recompilation overhead
        // We use a Lazy<Regex> to ensure thread-safe initialization per rule
        private readonly ConcurrentDictionary<IRedactionRule, Lazy<Regex>> _compiledRegexes;

        public RedactionEngine(IEnumerable<IRedactionRule> initialRules = null)
        {
            _rules = new ConcurrentBag<IRedactionRule>(initialRules ?? Enumerable.Empty<IRedactionRule>());
            _compiledRegexes = new ConcurrentDictionary<IRedactionRule, Lazy<Regex>>();
        }

        // Dynamic registration
        public void RegisterRule(IRedactionRule rule)
        {
            if (rule == null) throw new ArgumentNullException(nameof(rule));
            _rules.Add(rule);
        }

        // Helper to get or add a compiled regex
        private Regex GetRegex(IRedactionRule rule)
        {
            var lazyRegex = _compiledRegexes.GetOrAdd(rule, 
                r => new Lazy<Regex>(() => new Regex(r.Pattern, r.Options | RegexOptions.Compiled)));
            
            return lazyRegex.Value;
        }

        // High-performance async redaction using ValueTask
        public async ValueTask<string> RedactAsync(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            // Simulate I/O or heavy CPU work if necessary, though regex is CPU bound.
            // Using Yield to prevent blocking the sync context if called from UI.
            await Task.Yield();

            string currentText = input;

            // Process rules. Note: Order matters. 
            // To handle overlaps, we process one rule at a time.
            // A more complex implementation might use interval trees for true overlap resolution.
            foreach (var rule in _rules)
            {
                var regex = GetRegex(rule);
                
                // We use a replacement lambda to ensure we don't accidentally redact 
                // the replacement token itself if it contained pattern characters.
                currentText = regex.Replace(currentText, match => rule.ReplacementToken);
            }

            return currentText;
        }
    }

    // Extension method for IEnumerable<string>
    public static class RedactionExtensions
    {
        public static async IAsyncEnumerable<string> RedactStreamAsync(
            this IAsyncEnumerable<string> source, 
            RedactionEngine engine)
        {
            await foreach (var chunk in source)
            {
                yield return await engine.RedactAsync(chunk);
            }
        }
    }
}
