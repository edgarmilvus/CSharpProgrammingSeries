
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace NerRedaction
{
    public record EntityDetectionResult(string Text, int StartIndex, int EndIndex, string EntityType);

    public interface INerService
    {
        Task<IEnumerable<EntityDetectionResult>> DetectEntitiesAsync(string text);
    }

    // Mock NER Service simulating latency
    public class MockNerService : INerService
    {
        public async Task<IEnumerable<EntityDetectionResult>> DetectEntitiesAsync(string text)
        {
            // Simulate network latency
            await Task.Delay(100); 
            
            // Dummy detection logic for demonstration
            var results = new List<EntityDetectionResult>();
            if (text.Contains("John Doe"))
            {
                results.Add(new EntityDetectionResult("John Doe", text.IndexOf("John Doe"), text.IndexOf("John Doe") + 8, "PERSON"));
            }
            return results;
        }
    }

    public class NerBasedRedactor
    {
        private readonly INerService _nerService;
        private readonly SemaphoreSlim _semaphore;

        public NerBasedRedactor(INerService nerService, int maxConcurrency = 5)
        {
            _nerService = nerService;
            _semaphore = new SemaphoreSlim(maxConcurrency);
        }

        public async Task<string> RedactAsync(string text)
        {
            await _semaphore.WaitAsync();
            try
            {
                var entities = await _nerService.DetectEntitiesAsync(text);
                
                // Sort by StartIndex DESCENDING to prevent index shifting issues
                var sortedEntities = entities.OrderByDescending(e => e.StartIndex).ToList();

                var result = text.ToCharArray(); // Mutable buffer for efficiency

                foreach (var entity in sortedEntities)
                {
                    string replacement = $"[REDACTED_{entity.EntityType}]";
                    // In a real scenario, we'd handle variable length replacements carefully.
                    // Here we assume replacement fits or we truncate.
                    // For simplicity of this exercise, we replace strictly.
                    
                    // Replace in the char array (simplified for readability, 
                    // normally we'd use StringBuilder or Span<T> for performance)
                    // Converting back to string for replacement logic:
                    text = text.Remove(entity.StartIndex, entity.EndIndex - entity.StartIndex)
                              .Insert(entity.StartIndex, replacement);
                }
                return text;
            }
            finally
            {
                _semaphore.Release();
            }
        }
    }

    // --- Decorator Pattern Implementation ---

    public interface IRedactor
    {
        Task<string> RedactAsync(string text);
    }

    // Concrete Redactor for Patterns (from Exercise 1, simplified)
    public class PatternRedactor : IRedactor
    {
        public Task<string> RedactAsync(string text)
        {
            // Simplified pattern redaction
            var redacted = System.Text.RegularExpressions.Regex.Replace(
                text, @"\b\d{3}-\d{2}-\d{4}\b", "[REDACTED_SSN]");
            return Task.FromResult(redacted);
        }
    }

    // Concrete Redactor for NER
    public class NerRedactor : IRedactor
    {
        private readonly NerBasedRedactor _innerRedactor;
        public NerRedactor(INerService service) => _innerRedactor = new NerBasedRedactor(service);

        public Task<string> RedactAsync(string text) => _innerRedactor.RedactAsync(text);
    }

    // The Composite Decorator
    public class CompositeRedactor : IRedactor
    {
        private readonly IEnumerable<IRedactor> _redactors;

        public CompositeRedactor(params IRedactor[] redactors)
        {
            _redactors = redactors;
        }

        public async Task<string> RedactAsync(string text)
        {
            string current = text;
            foreach (var redactor in _redactors)
            {
                // Pass the result of the previous redactor to the next.
                // Note: To strictly prevent re-processing of redacted tokens (e.g., a name inside a redacted SSN),
                // we rely on the regex patterns not matching the token format (e.g., [REDACTED_...]).
                // If a pattern *could* match a token, we would need to track offsets of redacted regions.
                current = await redactor.RedactAsync(current);
            }
            return current;
        }
    }

    // JSON Output Wrapper
    public class RedactionResult
    {
        public string OriginalText { get; init; }
        public string RedactedText { get; init; }
    }
}
