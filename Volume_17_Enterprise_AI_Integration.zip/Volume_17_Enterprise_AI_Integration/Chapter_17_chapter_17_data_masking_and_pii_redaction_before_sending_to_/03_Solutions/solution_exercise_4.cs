
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Buffers;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace LlmGatewayMiddleware
{
    public class RedactionConfig
    {
        public string[] Fields { get; set; } = Array.Empty<string>();
        public string[] Patterns { get; set; } = Array.Empty<string>();
    }

    public class LlmSanitizationMiddleware : IMiddleware
    {
        private readonly IConfiguration _configuration;
        private readonly RedactionConfig _redactionConfig;
        private readonly RedactionEngine _redactionEngine; // Assuming reuse from Ex 1

        public LlmSanitizationMiddleware(IConfiguration configuration, IOptions<RedactionConfig> options)
        {
            _configuration = configuration;
            _redactionConfig = options.Value;
            // Initialize engine based on config (simplified)
            _redactionEngine = new RedactionEngine(); 
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            // Ensure the request is JSON
            if (!context.Request.ContentType.Contains("application/json"))
            {
                await next(context);
                return;
            }

            // Use a temporary memory stream to buffer the request body
            // Note: For truly massive payloads, we would need to stream directly to the JSON parser.
            // However, parsing requires the full document or a complex streaming writer.
            // For this exercise, we buffer to memory (limit size in production).
            context.Request.EnableBuffering();
            var bodyStream = context.Request.Body;
            
            // Reset stream position for reading
            bodyStream.Position = 0;
            
            using var reader = new StreamReader(bodyStream);
            string jsonPayload = await reader.ReadToEndAsync();

            try
            {
                // Parse JSON to DOM (simplification for readability vs pure streaming Utf8JsonReader)
                // In a high-performance scenario with large payloads, Utf8JsonReader/Writer is preferred.
                var node = JsonNode.Parse(jsonPayload);

                if (node is JsonObject root)
                {
                    int redactionCount = 0;

                    // Apply field-specific redactions
                    foreach (var field in _redactionConfig.Fields)
                    {
                        if (root.TryGetPropertyValue(field, out var value) && value != null)
                        {
                            string original = value.ToString();
                            string redacted = await _redactionEngine.RedactAsync(original);
                            
                            if (original != redacted)
                            {
                                root[field] = redacted;
                                redactionCount++;
                            }
                        }
                    }

                    // Inject Header
                    context.Response.Headers.Append("X-Redaction-Log", $"Count={redactionCount}");
                    
                    // Replace the request body for downstream middleware
                    var redactedBytes = System.Text.Encoding.UTF8.GetBytes(root.ToJsonString());
                    context.Request.Body = new MemoryStream(redactedBytes);
                    context.Request.Body.Position = 0;
                }

                await next(context);
            }
            catch (JsonException)
            {
                context.Response.StatusCode = 400;
                await context.Response.WriteAsync("{\"error\": \"Invalid JSON structure\", \"code\": \"MALFORMED_JSON\"}");
                return;
            }
            catch (Exception ex)
            {
                // Log the exception (omitted for brevity)
                context.Response.StatusCode = 500;
                await context.Response.WriteAsync("{\"error\": \"Internal processing error\", \"code\": \"REDACTION_FAIL\"}");
            }
        }
    }
}
