
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Concurrent;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace AuditLogging
{
    // Immutable Audit Record
    public readonly struct RedactionAuditEntry
    {
        public Guid CorrelationId { get; init; }
        public DateTimeOffset Timestamp { get; init; }
        public string DataType { get; init; }
        public int OriginalLength { get; init; }
        public string HashOfOriginal { get; init; } // SHA256
    }

    public interface IAuditSink
    {
        Task LogAsync(RedactionAuditEntry entry);
    }

    // File-based Sink
    public class FileAuditSink : IAuditSink
    {
        private readonly string _filePath;
        private readonly SemaphoreSlim _fileLock = new(1, 1);

        public FileAuditSink(string filePath)
        {
            _filePath = filePath;
        }

        public async Task LogAsync(RedactionAuditEntry entry)
        {
            // In a real app, use a library like Serilog or NLog for file handling.
            // Here we simulate simple JSON lines writing.
            var json = JsonSerializer.Serialize(entry);
            
            await _fileLock.WaitAsync();
            try
            {
                await File.AppendAllTextAsync(_filePath, json + Environment.NewLine);
            }
            finally
            {
                _fileLock.Release();
            }
        }
    }

    // Decorator for Redaction + Auditing
    public class AuditingRedactionDecorator
    {
        private readonly RedactionEngine _innerEngine; // From Ex 1
        private readonly IAuditSink _auditSink;
        private readonly Channel<RedactionAuditEntry> _auditChannel;

        public AuditingRedactionDecorator(RedactionEngine innerEngine, IAuditSink auditSink)
        {
            _innerEngine = innerEngine;
            _auditSink = auditSink;
            
            // Bounded channel to prevent memory overflow if logging is slow
            _auditChannel = Channel.CreateBounded<RedactionAuditEntry>(new BoundedChannelOptions(1000)
            {
                FullMode = BoundedChannelFullMode.Wait
            });

            // Start the background consumer
            _ = ProcessAuditQueueAsync();
        }

        // Calculate hash for audit
        private string ComputeHash(string input)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            return Convert.ToBase64String(bytes);
        }

        public async Task<string> RedactAndAuditAsync(string input, string dataType, Guid correlationId)
        {
            // Detect matches (simplified logic for demonstration)
            // In reality, we would capture the specific matched value inside RedactionEngine
            // For this exercise, we assume the engine returns the redacted string and we know the type.
            
            // Simulate detection logic
            if (input.Contains("SENSITIVE")) 
            {
                var entry = new RedactionAuditEntry
                {
                    CorrelationId = correlationId,
                    Timestamp = DateTimeOffset.UtcNow,
                    DataType = dataType,
                    OriginalLength = input.Length,
                    HashOfOriginal = ComputeHash(input)
                };

                // Non-blocking write to channel
                await _auditChannel.Writer.WriteAsync(entry);
            }

            return await _innerEngine.RedactAsync(input);
        }

        private async Task ProcessAuditQueueAsync()
        {
            await foreach (var entry in _auditChannel.Reader.ReadAllAsync())
            {
                // Fire and forget? No, we await the sink to ensure durability,
                // but this runs on a background thread, decoupled from the main request.
                await _auditSink.LogAsync(entry);
            }
        }
    }

    // --- Structured Logging Refactor (Interactive Challenge) ---
    
    // Mock External Log Aggregator
    public interface ILogAggregator
    {
        Task SendLogAsync(object logPayload);
    }

    // Custom ILoggerProvider for Structured Logging
    using Microsoft.Extensions.Logging;
    
    public class AuditLoggerProvider : ILoggerProvider
    {
        private readonly ILogAggregator _aggregator;
        private readonly ConcurrentDictionary<string, AuditLogger> _loggers = new();

        public AuditLoggerProvider(ILogAggregator aggregator) => _aggregator = aggregator;

        public ILogger CreateLogger(string categoryName) 
            => _loggers.GetOrAdd(categoryName, name => new AuditLogger(name, _aggregator));

        public void Dispose() => _loggers.Clear();
    }

    public class AuditLogger : ILogger
    {
        private readonly string _categoryName;
        private readonly ILogAggregator _aggregator;
        private readonly Channel<object> _logChannel;

        public AuditLogger(string categoryName, ILogAggregator aggregator)
        {
            _categoryName = categoryName;
            _aggregator = aggregator;
            _logChannel = Channel.CreateUnbounded<object>();
            _ = ForwardLogsAsync();
        }

        public IDisposable BeginScope<TState>(TState state) => null;

        public bool IsEnabled(LogLevel logLevel) => true;

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            // Non-blocking write to channel
            var payload = new { Level = logLevel, Category = _categoryName, State = state, Exception = exception };
            _logChannel.Writer.TryWrite(payload);
        }

        private async Task ForwardLogsAsync()
        {
            await foreach (var payload in _logChannel.Reader.ReadAllAsync())
            {
                await _aggregator.SendLogAsync(payload);
            }
        }
    }
}
