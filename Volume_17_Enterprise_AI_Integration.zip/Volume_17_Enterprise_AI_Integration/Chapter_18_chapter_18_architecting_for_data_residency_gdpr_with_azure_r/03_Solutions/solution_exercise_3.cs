
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using Azure.Core.Pipeline;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace DpaLoggingExercise
{
    public class ConsentLoggingHandler : DelegatingHandler
    {
        private readonly ConcurrentQueue<string> _auditQueue = new();
        private readonly Timer _flushTimer;
        private const string ConsentHeader = "X-User-Consent-ID";

        public ConsentLoggingHandler()
        {
            // Simulate periodic flushing to a persistent store (e.g., Blob Storage or DB)
            _flushTimer = new Timer(FlushLogs, null, TimeSpan.Zero, TimeSpan.FromSeconds(10));
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // 1. Extract Consent
            if (!request.Headers.TryGetValues(ConsentHeader, out var consentIds))
            {
                throw new UnauthorizedAccessException($"Missing required header: {ConsentHeader}");
            }

            var consentId = consentIds.First();
            
            // In a real scenario, validate the token against an Identity Provider here.
            if (string.IsNullOrWhiteSpace(consentId))
            {
                throw new UnauthorizedAccessException("Consent token is invalid or empty.");
            }

            // 2. Prepare Metadata for Async Logging
            var logEntry = new
            {
                UserId = consentId,
                Timestamp = DateTime.UtcNow,
                Operation = request.Method.Method,
                Endpoint = request.RequestUri?.ToString()
            };

            // 3. Serialize and Queue (Non-blocking)
            string jsonLog = JsonSerializer.Serialize(logEntry);
            _auditQueue.Enqueue(jsonLog);

            // 4. Proceed with the request
            // Note: We do not await the logging flush before sending the request to avoid latency.
            return await base.SendAsync(request, cancellationToken);
        }

        private void FlushLogs(object? state)
        {
            if (_auditQueue.IsEmpty) return;

            var logsToFlush = new List<string>();
            while (_auditQueue.TryDequeue(out var log))
            {
                logsToFlush.Add(log);
            }

            // Simulate writing to a secure file or database
            // In production, use IAsyncEnumerable or a background service for this.
            Console.WriteLine($"[Audit Store] Flushing {logsToFlush.Count} consent logs...");
            foreach (var log in logsToFlush)
            {
                // Write to secure storage (Simulated)
                // System.IO.File.AppendAllText("audit.log", log + Environment.NewLine);
                Console.WriteLine($" -> {log}");
            }
        }
    }

    public class Program
    {
        public static async Task Main(string[] args)
        {
            // Setup a mock client with the handler
            var innerHandler = new HttpClientHandler(); // Mocking the final HTTP call
            var consentHandler = new ConsentLoggingHandler
            {
                InnerHandler = innerHandler
            };

            using var client = new HttpClient(consentHandler);

            try
            {
                // Test 1: Missing Consent (Should fail)
                Console.WriteLine("Test 1: Missing Consent Header");
                var badRequest = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
                await client.SendAsync(badRequest);
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"Caught expected error: {ex.Message}\n");
            }

            try
            {
                // Test 2: Valid Consent (Should log and proceed)
                Console.WriteLine("Test 2: Valid Consent Header");
                var goodRequest = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions");
                goodRequest.Headers.Add("X-User-Consent-ID", "user-123-abc");
                
                // We expect this to fail with network error (since we aren't actually calling OpenAI), 
                // but the logging logic should have executed.
                await client.SendAsync(goodRequest);
            }
            catch (HttpRequestException)
            {
                Console.WriteLine("Request sent successfully (Network error expected). Check logs above for audit entry.");
            }
        }
    }
}
