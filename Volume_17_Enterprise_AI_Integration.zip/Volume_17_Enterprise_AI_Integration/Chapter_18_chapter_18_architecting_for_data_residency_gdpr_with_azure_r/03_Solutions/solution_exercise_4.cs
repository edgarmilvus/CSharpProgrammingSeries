
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using Azure.AI.OpenAI;
using Azure.Core;
using Azure.Core.Pipeline;
using Azure.Identity;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace InteractiveChallenge
{
    // Mocking the dependencies from previous exercises for compilation
    public class RegionLockedTransport : HttpClientTransport { /* Simplified for brevity */ }
    public class PrivateEndpointHandler : HttpClientHandler { /* Simplified for brevity */ }
    public class ConsentLoggingHandler : DelegatingHandler { /* Simplified for brevity */ }

    public class EnterpriseAutomationService
    {
        private readonly string _connectionString;
        private readonly string _openAiEndpoint;
        private readonly string _failoverEndpoint; // Added for GDPR failover

        public EnterpriseAutomationService(string connectionString, string openAiEndpoint, string failoverEndpoint)
        {
            // Retrieve DB connection from simulated Key Vault (Environment Variable)
            _connectionString = Environment.GetEnvironmentVariable("DB_CONNECTION_STRING") ?? connectionString;
            _openAiEndpoint = openAiEndpoint;
            _failoverEndpoint = failoverEndpoint;
        }

        private AzureOpenAIClient GetClient(bool useFailover = false)
        {
            var endpoint = useFailover ? _failoverEndpoint : _openAiEndpoint;

            // 1. Build the HTTP Pipeline (Order is critical: Logging -> Private Network -> Region Lock -> Transport)
            var handlers = new HttpPipelinePolicy[]
            {
                // Layer 1: Audit Logging
                new ConsentLoggingHandler(),
                
                // Layer 2: Private Networking (DNS override)
                // Note: In a real HttpPipeline, we wrap the transport. 
                // Here we simulate injecting the handler as the transport base.
                new HttpClientTransport(new PrivateEndpointHandler()),
                
                // Layer 3: Region Locking (Validation)
                new RegionLockedTransport()
            };

            // Construct options with the custom pipeline
            var options = new AzureOpenAIClientOptions
            {
                Transport = new CompositeTransport(handlers) // Hypothetical composite for demonstration
            };

            // Fallback to DefaultAzureCredential (Managed Identity)
            return new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential(), options);
        }

        public async Task<string> ExecuteSecureQuery(string userPrompt, string consentToken)
        {
            // 1. Validate Consent (Handled by ConsentLoggingHandler, but we check here for logic flow)
            if (string.IsNullOrEmpty(consentToken)) 
                throw new UnauthorizedAccessException("Consent required.");

            // 2. Attempt Primary Region Connection
            try
            {
                var client = GetClient(useFailover: false);
                return await ProcessRequest(client, userPrompt);
            }
            catch (DataResidencyViolationException)
            {
                // Security violation, do not retry
                throw;
            }
            catch (Exception ex) when (IsConnectionFailure(ex))
            {
                // 3. Private Endpoint Failure: Automatic Failover
                Console.WriteLine("Primary private endpoint failed. Failing over to secondary compliant region...");
                
                var failoverClient = GetClient(useFailover: true);
                return await ProcessRequest(failoverClient, userPrompt);
            }
        }

        private async Task<string> ProcessRequest(AzureOpenAIClient client, string prompt)
        {
            // Simulate Function Calling against Legacy DB
            // In reality, we would parse the LLM response, extract function arguments, 
            // and execute SQL using _connectionString.
            
            var options = new ChatCompletionsOptions
            {
                Messages = { new ChatMessage(ChatRole.User, prompt) }
            };

            // Mock call
            var response = await client.GetChatCompletionsAsync("deployment-name", options);
            return response.Value.Choices[0].Message.Content;
        }

        private bool IsConnectionFailure(Exception ex)
        {
            // Logic to detect network timeouts or private endpoint connection refused
            return ex is HttpRequestException || ex is TaskCanceledException;
        }
    }

    // Helper class to simulate composite transport (Abstracted for the exercise)
    public class CompositeTransport : HttpClientTransport
    {
        public CompositeTransport(HttpPipelinePolicy[] policies) 
        {
            // In a real scenario, we would build a custom HttpPipeline here
            // using HttpPipelineBuilder.Build(policies).
        }
    }
}
