
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Azure;
using Azure.AI.OpenAI;
using Azure.Core;
using Azure.Core.Pipeline;
using Azure.Identity;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace ResidencyExercise
{
    // Custom exception for data residency violations
    public class DataResidencyViolationException : Exception
    {
        public DataResidencyViolationException(string message) : base(message) { }
    }

    // Custom transport to enforce region locking
    public class RegionLockedTransport : HttpClientTransport
    {
        private static readonly string[] AllowedRegions = { "swedencentral", "francecentral", "germanywestcentral" };

        public RegionLockedTransport(HttpMessageHandler? handler = null) : base(handler) { }

        protected override ValueTask<HttpMessage> ProcessCoreAsync(HttpMessage message, CancellationToken cancellationToken)
        {
            var uri = message.Request.Uri;
            var host = uri.Host;

            // Check if the host contains one of the allowed region subdomains
            bool isCompliant = false;
            foreach (var region in AllowedRegions)
            {
                if (host.Contains(region, StringComparison.OrdinalIgnoreCase))
                {
                    isCompliant = true;
                    break;
                }
            }

            if (!isCompliant)
            {
                throw new DataResidencyViolationException(
                    $"Data Residency Violation: Request routed to '{host}'. " +
                    $"Only EU regions ({string.Join(", ", AllowedRegions)}) are permitted.");
            }

            // If compliant, proceed with the request
            return base.ProcessCoreAsync(message, cancellationToken);
        }
    }

    public class Program
    {
        public static async Task Main(string[] args)
        {
            // Simulated environment variables for credentials
            // In production, use Managed Identity or Key Vault
            Environment.SetEnvironmentVariable("AZURE_CLIENT_ID", "your-client-id");
            Environment.SetEnvironmentVariable("AZURE_TENANT_ID", "your-tenant-id");
            Environment.SetEnvironmentVariable("AZURE_CLIENT_SECRET", "your-client-secret");

            // 1. Define allowed and denied endpoints for testing
            string euEndpoint = "https://swedencentral.api.cognitive.microsoft.com/";
            string nonEuEndpoint = "https://eastus.api.cognitive.microsoft.com/";

            // 2. Create the custom transport
            var regionLockedTransport = new RegionLockedTransport();

            // 3. Configure Client Options with the custom transport
            var options = new AzureOpenAIClientOptions
            {
                Transport = regionLockedTransport
            };

            try
            {
                // Test 1: Valid EU Region (Should succeed in connecting, though auth will fail without valid keys)
                Console.WriteLine("Testing valid EU endpoint...");
                var client = new AzureOpenAIClient(
                    new Uri(euEndpoint), 
                    new DefaultAzureCredential(), 
                    options);
                
                // Attempt a call (will likely fail with 401/403 due to invalid credentials in this demo, 
                // but it should pass the region check)
                await client.GetChatCompletionsAsync("dummy-deployment", new ChatCompletionsOptions());
            }
            catch (DataResidencyViolationException ex)
            {
                Console.WriteLine($"Caught expected violation: {ex.Message}");
            }
            catch (Exception ex)
            {
                // Catching other exceptions (like Auth errors) because we know the credentials are dummy
                Console.WriteLine($"Request passed region check. (Auth error expected: {ex.GetType().Name})");
            }

            try
            {
                // Test 2: Invalid Non-EU Region (Should throw DataResidencyViolationException immediately)
                Console.WriteLine("\nTesting invalid Non-EU endpoint...");
                var nonCompliantClient = new AzureOpenAIClient(
                    new Uri(nonEuEndpoint), 
                    new DefaultAzureCredential(), 
                    options);

                await nonCompliantClient.GetChatCompletionsAsync("dummy-deployment", new ChatCompletionsOptions());
            }
            catch (DataResidencyViolationException ex)
            {
                Console.WriteLine($"Caught expected violation: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
            }
        }
    }
}
