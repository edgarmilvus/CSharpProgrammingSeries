
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace NetworkIsolationExercise
{
    public class PrivateEndpointHandler : HttpClientHandler
    {
        // Simulated mapping of FQDN to Private IP
        private static readonly Dictionary<string, IPAddress> PrivateDnsMap = new()
        {
            { "openai-private.openai.azure.com", IPAddress.Parse("10.0.1.5") }
        };

        public PrivateEndpointHandler()
        {
            // Ensure we don't use system proxy settings that might route to public internet
            UseProxy = false;
            // Pre-auth config
            AllowAutoRedirect = true;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var originalUri = request.RequestUri;
            var host = originalUri.Host;

            // Check if the requested host is in our private DNS map
            if (PrivateDnsMap.TryGetValue(host, out var privateIp))
            {
                // 1. Construct a new URI with the private IP but keep the original host structure
                var builder = new UriBuilder(originalUri)
                {
                    Host = privateIp.ToString()
                };

                // 2. Update the request URI to route to the private IP
                request.RequestUri = builder.Uri;

                // 3. CRITICAL: Restore the original Host header.
                // Without this, Azure Private Link authentication will fail because 
                // the TLS handshake (SNI) and Host header must match the FQDN, not the IP.
                if (request.Headers.Host == null)
                {
                    request.Headers.Host = host;
                }
            }

            // Proceed with the request
            return await base.SendAsync(request, cancellationToken);
        }
    }

    public class Program
    {
        public static async Task Main(string[] args)
        {
            // Simulate the private endpoint FQDN
            string privateFqdn = "openai-private.openai.azure.com";
            
            // Create the handler
            var handler = new PrivateEndpointHandler();
            
            // Use SocketsHttpHandler for connection pooling (injected into the handler)
            // Note: In modern .NET, HttpClientHandler manages this internally, 
            // but we can configure PooledConnectionLifetime here.
            handler.PooledConnectionLifetime = TimeSpan.FromMinutes(15);

            using var client = new HttpClient(handler);

            try
            {
                // Create a request to the private FQDN
                var request = new HttpRequestMessage(HttpMethod.Get, $"https://{privateFqdn}/swagger/index.html");
                
                Console.WriteLine($"Original Request URI: {request.RequestUri}");
                Console.WriteLine($"Target Host Header: {request.Headers.Host ?? "None (Will be set by handler)"}");

                // Send the request
                // Note: This will fail with a connection error in a local environment 
                // because the private IP 10.0.1.5 doesn't exist, but it proves the routing logic.
                var response = await client.SendAsync(request);
                
                Console.WriteLine($"Response Status: {response.StatusCode}");
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"Request failed (Expected in simulation): {ex.Message}");
                // In a real environment with connectivity, this would succeed.
                // We verify the logic by inspecting the exception or debugging:
                // The request should have attempted to connect to 10.0.1.5:443.
            }
        }
    }
}
