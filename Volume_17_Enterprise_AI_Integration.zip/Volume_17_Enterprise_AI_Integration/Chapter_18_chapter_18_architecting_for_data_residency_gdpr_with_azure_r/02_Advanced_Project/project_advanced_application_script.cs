
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EnterpriseGDPRComplianceSimulator
{
    // ==========================================
    // REAL-WORLD CONTEXT
    // ==========================================
    // A European healthcare provider ("MediSafe") processes patient records.
    // GDPR mandates that patient data (PII/PHI) must never leave the EU boundaries.
    // MediSafe uses Azure OpenAI for summarizing doctor notes, but the AI processing
    // must happen strictly within the 'France Central' region. Furthermore, any data
    // retention must be strictly limited, and data deletion requests (Right to be Forgotten)
    // must be propagated to the AI service immediately.

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("--- Starting GDPR-Compliant AI Processing Simulation ---\n");

            // 1. Configuration: Define strict regional boundaries
            string allowedRegion = "francecentral";
            string storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=medisafeeu;...";

            // 2. Initialize the Data Residency Guard
            // This class acts as the "Gatekeeper" ensuring no cross-border data leakage.
            var residencyGuard = new DataResidencyGuard(allowedRegion);

            // 3. Initialize the Azure OpenAI Service Client (Simulated)
            // In a real scenario, this wraps Azure.AI.OpenAI with Private Endpoint logic.
            var aiService = new AzureOpenAIService(residencyGuard);

            // 4. Initialize the Secure Storage (Simulated)
            // Represents Azure Blob Storage with Customer Managed Keys (CMK) in the same region.
            var secureStorage = new SecureStorage(storageConnectionString, residencyGuard);

            // 5. Simulate Ingestion and Processing
            try
            {
                // Scenario A: Valid EU Data
                Console.WriteLine("[Scenario 1] Processing valid patient data from Paris...");
                PatientRecord patient1 = new PatientRecord("P-101", "Jean Dupont", "Severe Allergy: Penicillin");
                
                // The process method encapsulates the full lifecycle: validation -> storage -> AI processing
                await ProcessPatientRecord(patient1, aiService, secureStorage, residencyGuard);

                Console.WriteLine("--------------------------------------------------\n");

                // Scenario B: Invalid Data (Cross-Border Attempt)
                Console.WriteLine("[Scenario 2] Attempting to process data tagged for US-East...");
                PatientRecord patient2 = new PatientRecord("P-102", "John Doe", "Routine Checkup");
                // Simulate a metadata error where data claims origin outside EU
                patient2.OriginRegion = "us-east"; 

                try
                {
                    await ProcessPatientRecord(patient2, aiService, secureStorage, residencyGuard);
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine($"[Security Alert] Processing blocked: {ex.Message}");
                }

                Console.WriteLine("--------------------------------------------------\n");

                // Scenario C: Right to Erasure (GDPR Article 17)
                Console.WriteLine("[Scenario 3] Executing Right to Erasure (Right to be Forgotten)...");
                await ExecuteDataDeletionRequest("P-101", aiService, secureStorage);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Critical System Failure: {ex.Message}");
            }
        }

        // ==========================================
        // LOGIC BLOCK 1: DATA PROCESSING PIPELINE
        // ==========================================
        // This method represents the core business process automation.
        // It enforces the "Check-Store-Process" pattern required by GDPR.
        static async Task ProcessPatientRecord(
            PatientRecord record, 
            AzureOpenAIService aiService, 
            SecureStorage storage, 
            DataResidencyGuard guard)
        {
            // Step 1: Validate Data Residency
            // Before any processing, we verify the data origin matches the allowed region.
            // This prevents "Data Laundering" (routing data through allowed regions to bypass restrictions).
            if (!guard.IsCompliant(record.OriginRegion))
            {
                throw new InvalidOperationException($"Data origin {record.OriginRegion} violates residency policy.");
            }

            // Step 2: Encrypt and Store
            // Data must be persisted securely before AI processing to ensure auditability.
            // In a real scenario, this uses Azure Key Vault for key management.
            string storageLocation = await storage.StoreAsync(record);
            Console.WriteLine($"[Storage] Patient data encrypted and stored at: {storageLocation}");

            // Step 3: AI Processing (Restricted Region)
            // The AI client is injected with the residency guard. It ensures the API call
            // is routed strictly to the 'France Central' endpoint.
            string summary = await aiService.SummarizeNotesAsync(record.MedicalNotes);
            Console.WriteLine($"[AI Output] Generated Summary: \"{summary}\"");
        }

        // ==========================================
        // LOGIC BLOCK 2: DATA DELETION REQUEST
        // ==========================================
        // GDPR Article 17 requires the "Right to Erasure".
        // This is not just deleting a file; it must propagate to backups, AI logs, and caches.
        static async Task ExecuteDataDeletionRequest(string patientId, AzureOpenAIService aiService, SecureStorage storage)
        {
            Console.WriteLine($"[Compliance] Initiating deletion for ID: {patientId}");

            // 1. Remove from Primary Storage
            await storage.DeleteAsync(patientId);
            Console.WriteLine($"[Storage] Primary record {patientId} deleted.");

            // 2. Purge AI Context (Simulated)
            // If the AI model was fine-tuned on this data (RAG pattern), specific vectors 
            // must be removed from the vector database.
            await aiService.PurgeUserDataAsync(patientId);
            Console.WriteLine($"[AI Service] User data vectors for {patientId} purged.");

            // 3. Log Deletion for Audit Trail
            // GDPR requires proof of deletion. We log the timestamp and action.
            Console.WriteLine($"[Audit Log] Deletion request for {patientId} completed at {DateTime.UtcNow:u}.");
        }
    }

    // ==========================================
    // ARCHITECTURAL COMPONENTS (SIMULATED)
    // ==========================================
    // These classes represent the Azure Services discussed in Chapter 18.

    /// <summary>
    /// Represents the core constraint: Data Residency.
    /// In a real implementation, this wraps the Azure SDK configuration to enforce
    /// region-specific endpoints (e.g., https://francecentral.api.openai.azure.com/).
    /// </summary>
    class DataResidencyGuard
    {
        private readonly string _approvedRegion;

        public DataResidencyGuard(string approvedRegion)
        {
            _approvedRegion = approvedRegion.ToLower();
        }

        public bool IsCompliant(string dataRegion)
        {
            // Logic: Strict equality check. 
            // Note: In production, this would also check ISO 3166-1 codes.
            return dataRegion.ToLower() == _approvedRegion;
        }
    }

    /// <summary>
    /// Simulates Azure OpenAI Service with Private Endpoints.
    /// Private Endpoints ensure traffic stays on the Microsoft backbone, not the public internet.
    /// </summary>
    class AzureOpenAIService
    {
        private readonly DataResidencyGuard _guard;

        public AzureOpenAIService(DataResidencyGuard guard)
        {
            _guard = guard;
        }

        public async Task<string> SummarizeNotesAsync(string medicalNotes)
        {
            // Simulate network latency
            await Task.Delay(100);

            // In a real scenario, the SDK client would be configured with:
            // options.Network = "Private"; options.Region = "francecentral";
            if (!_guard.IsCompliant("francecentral"))
            {
                throw new InvalidOperationException("AI Service called from non-compliant region.");
            }

            // Simulated AI Logic
            return $"[AI Summary] Patient notes indicate: {medicalNotes.Substring(0, Math.Min(medicalNotes.Length, 20))}...";
        }

        public async Task PurgeUserDataAsync(string userId)
        {
            await Task.Delay(50);
            // Simulates calling the Delete API for specific data points used in fine-tuning or RAG.
            Console.WriteLine($"   -> (Backend) Calling DELETE /openai/deployments/.../indexes/.../docs/{userId}");
        }
    }

    /// <summary>
    /// Simulates Azure Blob Storage with Customer Managed Keys (CMK).
    /// </summary>
    class SecureStorage
    {
        private readonly string _connectionString;
        private readonly DataResidencyGuard _guard;
        // Simulating an in-memory store for the console app
        private readonly Dictionary<string, PatientRecord> _db = new Dictionary<string, PatientRecord>();

        public SecureStorage(string connectionString, DataResidencyGuard guard)
        {
            _connectionString = connectionString;
            _guard = guard;
        }

        public async Task<string> StoreAsync(PatientRecord record)
        {
            await Task.Delay(50);
            
            // Verify storage account is in the allowed region
            if (!_guard.IsCompliant("francecentral")) 
                throw new InvalidOperationException("Storage account region mismatch.");

            _db[record.Id] = record;
            return $"https://medisafeeu.blob.core.windows.net/patients/{record.Id}.enc";
        }

        public async Task DeleteAsync(string patientId)
        {
            await Task.Delay(50);
            if (_db.ContainsKey(patientId))
            {
                _db.Remove(patientId);
            }
            // In real Azure, this triggers a "Soft Delete" then "Hard Delete" after retention policy.
        }
    }

    /// <summary>
    /// Domain Model representing the data entity.
    /// </summary>
    class PatientRecord
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string MedicalNotes { get; set; }
        public string OriginRegion { get; set; } // Metadata tag for residency validation

        public PatientRecord(string id, string name, string notes)
        {
            Id = id;
            Name = name;
            MedicalNotes = notes;
            OriginRegion = "francecentral"; // Default to compliant region
        }
    }
}
