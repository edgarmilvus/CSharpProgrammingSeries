
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using Azure;
using Azure.AI.OpenAI;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using System;
using System.ClientModel;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace EnterpriseAI.GDPR
{
    /// <summary>
    /// Demonstrates a GDPR-compliant pattern for invoking Azure OpenAI 
    /// using Private Endpoints and Regional Locking.
    /// 
    /// REAL-WORLD CONTEXT:
    /// A European healthcare provider processes patient intake forms via an LLM.
    /// GDPR mandates that:
    /// 1. Data never traverses the public internet.
    /// 2. Data remains within the EU (e.g., Sweden Central).
    /// 3. Data is ephemeral (not stored for training).
    /// </summary>
    public class RegionalCompliantClient
    {
        private readonly OpenAIClient _client;
        private readonly string _deploymentName;

        public RegionalCompliantClient(string endpoint, string deploymentName)
        {
            this._deploymentName = deploymentName;

            // CRITICAL: Use DefaultAzureCredential for secure authentication.
            // In production, this utilizes Managed Identity (MI) or Service Principals,
            // avoiding the need to store secrets in code.
            var credential = new DefaultAzureCredential();

            // ARCHITECTURAL NOTE:
            // The 'endpoint' provided MUST be the Private Endpoint URL (e.g., 
            // https://my-ai.openai.azure.com) and NOT the public internet URL.
            // This ensures traffic routes through the Azure Virtual Network (VNet).
            var options = new OpenAIClientOptions
            {
                // Enforce strict regional consistency.
                // While the endpoint implies the region, this acts as a logical guardrail.
                NetworkTimeout = TimeSpan.FromSeconds(30)
            };

            _client = new OpenAIClient(new Uri(endpoint), credential, options);
        }

        public async Task<string> ProcessPatientDataAsync(string rawText)
        {
            try
            {
                // 1. DATA MINIMIZATION: We only send the necessary prompt context.
                // We do NOT send the full patient record if it's not needed.
                var prompt = $"Summarize the following patient intake notes into bullet points: {rawText}";

                var options = new ChatCompletionOptions
                {
                    // 2. EPHEMERAL PROCESSING: 
                    // 'Logprobs' and 'BestOf' parameters are left default (null) 
                    // to prevent Azure OpenAI from retaining intermediate generations 
                    // for internal optimization, adhering to the "Do Not Train" clause.
                    
                    // 3. REGIONAL COMPLIANCE CHECK:
                    // We explicitly set the API version to a stable, auditable version.
                    // Note: The actual data residency is enforced by the Azure Resource Group's region.
                    ApiVersion = "2024-02-01"
                };

                // 4. PRIVATE ENDPOINT TRAFFIC:
                // The underlying HttpClient inside OpenAIClient will resolve the 
                // DNS to the private IP within the VNet.
                var response = await _client.GetChatCompletionsAsync(
                    _deploymentName,
                    new ChatMessage(ChatRole.User, prompt),
                    options
                );

                return response.Value.Choices[0].Message.Content;
            }
            catch (RequestFailedException ex) when (ex.Status == 403)
            {
                // 5. ACCESS CONTROL:
                // 403 indicates a network or permission issue.
                // In a Private Endpoint setup, this often means the client 
                // is not joined to the correct VNet/Subnet.
                throw new InvalidOperationException(
                    "Access denied. Ensure the client is connected to the Virtual Network " +
                    "hosting the Private Endpoint and has the 'Cognitive Services User' role.", 
                    ex
                );
            }
        }
    }

    // ENTRY POINT
    class Program
    {
        static async Task Main(string[] args)
        {
            // CONFIGURATION:
            // In a real scenario, load these from Azure Key Vault.
            // Hardcoded here for the self-contained example.
            string endpoint = "https://contoso-ai.openai.azure.com/"; // Private Endpoint URL
            string deploymentName = "gpt-4o-mini";

            var processor = new RegionalCompliantClient(endpoint, deploymentName);

            // MOCK DATA: Simulating sensitive patient data.
            string sensitiveData = "Patient: John Doe. Diagnosis: Mild Hypertension. Prescribed: Lisinopril 10mg.";

            try
            {
                Console.WriteLine("Initiating GDPR-compliant processing...");
                
                // Visualizing the data flow
                VisualizeArchitecture();

                string result = await processor.ProcessPatientDataAsync(sensitiveData);
                
                Console.WriteLine("\n--- RESULT ---");
                Console.WriteLine(result);
                Console.WriteLine("--------------");
                Console.WriteLine("Processing complete. Data was not stored or transmitted over public internet.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void VisualizeArchitecture()
        {
            // Embedded visualization of the secure architecture
            string dot = @"
digraph G {
    rankdir=TB;
    node [shape=box, style=filled, color=lightblue];
    
    Client [label=""Client App\n(On-Premises or Azure VM)""];
    VNet [label=""Azure Virtual Network\n(Private Subnet)"" shape=ellipse];
    PrivateEndpoint [label=""Private Endpoint\n(Network Interface)""];
    AzureOpenAI [label=""Azure OpenAI Service\n(Regional: Sweden Central)""];
    PublicInternet [label=""Public Internet\n(Blocked)"" shape=invhouse];

    Client -> VNet [label=""VPN / ExpressRoute""];
    VNet -> PrivateEndpoint [label=""Private IP""];
    PrivateEndpoint -> AzureOpenAI [label=""Internal Traffic""];
    PublicInternet -> AzureOpenAI [label=""Blocked by NSG"" style=dashed color=red];
}";
            Console.WriteLine("\n[VISUALIZATION: Architecture Diagram]");
            Console.WriteLine(dot);
        }
    }
}
