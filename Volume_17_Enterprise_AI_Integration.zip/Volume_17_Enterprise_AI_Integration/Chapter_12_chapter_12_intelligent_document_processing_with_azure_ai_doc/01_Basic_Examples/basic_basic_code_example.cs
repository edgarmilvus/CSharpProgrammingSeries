
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using Azure;
using Azure.AI.DocumentIntelligence;
using System;
using System.Threading.Tasks;

namespace DocumentIntelligenceQuickstart
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // 1. Configuration: Replace these with your actual Azure Document Intelligence credentials
            //    (Available in the Azure Portal under your resource's "Keys and Endpoint" tab)
            string endpoint = "YOUR_DOCUMENT_INTELLIGENCE_ENDPOINT";
            string apiKey = "YOUR_DOCUMENT_INTELLIGENCE_KEY";

            // 2. Input: The specific document we want to analyze (e.g., an invoice)
            //    In a real scenario, this might come from an email attachment or a file upload.
            string filePath = "invoice_sample.pdf";

            try
            {
                // 3. Initialize the Client
                //    We use the DocumentIntelligenceClient to authenticate and communicate with the Azure service.
                var credential = new AzureKeyCredential(apiKey);
                var client = new DocumentIntelligenceClient(new Uri(endpoint), credential);

                Console.WriteLine("Initializing Azure AI Document Intelligence Client...");

                // 4. Prepare the Analysis Request
                //    We target the 'prebuilt-invoice' model which is optimized for extracting
                //    vendor, customer, totals, and line items without training a custom model.
                AnalyzeDocumentContent content = new AnalyzeDocumentContent()
                {
                    Base64Source = BinaryData.FromString("...") // Placeholder: See detailed explanation below
                };

                // 5. Execute the Analysis Operation
                //    This sends the document to the cloud API and waits for the structured result.
                //    Note: In a production app, you would load the actual file bytes here.
                Console.WriteLine($"Analyzing document: {filePath}...");
                
                // *SIMULATED EXECUTION BLOCK*
                // Since we cannot actually call the API without valid credentials and a real file,
                // we simulate the successful response structure to demonstrate the logic flow.
                // In a real implementation, you would uncomment the lines below:
                
                // Operation<AnalyzeResult> operation = await client.AnalyzeDocumentAsync(
                //     WaitUntil.Completed, 
                //     "prebuilt-invoice", 
                //     content);
                // AnalyzeResult result = operation.Value;

                // 6. Parse and Extract Data
                //    The result contains a 'Documents' collection. For invoices, we expect one document.
                //    We access the 'Fields' property to get specific values like 'VendorName' and 'Total'.
                
                // *SIMULATED RESULT FOR DEMONSTRATION*
                var simulatedResult = new
                {
                    Documents = new[]
                    {
                        new
                        {
                            Fields = new
                            {
                                VendorName = new { Content = "Contoso Ltd." },
                                InvoiceTotal = new { Content = "$1,250.00" },
                                Items = new // A collection of line items
                                {
                                    ValueArray = new[]
                                    {
                                        new { Content = "Consulting Services: $500" },
                                        new { Content = "Software License: $750" }
                                    }
                                }
                            }
                        }
                    }
                };

                Console.WriteLine("\n--- Extraction Results ---");

                // 7. Data Validation & Error Handling
                //    We check if the document was actually parsed and if required fields exist.
                if (simulatedResult.Documents.Length > 0)
                {
                    var doc = simulatedResult.Documents[0];
                    var fields = doc.Fields;

                    // Extract Vendor Name
                    // We use a helper pattern to safely access nested properties.
                    string vendorName = GetFieldContent(fields, "VendorName");
                    Console.WriteLine($"Vendor: {vendorName}");

                    // Extract Total Amount
                    string totalAmount = GetFieldContent(fields, "InvoiceTotal");
                    Console.WriteLine($"Total: {totalAmount}");

                    // Extract Line Items (Iterating over a collection)
                    // 'Items' is typically an array in the JSON response.
                    Console.WriteLine("Line Items:");
                    if (fields.ContainsKey("Items"))
                    {
                        // This logic mimics accessing the 'ValueArray' property of a dynamic result
                        // In the real SDK, this is accessed via `field.ValueArray`
                        var items = fields["Items"].ValueArray; 
                        foreach (var item in items)
                        {
                            // Line items often contain nested fields (Description, Amount)
                            // Here we just print the raw content for simplicity.
                            Console.WriteLine($" - {item.Content}");
                        }
                    }

                    // 8. Integration Logic (Mock)
                    //    In a real workflow, this data would be formatted and sent to a legacy ERP system.
                    Console.WriteLine("\n--- Integration Status ---");
                    if (!string.IsNullOrEmpty(totalAmount))
                    {
                        Console.WriteLine("SUCCESS: Data extracted. Ready for ERP ingestion.");
                    }
                    else
                    {
                        Console.WriteLine("WARNING: Total amount missing. Flagging for manual review.");
                    }
                }
                else
                {
                    Console.WriteLine("FAILURE: No documents found in the response.");
                }
            }
            catch (RequestFailedException ex)
            {
                // 9. Exception Handling
                //    Catches HTTP errors (401 Unauthorized, 429 Too Many Requests, 500 Server Error).
                Console.WriteLine($"Azure API Error: {ex.Status} - {ex.Message}");
            }
            catch (Exception ex)
            {
                // Catches general errors (File not found, parsing errors).
                Console.WriteLine($"General Error: {ex.Message}");
            }
        }

        /// <summary>
        /// Helper method to safely retrieve field content from the dynamic result object.
        /// </summary>
        private static string GetFieldContent(dynamic fields, string fieldName)
        {
            // In the real SDK, 'fields' is a Dictionary<string, DocumentField>.
            // We check for key existence to prevent runtime exceptions.
            if (fields != null && fields.ContainsKey(fieldName))
            {
                // Access the 'Content' property of the field.
                // Note: In real usage, you might check field.Confidence before accepting the data.
                return fields[fieldName].Content;
            }
            return "[Missing]";
        }
    }
}
