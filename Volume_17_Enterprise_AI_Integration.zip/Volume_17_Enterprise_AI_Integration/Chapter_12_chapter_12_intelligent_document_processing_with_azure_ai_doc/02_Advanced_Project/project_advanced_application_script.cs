
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Azure;
using Azure.AI.DocumentIntelligence;

namespace EnterpriseInvoiceProcessor
{
    // =======================================================================
    // REAL-WORLD PROBLEM CONTEXT
    // =======================================================================
    // Scenario: A mid-sized manufacturing company receives hundreds of invoices
    // daily from various suppliers in PDF format. These invoices need to be
    // processed into their legacy ERP system (e.g., SAP, Oracle, or a custom
    // .NET application).
    //
    // Challenges:
    // 1. Manual data entry is slow and error-prone.
    // 2. Invoices have varying formats (different suppliers = different layouts).
    // 3. Data must be validated before entering the ERP to prevent bad data.
    // 4. Invalid invoices must be flagged for manual review.
    //
    // Solution: This application uses Azure AI Document Intelligence to:
    // 1. Analyze invoices using the pre-built "Invoice" model.
    // 2. Extract key fields (Vendor Name, Invoice ID, Total Amount, Due Date).
    // 3. Implement validation logic (e.g., check if Total > 0).
    // 4. Format the data for ERP ingestion or flag for exception handling.
    // =======================================================================

    class Program
    {
        // Main entry point for the console application.
        static async Task Main(string[] args)
        {
            Console.WriteLine("Starting Enterprise Invoice Processor...");
            Console.WriteLine("---------------------------------------");

            // In a real scenario, you would load these from a config file or environment variables.
            // For this example, we simulate the endpoint and key.
            string endpoint = "https://<your-resource>.cognitiveservices.azure.com/";
            string apiKey = "<your-api-key>";

            // We will process a batch of invoice files.
            // In a real app, this list would be populated by reading files from a folder or blob storage.
            string[] invoiceFiles = {
                "invoice_supplier_a.pdf",
                "invoice_supplier_b.pdf",
                "invalid_invoice_no_amount.pdf"
            };

            // Initialize the processor service.
            var invoiceService = new InvoiceProcessorService(endpoint, apiKey);

            // Process each file in the batch.
            foreach (string file in invoiceFiles)
            {
                Console.WriteLine($"\nProcessing File: {file}");

                try
                {
                    // Step 1: Analyze the document using Azure AI Document Intelligence.
                    AnalyzedInvoiceResult result = await invoiceService.AnalyzeInvoiceAsync(file);

                    // Step 2: Validate the extracted data.
                    ValidationResult validation = invoiceService.ValidateInvoiceData(result);

                    // Step 3: Handle the result based on validation.
                    if (validation.IsValid)
                    {
                        // Step 3a: Format for ERP ingestion.
                        string erpPayload = invoiceService.FormatForERP(result);
                        Console.WriteLine($"SUCCESS: Ready for ERP.");
                        Console.WriteLine($"   Payload: {erpPayload}");
                    }
                    else
                    {
                        // Step 3b: Flag for manual review.
                        Console.WriteLine($"WARNING: Validation Failed.");
                        foreach (var error in validation.Errors)
                        {
                            Console.WriteLine($"   - {error}");
                        }
                        // In a real system, you might send this to a "Review Queue" (e.g., Azure Queue Storage).
                    }
                }
                catch (Exception ex)
                {
                    // Step 4: Handle system errors (e.g., API connection issues).
                    Console.WriteLine($"ERROR: Failed to process {file}. Reason: {ex.Message}");
                    // Log this exception to a monitoring system (e.g., Application Insights).
                }
            }

            Console.WriteLine("\nBatch processing complete.");
        }
    }

    // =======================================================================
    // SERVICE CLASS: InvoiceProcessorService
    // =======================================================================
    // This class encapsulates the logic for interacting with Azure AI Document
    // Intelligence and handling the business logic for validation and formatting.
    public class InvoiceProcessorService
    {
        private readonly DocumentIntelligenceClient _client;

        public InvoiceProcessorService(string endpoint, string apiKey)
        {
            // Initialize the Azure SDK client.
            // We use the AzureKeyCredential for authentication.
            var credential = new AzureKeyCredential(apiKey);
            _client = new DocumentIntelligenceClient(new Uri(endpoint), credential);
        }

        // -----------------------------------------------------------------------
        // METHOD: AnalyzeInvoiceAsync
        // -----------------------------------------------------------------------
        // Purpose: Sends the invoice document to Azure AI Document Intelligence
        //          and parses the response into a custom domain object.
        public async Task<AnalyzedInvoiceResult> AnalyzeInvoiceAsync(string filePath)
        {
            // In a real application, you would load the file bytes.
            // Here, we simulate the file content for demonstration.
            byte[] fileBytes = GetSimulatedFileBytes(filePath);

            // Prepare the input for the AnalyzeDocument method.
            // We specify the "prebuilt:invoice" model ID which is provided by Azure.
            AnalyzeDocumentContent content = new AnalyzeDocumentContent(BinaryData.FromBytes(fileBytes));
            
            // Call the Azure API.
            // Note: In a real scenario, handle retries and throttling here.
            AnalyzeResult result = await _client.AnalyzeDocumentAsync("prebuilt:invoice", content);

            // Extract the specific fields we need from the result.
            // The SDK returns a generic model; we map it to our specific needs.
            var extractedInvoice = new AnalyzedInvoiceResult();

            if (result.Documents.Count > 0)
            {
                // Grab the first document found (usually one invoice per file).
                var doc = result.Documents[0];
                
                // Helper local function to safely get field values.
                // We use basic dictionary lookups and string checks.
                string GetField(string fieldName)
                {
                    if (doc.Fields.ContainsKey(fieldName) && doc.Fields[fieldName].Value != null)
                    {
                        return doc.Fields[fieldName].Value.ToString();
                    }
                    return null;
                }

                extractedInvoice.VendorName = GetField("VendorName");
                extractedInvoice.InvoiceId = GetField("InvoiceId");
                extractedInvoice.InvoiceTotal = GetField("Total");
                extractedInvoice.DueDate = GetField("DueDate");
            }

            return extractedInvoice;
        }

        // -----------------------------------------------------------------------
        // METHOD: ValidateInvoiceData
        // -----------------------------------------------------------------------
        // Purpose: Applies business rules to the extracted data to ensure
        //          integrity before sending to the ERP.
        public ValidationResult ValidateInvoiceData(AnalyzedInvoiceResult invoice)
        {
            var validation = new ValidationResult();
            validation.Errors = new List<string>();

            // Rule 1: Vendor Name is mandatory.
            if (string.IsNullOrWhiteSpace(invoice.VendorName))
            {
                validation.Errors.Add("Vendor Name is missing.");
            }

            // Rule 2: Invoice ID is mandatory.
            if (string.IsNullOrWhiteSpace(invoice.InvoiceId))
            {
                validation.Errors.Add("Invoice ID is missing.");
            }

            // Rule 3: Total Amount must be present and greater than zero.
            if (string.IsNullOrWhiteSpace(invoice.InvoiceTotal))
            {
                validation.Errors.Add("Invoice Total is missing.");
            }
            else
            {
                // Basic parsing logic (avoiding advanced features like LINQ/Regex).
                if (double.TryParse(invoice.InvoiceTotal, out double total))
                {
                    if (total <= 0)
                    {
                        validation.Errors.Add("Invoice Total must be greater than zero.");
                    }
                }
                else
                {
                    validation.Errors.Add("Invoice Total is not a valid number.");
                }
            }

            // Rule 4: Due Date should not be in the past (basic check).
            if (!string.IsNullOrWhiteSpace(invoice.DueDate))
            {
                if (DateTime.TryParse(invoice.DueDate, out DateTime dueDate))
                {
                    if (dueDate < DateTime.Now.Date)
                    {
                        validation.Errors.Add("Invoice Due Date is in the past.");
                    }
                }
            }

            // If no errors were added, the result is valid.
            if (validation.Errors.Count == 0)
            {
                validation.IsValid = true;
            }
            else
            {
                validation.IsValid = false;
            }

            return validation;
        }

        // -----------------------------------------------------------------------
        // METHOD: FormatForERP
        // -----------------------------------------------------------------------
        // Purpose: Converts the validated invoice object into a standardized
        //          format (e.g., CSV or JSON string) for the legacy ERP system.
        public string FormatForERP(AnalyzedInvoiceResult invoice)
        {
            // Simple CSV format for legacy ingestion.
            // Format: Vendor,InvoiceID,Amount,DueDate
            // Example: "Contoso Ltd,INV-10234,1500.00,2023-12-01"
            
            // Sanitize data to prevent CSV injection or formatting issues.
            string vendor = SanitizeCsvField(invoice.VendorName);
            string id = SanitizeCsvField(invoice.InvoiceId);
            string total = SanitizeCsvField(invoice.InvoiceTotal);
            string date = SanitizeCsvField(invoice.DueDate);

            return $"{vendor},{id},{total},{date}";
        }

        // Helper method to simulate reading file bytes.
        private byte[] GetSimulatedFileBytes(string fileName)
        {
            // In reality: return File.ReadAllBytes(fileName);
            return System.Text.Encoding.UTF8.GetBytes($"Simulated content for {fileName}");
        }

        // Helper method to sanitize strings for CSV.
        private string SanitizeCsvField(string input)
        {
            if (string.IsNullOrEmpty(input)) return "";

            // If the string contains a comma, wrap it in quotes.
            if (input.Contains(','))
            {
                return $"\"{input}\"";
            }
            return input;
        }
    }

    // =======================================================================
    // DATA MODELS
    // =======================================================================
    // Simple classes to hold data. We avoid Records (as per constraints)
    // and use standard classes with properties.

    public class AnalyzedInvoiceResult
    {
        public string VendorName { get; set; }
        public string InvoiceId { get; set; }
        public string InvoiceTotal { get; set; }
        public string DueDate { get; set; }
    }

    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public List<string> Errors { get; set; }
    }
}
