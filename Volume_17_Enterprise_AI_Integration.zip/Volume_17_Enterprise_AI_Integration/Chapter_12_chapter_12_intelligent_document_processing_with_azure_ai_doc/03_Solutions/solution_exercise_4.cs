
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// Mock interfaces for the exercise
public interface IErpSystemConnector
{
    Task PushInvoiceAsync(InvoiceData invoice);
}

public interface IErrorQueuePublisher
{
    Task PublishAsync(InvoiceData invoice, List<string> errors);
}

// Result object for the stream processing
public record ValidationResult(bool IsValid, string InvoiceId, List<string> Errors);

public class DataValidationGateway
{
    private readonly IErpSystemConnector _erpConnector;
    private readonly IErrorQueuePublisher _errorQueue;

    public DataValidationGateway(IErpSystemConnector erpConnector, IErrorQueuePublisher errorQueue)
    {
        _erpConnector = erpConnector;
        _errorQueue = errorQueue;
    }

    // 1. Process a stream of documents using IAsyncEnumerable
    public async IAsyncEnumerable<ValidationResult> ValidateAndRouteAsync(IAsyncEnumerable<InvoiceData> documentStream)
    {
        await foreach (var invoice in documentStream)
        {
            var errors = ValidateInvoice(invoice);

            if (errors.Count == 0)
            {
                try
                {
                    await _erpConnector.PushInvoiceAsync(invoice);
                    yield return new ValidationResult(true, invoice.InvoiceId, new List<string>());
                }
                catch (Exception ex)
                {
                    // If ERP push fails, treat as validation failure for this exercise
                    yield return new ValidationResult(false, invoice.InvoiceId, new List<string> { $"ERP System Error: {ex.Message}" });
                }
            }
            else
            {
                // Route to dead-letter queue
                await _errorQueue.PublishAsync(invoice, errors);
                yield return new ValidationResult(false, invoice.InvoiceId, errors);
            }
        }
    }

    private List<string> ValidateInvoice(InvoiceData invoice)
    {
        var errors = new List<string>();

        // 1. Presence Checks
        if (string.IsNullOrWhiteSpace(invoice.InvoiceId)) errors.Add("InvoiceId is missing.");
        if (string.IsNullOrWhiteSpace(invoice.VendorName)) errors.Add("VendorName is missing.");
        if (invoice.TotalAmount <= 0) errors.Add("TotalAmount must be greater than 0.");

        // 2. Format Checks (Date parsing is usually handled by deserializer, but checking defaults)
        if (invoice.InvoiceDate == default) errors.Add("InvoiceDate is invalid or missing.");

        // 3. Business Logic Checks
        if (invoice.DueDate != default && invoice.DueDate <= invoice.InvoiceDate)
        {
            errors.Add("DueDate must be after InvoiceDate.");
        }

        return errors;
    }
}

// Extension to InvoiceData to support DueDate for this exercise
public static class InvoiceDataExtensions
{
    public static InvoiceData WithDueDate(this InvoiceData invoice, DateTime dueDate)
    {
        // In a real app, DueDate would be part of the record definition
        return invoice; // simplified
    }
}
