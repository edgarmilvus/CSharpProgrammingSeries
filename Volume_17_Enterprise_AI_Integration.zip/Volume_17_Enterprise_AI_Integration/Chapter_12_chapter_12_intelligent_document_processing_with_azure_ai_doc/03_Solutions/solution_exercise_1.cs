
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

// Custom exception for timeout scenarios
public class DocumentAnalysisTimeoutException : Exception
{
    public DocumentAnalysisTimeoutException(string message) : base(message) { }
}

// Result model (simplified for example)
public class AnalyzedDocument
{
    public string DocumentType { get; set; }
    public object Fields { get; set; }
    public string Status { get; set; }
}

// Client interface for testability
public interface IAnalyzeResultClient
{
    Task<AnalyzedDocument> AnalyzeDocumentAsync(byte[] documentBytes, string modelId, CancellationToken cancellationToken = default);
}

public class AnalyzeResultClient : IAnalyzeResultClient
{
    private readonly HttpClient _httpClient;
    private readonly JsonSerializerOptions _jsonOptions;
    private readonly TimeSpan _defaultTimeout;

    public AnalyzeResultClient(HttpClient httpClient, TimeSpan? defaultTimeout = null)
    {
        _httpClient = httpClient;
        _defaultTimeout = defaultTimeout ?? TimeSpan.FromMinutes(5);
        _jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
    }

    public async Task<AnalyzedDocument> AnalyzeDocumentAsync(byte[] documentBytes, string modelId, CancellationToken cancellationToken = default)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(_defaultTimeout);

        // 1. Initial POST request
        using var content = new ByteArrayContent(documentBytes);
        content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf"); // Simplified content type

        var analyzeUrl = $"documentModels/{modelId}:analyze?api-version=2023-10-31-preview"; // Adjust API version as needed
        var response = await _httpClient.PostAsync(analyzeUrl, content, cts.Token);

        if (response.StatusCode != System.Net.HttpStatusCode.Accepted)
        {
            throw new HttpRequestException($"Initial analysis request failed: {response.StatusCode}");
        }

        // 2. Extract Operation-Location
        if (!response.Headers.TryGetValues("Operation-Location", out var operationLocationValues))
        {
            throw new InvalidOperationException("Operation-Location header missing from response.");
        }

        var operationLocationUrl = operationLocationValues.First();
        
        // 3. Poll for result
        return await PollForResultAsync(operationLocationUrl, cts.Token);
    }

    private async Task<AnalyzedDocument> PollForResultAsync(string operationLocationUrl, CancellationToken cancellationToken)
    {
        var startTime = DateTime.UtcNow;
        
        while (!cancellationToken.IsCancellationRequested)
        {
            var response = await _httpClient.GetAsync(operationLocationUrl, cancellationToken);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync(cancellationToken);
                return JsonSerializer.Deserialize<AnalyzedDocument>(jsonResponse, _jsonOptions);
            }

            if (response.StatusCode != System.Net.HttpStatusCode.Accepted)
            {
                throw new HttpRequestException($"Polling failed with status: {response.StatusCode}");
            }

            // 4. Handle Retry-After or Exponential Backoff
            TimeSpan delay;
            if (response.Headers.TryGetValues("Retry-After", out var retryAfterValues) && int.TryParse(retryAfterValues.First(), out int retrySeconds))
            {
                delay = TimeSpan.FromSeconds(retrySeconds);
            }
            else
            {
                // Simple exponential backoff logic (simplified for brevity)
                // In a real scenario, track attempt count to calculate backoff
                delay = TimeSpan.FromSeconds(1); 
            }

            // Check for overall timeout
            if (DateTime.UtcNow - startTime > _defaultTimeout)
            {
                throw new DocumentAnalysisTimeoutException($"Operation timed out after {_defaultTimeout.TotalMinutes} minutes.");
            }

            await Task.Delay(delay, cancellationToken);
        }

        throw new OperationCanceledException("Polling was cancelled.");
    }
}
