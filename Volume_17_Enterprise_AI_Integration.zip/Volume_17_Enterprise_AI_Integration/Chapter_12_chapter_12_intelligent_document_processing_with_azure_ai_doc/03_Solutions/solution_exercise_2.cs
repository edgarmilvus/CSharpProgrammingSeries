
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

public class ModelLifecycleManager
{
    private readonly HttpClient _httpClient;
    private readonly JsonSerializerOptions _jsonOptions;

    public ModelLifecycleManager(HttpClient httpClient)
    {
        _httpClient = httpClient;
        _jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
    }

    // DTO for training status response
    private record TrainingStatusResponse(string Status, string Error?);

    // 1. Train Model
    public async Task<(string ModelId, string OperationLocation)> TrainModelAsync(string sourceUrl, CancellationToken cancellationToken = default)
    {
        var payload = new { source = sourceUrl };
        // Endpoint for building a model (v3.0 or later syntax)
        var response = await _httpClient.PostAsJsonAsync("documentModels:build?api-version=2023-10-31-preview", payload, cancellationToken);

        if (response.StatusCode != System.Net.HttpStatusCode.Accepted)
        {
            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
            throw new HttpRequestException($"Training request failed: {response.StatusCode}. Details: {errorContent}");
        }

        if (!response.Headers.TryGetValues("Operation-Location", out var opLocation))
        {
            throw new InvalidOperationException("Operation-Location header missing.");
        }

        // The Model ID is often returned in the 'Location' header or the body, 
        // but for 'build' operations, we usually track via the Operation-Location.
        // For this exercise, we assume the Model ID is derivable or returned in a header (simplified).
        // In Azure AI Document Intelligence, the Model ID is returned in the 'Location' header upon 202 Accepted.
        var modelId = response.Headers.Location?.Segments.Last() ?? "unknown-model-id"; 

        return (modelId, opLocation.First());
    }

    // 2. Get Training Status (Polling)
    public async Task<string> GetTrainingStatusAsync(string operationLocationUrl, CancellationToken cancellationToken = default)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            var response = await _httpClient.GetAsync(operationLocationUrl, cancellationToken);
            
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var statusData = await response.Content.ReadFromJsonAsync<TrainingStatusResponse>(_jsonOptions, cancellationToken);
                
                if (statusData?.Status == "succeeded") return "Succeeded";
                if (statusData?.Status == "failed") 
                {
                    throw new Exception($"Training failed: {statusData.Error ?? "Unknown error"}");
                }
                
                // Still processing, wait and retry
                await Task.Delay(2000, cancellationToken); // Fixed delay for simplicity
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Accepted)
            {
                await Task.Delay(2000, cancellationToken);
            }
            else
            {
                throw new HttpRequestException($"Status check failed: {response.StatusCode}");
            }
        }
        throw new OperationCanceledException("Status check cancelled.");
    }

    // 3. Delete Model
    public async Task DeleteModelAsync(string modelId, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.DeleteAsync($"documentModels/{modelId}?api-version=2023-10-31-preview", cancellationToken);

        if (response.StatusCode == System.Net.HttpStatusCode.NoContent) return;
        
        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            throw new HttpRequestException($"Model {modelId} not found.");
        }

        var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
        throw new HttpRequestException($"Deletion failed: {response.StatusCode}. Details: {errorContent}");
    }
}
