
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Transactions;

// --- 1. Data Models (Using Records) ---
public record LineItem(string Description, decimal Amount);
public record InvoiceData(string InvoiceId, string VendorName, decimal TotalAmount, DateTime InvoiceDate, List<LineItem> LineItems);

// --- 2. Interfaces (Abstractions) ---
public interface IDocumentIntelligenceClient
{
    Task<InvoiceData> ExtractInvoiceDataAsync(byte[] documentBytes);
}

public interface IInvoiceDataRepository
{
    Task SaveInvoiceAsync(InvoiceData invoice);
}

// --- 3. Service Implementation ---
public class InvoiceProcessingService
{
    private readonly IDocumentIntelligenceClient _docClient;
    private readonly IInvoiceDataRepository _repository;

    public InvoiceProcessingService(IDocumentIntelligenceClient docClient, IInvoiceDataRepository repository)
    {
        _docClient = docClient;
        _repository = repository;
    }

    public async Task ProcessInvoiceAsync(byte[] documentBytes)
    {
        // 1. Extraction
        var invoiceData = await _docClient.ExtractInvoiceDataAsync(documentBytes);

        // 2. Validation
        if (!ValidateInvoice(invoiceData, out var validationErrors))
        {
            // In a real app, log errors or push to a dead-letter queue
            throw new InvalidOperationException($"Validation failed: {string.Join(", ", validationErrors)}");
        }

        // 3. Persistence
        await _repository.SaveInvoiceAsync(invoiceData);
    }

    private bool ValidateInvoice(InvoiceData invoice, out List<string> errors)
    {
        errors = new List<string>();
        
        // Business Rule: Total must match sum of line items
        var lineItemSum = invoice.LineItems.Sum(li => li.Amount);
        if (invoice.TotalAmount != lineItemSum)
        {
            errors.Add($"Total amount ({invoice.TotalAmount}) does not match line item sum ({lineItemSum}).");
        }

        // Presence checks
        if (string.IsNullOrWhiteSpace(invoice.InvoiceId)) errors.Add("Invoice ID is required.");
        
        return errors.Count == 0;
    }
}

// --- 4. Concrete Implementations ---

// Implementation using HttpClientFactory (Conceptual)
public class DocumentIntelligenceClient : IDocumentIntelligenceClient
{
    private readonly HttpClient _httpClient;

    public DocumentIntelligenceClient(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<InvoiceData> ExtractInvoiceDataAsync(byte[] documentBytes)
    {
        // Calls Azure AI Document Intelligence API
        // Deserializes JSON response into InvoiceData record
        // Omitted for brevity, follows similar pattern to Exercise 1
        await Task.Delay(100); // Simulate API call
        return new InvoiceData("INV-1001", "Contoso", 150.00m, DateTime.Now, new List<LineItem> { new LineItem("Widget", 150.00m) });
    }
}

// Implementation using ADO.NET with TransactionScope
public class SqlInvoiceRepository : IInvoiceDataRepository
{
    private readonly string _connectionString;

    public SqlInvoiceRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task SaveInvoiceAsync(InvoiceData invoice)
    {
        // Using TransactionScope for atomicity
        using var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled);
        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();

        // Insert Header
        var cmdHeader = new SqlCommand("INSERT INTO Invoices (Id, Vendor, Total, Date) VALUES (@id, @vendor, @total, @date)", connection);
        cmdHeader.Parameters.AddWithValue("@id", invoice.InvoiceId);
        cmdHeader.Parameters.AddWithValue("@vendor", invoice.VendorName);
        cmdHeader.Parameters.AddWithValue("@total", invoice.TotalAmount);
        cmdHeader.Parameters.AddWithValue("@date", invoice.InvoiceDate);
        await cmdHeader.ExecuteNonQueryAsync();

        // Insert Line Items
        foreach (var item in invoice.LineItems)
        {
            var cmdLine = new SqlCommand("INSERT INTO LineItems (InvoiceId, Description, Amount) VALUES (@id, @desc, @amt)", connection);
            cmdLine.Parameters.AddWithValue("@id", invoice.InvoiceId);
            cmdLine.Parameters.AddWithValue("@desc", item.Description);
            cmdLine.Parameters.AddWithValue("@amt", item.Amount);
            await cmdLine.ExecuteNonQueryAsync();
        }

        scope.Complete(); // Commit transaction
    }
}
