
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

// Models for Event Grid Webhook payload
public record EventGridEvent(string Id, string EventType, string Subject, DateTime EventTime, object Data);
public record CloudEvent<T>(string Id, string Type, string Source, DateTime Time, T Data);

// Mock service
public interface INotificationService
{
    Task SendNotificationAsync(string message);
}

public static class WebhookReceiver
{
    // Simple in-memory store for idempotency (Note: This resets on function restart)
    private static readonly HashSet<string> ProcessedEvents = new HashSet<string>();
    private const string ValidationCodeHeader = "aeg-sas-key"; // Or query param

    [FunctionName("WebhookReceiver")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        // 1. Security Validation (Simplified for Azure Event Grid)
        // In production, validate the 'aeg-sas-key' header or query parameter matches your subscription key.
        if (!req.Headers.TryGetValue(ValidationCodeHeader, out var validationKey) || validationKey != "YourSecretKey")
        {
            return new UnauthorizedResult();
        }

        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        
        // 2. Handle Validation Handshake (Event Grid Subscription Validation)
        // Event Grid sends a validation request with a validationCode in the data payload.
        try 
        {
            var events = JsonSerializer.Deserialize<List<EventGridEvent>>(requestBody);
            if (events != null && events.Count > 0)
            {
                var firstEvent = events.First();
                
                // Check if it's a subscription validation event
                if (firstEvent.EventType == "Microsoft.EventGrid.SubscriptionValidationEvent")
                {
                    var data = JsonSerializer.Deserialize<ValidationEventData>(firstEvent.Data.ToString());
                    return new OkObjectResult(new { validationResponse = data.ValidationCode });
                }

                // 3. Process Actual Notifications & Idempotency
                foreach (var eventItem in events)
                {
                    if (ProcessedEvents.Contains(eventItem.Id))
                    {
                        log.LogInformation($"Event {eventItem.Id} already processed. Skipping.");
                        continue;
                    }

                    // Mark as processed
                    ProcessedEvents.Add(eventItem.Id);

                    // Extract Operation-Location from Data (assuming Data is a string URL or object)
                    var operationLocationUrl = eventItem.Data.ToString(); // Simplified extraction

                    // Trigger downstream process
                    var notificationService = new MockNotificationService(); // In real app, inject via DI
                    await notificationService.SendNotificationAsync($"Document processed. Check status at: {operationLocationUrl}");
                }
            }
        }
        catch (JsonException ex)
        {
            log.LogError(ex, "Failed to parse webhook payload.");
            return new BadRequestObjectResult("Invalid JSON payload.");
        }

        return new OkResult();
    }
}

// Mock implementation for the exercise
public class MockNotificationService : INotificationService
{
    public Task SendNotificationAsync(string message)
    {
        // Logic to send email/Teams message
        Console.WriteLine($"NOTIFICATION: {message}");
        return Task.CompletedTask;
    }
}

// Helper class for validation handshake
public class ValidationEventData
{
    public string ValidationCode { get; set; }
}
