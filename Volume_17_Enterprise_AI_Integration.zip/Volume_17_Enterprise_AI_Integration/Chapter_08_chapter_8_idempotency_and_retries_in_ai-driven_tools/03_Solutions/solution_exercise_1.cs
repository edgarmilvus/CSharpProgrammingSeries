
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

public enum PaymentStatus { Pending, Completed, Failed }

public record PaymentRequest(
    decimal Amount,
    string Currency,
    string MerchantId,
    string? IdempotencyKey = null
);

public record PaymentResult(
    string IdempotencyKey,
    PaymentStatus Status,
    string TransactionId
);

public class PaymentService
{
    // Thread-safe persistent store simulation
    private readonly ConcurrentDictionary<string, PaymentStatus> _store = new();
    private readonly Random _random = new();

    public async Task<PaymentResult> ProcessPaymentAsync(PaymentRequest request)
    {
        // 1. Generate deterministic key if not provided
        string idempotencyKey = request.IdempotencyKey ?? GenerateIdempotencyKey(request);

        // 2. Check store for existing status
        if (_store.TryGetValue(idempotencyKey, out var existingStatus))
        {
            if (existingStatus == PaymentStatus.Completed)
            {
                // Return existing result immediately (Idempotency)
                return new PaymentResult(idempotencyKey, existingStatus, $"TXN-{idempotencyKey[..8]}");
            }
            if (existingStatus == PaymentStatus.Pending)
            {
                // Handle concurrent operation in progress
                throw new InvalidOperationException("Concurrent operation detected. Please retry later.");
            }
            // If Failed, we allow retry (business decision), so fall through to processing logic
        }

        // 3. Register pending status atomically
        // TryAdd returns false if key exists; if so, we lost the race to another thread
        if (!_store.TryAdd(idempotencyKey, PaymentStatus.Pending))
        {
             throw new InvalidOperationException("Race condition detected. Request is already being processed.");
        }

        try
        {
            // 4. Simulate network call
            await Task.Delay(100); // Simulate latency
            bool isSuccess = _random.NextDouble() > 0.3; // 70% success rate

            var finalStatus = isSuccess ? PaymentStatus.Completed : PaymentStatus.Failed;
            
            // 5. Update store status
            _store.AddOrUpdate(idempotencyKey, finalStatus, (key, oldVal) => finalStatus);

            return new PaymentResult(idempotencyKey, finalStatus, isSuccess ? $"TXN-{Guid.NewGuid()}" : "FAILED");
        }
        catch (Exception)
        {
            // Ensure we clean up or mark as failed on exception
            _store.AddOrUpdate(idempotencyKey, PaymentStatus.Failed, (key, oldVal) => PaymentStatus.Failed);
            throw;
        }
    }

    private string GenerateIdempotencyKey(PaymentRequest request)
    {
        // Deterministic hash based on Merchant, Amount, and current minute (drifts over time)
        // In a real scenario, you might use a unique client-generated ID or a stricter hash.
        var source = $"{request.MerchantId}-{request.Amount}-{request.Currency}-{DateTime.UtcNow:yyyyMMddHHmm}";
        
        using var sha256 = SHA256.Create();
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(source));
        return Convert.ToBase64String(bytes);
    }
}
