
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IDocumentState
{
    Task EnterAsync(DocumentContext context);
    Task ExecuteAsync(DocumentContext context);
    Task ExitAsync(DocumentContext context);
}

public class DocumentContext
{
    public Guid ProcessId { get; } = Guid.NewGuid();
    public string Payload { get; set; } = string.Empty;
    public IDocumentState CurrentState { get; private set; }

    // Simulated Database
    private static readonly Dictionary<Guid, string> _db = new();

    public DocumentContext(IDocumentState initialState)
    {
        CurrentState = initialState;
    }

    public async Task TransitionTo(IDocumentState state)
    {
        Console.WriteLine($"Context: Transitioning to {state.GetType().Name}");
        CurrentState = state;
        
        // Persist state to simulated DB
        lock (_db) // Simulate thread-safe DB write
        {
            _db[ProcessId] = state.GetType().Name;
        }

        await CurrentState.EnterAsync(this);
    }
}

// --- Concrete States ---

public class Ingesting : IDocumentState
{
    public async Task EnterAsync(DocumentContext context) => await Task.Delay(100); // Simulate work
    public async Task ExecuteAsync(DocumentContext context) => await context.TransitionTo(new Parsing());
    public async Task ExitAsync(DocumentContext context) => await Task.CompletedTask;
}

public class Parsing : IDocumentState
{
    public async Task EnterAsync(DocumentContext context) => await Task.Delay(100);
    public async Task ExecuteAsync(DocumentContext context) => await context.TransitionTo(new Analyzing());
    public async Task ExitAsync(DocumentContext context) => await Task.CompletedTask;
}

public class Analyzing : IDocumentState
{
    public async Task EnterAsync(DocumentContext context) => await Task.Delay(100);
    
    public async Task ExecuteAsync(DocumentContext context)
    {
        // Simulate failure condition
        if (context.Payload.Contains("ERROR"))
        {
            Console.WriteLine("Analysis failed: Payload contains 'ERROR'.");
            await context.TransitionTo(new Failed());
        }
        else
        {
            await context.TransitionTo(new Summarizing());
        }
    }
    
    public async Task ExitAsync(DocumentContext context) => await Task.CompletedTask;
}

public class Summarizing : IDocumentState
{
    public async Task EnterAsync(DocumentContext context) => await Task.Delay(100);
    public async Task ExecuteAsync(DocumentContext context) => await context.TransitionTo(new Archiving());
    public async Task ExitAsync(DocumentContext context) => await Task.CompletedTask;
}

public class Archiving : IDocumentState
{
    public async Task EnterAsync(DocumentContext context) => await Task.Delay(100);
    public async Task ExecuteAsync(DocumentContext context) 
    {
        Console.WriteLine("Process Complete: Archived.");
    }
    public async Task ExitAsync(DocumentContext context) => await Task.CompletedTask;
}

public class Failed : IDocumentState
{
    public async Task EnterAsync(DocumentContext context) => await Task.Delay(50);
    
    public async Task ExecuteAsync(DocumentContext context)
    {
        Console.WriteLine("In Failed State. Choose action: (R)etry Analysis or (A)bort?");
        // Simulating automatic retry for the challenge requirement
        Console.WriteLine("Automatically retrying analysis...");
        await context.TransitionTo(new Analyzing());
    }

    public async Task ExitAsync(DocumentContext context) => await Task.CompletedTask;
}

// --- Main Execution ---

public class DocumentProcessor
{
    public async Task ProcessQueueAsync()
    {
        var documents = new List<DocumentContext>
        {
            new(new Ingesting()) { Payload = "Valid Document" },
            new(new Ingesting()) { Payload = "Document with ERROR" }
        };

        foreach (var doc in documents)
        {
            Console.WriteLine($"\n--- Starting Process: {doc.ProcessId} ---");
            // Loop until terminal state (Archiving) or manual break
            while (doc.CurrentState is not Archiving)
            {
                await doc.CurrentState.ExecuteAsync(doc);
                
                // Safety break for the Failed state retry simulation to avoid infinite loop in this demo
                if (doc.CurrentState is Failed) 
                {
                    // In the 'Failed' ExecuteAsync logic above, we transitioned back to Analyzing.
                    // If we wanted to stop, we would break here.
                    continue; 
                }
            }
        }
    }
}
