
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public interface IWorkflowStep
{
    Task<StepResult> ExecuteAsync(object input);
}

public record StepResult(string StepName, bool IsSuccess, object Output);

public class WorkflowOrchestrator
{
    private readonly IEnumerable<IWorkflowStep> _steps;
    private readonly CircuitBreaker _circuitBreaker;

    public WorkflowOrchestrator(IEnumerable<IWorkflowStep> steps)
    {
        _steps = steps;
        _circuitBreaker = new CircuitBreaker(failureThreshold: 3, timeoutSeconds: 2);
    }

    public async Task<ConcurrentBag<StepResult>> ProcessBatchConcurrentlyAsync(IEnumerable<object> inputs)
    {
        var results = new ConcurrentBag<StepResult>();
        
        // Process inputs in parallel
        await Parallel.ForEachAsync(inputs, async (input, cancellationToken) =>
        {
            // Use Circuit Breaker for the execution
            try
            {
                // We wrap the entire sequence for this input in the circuit breaker,
                // or we could wrap specific external calls. Here we wrap the whole sequence 
                // as if the workflow is a single unit of work against an external system.
                var finalResult = await _circuitBreaker.ExecuteAsync(async () =>
                {
                    object currentOutput = input;
                    foreach (var step in _steps)
                    {
                        var result = await step.ExecuteAsync(currentOutput);
                        if (!result.IsSuccess) throw new Exception($"Step {result.StepName} failed"); // Trigger CB
                        currentOutput = result.Output;
                    }
                    return new StepResult("Workflow", true, currentOutput);
                });
                
                results.Add(finalResult);
            }
            catch (Exception ex)
            {
                // If Circuit Breaker is open or the step fails, log failure
                results.Add(new StepResult("Workflow", false, ex.Message));
            }
        });

        return results;
    }
}

public class CircuitBreaker
{
    private int _failureCount = 0;
    private CircuitState _state = CircuitState.Closed;
    private DateTime _lastFailureTime = DateTime.MinValue;
    private readonly int _failureThreshold;
    private readonly TimeSpan _timeout;

    // Thread-safe lock object
    private readonly object _lock = new();

    public CircuitBreaker(int failureThreshold, int timeoutSeconds)
    {
        _failureThreshold = failureThreshold;
        _timeout = TimeSpan.FromSeconds(timeoutSeconds);
    }

    public async Task<T> ExecuteAsync<T>(Func<Task<T>> operation)
    {
        if (IsCircuitOpen())
        {
            // If Half-Open, we allow one trial. If Closed, we proceed.
            // If Open, we throw immediately.
            throw new CircuitBreakerOpenException("Circuit is OPEN. Request rejected.");
        }

        try
        {
            var result = await operation();
            OnSuccess();
            return result;
        }
        catch (Exception)
        {
            OnFailure();
            throw;
        }
    }

    private bool IsCircuitOpen()
    {
        lock (_lock)
        {
            if (_state == CircuitState.Closed) return false;

            if (_state == CircuitState.Open)
            {
                // Check if timeout has passed to switch to Half-Open
                if (DateTime.UtcNow - _lastFailureTime > _timeout)
                {
                    _state = CircuitState.HalfOpen;
                    Console.WriteLine("Circuit Breaker: Half-Open (Testing recovery)");
                    return false; // Allow one trial
                }
                return true;
            }

            // Half-Open allows execution
            return false;
        }
    }

    private void OnSuccess()
    {
        lock (_lock)
        {
            _failureCount = 0;
            _state = CircuitState.Closed;
            if (_state == CircuitState.HalfOpen)
            {
                Console.WriteLine("Circuit Breaker: Closed (Recovered)");
            }
        }
    }

    private void OnFailure()
    {
        lock (_lock)
        {
            _failureCount++;
            _lastFailureTime = DateTime.UtcNow;

            if (_state == CircuitState.HalfOpen || _failureCount >= _failureThreshold)
            {
                _state = CircuitState.Open;
                Console.WriteLine($"Circuit Breaker: OPEN (Failures: {_failureCount})");
            }
        }
    }
}

public enum CircuitState { Closed, Open, HalfOpen }
public class CircuitBreakerOpenException : Exception 
{
    public CircuitBreakerOpenException(string msg) : base(msg) { }
}

// --- Mock Step for Testing ---
public class ExternalApiStep : IWorkflowStep
{
    private readonly Random _random = new();
    public async Task<StepResult> ExecuteAsync(object input)
    {
        await Task.Delay(50);
        // Simulate random failures
        if (_random.NextDouble() < 0.4) 
        {
            return new StepResult("ExternalAPI", false, input);
        }
        return new StepResult("ExternalAPI", true, input);
    }
}
