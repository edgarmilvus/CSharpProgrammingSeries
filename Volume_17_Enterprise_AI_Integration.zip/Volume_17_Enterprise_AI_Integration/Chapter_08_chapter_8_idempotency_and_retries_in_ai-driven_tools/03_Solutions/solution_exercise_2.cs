
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Threading.Tasks;

public class RateLimitExceededException : Exception { }
public class MaxRetriesExceededException : Exception 
{
    public MaxRetriesExceededException(string message) : base(message) { }
}

public class AIIntegrationService
{
    private readonly Random _random = new();
    private int _callCounter = 0;

    public async Task<string> CallAIModelAsync(string prompt)
    {
        // Simulate API behavior: fail first 3 times, succeed on 4th
        _callCounter++;
        if (_callCounter <= 3)
        {
            throw new RateLimitExceededException();
        }
        
        // Simulate processing time
        await Task.Delay(50); 
        return $"Result for: {prompt}";
    }

    public async Task<string> ExecuteWithRetryAsync(string prompt)
    {
        const int maxRetries = 5;
        const double baseDelayMs = 100; // Base delay in milliseconds

        for (int attempt = 0; attempt <= maxRetries; attempt++)
        {
            try
            {
                return await CallAIModelAsync(prompt);
            }
            catch (RateLimitExceededException)
            {
                if (attempt == maxRetries)
                {
                    throw new MaxRetriesExceededException($"Failed after {maxRetries + 1} attempts.");
                }

                // Calculate Exponential Backoff: base * 2^attempt
                double backoff = baseDelayMs * Math.Pow(2, attempt);
                
                // Add Jitter: random value between 0 and 1000ms
                double jitter = _random.Next(0, 1000);
                double totalDelay = backoff + jitter;

                Console.WriteLine($"Attempt {attempt + 1} failed. Retrying in {totalDelay:F2}ms...");

                await Task.Delay(TimeSpan.FromMilliseconds(totalDelay));
            }
        }

        throw new MaxRetriesExceededException("Unexpected control flow.");
    }
}
