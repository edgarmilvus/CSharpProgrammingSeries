
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

/// <summary>
/// A self-contained demonstration of an Idempotent Retry Handler for a legacy system.
/// </summary>
public class IdempotentRefundProcessor
{
    // --- Configuration & State ---

    // Simulates the external legacy system we are integrating with.
    private readonly LegacyRefundGateway _legacyGateway;
    
    // A simple in-memory store for tracking processed requests.
    // In a real system, this would be a distributed cache (Redis) or a database.
    private readonly HashSet<string> _processedIdempotencyKeys = new();

    public IdempotentRefundProcessor()
    {
        // Initialize the gateway with a high failure rate to simulate flakiness.
        _legacyGateway = new LegacyRefundGateway(failureRate: 0.6); 
    }

    /// <summary>
    /// The main entry point for the AI tool to request a refund.
    /// Handles idempotency and retries automatically.
    /// </summary>
    public async Task<RefundResult> ProcessRefundAsync(string transactionId, decimal amount)
    {
        // 1. Generate a deterministic Idempotency Key.
        // This key ensures that even if we retry this method 10 times, 
        // the backend logic (or our handler) treats it as the same operation.
        string idempotencyKey = $"REFUND_{transactionId}_{amount}";

        Console.WriteLine($"[AI Assistant] Requesting refund for Tx: {transactionId}. Key: {idempotencyKey}");

        // 2. Check for existing execution (Optimistic Concurrency / Record-Keeping).
        // If we crashed after sending to the gateway but before replying to the user,
        // this check allows us to resume the operation safely.
        if (_processedIdempotencyKeys.Contains(idempotencyKey))
        {
            Console.WriteLine($"[System] Detected duplicate request. Retrieving previous result...");
            return new RefundResult { Status = "Success", Message = "Refund processed previously (idempotent check)." };
        }

        // 3. Execute the operation with Exponential Backoff Retry Logic.
        var result = await ExecuteWithRetryAsync(
            operation: () => _legacyGateway.IssueRefund(idempotencyKey, amount),
            maxRetries: 5
        );

        // 4. Persist the result ONLY if the operation was successful.
        // This is crucial. We only mark it as 'done' after we are sure.
        if (result.IsSuccess)
        {
            _processedIdempotencyKeys.Add(idempotencyKey);
            Console.WriteLine($"[System] Refund confirmed. Idempotency Key persisted.");
        }

        return result;
    }

    /// <summary>
    /// Implements a robust retry strategy with exponential backoff and jitter.
    /// </summary>
    private async Task<RefundResult> ExecuteWithRetryAsync(
        Func<Task<RefundResult>> operation, 
        int maxRetries)
    {
        int retryCount = 0;
        TimeSpan delay = TimeSpan.FromSeconds(1);

        while (true)
        {
            var result = await operation();

            // If successful, return immediately.
            if (result.IsSuccess)
            {
                return result;
            }

            // If we hit the max retries, throw or return failure.
            if (retryCount >= maxRetries)
            {
                Console.WriteLine($"[System] Operation failed after {maxRetries} retries. Giving up.");
                return new RefundResult { Status = "Failed", Message = "Max retries exceeded." };
            }

            // Log the retry attempt.
            Console.WriteLine($"[System] Attempt {retryCount + 1} failed: {result.Message}. Retrying in {delay.TotalSeconds}s...");

            // Wait before the next attempt.
            await Task.Delay(delay);

            // 5. Exponential Backoff Calculation.
            // Double the delay for the next iteration.
            delay = delay * 2;
            
            // 6. Jitter (Optional but recommended).
            // Add a random small amount to prevent "thundering herd" if multiple AIs retry simultaneously.
            delay += TimeSpan.FromMilliseconds(new Random().Next(0, 500));

            retryCount++;
        }
    }

    public static async Task Main(string[] args)
    {
        var processor = new IdempotentRefundProcessor();

        // Scenario: The AI attempts to refund a customer $50.00.
        // We will run this twice to prove idempotency.
        
        Console.WriteLine("--- First Attempt ---");
        var result1 = await processor.ProcessRefundAsync("TX-1001", 50.00);
        Console.WriteLine($"Result: {result1.Status} - {result1.Message}\n");

        Console.WriteLine("--- Second Attempt (Simulating a duplicate trigger) ---");
        var result2 = await processor.ProcessRefundAsync("TX-1001", 50.00);
        Console.WriteLine($"Result: {result2.Status} - {result2.Message}");
    }
}

// --- Supporting Models and Mocks ---

public class RefundResult
{
    public bool IsSuccess => Status == "Success";
    public string Status { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}

/// <summary>
/// Simulates a legacy system that is flaky (throws exceptions) or times out.
/// </summary>
public class LegacyRefundGateway
{
    private readonly double _failureRate;
    private readonly Random _random = new();

    public LegacyRefundGateway(double failureRate)
    {
        _failureRate = failureRate;
    }

    public async Task<RefundResult> IssueRefund(string idempotencyKey, decimal amount)
    {
        // Simulate network latency
        await Task.Delay(200);

        // Simulate failure
        if (_random.NextDouble() < _failureRate)
        {
            // Sometimes it throws an exception (connection drop)
            if (_random.NextDouble() > 0.5) 
                throw new TimeoutException("The legacy system timed out.");
            
            // Sometimes it returns a generic error
            return new RefundResult { Status = "Error", Message = "Database lock contention." };
        }

        // Simulate success
        return new RefundResult { Status = "Success", Message = $"Refunded {amount:C}." };
    }
}
