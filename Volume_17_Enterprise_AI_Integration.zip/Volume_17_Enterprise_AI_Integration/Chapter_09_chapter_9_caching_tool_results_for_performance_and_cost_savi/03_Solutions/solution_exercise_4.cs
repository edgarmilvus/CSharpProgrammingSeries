
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

// 1. The Event Bus (Simulating Distributed Pub/Sub)
public class InMemoryEventBus
{
    private readonly ConcurrentDictionary<string, Func<string, Task>> _subscribers = new();

    public void Subscribe(string topic, Func<string, Task> handler)
    {
        _subscribers.TryAdd(topic, handler);
    }

    public async Task Publish(string topic, string payload)
    {
        if (_subscribers.TryGetValue(topic, out var handler))
        {
            await handler.Invoke(payload);
        }
    }
}

// 2. The Cache Service
public class OrderCacheService
{
    private readonly IMemoryCache _cache;
    private readonly InMemoryEventBus _eventBus;
    private const string Topic = "OrderUpdated";

    public OrderCacheService(IMemoryCache cache, InMemoryEventBus eventBus)
    {
        _cache = cache;
        _eventBus = eventBus;
        
        // Subscribe to invalidation events immediately
        _eventBus.Subscribe(Topic, async (orderId) => await InvalidateAsync(orderId));
    }

    public async Task<string> GetAsync(string orderId)
    {
        string key = $"order_{orderId}";
        if (_cache.TryGetValue(key, out string data))
        {
            Console.WriteLine($"[OrderService] Cache HIT for Order {orderId}");
            return data;
        }

        Console.WriteLine($"[OrderService] Cache MISS for Order {orderId}. Loading from DB...");
        // Mock DB Load
        await Task.Delay(100);
        var dbData = $"Order Data for {orderId} (Fresh from DB)";
        
        // Cache it
        _cache.Set(key, dbData, TimeSpan.FromMinutes(30));
        return dbData;
    }

    public async Task SetAsync(string orderId, string data)
    {
        string key = $"order_{orderId}";
        _cache.Set(key, data, TimeSpan.FromMinutes(30));
        await Task.CompletedTask;
    }

    public async Task InvalidateAsync(string orderId)
    {
        string key = $"order_{orderId}";
        Console.WriteLine($"[EventBus] Received invalidation for Order {orderId}. Evicting from cache.");
        _cache.Remove(key);
        await Task.CompletedTask;
    }
}

// 3. Simulation
public class Program
{
    public static async Task Main()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var eventBus = new InMemoryEventBus();
        
        // Service A: Order Processing
        var orderService = new OrderCacheService(cache, eventBus);

        // Service B: Inventory Service (Simulated logic)
        // This runs in the background or a different process
        
        // Step 1: Initial Cache Population
        Console.WriteLine("--- Step 1: Caching Order 123 ---");
        await orderService.SetAsync("123", "Order 123 Data");

        // Step 2: Request (Should be Cache Hit)
        await orderService.GetAsync("123");

        // Step 3: Inventory Service updates the order and publishes event
        Console.WriteLine("\n--- Step 2: Inventory Updates Order 123 ---");
        // In a real system, this happens in a different service instance
        await eventBus.Publish("OrderUpdated", "123");

        // Step 4: Request again (Should be Cache Miss due to invalidation)
        Console.WriteLine("\n--- Step 3: Order Service Requests Data Again ---");
        await orderService.GetAsync("123");
    }
}
