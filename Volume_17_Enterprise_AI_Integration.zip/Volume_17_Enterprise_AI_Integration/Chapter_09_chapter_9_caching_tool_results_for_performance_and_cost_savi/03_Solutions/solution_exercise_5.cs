
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

// --- 1. Tool Definitions & Interfaces ---

public interface ITool
{
    string Name { get; }
    bool IsExpensive { get; }
    TimeSpan DefaultTtl { get; }
    Task<string> ExecuteAsync(Dictionary<string, string> parameters);
}

public class WeatherTool : ITool
{
    public string Name => "Weather";
    public bool IsExpensive => true; // External API call
    public TimeSpan DefaultTtl => TimeSpan.FromMinutes(30);

    public async Task<string> ExecuteAsync(Dictionary<string, string> parameters)
    {
        await Task.Delay(500); // Simulate API latency
        return $"Weather in {parameters["city"]}: 72°F, Sunny";
    }
}

public class StockTool : ITool
{
    public string Name => "Stock";
    public bool IsExpensive => true;
    public TimeSpan DefaultTtl => TimeSpan.FromMinutes(1);

    public async Task<string> ExecuteAsync(Dictionary<string, string> parameters)
    {
        await Task.Delay(300);
        return $"Stock {parameters["symbol"]}: $150.00";
    }
}

public class DatabaseQueryTool : ITool
{
    public string Name => "DBQuery";
    public bool IsExpensive => false;
    public TimeSpan DefaultTtl => TimeSpan.Zero; // No caching

    public async Task<string> ExecuteAsync(Dictionary<string, string> parameters)
    {
        await Task.Delay(100);
        return $"Query Result: {parameters["sql"]}";
    }
}

// --- 2. Caching Logic ---

public class CachingToolExecutor
{
    private readonly IMemoryCache _cache;
    private readonly ConcurrentDictionary<string, AsyncLazy<string>> _activeRequests = new();

    public CachingToolExecutor(IMemoryCache cache)
    {
        _cache = cache;
    }

    public async Task<string> ExecuteWithCacheAsync(ITool tool, Dictionary<string, string> parameters)
    {
        // 1. Cost Optimization: Skip cache if tool is not expensive and TTL is 0
        if (tool.DefaultTtl == TimeSpan.Zero)
        {
            return await tool.ExecuteAsync(parameters);
        }

        // 2. Generate Cache Key (ToolName + Serialized Params)
        var cacheKey = GenerateCacheKey(tool.Name, parameters);

        // 3. Check for active request (Thundering Herd protection)
        // AsyncLazy ensures concurrent callers await the same execution task
        var lazyResult = _activeRequests.GetOrAdd(cacheKey, _ => 
            new AsyncLazy<string>(() => ExecuteAndCacheAsync(tool, parameters, cacheKey))
        );

        try 
        {
            var result = await lazyResult.Value;
            return result;
        }
        finally
        {
            // Cleanup active request tracking once completed
            _activeRequests.TryRemove(cacheKey, out _);
        }
    }

    private async Task<string> ExecuteAndCacheAsync(ITool tool, Dictionary<string, string> parameters, string cacheKey)
    {
        // 4. Check Memory Cache
        if (_cache.TryGetValue<string>(cacheKey, out var cachedValue))
        {
            Console.WriteLine($"[Cache Hit] Tool: {tool.Name} | Key: {cacheKey.Substring(0, 8)}...");
            return cachedValue;
        }

        Console.WriteLine($"[Cache Miss] Tool: {tool.Name} | Executing...");
        
        // 5. Execute Tool
        var result = await tool.ExecuteAsync(parameters);

        // 6. Set Cache with Tool-specific TTL
        if (tool.DefaultTtl > TimeSpan.Zero)
        {
            _cache.Set(cacheKey, result, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = tool.DefaultTtl
            });
        }

        return result;
    }

    private string GenerateCacheKey(string toolName, Dictionary<string, string> parameters)
    {
        // Simple JSON serialization for key generation
        var paramString = JsonSerializer.Serialize(parameters);
        return $"{toolName}:{paramString}";
    }
}

// Helper for AsyncLazy
public class AsyncLazy<T> : Lazy<Task<T>>
{
    public AsyncLazy(Func<Task<T>> taskFactory) : base(() => Task.Run(taskFactory)) { }
}

// --- 3. Orchestrator & Interactive Harness ---

public class ToolOrchestrator
{
    private readonly CachingToolExecutor _executor;
    private readonly List<ITool> _tools;

    public ToolOrchestrator(CachingToolExecutor executor, List<ITool> tools)
    {
        _executor = executor;
        _tools = tools;
    }

    public async Task<string> ProcessRequestAsync(string userPrompt)
    {
        // Mock Parsing Logic
        ITool selectedTool = null;
        Dictionary<string, string> parameters = new();

        if (userPrompt.Contains("weather", StringComparison.OrdinalIgnoreCase))
        {
            selectedTool = _tools.First(t => t.Name == "Weather");
            parameters["city"] = "Tokyo"; // Hardcoded for demo
        }
        else if (userPrompt.Contains("stock", StringComparison.OrdinalIgnoreCase))
        {
            selectedTool = _tools.First(t => t.Name == "Stock");
            parameters["symbol"] = "MSFT";
        }
        else
        {
            selectedTool = _tools.First(t => t.Name == "DBQuery");
            parameters["sql"] = "SELECT * FROM Users";
        }

        if (selectedTool == null) return "Unknown request";

        var sw = Stopwatch.StartNew();
        var result = await _executor.ExecuteWithCacheAsync(selectedTool, parameters);
        sw.Stop();

        return $"Result: {result} | Time: {sw.ElapsedMilliseconds}ms";
    }
}

public class Program
{
    public static async Task Main()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var executor = new CachingToolExecutor(cache);
        
        var tools = new List<ITool> 
        { 
            new WeatherTool(), 
            new StockTool(), 
            new DatabaseQueryTool() 
        };
        
        var orchestrator = new ToolOrchestrator(executor, tools);

        Console.WriteLine("=== Interactive LLM Tool Orchestrator ===");
        Console.WriteLine("Try: 'What is the weather in Tokyo?' or 'What is the stock price of MSFT?'");
        
        // Simulation Loop
        string[] inputs = {
            "What is the weather in Tokyo?",
            "What is the weather in Tokyo?", // Should be Cache Hit
            "What is the stock price of MSFT?",
            "Run DB Query" // Should not cache
        };

        foreach (var input in inputs)
        {
            Console.WriteLine($"\nUser Input: {input}");
            var response = await orchestrator.ProcessRequestAsync(input);
            Console.WriteLine($"System: {response}");
            await Task.Delay(100); // Small delay for readability
        }
    }
}
