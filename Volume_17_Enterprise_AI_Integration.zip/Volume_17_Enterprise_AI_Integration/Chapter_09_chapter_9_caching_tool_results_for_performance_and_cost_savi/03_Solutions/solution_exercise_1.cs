
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;

public class CustomerService
{
    private readonly IMemoryCache _cache;
    private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(10);

    public CustomerService(IMemoryCache cache)
    {
        _cache = cache;
    }

    public async Task<string> GetCustomerAsync(int customerId)
    {
        string cacheKey = $"customer_{customerId}";

        // GetOrCreateAsync handles the locking mechanism internally.
        // If multiple threads call this simultaneously for the same key, 
        // the valueFactory is executed only once.
        return await _cache.GetOrCreateAsync(cacheKey, async entry =>
        {
            // Configure cache entry settings
            entry.AbsoluteExpirationRelativeToNow = _cacheDuration;

            Console.WriteLine($"[API] Fetching data for Customer ID: {customerId}...");
            
            // Simulate high latency API call
            await Task.Delay(2000); 
            
            // Simulate data retrieval
            var data = $"Customer Details for ID {customerId} - Last Updated: {DateTime.Now}";
            
            return data;
        });
    }
}

// Example Usage / Test Harness
public class Program
{
    public static async Task Main()
    {
        // Setup DI container (simplified for this exercise)
        var services = new ServiceCollection();
        services.AddMemoryCache();
        var serviceProvider = services.BuildServiceProvider();
        var cache = serviceProvider.GetRequiredService<IMemoryCache>();

        var customerService = new CustomerService(cache);

        // First call (Cache Miss)
        Console.WriteLine("Request 1:");
        var result1 = await customerService.GetCustomerAsync(101);
        Console.WriteLine($"Result: {result1}\n");

        // Second call immediately after (Cache Hit)
        Console.WriteLine("Request 2 (Immediate):");
        var result2 = await customerService.GetCustomerAsync(101);
        Console.WriteLine($"Result: {result2}\n");

        // Concurrent calls to test thread safety
        Console.WriteLine("Request 3 & 4 (Concurrent):");
        var taskA = customerService.GetCustomerAsync(102);
        var taskB = customerService.GetCustomerAsync(102);
        
        await Task.WhenAll(taskA, taskB);
        Console.WriteLine($"Result A: {taskA.Result}");
        Console.WriteLine($"Result B: {taskB.Result}");
    }
}
