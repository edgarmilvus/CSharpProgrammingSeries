
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

public class SalesAggregatorService
{
    private readonly IMemoryCache _cache;
    private readonly TimeSpan _freshDuration = TimeSpan.FromMinutes(1);
    // Lock object to prevent thundering herd on refresh
    private readonly SemaphoreSlim _refreshLock = new SemaphoreSlim(1, 1);

    public SalesAggregatorService(IMemoryCache cache)
    {
        _cache = cache;
    }

    public async Task<string> GetSalesDataAsync()
    {
        string cacheKey = "sales_dashboard_data";
        
        // 1. Check if data exists in cache
        if (_cache.TryGetValue(cacheKey, out string cachedData))
        {
            // Data exists, but we need to check if it is stale.
            // In a strict implementation, we might store an object with a timestamp.
            // For this exercise, we simulate staleness by checking a separate "last updated" flag
            // or relying on the cache entry's expiration policy. 
            // However, MemoryCache doesn't expose expiration state easily.
            // We will use a wrapper object to track state.
            
            // Note: To strictly support Stale-While-Revalidate with MemoryCache, 
            // we usually need to store an object containing the data + metadata.
            // Let's assume we stored a wrapper previously. 
            // For simplicity in this specific exercise flow, we will simulate the logic:
            
            // Since MemoryCache evicts expired items, we can't easily get the expired item.
            // A common pattern is to set a "SlidingExpiration" and check if it's near expiry,
            // or store the item with a long TTL and manage "freshness" manually.
            
            // REVISED STRATEGY for this exercise:
            // We will cache the data with a long TTL (e.g., 2 hours) but track "Freshness" manually
            // to demonstrate the logic flow requested.
            
            // However, standard MemoryCache usage usually evicts on expiration.
            // To allow returning "Stale" data, we must NOT let the cache evict it yet.
            // Let's assume we are using a wrapper class `CachedItem<T>`.
            
            // Implementation below assumes we are checking a wrapper object.
        }

        // To strictly meet the requirements with standard MemoryCache:
        // We will cache a wrapper object that holds the data and a timestamp.
        
        var wrapper = _cache.GetOrCreate<CachedSalesData>(cacheKey, entry => 
        {
            // Set a long expiration so we can manually detect staleness
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(2); 
            return null; // Force a miss initially
        });

        if (wrapper != null && (DateTime.UtcNow - wrapper.LastUpdated) < _freshDuration)
        {
            Console.WriteLine("[Cache] Returning Fresh Data.");
            return wrapper.Data;
        }
        else if (wrapper != null)
        {
            // Stale Data Found: Return immediately but trigger revalidation
            Console.WriteLine("[Cache] Returning Stale Data & Triggering Background Refresh.");
            
            // Use a lock to ensure only one background refresh starts
            if (_refreshLock.Wait(0)) // Non-blocking wait
            {
                _ = Task.Run(async () => 
                {
                    try 
                    {
                        await RefreshDataAsync(cacheKey);
                    }
                    finally 
                    {
                        _refreshLock.Release();
                    }
                });
            }

            return wrapper.Data;
        }
        else
        {
            // Cold Start: Block and wait
            Console.WriteLine("[Cold Start] Calculating Data (Blocking)...");
            return await RefreshDataAsync(cacheKey);
        }
    }

    private async Task<string> RefreshDataAsync(string cacheKey)
    {
        // Simulate heavy calculation
        await Task.Delay(5000); 
        
        var newData = $"Sales Data calculated at {DateTime.Now}";
        var newWrapper = new CachedSalesData 
        { 
            Data = newData, 
            LastUpdated = DateTime.UtcNow 
        };

        _cache.Set(cacheKey, newWrapper, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(2) // Keep in cache for a long time
        });

        return newData;
    }

    private class CachedSalesData
    {
        public string Data { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}

// Usage Example
public class Program
{
    public static async Task Main()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var service = new SalesAggregatorService(cache);

        // 1. Cold Load
        Console.WriteLine($"Request 1: {await service.GetSalesDataAsync()}");

        // 2. Immediate Request (Fresh)
        Console.WriteLine($"Request 2: {await service.GetSalesDataAsync()}");

        // 3. Simulate time passing (manually removing to simulate expiry for the demo)
        // In real usage, we wait or set short TTL. 
        // For the demo, let's assume we wait or hack the cache to be "stale".
        // Since we can't easily expire it without waiting, we'll rely on the logic flow.
        // To force the Stale path in a demo, we can modify the cache entry manually or wait.
        // Let's wait 1 second (less than 5s calc) to show rapid response vs background task.
        
        // Note: In a real scenario, the background refresh happens asynchronously.
    }
}
