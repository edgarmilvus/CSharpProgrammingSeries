
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

public class VectorCacheService
{
    private readonly IMemoryCache _cache;

    public VectorCacheService(IMemoryCache cache)
    {
        _cache = cache;
    }

    public async Task<float[]> GetOrGenerateEmbeddingAsync(string text)
    {
        // 1. Edge Case Handling
        if (string.IsNullOrWhiteSpace(text))
        {
            throw new ArgumentException("Text cannot be null or empty.", nameof(text));
        }

        // 2. Generate Cache Key (SHA256)
        string cacheKey = ComputeSha256Hash(text);

        // 3. Check Cache
        if (_cache.TryGetValue<float[]>(cacheKey, out var cachedEmbedding))
        {
            Console.WriteLine($"[Cache Hit] Retrieved embedding for: '{text.Substring(0, Math.Min(15, text.Length))}...'");
            return cachedEmbedding;
        }

        // 4. Cache Miss: Generate Embedding
        Console.WriteLine($"[Cache Miss] Generating embedding for: '{text.Substring(0, Math.Min(15, text.Length))}...'");
        
        var stopwatch = Stopwatch.StartNew();
        var embedding = await MockLLMEmbeddingService(text);
        stopwatch.Stop();

        Console.WriteLine($"[Performance] Generation took: {stopwatch.ElapsedMilliseconds}ms");

        // 5. Store in Cache (Infinite TTL as per requirements)
        var cacheOptions = new MemoryCacheEntryOptions()
            .SetAbsoluteExpiration(TimeSpan.MaxValue) // effectively infinite
            .SetPriority(CacheItemPriority.High);

        _cache.Set(cacheKey, embedding, cacheOptions);

        return embedding;
    }

    private async Task<float[]> MockLLMEmbeddingService(string text)
    {
        // Simulate API delay
        await Task.Delay(1000);
        
        // Return a dummy vector (e.g., 128 dimensions)
        var random = new Random(text.Length); // Deterministic based on input for consistency
        var vector = new float[128];
        for (int i = 0; i < vector.Length; i++)
        {
            vector[i] = (float)random.NextDouble();
        }
        return vector;
    }

    private string ComputeSha256Hash(string input)
    {
        using (SHA256 sha256 = SHA256.Create())
        {
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }
}

// Usage Example
public class Program
{
    public static async Task Main()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var service = new VectorCacheService(cache);

        string query1 = "Reset my password";
        string query2 = "I forgot my login credentials"; // Different text, different hash for this exercise
        string query3 = "Reset my password"; // Identical to query 1

        await service.GetOrGenerateEmbeddingAsync(query1);
        await service.GetOrGenerateEmbeddingAsync(query2);
        
        // Should be instant (Cache Hit)
        await service.GetOrGenerateEmbeddingAsync(query3);
    }
}
