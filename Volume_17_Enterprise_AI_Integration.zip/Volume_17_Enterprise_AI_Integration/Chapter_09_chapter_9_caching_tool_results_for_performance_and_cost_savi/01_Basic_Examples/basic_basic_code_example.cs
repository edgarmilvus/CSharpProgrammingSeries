
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class Program
{
    public static async Task Main(string[] args)
    {
        // 1. Setup the external service and the caching wrapper
        var stockService = new MockStockApiService();
        var cachedService = new CachingStockService(stockService, TimeSpan.FromSeconds(5));

        Console.WriteLine("--- Request 1: Fetching 'AAPL' (Cold Start) ---");
        var price1 = await cachedService.GetStockPriceAsync("AAPL");
        Console.WriteLine($"Result: ${price1}");

        Console.WriteLine("\n--- Request 2: Fetching 'AAPL' (Cache Hit) ---");
        var price2 = await cachedService.GetStockPriceAsync("AAPL");
        Console.WriteLine($"Result: ${price2}");

        Console.WriteLine("\n--- Request 3: Fetching 'GOOG' (New Item) ---");
        var price3 = await cachedService.GetStockPriceAsync("GOOG");
        Console.WriteLine($"Result: ${price3}");

        Console.WriteLine("\n--- Request 4: Wait 6 seconds for TTL expiration ---");
        await Task.Delay(6000);

        Console.WriteLine("\n--- Request 5: Fetching 'AAPL' (Cache Miss due to TTL) ---");
        var price4 = await cachedService.GetStockPriceAsync("AAPL");
        Console.WriteLine($"Result: ${price4}");
    }
}

// --- Core Logic ---

public class CachingStockService
{
    private readonly IStockService _innerService;
    private readonly TimeSpan _ttl;
    private readonly ConcurrentDictionary<string, (DateTime Expiry, double Price)> _cache;

    public CachingStockService(IStockService innerService, TimeSpan ttl)
    {
        _innerService = innerService;
        _ttl = ttl;
        _cache = new ConcurrentDictionary<string, (DateTime, double)>();
    }

    public async Task<double> GetStockPriceAsync(string symbol)
    {
        // Check if item exists and is not expired
        if (_cache.TryGetValue(symbol, out var entry))
        {
            if (DateTime.UtcNow <= entry.Expiry)
            {
                Console.WriteLine($"  [CACHE] Hit for {symbol}");
                return entry.Price;
            }
            else
            {
                Console.WriteLine($"  [CACHE] Expired for {symbol}");
            }
        }
        else
        {
            Console.WriteLine($"  [CACHE] Miss for {symbol}");
        }

        // Item not in cache or expired, fetch from source
        var price = await _innerService.FetchPriceAsync(symbol);

        // Store in cache with new expiration
        var expiry = DateTime.UtcNow.Add(_ttl);
        _cache[symbol] = (expiry, price);

        return price;
    }
}

// --- Interfaces and Mocks ---

public interface IStockService
{
    Task<double> FetchPriceAsync(string symbol);
}

public class MockStockApiService : IStockService
{
    public async Task<double> FetchPriceAsync(string symbol)
    {
        // Simulate expensive network call
        Console.WriteLine($"  [API] Calling External API for {symbol}...");
        await Task.Delay(1000); // Simulate 1 second latency
        
        // Return a pseudo-random price based on symbol length to verify consistency
        return 150.00 + (symbol.Length * 1.23); 
    }
}
