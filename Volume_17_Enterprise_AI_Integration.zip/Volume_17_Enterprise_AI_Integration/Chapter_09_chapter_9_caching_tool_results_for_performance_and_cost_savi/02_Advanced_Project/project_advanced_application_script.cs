
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace EnterpriseAI_CachingDemo
{
    // ============================================================================
    // CLASS: LegacySystemConnector
    // PURPOSE: Simulates a connection to a slow, legacy enterprise system (e.g., Mainframe or on-prem ERP).
    //          This represents the "Expensive Tool Call" mentioned in Chapter 9.
    // ============================================================================
    public class LegacySystemConnector
    {
        // Simulates a database of customer records.
        private readonly Dictionary<string, CustomerRecord> _database;

        public LegacySystemConnector()
        {
            // Initialize with dummy data to simulate a legacy database.
            _database = new Dictionary<string, CustomerRecord>
            {
                { "CUST_001", new CustomerRecord { Id = "CUST_001", Name = "Acme Corp", CreditScore = 750, Region = "NA" } },
                { "CUST_002", new CustomerRecord { Id = "CUST_002", Name = "Globex Inc", CreditScore = 620, Region = "EU" } },
                { "CUST_003", new CustomerRecord { Id = "CUST_003", Name = "Soylent Corp", CreditScore = 810, Region = "ASIA" } }
            };
        }

        // ============================================================================
        // METHOD: FetchCustomerData
        // PURPOSE: Simulates an expensive API call to the legacy system.
        //          It introduces artificial latency (2 seconds) and logs the cost.
        // ============================================================================
        public CustomerRecord FetchCustomerData(string customerId)
        {
            Console.WriteLine($"[LEGACY SYSTEM] Connecting to database for ID: {customerId}...");
            
            // Simulate network latency and processing time of a legacy system.
            System.Threading.Thread.Sleep(2000); 

            if (_database.TryGetValue(customerId, out var record))
            {
                Console.WriteLine($"[LEGACY SYSTEM] Data fetched successfully.");
                return record;
            }

            Console.WriteLine($"[LEGACY SYSTEM] Customer ID {customerId} not found.");
            return null;
        }
    }

    // ============================================================================
    // CLASS: CacheEntry
    // PURPOSE: A simple container to hold cached data along with metadata for TTL.
    //          This is the basic structure of a cache item.
    // ============================================================================
    public class CacheEntry
    {
        public object Data { get; set; }
        public DateTime ExpiryTime { get; set; }

        public bool IsExpired()
        {
            return DateTime.UtcNow > ExpiryTime;
        }
    }

    // ============================================================================
    // CLASS: CachingService
    // PURPOSE: Implements the caching layer discussed in Chapter 9.
    //          Handles storage, retrieval, and Time-To-Live (TTL) invalidation.
    // ============================================================================
    public class CachingService
    {
        // In-memory dictionary acting as our cache store.
        // Key: string (Cache Key), Value: CacheEntry (Data + Expiry)
        private readonly Dictionary<string, CacheEntry> _cacheStore;
        private readonly int _ttlSeconds;

        public CachingService(int ttlSeconds)
        {
            _ttlSeconds = ttlSeconds;
            _cacheStore = new Dictionary<string, CacheEntry>();
        }

        // ============================================================================
        // METHOD: TryGet
        // PURPOSE: Attempts to retrieve an item from the cache.
        //          Checks for existence AND validity (TTL) before returning.
        // ============================================================================
        public bool TryGet(string key, out object data)
        {
            data = null;
            
            // Check if key exists in the dictionary
            if (_cacheStore.ContainsKey(key))
            {
                CacheEntry entry = _cacheStore[key];

                // Check if the entry has expired
                if (!entry.IsExpired())
                {
                    // Cache Hit
                    data = entry.Data;
                    return true;
                }
                else
                {
                    // Cache Expired: Remove it to clean up memory
                    _cacheStore.Remove(key);
                }
            }
            
            // Cache Miss
            return false;
        }

        // ============================================================================
        // METHOD: Set
        // PURPOSE: Stores data in the cache with a calculated expiration time.
        // ============================================================================
        public void Set(string key, object data)
        {
            var entry = new CacheEntry
            {
                Data = data,
                ExpiryTime = DateTime.UtcNow.AddSeconds(_ttlSeconds)
            };

            // Overwrite if exists, otherwise add
            _cacheStore[key] = entry;
            Console.WriteLine($"[CACHE LAYER] Item stored under key: '{key}'. Expires at {entry.ExpiryTime:HH:mm:ss}");
        }
    }

    // ============================================================================
    // CLASS: Program
    // PURPOSE: Main entry point. Orchestrates the interaction between the LLM (simulated),
    //          the Caching Layer, and the Legacy System.
    // ============================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Enterprise AI Integration: Caching Tool Results ===\n");

            // Configuration
            int cacheTTL = 10; // 10 seconds TTL for demonstration purposes
            CachingService cache = new CachingService(cacheTTL);
            LegacySystemConnector legacySystem = new LegacySystemConnector();

            // Simulate an LLM requesting data multiple times
            string[] requests = { "CUST_001", "CUST_002", "CUST_001", "CUST_003", "CUST_001" };

            foreach (var customerId in requests)
            {
                ProcessLLMRequest(customerId, cache, legacySystem);
                
                // Artificial delay between requests to simulate real-world usage patterns
                System.Threading.Thread.Sleep(1000); 
            }

            Console.WriteLine("\n=== Simulation Complete ===");
            Console.WriteLine("Notice how the second request for 'CUST_001' was instant (Cache Hit),");
            Console.WriteLine("while the first request took 2 seconds (Legacy System Latency).");
        }

        // ============================================================================
        // METHOD: ProcessLLMRequest
        // PURPOSE: Orchestrates the logic: Check Cache -> If Miss, Call Legacy System -> Update Cache.
        // ============================================================================
        static void ProcessLLMRequest(string customerId, CachingService cache, LegacySystemConnector legacySystem)
        {
            Console.WriteLine($"\n--- Requesting Data for: {customerId} ---");
            Stopwatch stopwatch = Stopwatch.StartNew();

            // 1. Generate Cache Key
            // In a real scenario, this might include the prompt hash or specific query parameters.
            string cacheKey = $"customer_data_{customerId}";

            // 2. Check Cache
            object cachedData = null;
            bool isCached = cache.TryGet(cacheKey, out cachedData);

            if (isCached)
            {
                // CACHE HIT PATH
                stopwatch.Stop();
                CustomerRecord record = (CustomerRecord)cachedData; // Safe cast in this context
                Console.WriteLine($"[LLM AGENT] Retrieved from Cache: {record.Name} (Score: {record.CreditScore})");
                Console.WriteLine($"[LLM AGENT] Response Time: {stopwatch.ElapsedMilliseconds}ms");
            }
            else
            {
                // CACHE MISS PATH
                Console.WriteLine("[LLM AGENT] Cache Miss. Calling Legacy System...");

                // 3. Call Expensive Tool (Legacy System)
                CustomerRecord record = legacySystem.FetchCustomerData(customerId);

                if (record != null)
                {
                    // 4. Update Cache
                    cache.Set(cacheKey, record);
                    
                    stopwatch.Stop();
                    Console.WriteLine($"[LLM AGENT] Retrieved from Legacy: {record.Name} (Score: {record.CreditScore})");
                    Console.WriteLine($"[LLM AGENT] Total Processing Time: {stopwatch.ElapsedMilliseconds}ms");
                }
                else
                {
                    Console.WriteLine("[LLM AGENT] No data found.");
                }
            }
        }
    }

    // ============================================================================
    // CLASS: CustomerRecord
    // PURPOSE: Data Transfer Object (DTO) representing the structure of the data
    //          returned by the legacy system.
    // ============================================================================
    public class CustomerRecord
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int CreditScore { get; set; }
        public string Region { get; set; }
    }
}
