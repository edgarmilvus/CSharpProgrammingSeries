
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.cs
// Description: Theoretical Foundations
// ==========================================

using System;
using System.ComponentModel.DataAnnotations;

namespace EnterpriseAI.HR.Domain
{
    public class OnboardingPlan
    {
        [Required]
        [StringLength(100)]
        public string EmployeeName { get; set; }

        // Guardrail: Work week cannot exceed 40 hours by default policy
        [Range(0, 40, ErrorMessage = "Standard onboarding cannot exceed 40 hours/week.")]
        public int WeeklyHours { get; set; }

        // Guardrail: Start date must be in the future
        [FutureDate]
        public DateTime StartDate { get; set; }
    }

    // Custom Attribute for complex validation logic
    public class FutureDateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext context)
        {
            var date = (DateTime)value;
            if (date < DateTime.Now)
            {
                return new ValidationResult("Start date must be in the future.");
            }
            return ValidationResult.Success;
        }
    }
}
