
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HrOnboardingAssistant
{
    // 1. Domain Models: Represents the structured data we work with.
    // In a real system, these would likely be generated from a database schema or OpenAPI spec.
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
    }

    public class OnboardingTask
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool IsCompleted { get; set; }
    }

    // 2. The "Legacy" HRIS System Interface
    // This abstract class represents a legacy system that we cannot easily modify.
    // It uses synchronous methods and older patterns, which we need to adapt.
    public abstract class LegacyHrisSystem
    {
        public abstract Employee GetEmployeeById(int id);
        public abstract List<string> GetPendingComplianceForms(int employeeId);
    }

    // 3. The Modern API Interface (Internal Identity Management)
    // This represents a modern, RESTful microservice we need to integrate with.
    public interface IIdentityService
    {
        Task<string> ProvisionUserAccountAsync(string name, string role);
        Task<string> AssignAccessPermissionsAsync(string userId, string department);
    }

    // 4. The AI Service Interface
    // This abstracts the LLM interaction. In a real scenario, this would call 
    // Azure OpenAI, AWS Bedrock, or a local model via an SDK.
    public interface ILlmOrchestrator
    {
        Task<string> GeneratePersonalizedMessageAsync(Employee employee, List<OnboardingTask> tasks);
    }

    // 5. Concrete Implementation of the Legacy System (Mocked)
    // We simulate a database connection here. Note the lack of async/await.
    public class MockLegacyHrisSystem : LegacyHrisSystem
    {
        private readonly Dictionary<int, Employee> _employees = new()
        {
            { 101, new Employee { Id = 101, Name = "Alice Johnson", Role = "Software Engineer", Department = "Engineering" } },
            { 102, new Employee { Id = 102, Name = "Bob Smith", Role = "Product Manager", Department = "Product" } }
        };

        public override Employee GetEmployeeById(int id)
        {
            // Simulate I/O latency
            Thread.Sleep(100); 
            return _employees.TryGetValue(id, out var emp) ? emp : null!;
        }

        public override List<string> GetPendingComplianceForms(int employeeId)
        {
            Thread.Sleep(50);
            return new List<string> { "W-4 Tax Form", "I-9 Employment Eligibility", "NDA Agreement" };
        }
    }

    // 6. Concrete Implementation of the Modern Identity Service (Mocked)
    // This uses modern async patterns.
    public class MockIdentityService : IIdentityService
    {
        public async Task<string> ProvisionUserAccountAsync(string name, string role)
        {
            // Simulate network call
            await Task.Delay(200);
            // Generate a pseudo GUID for the new user
            var userId = Guid.NewGuid().ToString()[..8];
            Console.WriteLine($"[Identity Service] Created account for {name} ({role}) with ID: {userId}");
            return userId;
        }

        public async Task<string> AssignAccessPermissionsAsync(string userId, string department)
        {
            await Task.Delay(150);
            var permissionLevel = department == "Engineering" ? "Admin" : "Standard";
            Console.WriteLine($"[Identity Service] Assigned {permissionLevel} permissions to {userId} for {department}");
            return permissionLevel;
        }
    }

    // 7. Concrete Implementation of the LLM Orchestrator (Mocked)
    // Simulates generating text based on context.
    public class MockLlmOrchestrator : ILlmOrchestrator
    {
        public async Task<string> GeneratePersonalizedMessageAsync(Employee employee, List<OnboardingTask> tasks)
        {
            await Task.Delay(300); // Simulate LLM inference time
            
            var taskList = string.Join(", ", tasks.Select(t => t.Title));
            
            // In a real RAG system, this prompt would be injected with retrieved context
            // from a vector database (e.g., company handbook snippets).
            return $"Welcome to the team, {employee.Name}!\n\n" +
                   $"We are thrilled to have you join as a {employee.Role} in the {employee.Department} department.\n\n" +
                   $"Here is your personalized AI-generated onboarding plan:\n" +
                   $"1. Initial Setup (Immediate)\n" +
                   $"2. Review Policies (Day 1)\n" +
                   $"3. Task: {taskList} (Day 2)\n\n" +
                   $"Generated by AI Orchestrator v1.0";
        }
    }

    // 8. The Core Orchestration Logic
    // This class acts as the bridge between the old (Legacy) and new (Modern) worlds.
    // It handles data transformation, concurrency, and error handling.
    public class OnboardingOrchestrator
    {
        private readonly LegacyHrisSystem _legacySystem;
        private readonly IIdentityService _identityService;
        private readonly ILlmOrchestrator _llmOrchestrator;

        public OnboardingOrchestrator(
            LegacyHrisSystem legacySystem, 
            IIdentityService identityService, 
            ILlmOrchestrator llmOrchestrator)
        {
            _legacySystem = legacySystem;
            _identityService = identityService;
            _llmOrchestrator = llmOrchestrator;
        }

        public async Task<string> ExecuteOnboardingWorkflowAsync(int employeeId)
        {
            Console.WriteLine($"--- Starting Onboarding Workflow for Employee ID: {employeeId} ---");

            // Step 1: Retrieve data from the Legacy System (Synchronous)
            // We must bridge the sync/async boundary here.
            var employee = _legacySystem.GetEmployeeById(employeeId);
            if (employee == null)
            {
                throw new InvalidOperationException($"Employee {employeeId} not found in legacy HRIS.");
            }

            // Step 2: Retrieve compliance requirements
            var pendingForms = _legacySystem.GetPendingComplianceForms(employeeId);

            // Step 3: Map legacy data to modern domain objects (Tasks)
            var onboardingTasks = pendingForms.Select(f => new OnboardingTask 
            { 
                Title = $"Complete {f}", 
                Description = $"Legacy form requirement: {f}" 
            }).ToList();

            // Step 4: Parallel execution of Modern APIs
            // We can provision the IT account and assign permissions concurrently 
            // as they are likely independent operations in different systems.
            var provisionTask = _identityService.ProvisionUserAccountAsync(employee.Name, employee.Role);
            var permissionTask = _identityService.AssignAccessPermissionsAsync(employee.Id.ToString(), employee.Department);

            // Await both tasks efficiently
            await Task.WhenAll(provisionTask, permissionTask);

            string accountId = provisionTask.Result;
            string permissions = permissionTask.Result;

            // Step 5: AI Integration (RAG Context Injection)
            // The LLM needs the employee data and the generated tasks to create a personalized message.
            // In a full RAG system, we would also fetch relevant policy documents here.
            var personalizedMessage = await _llmOrchestrator.GeneratePersonalizedMessageAsync(employee, onboardingTasks);

            // Step 6: Construct Final Payload
            // Combine results from Legacy, Modern, and AI sources.
            var result = new
            {
                EmployeeId = employee.Id,
                ModernAccountId = accountId,
                Permissions = permissions,
                ComplianceTasks = onboardingTasks,
                AiGeneratedWelcomeMessage = personalizedMessage,
                Timestamp = DateTime.UtcNow
            };

            return JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
        }
    }

    // 9. Main Execution Entry Point
    class Program
    {
        static async Task Main(string[] args)
        {
            // Dependency Injection Setup (Manual for this self-contained example)
            var legacySystem = new MockLegacyHrisSystem();
            var identityService = new MockIdentityService();
            var llmOrchestrator = new MockLlmOrchestrator();

            var orchestrator = new OnboardingOrchestrator(legacySystem, identityService, llmOrchestrator);

            try
            {
                // Execute the workflow for Employee ID 101
                string jsonResult = await orchestrator.ExecuteOnboardingWorkflowAsync(101);
                
                Console.WriteLine("\n--- Workflow Complete ---");
                Console.WriteLine(jsonResult);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during onboarding: {ex.Message}");
            }
        }
    }
}
