
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace HR_Onboarding_Assistant
{
    // CLASS 1: Data Models
    // These classes represent the structured data exchanged between the LLM and legacy systems.
    // They mimic the JSON schemas often used in API contracts.
    public class EmployeeData
    {
        public string EmployeeId { get; set; }
        public string FullName { get; set; }
        public string Department { get; set; }
        public string Role { get; set; }
        public string StartDate { get; set; }
    }

    public class OnboardingTask
    {
        public string TaskName { get; set; }
        public string Description { get; set; }
        public string AssignedSystem { get; set; } // e.g., "ActiveDirectory", "Payroll", "Bench"
        public bool IsCompleted { get; set; }
    }

    public class PolicyQueryResult
    {
        public string RelevantSection { get; set; }
        public string PolicyText { get; set; }
        public string Citation { get; set; }
    }

    // CLASS 2: Legacy System Simulators
    // In a real enterprise, these would be API clients (HTTPClient) connecting to mainframes or SQL databases.
    // Here we simulate the latency and data retrieval logic.
    public class LegacyHRIS
    {
        // Simulates a slow database query to retrieve employee master data.
        public EmployeeData GetEmployeeRecord(string employeeId)
        {
            Console.WriteLine($"[Legacy HRIS] Querying database for ID: {employeeId}...");
            // Simulate network latency
            System.Threading.Thread.Sleep(500); 
            
            // Mock data return
            return new EmployeeData
            {
                EmployeeId = employeeId,
                FullName = "Alex Mercer",
                Department = "Engineering",
                Role = "Software Developer II",
                StartDate = "2024-01-15"
            };
        }

        // Simulates writing a status flag back to a mainframe.
        public void UpdateOnboardingStatus(string employeeId, string status)
        {
            Console.WriteLine($"[Legacy HRIS] Updating status for {employeeId}: {status}");
        }
    }

    public class IdentityManagementSystem
    {
        // Simulates provisioning an account in Active Directory or similar.
        public string ProvisionAccount(EmployeeData emp)
        {
            Console.WriteLine($"[Identity Mgmt] Provisioning account for {emp.FullName}...");
            // Generate a mock username
            string username = emp.FullName.Replace(" ", ".").ToLower();
            return username;
        }
    }

    // CLASS 3: RAG (Retrieval-Augmented Generation) Service
    // This simulates the vector database lookup for company policies.
    // It retrieves context to ground the LLM response.
    public class PolicyKnowledgeBase
    {
        // Simulates a vector search for "Remote Work Policy"
        public PolicyQueryResult RetrievePolicyContext(string queryTopic)
        {
            Console.WriteLine($"[Knowledge Base] Searching for policy: '{queryTopic}'...");
            
            if (queryTopic.ToLower().Contains("remote") || queryTopic.ToLower().Contains("work from home"))
            {
                return new PolicyQueryResult
                {
                    RelevantSection = "Section 4.2",
                    PolicyText = "Remote work is permitted 2 days per week. Equipment must be returned to the office if employment terminates.",
                    Citation = "Employee Handbook v3.1"
                };
            }
            return null;
        }
    }

    // CLASS 4: LLM Orchestrator (The Brain)
    // This class acts as the logic controller, routing requests and managing state.
    public class OnboardingOrchestrator
    {
        private LegacyHRIS _hris;
        private IdentityManagementSystem _idm;
        private PolicyKnowledgeBase _kb;

        public OnboardingOrchestrator()
        {
            _hris = new LegacyHRIS();
            _idm = new IdentityManagementSystem();
            _kb = new PolicyKnowledgeBase();
        }

        // Main entry point for the assistant
        public void ProcessOnboardingRequest(string employeeId)
        {
            Console.WriteLine("\n--- Starting Onboarding Process ---");
            
            // 1. Data Retrieval (RAG & Legacy Integration)
            EmployeeData emp = _hris.GetEmployeeRecord(employeeId);
            if (emp == null)
            {
                Console.WriteLine("Error: Employee not found in HRIS.");
                return;
            }

            // 2. Generate Personalized Plan (LLM Logic Simulation)
            List<OnboardingTask> plan = GeneratePersonalizedPlan(emp);
            
            // 3. Execute Tasks (Workflow Automation)
            ExecuteTasks(plan, emp);

            // 4. Handle Policy Query (Contextual Retrieval)
            HandlePolicyQuery("Remote work rules for developers");

            Console.WriteLine("--- Onboarding Process Complete ---\n");
        }

        // Simulates LLM generating a structured plan based on employee data
        private List<OnboardingTask> GeneratePersonalizedPlan(EmployeeData emp)
        {
            Console.WriteLine("[Orchestrator] Generating personalized onboarding plan...");
            var tasks = new List<OnboardingTask>();

            // Logic: Department specific tasks
            if (emp.Department == "Engineering")
            {
                tasks.Add(new OnboardingTask 
                { 
                    TaskName = "Setup Dev Environment", 
                    Description = $"Install VS Code and Git for {emp.Role}", 
                    AssignedSystem = "DevOps", 
                    IsCompleted = false 
                });
            }

            // Logic: Role specific tasks
            tasks.Add(new OnboardingTask 
            { 
                TaskName = "Security Training", 
                Description = "Complete mandatory GDPR compliance module", 
                AssignedSystem = "LMS", 
                IsCompleted = false 
            });

            // Logic: General IT tasks
            tasks.Add(new OnboardingTask 
            { 
                TaskName = "Account Provisioning", 
                Description = "Create email and network drive access", 
                AssignedSystem = "IdentityMgmt", 
                IsCompleted = false 
            });

            return tasks;
        }

        // Executes the plan against specific systems
        private void ExecuteTasks(List<OnboardingTask> tasks, EmployeeData emp)
        {
            Console.WriteLine("[Orchestrator] Executing automated workflows...");
            
            foreach (var task in tasks)
            {
                // Guardrail: Check if task requires sensitive action
                if (task.AssignedSystem == "IdentityMgmt")
                {
                    // Perform the action via the connector
                    string username = _idm.ProvisionAccount(emp);
                    Console.WriteLine($"   -> Result: Account '{username}' created.");
                    task.IsCompleted = true;
                }
                else
                {
                    // Simulate generic system integration
                    Console.WriteLine($"   -> Dispatching '{task.TaskName}' to {task.AssignedSystem} API.");
                    task.IsCompleted = true;
                }
            }

            // Update Legacy System Status
            _hris.UpdateOnboardingStatus(emp.EmployeeId, "Active - Onboarding Complete");
        }

        // Handles natural language queries using RAG
        private void HandlePolicyQuery(string query)
        {
            Console.WriteLine("\n[Orchestrator] Handling Policy Query...");
            
            // 1. Retrieve Context
            PolicyQueryResult context = _kb.RetrievePolicyContext(query);

            if (context != null)
            {
                // 2. Simulate LLM Generation (Grounded Response)
                // In reality, this sends 'context' + 'query' to an LLM API.
                string generatedResponse = $"Based on {context.Citation}, {context.RelevantSection}: {context.PolicyText}";
                
                Console.WriteLine($"[LLM Response]: \"{generatedResponse}\"");
            }
            else
            {
                Console.WriteLine("[LLM Response]: \"I'm sorry, I couldn't find a relevant policy for that query.\"");
            }
        }
    }

    // CLASS 5: Main Program Execution
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the Orchestrator
            // In a real scenario, this would be a Dependency Injection container
            var assistant = new OnboardingOrchestrator();

            // Simulate a new hire event
            string newHireId = "EMP-2024-089";
            
            // Run the process
            assistant.ProcessOnboardingRequest(newHireId);

            // Keep console open
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
