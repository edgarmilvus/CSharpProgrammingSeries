
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HrOnboarding.Rag
{
    public enum AccessLevel { Employee, Manager, Executive }

    public record DocumentChunk(string Id, string Content, List<float> Embedding, AccessLevel RequiredAccessLevel);

    public class SecureRagPipeline
    {
        private readonly List<DocumentChunk> _vectorStore;
        
        public SecureRagPipeline(List<DocumentChunk> initialData) => _vectorStore = initialData;

        public async IAsyncEnumerable<string> RetrieveAndGenerateAsync(string query, AccessLevel userAccess)
        {
            // 1. Simulate embedding generation for the query
            var queryEmbedding = await GenerateEmbeddingAsync(query);

            // 2. Perform Semantic Search (Cosine Similarity)
            var candidates = _vectorStore
                .Select(chunk => new 
                { 
                    Chunk = chunk, 
                    Score = CalculateCosineSimilarity(queryEmbedding, chunk.Embedding) 
                })
                .OrderByDescending(x => x.Score)
                .Take(5) // Top-k
                .ToList();

            // 3. Apply Security Filter using pattern matching
            var filteredCandidates = candidates
                .Where(x => x.Chunk.RequiredAccessLevel <= userAccess)
                .ToList();

            // 4. Check for Empty Context
            if (!filteredCandidates.Any())
            {
                yield return "I cannot answer that based on your current access level.";
                yield break;
            }

            // 5. Construct Context and Generate
            var context = string.Join("\n\n", filteredCandidates.Select(x => x.Chunk.Content));
            var prompt = $"Context: {context}\n\nQuestion: {query}\n\nAnswer concisely.";
            
            // Mock LLM Call
            var response = await MockLLMGenerateAsync(prompt);
            yield return response;
        }

        private Task<float[]> GenerateEmbeddingAsync(string text) 
            => Task.FromResult(new float[] { 0.1f, 0.2f, 0.3f }); // Mock

        private float CalculateCosineSimilarity(float[] a, float[] b) 
            => 0.95f; // Mock

        private Task<string> MockLLMGenerateAsync(string prompt) 
            => Task.FromResult($"Generated response for: {prompt}");
    }
}
