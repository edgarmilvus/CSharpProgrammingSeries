
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace HrOnboarding.DocumentProcessing
{
    public class ProcessedFormData
    {
        public string FormType { get; set; }
        public decimal Salary { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; } // Added for guardrail logic
    }

    public class DocumentProcessingWorkflow
    {
        private readonly IOcrService _ocrService;
        private readonly ILlmClient _llmClient;

        public DocumentProcessingWorkflow(IOcrService ocrService, ILlmClient llmClient)
        {
            _ocrService = ocrService;
            _llmClient = llmClient;
        }

        public async Task<ProcessedFormData> ProcessForm(byte[] fileData, string formType)
        {
            // 1. Parallel Processing using Task.WhenAll
            var ocrTask = _ocrService.ExtractTextAsync(fileData);
            var textExtractionTask = _ocrService.ExtractTextFromMetadataAsync(fileData);

            await Task.WhenAll(ocrTask, textExtractionTask);

            var extractedText = CombineResults(ocrTask.Result, textExtractionTask.Result);

            // 2. LLM Extraction with Retry Logic
            string jsonResponse = await CallLlmWithRetryAsync(extractedText, formType);

            // 3. Deserialization
            var formData = JsonSerializer.Deserialize<ProcessedFormData>(jsonResponse);

            // 4. Compliance Guardrail
            ApplyComplianceGuardrail(formData);

            return formData;
        }

        private async Task<string> CallLlmWithRetryAsync(string text, string formType)
        {
            int attempts = 0;
            while (attempts < 3)
            {
                try
                {
                    var response = await _llmClient.ExtractDataAsync(text, formType);
                    // Validate JSON structure immediately
                    JsonDocument.Parse(response);
                    return response;
                }
                catch (JsonException)
                {
                    attempts++;
                    if (attempts >= 3) 
                        throw new InvalidOperationException("LLM failed to produce valid JSON after 3 attempts.");
                    
                    // Exponential backoff: 2s, 4s, 8s...
                    await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempts)));
                }
            }
            throw new InvalidOperationException("Unexpected error in LLM call.");
        }

        private void ApplyComplianceGuardrail(ProcessedFormData data)
        {
            // Example Rule: IT roles cannot have salary > 200,000 without executive approval
            if (data.Department?.Equals("IT", StringComparison.OrdinalIgnoreCase) == true && data.Salary > 200000)
            {
                throw new InvalidOperationException($"Compliance Violation: Salary {data.Salary} exceeds limit for role {data.Department}.");
            }
        }

        private string CombineResults(string r1, string r2) => $"{r1} {r2}";
    }

    // Mock interfaces for context
    public interface IOcrService { Task<string> ExtractTextAsync(byte[] data); Task<string> ExtractTextFromMetadataAsync(byte[] data); }
    public interface ILlmClient { Task<string> ExtractDataAsync(string text, string type); }
}
