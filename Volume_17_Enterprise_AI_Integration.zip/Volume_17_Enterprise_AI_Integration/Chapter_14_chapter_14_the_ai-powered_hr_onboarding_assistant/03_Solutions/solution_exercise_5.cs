
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HrOnboarding.Validation
{
    public record OnboardingPlan
    {
        [JsonPropertyName("start_date")]
        public DateTime StartDate { get; init; }

        [JsonPropertyName("tasks")]
        public List<string> Tasks { get; init; } = new();

        [JsonPropertyName("probation_days")]
        public int ProbationDays { get; init; }
    }

    public class ValidationResult
    {
        public bool IsValid => !ParseErrors.Any() && !BusinessRuleViolations.Any();
        public List<string> ParseErrors { get; } = new();
        public List<string> BusinessRuleViolations { get; } = new();
    }

    public class PlanValidator
    {
        public async Task<ValidationResult> ValidatePlanAsync(string llmJsonOutput)
        {
            var result = new ValidationResult();

            // 1. Schema Validation (Parsing)
            OnboardingPlan plan;
            try
            {
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                plan = JsonSerializer.Deserialize<OnboardingPlan>(llmJsonOutput, options);
            }
            catch (JsonException ex)
            {
                result.ParseErrors.Add($"Failed to parse JSON: {ex.Message}");
                return result;
            }

            // 2. Business Rule Validation (Guardrails)
            // Rule: Start date must be in the future
            if (plan.StartDate < DateTime.Now)
            {
                result.BusinessRuleViolations.Add($"Start date {plan.StartDate:yyyy-MM-dd} cannot be in the past.");
            }

            // Rule: Tasks must not be empty
            if (plan.Tasks == null || !plan.Tasks.Any())
            {
                result.BusinessRuleViolations.Add("Onboarding plan must contain at least one task.");
            }

            // Rule: Probation days logic
            if (plan.ProbationDays > 90)
            {
                result.BusinessRuleViolations.Add("Probation period cannot exceed 90 days by company policy.");
            }

            return result;
        }
    }

    public class AiAssistant
    {
        public async Task<string> GenerateStructuredPlanAsync(string employeeData)
        {
            // Simulate LLM generating JSON based on input
            await Task.Delay(100);
            return @"{
                ""start_date"": ""2024-12-01"",
                ""tasks"": [""Orientation"", ""Security Training""],
                ""probation_days"": 100
            }";
        }
    }
}
