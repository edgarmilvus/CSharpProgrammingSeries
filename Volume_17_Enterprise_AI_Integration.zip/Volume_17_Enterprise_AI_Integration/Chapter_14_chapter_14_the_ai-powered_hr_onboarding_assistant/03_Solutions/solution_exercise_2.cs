
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Xml.Linq;
using System.Threading.Tasks;

namespace HrOnboarding.Integration
{
    // Legacy System (Mock)
    public interface ILegacyHrisService
    {
        Task<string> GetEmployeeXmlAsync(string employeeId);
    }

    // Modern Target
    public record EmployeeProfile(string Id, string FullName, string Department, DateTime HireDate);

    public interface INewHrisService
    {
        Task<EmployeeProfile> GetProfileAsync(string employeeId);
    }

    // The Adapter
    public class LegacyHrisAdapter : INewHrisService
    {
        private readonly ILegacyHrisService _legacyService;

        public LegacyHrisAdapter(ILegacyHrisService legacyService)
        {
            _legacyService = legacyService;
        }

        public async Task<EmployeeProfile> GetProfileAsync(string employeeId)
        {
            // 1. Call Legacy System
            string xmlContent = await _legacyService.GetEmployeeXmlAsync(employeeId);

            // 2. Parse XML using XDocument
            var doc = XDocument.Parse(xmlContent);
            var root = doc.Root ?? throw new InvalidOperationException("Invalid XML: No root element.");

            // 3. Extract Data with pattern matching for null safety
            var id = root.Element("Id")?.Value;
            var name = root.Element("Name")?.Value;
            var dept = root.Element("Dept")?.Value;
            var dateStr = root.Element("Date")?.Value;

            // 4. Map to Modern Object
            if (string.IsNullOrEmpty(id) || !DateTime.TryParse(dateStr, out var hireDate))
            {
                throw new InvalidOperationException("Invalid legacy data format");
            }

            return new EmployeeProfile(id, name ?? "Unknown", dept ?? "Unassigned", hireDate);
        }
    }
}
