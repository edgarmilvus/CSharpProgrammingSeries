
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace HrOnboarding.Events
{
    public record OnboardingEvent(string EmployeeId, string EventType, Dictionary<string, object> Payload);

    public class EventPublisher
    {
        private readonly Channel<OnboardingEvent> _channel;

        public EventPublisher(int capacity)
        {
            var options = new BoundedChannelOptions(capacity)
            {
                FullMode = BoundedChannelFullMode.Wait // Blocks producer when capacity is reached
            };
            _channel = Channel.CreateBounded<OnboardingEvent>(options);
        }

        public ChannelReader<OnboardingEvent> Reader => _channel.Reader;

        public async Task PublishAsync(OnboardingEvent evt)
        {
            // Asynchronously write to the channel
            await _channel.Writer.WriteAsync(evt);
        }

        public void Complete() => _channel.Writer.Complete();
    }

    public class EventConsumer
    {
        private readonly ChannelReader<OnboardingEvent> _reader;
        private readonly Dictionary<string, Action<OnboardingEvent>> _handlers;

        public EventConsumer(ChannelReader<OnboardingEvent> reader)
        {
            _reader = reader;
            _handlers = new Dictionary<string, Action<OnboardingEvent>>
            {
                { "AccountProvisioning", e => Console.WriteLine($"[IT] Provisioning account for {e.EmployeeId}") },
                { "DeskAssignment", e => Console.WriteLine($"[Facilities] Assigning desk for {e.EmployeeId}") }
            };
        }

        public async Task ProcessEventsAsync()
        {
            // Async stream reading from the channel
            await foreach (var evt in _reader.ReadAllAsync())
            {
                if (_handlers.TryGetValue(evt.EventType, out var handler))
                {
                    // Simulate async processing
                    await Task.Run(() => handler(evt));
                }
            }
        }
    }

    // Usage in AI Orchestrator
    public class AiOrchestrator
    {
        private readonly EventPublisher _publisher;

        public AiOrchestrator(EventPublisher publisher) => _publisher = publisher;

        public async Task OnboardEmployeeAsync(string employeeId)
        {
            // Fire and forget publishing - non-blocking
            await _publisher.PublishAsync(new OnboardingEvent(employeeId, "AccountProvisioning", new()));
            await _publisher.PublishAsync(new OnboardingEvent(employeeId, "DeskAssignment", new()));
            
            // Continue with AI logic immediately
            Console.WriteLine($"AI Orchestrator finished triggers for {employeeId}");
        }
    }
}
