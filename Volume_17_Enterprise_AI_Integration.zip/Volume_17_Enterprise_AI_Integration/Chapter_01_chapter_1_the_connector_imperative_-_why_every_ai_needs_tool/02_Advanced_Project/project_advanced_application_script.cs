
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;

namespace EnterpriseAI.ConnectorPattern
{
    // CONTEXT: The 'Connector' Imperative - Why Every AI Needs Tools
    // REAL-WORLD PROBLEM: A manufacturing company needs to automate its "Inventory Replenishment" process.
    // The AI Agent must access real-time inventory levels (from a legacy mainframe database)
    // and current sales orders (from a modern REST API) to make a decision.
    // STANDALONE LLM LIMITATION: The LLM knows the *procedure* (if stock < threshold, order),
    // but has no access to the live data or the ability to trigger the procurement system.
    // SOLUTION: We implement the "Connector" pattern using basic C# constructs to bridge the gap.

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Enterprise AI Inventory Replenishment System ===");
            Console.WriteLine("Initializing AI Agent with Legacy System Connectors...\n");

            // 1. INITIALIZE SYSTEMS
            // We simulate two distinct data sources:
            // A. Legacy Mainframe (Simulated via a class with hardcoded data)
            // B. Modern REST API (Simulated via a class with hardcoded data)
            LegacyInventorySystem legacySystem = new LegacyInventorySystem();
            ModernSalesApi salesApi = new ModernSalesApi();

            // 2. AI AGENT LOGIC FLOW
            // The AI Agent acts as the orchestrator. It doesn't "know" the data; it queries it via connectors.
            AIReplenishmentAgent agent = new AIReplenishmentAgent(legacySystem, salesApi);
            
            // Execute the automation process
            agent.ExecuteReplenishmentCycle();

            Console.WriteLine("\n=== Process Cycle Complete ===");
        }
    }

    // ARCHITECTURE COMPONENT: Legacy System Connector
    // PURPOSE: Encapsulates access to the mainframe database.
    // CONSTRAINT: Uses basic methods and strings. No LINQ or advanced features.
    public class LegacyInventorySystem
    {
        // Simulated database state
        private string[,] inventoryData;

        public LegacyInventorySystem()
        {
            // Structure: [ProductID, Name, CurrentStock, ReorderThreshold]
            inventoryData = new string[3, 4];
            inventoryData[0, 0] = "P100"; inventoryData[0, 1] = "Widget A"; inventoryData[0, 2] = "50"; inventoryData[0, 3] = "100";
            inventoryData[1, 0] = "P101"; inventoryData[1, 1] = "Widget B"; inventoryData[1, 2] = "200"; inventoryData[1, 3] = "150";
            inventoryData[2, 0] = "P102"; inventoryData[2, 1] = "Widget C"; inventoryData[2, 2] = "10"; inventoryData[2, 3] = "50";
        }

        // CONNECTOR METHOD: Exposes internal logic to the AI Agent
        public int GetCurrentStock(string productId)
        {
            // Basic loop to search the 2D array (simulating a database query)
            for (int i = 0; i < inventoryData.GetLength(0); i++)
            {
                if (inventoryData[i, 0] == productId)
                {
                    return int.Parse(inventoryData[i, 2]);
                }
            }
            return 0; // Default if not found
        }

        public int GetReorderThreshold(string productId)
        {
            for (int i = 0; i < inventoryData.GetLength(0); i++)
            {
                if (inventoryData[i, 0] == productId)
                {
                    return int.Parse(inventoryData[i, 3]);
                }
            }
            return 0;
        }
    }

    // ARCHITECTURE COMPONENT: External API Connector
    // PURPOSE: Simulates fetching real-time sales orders from a cloud service.
    public class ModernSalesApi
    {
        // Simulated API Response Data
        private string[] pendingOrders;

        public ModernSalesApi()
        {
            // Simulating a JSON response parsed into a simple array
            pendingOrders = new string[] { "P100:20", "P102:45" }; // Format: ProductID:Quantity
        }

        // CONNECTOR METHOD: Exposes external data to the AI Agent
        public int GetIncomingDemand(string productId)
        {
            int totalDemand = 0;
            
            // Iterating through "API response"
            for (int i = 0; i < pendingOrders.Length; i++)
            {
                // Basic string parsing (simulating JSON parsing)
                string[] parts = pendingOrders[i].Split(':');
                if (parts[0] == productId)
                {
                    totalDemand += int.Parse(parts[1]);
                }
            }
            return totalDemand;
        }
    }

    // ARCHITECTURE COMPONENT: The AI Agent (Orchestrator)
    // PURPOSE: Contains the business logic (the "Brain") and coordinates the connectors.
    public class AIReplenishmentAgent
    {
        private LegacyInventorySystem _legacySystem;
        private ModernSalesApi _salesApi;

        // Dependency Injection via Constructor (Basic OOP)
        public AIReplenishmentAgent(LegacyInventorySystem legacy, ModernSalesApi sales)
        {
            _legacySystem = legacy;
            _salesApi = sales;
        }

        public void ExecuteReplenishmentCycle()
        {
            string[] productIds = { "P100", "P101", "P102" };

            Console.WriteLine("AI Agent: Analyzing inventory levels for " + productIds.Length + " products...");

            // Loop through all products (Batch Processing)
            for (int i = 0; i < productIds.Length; i++)
            {
                string currentProduct = productIds[i];

                // STEP 1: GATHER CONTEXT (via Connectors)
                // The AI Agent calls the tools to get real-time data.
                int currentStock = _legacySystem.GetCurrentStock(currentProduct);
                int threshold = _legacySystem.GetReorderThreshold(currentProduct);
                int incomingDemand = _salesApi.GetIncomingDemand(currentProduct);

                // Display current state
                Console.WriteLine($"\n--- Analysis for {currentProduct} ---");
                Console.WriteLine($"  [Legacy DB] Current Stock: {currentStock}");
                Console.WriteLine($"  [Legacy DB] Reorder Threshold: {threshold}");
                Console.WriteLine($"  [Sales API] Incoming Demand: {incomingDemand}");

                // STEP 2: APPLY BUSINESS LOGIC (The "Reasoning" Layer)
                // This logic could be replaced by an LLM's decision output in a more advanced system.
                // Here, we use deterministic logic to simulate the AI's decision.
                
                int projectedStock = currentStock - incomingDemand;

                if (projectedStock < threshold)
                {
                    // STEP 3: EXECUTE ACTION (via Connector)
                    // The AI decides to act. It calls a function to trigger the procurement system.
                    TriggerProcurementOrder(currentProduct, threshold, projectedStock);
                }
                else
                {
                    Console.WriteLine("  DECISION: Stock levels healthy. No action needed.");
                }
            }
        }

        // SIMULATED ACTION CONNECTOR
        // In a real enterprise, this would call an ERP API (e.g., SAP, Oracle) to create a Purchase Order.
        private void TriggerProcurementOrder(string productId, int threshold, int currentStock)
        {
            int orderQuantity = threshold - currentStock + 50; // Safety buffer logic
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  DECISION: REPLENISH REQUIRED.");
            Console.WriteLine($"  ACTION: Sending POST request to Procurement API...");
            Console.WriteLine($"  DETAILS: Order ID: {Guid.NewGuid().ToString().Substring(0, 8)} | Product: {productId} | Qty: {orderQuantity}");
            Console.ResetColor();
        }
    }
}
