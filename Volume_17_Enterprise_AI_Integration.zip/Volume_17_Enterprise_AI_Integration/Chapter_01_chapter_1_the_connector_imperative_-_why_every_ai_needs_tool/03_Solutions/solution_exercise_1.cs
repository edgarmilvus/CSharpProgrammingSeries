
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// 1. Legacy Code Simulation
public static class LegacyOrderSystem
{
    public static decimal CalculateTotal(decimal subtotal, string stateCode, bool isExpressShipping)
    {
        // State tax rates
        decimal taxRate = stateCode?.ToUpper() switch
        {
            "CA" => 0.085m,
            "NY" => 0.080m,
            "TX" => 0.065m,
            _ => 0.050m
        };

        decimal taxAmount = subtotal * taxRate;

        // Shipping logic
        decimal shippingCost = 0.0m;
        if (isExpressShipping)
        {
            shippingCost = 15.00m;
        }
        else
        {
            // Standard shipping: $5 if subtotal < $50, otherwise free
            shippingCost = subtotal < 50 ? 5.00m : 0.00m;
        }

        return subtotal + taxAmount + shippingCost;
    }
}

// Metadata DTO (Simulating a schema definition)
public class FunctionDefinition
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Dictionary<string, ParameterDefinition> Parameters { get; set; } = new();
    public List<string> Required { get; set; } = new();
}

public class ParameterDefinition
{
    public string Type { get; set; } = string.Empty; // "string", "number", "boolean"
    public string Description { get; set; } = string.Empty;
    public List<string>? Enum { get; set; } // For shipping tiers
}

// 2. Connector Definition
public class OrderCalculatorConnector
{
    // 3. Metadata Generation
    public FunctionDefinition GetDefinition()
    {
        return new FunctionDefinition
        {
            Name = "calculate_order_total",
            Description = "Calculates the total price of an order including tax and shipping based on the state and shipping tier.",
            Parameters = new Dictionary<string, ParameterDefinition>
            {
                ["subtotal"] = new ParameterDefinition 
                { 
                    Type = "number", 
                    Description = "The total cost of items before tax and shipping." 
                },
                ["stateCode"] = new ParameterDefinition 
                { 
                    Type = "string", 
                    Description = "The two-letter state code (e.g., CA, NY, TX)." 
                },
                ["shippingTier"] = new ParameterDefinition 
                { 
                    Type = "string", 
                    Description = "The shipping speed tier.", 
                    Enum = new List<string> { "Standard", "Express", "Overnight" } 
                }
            },
            Required = new List<string> { "subtotal", "stateCode", "shippingTier" }
        };
    }

    // 4. Invocation Logic (Interactive Challenge Implementation)
    public async Task<string> InvokeAsync(Dictionary<string, object> arguments)
    {
        // Validate existence of required arguments
        if (!arguments.TryGetValue("subtotal", out var subObj) ||
            !arguments.TryGetValue("stateCode", out var stateObj) ||
            !arguments.TryGetValue("shippingTier", out var tierObj))
        {
            throw new ArgumentException("Missing required arguments: subtotal, stateCode, or shippingTier.");
        }

        // Deserialize arguments
        decimal subtotal;
        try 
        { 
            // Handle both numeric types and strings from JSON
            subtotal = Convert.ToDecimal(subObj); 
        }
        catch 
        { 
            throw new ArgumentException("Subtotal must be a valid number."); 
        }

        string stateCode = stateObj.ToString() ?? string.Empty;
        string shippingTier = tierObj.ToString() ?? string.Empty;

        // Map shipping tier to boolean logic for the legacy system
        bool isExpressShipping = shippingTier.Equals("Express", StringComparison.OrdinalIgnoreCase);
        bool isOvernight = shippingTier.Equals("Overnight", StringComparison.OrdinalIgnoreCase);

        // Interactive Challenge: Extended logic for Overnight
        decimal shippingCost = 0m;
        
        // We simulate the legacy call, but we intercept the shipping logic to support new tiers
        // Note: The legacy method only supports boolean express. We will adapt inputs.
        
        // If Overnight, we treat it as Express for the base call, then add a surcharge, 
        // or we can just implement the logic directly here to avoid modifying the legacy class.
        // Let's implement the logic directly here to support the new requirement fully.
        
        decimal taxRate = stateCode.ToUpper() switch
        {
            "CA" => 0.085m,
            "NY" => 0.080m,
            "TX" => 0.065m,
            _ => 0.050m
        };

        decimal taxAmount = subtotal * taxRate;

        // New Shipping Logic
        shippingCost = shippingTier.ToUpper() switch
        {
            "EXPRESS" => 15.00m,
            "OVERNIGHT" => 25.00m,
            "STANDARD" => subtotal < 50 ? 5.00m : 0.00m,
            _ => throw new ArgumentException($"Unknown shipping tier: {shippingTier}")
        };

        decimal total = subtotal + taxAmount + shippingCost;

        // Simulate async work
        await Task.Delay(50); 

        return $"{{ \"total\": {total:F2}, \"currency\": \"USD\" }}";
    }
}

// Usage Example (Not required for solution, but good for context)
public class Program
{
    public static void Main()
    {
        var connector = new OrderCalculatorConnector();
        var args = new Dictionary<string, object>
        {
            ["subtotal"] = 100.0m,
            ["stateCode"] = "CA",
            ["shippingTier"] = "Overnight"
        };

        var result = connector.InvokeAsync(args).Result;
        Console.WriteLine(result); // Output: {"total": 143.50, "currency": "USD"}
    }
}
