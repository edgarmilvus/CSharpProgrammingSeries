
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// 1. External API Simulation
public interface IInventoryService
{
    Task<InventoryResponse> GetStockAsync(string sku);
}

public class InventoryResponse
{
    public string Sku { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public int QuantityAvailable { get; set; }
    public List<WarehouseLocation> WarehouseLocations { get; set; } = new();
    public int ReorderThreshold { get; set; }
    public string Status { get; set; } = string.Empty; // Calculated field
}

public class WarehouseLocation
{
    public string WarehouseId { get; set; } = string.Empty;
    public string BinCode { get; set; } = string.Empty;
}

// Mock Implementation
public class MockInventoryService : IInventoryService
{
    public Task<InventoryResponse> GetStockAsync(string sku)
    {
        var response = new InventoryResponse
        {
            Sku = sku,
            ProductName = "High-Performance Laptop",
            QuantityAvailable = 150,
            ReorderThreshold = 20,
            WarehouseLocations = new List<WarehouseLocation>
            {
                new() { WarehouseId = "WH-NY", BinCode = "A-12" },
                new() { WarehouseId = "WH-CA", BinCode = "B-05" }
            }
        };
        
        // Calculate Status
        response.Status = response.QuantityAvailable switch
        {
            0 => "OutOfStock",
            <= 20 => "LowStock",
            _ => "InStock"
        };

        return Task.FromResult(response);
    }
}

// 2. Internal DTO Definition (Immutable Records)
public record WarehouseLocationDto(string WarehouseId, string BinCode);

public record InventoryItemDto(
    string Sku, 
    string ProductName, 
    int QuantityAvailable, 
    List<WarehouseLocationDto> WarehouseLocations, 
    string Status
);

// 3. Connector Implementation
public class InventoryConnector
{
    private readonly IInventoryService _service;

    public InventoryConnector(IInventoryService service)
    {
        _service = service;
    }

    // 4. Schema Mapping (Simulating JSON Schema generation)
    public string GetJsonSchema()
    {
        // In a real scenario, use System.Text.Json.Nodes or a library like NJsonSchema.
        // Here we return a simplified string representation for the LLM.
        return """
        {
            "type": "object",
            "properties": {
                "sku": { "type": "string", "description": "The product SKU code." },
                "include_filter": { "type": "string", "enum": ["all", "available"], "description": "Filter results by availability." }
            },
            "required": ["sku"]
        }
        """;
    }

    // 5. Data Retrieval with Filtering (Interactive Challenge)
    public async Task<string> ExecuteQueryAsync(string sku, string includeFilter = "all")
    {
        var response = await _service.GetStockAsync(sku);

        // Interactive Challenge: Filtering logic
        if (includeFilter == "available" && response.Status != "InStock")
        {
            return $"Product {sku} is currently {response.Status} and is excluded from the results.";
        }

        // Map to DTO
        var dto = new InventoryItemDto(
            response.Sku,
            response.ProductName,
            response.QuantityAvailable,
            response.WarehouseLocations.Select(w => new WarehouseLocationDto(w.WarehouseId, w.BinCode)).ToList(),
            response.Status
        );

        // Return simplified summary for LLM context
        var warehouseCount = dto.WarehouseLocations.Count;
        return $"Product: {dto.ProductName} (SKU: {dto.Sku}). Status: {dto.Status}. " +
               $"Available Units: {dto.QuantityAvailable}. " +
               $"Stored in {warehouseCount} warehouses.";
    }
}

// Usage Example
public class InventoryProgram
{
    public static async Task Main()
    {
        var service = new MockInventoryService();
        var connector = new InventoryConnector(service);

        // Test 1: Standard query
        Console.WriteLine(await connector.ExecuteQueryAsync("LAP-001"));

        // Test 2: Filter for available items (Interactive Challenge)
        // Simulating a low stock scenario for testing
        // (Modify MockInventoryService to return low stock if needed, 
        // but here it returns InStock, so it will pass through).
        Console.WriteLine(await connector.ExecuteQueryAsync("LAP-001", "available"));
    }
}
