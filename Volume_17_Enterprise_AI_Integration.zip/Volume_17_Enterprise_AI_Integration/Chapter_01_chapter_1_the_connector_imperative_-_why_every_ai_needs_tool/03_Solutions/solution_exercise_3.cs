
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Threading.Tasks;

// 1. Context Definition
public record UserContext(string UserId, string Department, string Role, string AuthToken);

// 2. Middleware Interface
public interface IConnectorMiddleware
{
    Task InvokeAsync(UserContext context, string functionName, Dictionary<string, object> args, Func<Task> next);
}

// 3. Security Middleware
public class RoleCheckMiddleware : IConnectorMiddleware
{
    private readonly string _requiredRole;

    public RoleCheckMiddleware(string requiredRole)
    {
        _requiredRole = requiredRole;
    }

    public async Task InvokeAsync(UserContext context, string functionName, Dictionary<string, object> args, Func<Task> next)
    {
        if (context.Role != _requiredRole && context.Role != "Admin") // Admin bypass
        {
            throw new UnauthorizedAccessException($"User {context.UserId} with role '{context.Role}' is not authorized to execute '{functionName}'. Required role: {_requiredRole}");
        }
        
        Console.WriteLine($"[RoleCheck] Access granted for {functionName}.");
        await next();
    }
}

// 4. Logging Middleware
public class AuditLoggingMiddleware : IConnectorMiddleware
{
    public async Task InvokeAsync(UserContext context, string functionName, Dictionary<string, object> args, Func<Task> next)
    {
        Console.WriteLine($"[AuditLog] User: {context.UserId}, Function: {functionName}, Timestamp: {DateTime.UtcNow}");
        
        // Mask sensitive data in logs if needed
        await next();
    }
}

// 5. Connector Execution Host
public class SecureConnectorHost
{
    private readonly List<IConnectorMiddleware> _middlewares = new();

    public void Use(IConnectorMiddleware middleware)
    {
        _middlewares.Add(middleware);
    }

    public async Task ExecuteAsync(UserContext context, string functionName, Dictionary<string, object> args)
    {
        // Build the pipeline
        Func<Task> pipeline = () => Task.CompletedTask;

        // Reverse order to execute in the order they were added (Standard middleware pattern)
        for (int i = _middlewares.Count - 1; i >= 0; i--)
        {
            var currentMiddleware = _middlewares[i];
            var next = pipeline;
            pipeline = () => currentMiddleware.InvokeAsync(context, functionName, args, next);
        }

        try
        {
            await pipeline();
            
            // Simulate the actual connector logic after middleware
            Console.WriteLine($"[Connector] Executing {functionName} with args: {string.Join(", ", args)}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Error] Pipeline failed: {ex.Message}");
            throw;
        }
    }
}

// Interactive Challenge: Token Refresh Middleware
public class TokenRefreshMiddleware : IConnectorMiddleware
{
    public async Task InvokeAsync(UserContext context, string functionName, Dictionary<string, object> args, Func<Task> next)
    {
        // Simulate checking token expiration
        bool isExpired = context.AuthToken.EndsWith("EXPIRED");
        
        if (isExpired)
        {
            Console.WriteLine("[TokenRefresh] Token expired. Refreshing...");
            await Task.Delay(100); // Simulate network call
            
            // Update context (Note: records are immutable, so we need to pass updated context downstream)
            // However, the interface signature doesn't allow modifying context easily in place.
            // For this exercise, we will simulate the update by logging it, 
            // but in a real immutable setup, we'd pass a new Context object down the pipeline.
            Console.WriteLine("[TokenRefresh] Token refreshed successfully.");
        }
        else
        {
            Console.WriteLine("[TokenRefresh] Token valid.");
        }

        await next();
    }
}

// Usage Example
public class MiddlewareProgram
{
    public static async Task Main()
    {
        var host = new SecureConnectorHost();
        
        // Register Middleware (Order matters: Logging -> Token -> Role -> Execution)
        host.Use(new AuditLoggingMiddleware());
        host.Use(new TokenRefreshMiddleware());
        host.Use(new RoleCheckMiddleware("Admin"));

        var adminContext = new UserContext("user_123", "IT", "Admin", "token_123");
        var userContext = new UserContext("user_456", "Sales", "User", "token_456_EXPIRED");

        var args = new Dictionary<string, object> { ["target"] = "system_config" };

        try
        {
            // Should succeed
            Console.WriteLine("--- Executing Admin Request ---");
            await host.ExecuteAsync(adminContext, "DeleteUser", args);
        }
        catch { }

        try
        {
            // Should fail authorization
            Console.WriteLine("\n--- Executing User Request ---");
            await host.ExecuteAsync(userContext, "DeleteUser", args);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Caught expected exception: {ex.Message}");
        }
    }
}
