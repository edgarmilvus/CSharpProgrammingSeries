
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// 1. Simulated Database
public static class InMemoryDatabase
{
    public static Dictionary<int, string> Users = new()
    {
        { 1, "{\"Id\": 1, \"Email\": \"user@example.com\", \"Phone\": \"555-0100\"}" }
    };
}

// 2. Transactional Interface
public interface ITransactionalConnector
{
    void BeginTransaction();
    void Commit();
    void Rollback();
    Task ExecuteOperationAsync(string operation, object args);
}

// 3. Connector Implementation
public class UserManagementConnector : ITransactionalConnector
{
    // Staging area
    private Dictionary<int, string> _stagingUsers = new();
    private bool _inTransaction = false;

    // For Saga Pattern
    private List<Func<Task>> _compensationActions = new();

    public void BeginTransaction()
    {
        if (_inTransaction) throw new InvalidOperationException("Transaction already started.");
        _inTransaction = true;
        _stagingUsers = new Dictionary<int, string>(InMemoryDatabase.Users); // Clone current state
        Console.WriteLine("[Transaction] Begun.");
    }

    public async Task ExecuteOperationAsync(string operation, object args)
    {
        if (!_inTransaction) throw new InvalidOperationException("No active transaction.");

        // Parse args
        var argDict = args as Dictionary<string, object> ?? new Dictionary<string, object>();
        int userId = Convert.ToInt32(argDict["userId"]);

        if (operation == "UpdateEmail")
        {
            string newEmail = argDict["email"].ToString()!;
            
            // Store old value for compensation
            var oldData = _stagingUsers[userId];
            _compensationActions.Add(async () => 
            {
                Console.WriteLine($"[Compensation] Reverting email for User {userId}.");
                _stagingUsers[userId] = oldData;
            });

            // Apply to staging
            // Simulating JSON update
            _stagingUsers[userId] = $"{{\"Id\": {userId}, \"Email\": \"{newEmail}\", \"Phone\": \"555-0100\"}}";
            Console.WriteLine($"[Staging] Updated Email for User {userId}.");
        }
        else if (operation == "LogAudit")
        {
            // Simulate external service call
            bool shouldFail = new Random().Next(0, 10) < 3; // 30% chance of failure
            if (shouldFail) throw new Exception("Audit Service Unavailable");

            // If successful, we might not need compensation if it's just logging, 
            // but for the Saga pattern, we assume we need to undo the email if audit fails.
            Console.WriteLine($"[External] Audit log written for User {userId}.");
        }
    }

    public void Commit()
    {
        if (!_inTransaction) return;
        
        // Apply staging to main DB
        InMemoryDatabase.Users = new Dictionary<int, string>(_stagingUsers);
        _inTransaction = false;
        _compensationActions.Clear();
        Console.WriteLine("[Transaction] Committed to database.");
    }

    public async Task Rollback()
    {
        if (!_inTransaction) return;

        Console.WriteLine("[Transaction] Rolling back...");
        
        // Execute compensation actions (Saga pattern)
        foreach (var action in _compensationActions.Reverse<Func<Task>>())
        {
            await action();
        }

        _inTransaction = false;
        _compensationActions.Clear();
        Console.WriteLine("[Transaction] Rollback complete.");
    }

    // 4. LLM Interface & Saga Logic (Interactive Challenge)
    public async Task<string> ProcessRequestAsync(string command, Dictionary<string, object> args)
    {
        if (command == "batch_update")
        {
            BeginTransaction();
            try
            {
                // Step A: Update Email
                await ExecuteOperationAsync("UpdateEmail", args);

                // Step B: Trigger External Audit (Simulated)
                // If this fails, we must revert Step A
                await ExecuteOperationAsync("LogAudit", args);

                Commit();
                return "Batch update successful.";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Saga] Failure detected: {ex.Message}");
                await Rollback(); // Trigger compensation
                return $"Batch update failed: {ex.Message}. Changes reverted.";
            }
        }
        return "Unknown command.";
    }
}

// Usage Example
public class TransactionProgram
{
    public static async Task Main()
    {
        var connector = new UserManagementConnector();
        
        var args = new Dictionary<string, object>
        {
            ["userId"] = 1,
            ["email"] = "new_email@company.com"
        };

        // Run Saga
        string result = await connector.ProcessRequestAsync("batch_update", args);
        Console.WriteLine($"Result: {result}");
        
        // Check DB State
        Console.WriteLine($"DB State: {InMemoryDatabase.Users[1]}");
    }
}
