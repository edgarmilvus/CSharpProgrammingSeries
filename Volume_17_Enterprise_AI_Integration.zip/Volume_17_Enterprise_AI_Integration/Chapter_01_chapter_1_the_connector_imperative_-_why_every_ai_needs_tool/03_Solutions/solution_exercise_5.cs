
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// --- 1. System Components ---

// Mock Services
public interface IInventoryService { Task<bool> ReserveStockAsync(string sku, int qty); Task ReleaseStockAsync(string sku, int qty); }
public interface IPaymentGateway { Task<bool> ProcessPaymentAsync(decimal amount, string token); Task<bool> RefundAsync(decimal amount); }
public interface IOrderCalculator { Task<decimal> CalculateTotalAsync(decimal subtotal); }

public class MockInventory : IInventoryService 
{
    public Task<bool> ReserveStockAsync(string sku, int qty) 
    {
        Console.WriteLine($"[Inventory] Reserving {qty} of {sku}.");
        return Task.FromResult(true); // Simulate success
    }
    public Task<bool> ReleaseStockAsync(string sku, int qty) 
    {
        Console.WriteLine($"[Inventory] Releasing {qty} of {sku}.");
        return Task.FromResult(true);
    }
}

public class MockPayment : IPaymentGateway
{
    public Task<bool> ProcessPaymentAsync(decimal amount, string token)
    {
        Console.WriteLine($"[Payment] Processing ${amount} with token {token}.");
        if (token == "FAIL") return Task.FromResult(false);
        return Task.FromResult(true);
    }
    public Task<bool> RefundAsync(decimal amount)
    {
        Console.WriteLine($"[Payment] Refunding ${amount}.");
        return Task.FromResult(true);
    }
}

public class MockCalculator : IOrderCalculator
{
    public Task<decimal> CalculateTotalAsync(decimal subtotal) => Task.FromResult(subtotal * 1.1m); // +10% tax
}

// --- 2. Middleware Pipeline (From Ex 3) ---
public interface IConnectorMiddleware
{
    Task InvokeAsync(Context context, Func<Task> next);
}

public class Context
{
    public Dictionary<string, object> State { get; } = new();
}

// --- 3. Transaction Scope Middleware (Interactive Challenge) ---
public class TransactionScopeMiddleware : IConnectorMiddleware
{
    private readonly List<Func<Task>> _compensations = new();

    public async Task InvokeAsync(Context context, Func<Task> next)
    {
        try
        {
            await next();
            Console.WriteLine("[TransactionScope] Success. Committing...");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TransactionScope] Failure: {ex.Message}. Rolling back...");
            // Execute compensations in reverse order
            foreach (var compensate in _compensations.Reverse<Func<Task>>())
            {
                await compensate();
            }
            throw; // Re-throw to stop the pipeline
        }
    }

    public void RegisterCompensation(Func<Task> compensationAction)
    {
        _compensations.Add(compensationAction);
    }
}

// --- 4. Connectors with Middleware Support ---

public class InventoryConnector
{
    private readonly IInventoryService _service;
    private readonly TransactionScopeMiddleware _transaction;

    public InventoryConnector(IInventoryService service, TransactionScopeMiddleware transaction)
    {
        _service = service;
        _transaction = transaction;
    }

    public async Task CheckAndReserve(string sku, int qty)
    {
        bool success = await _service.ReserveStockAsync(sku, qty);
        if (!success) throw new Exception("Inventory reservation failed.");
        
        // Register rollback
        _transaction.RegisterCompensation(async () => await _service.ReleaseStockAsync(sku, qty));
    }
}

public class PaymentGatewayConnector
{
    private readonly IPaymentGateway _gateway;
    private readonly TransactionScopeMiddleware _transaction;

    public PaymentGatewayConnector(IPaymentGateway gateway, TransactionScopeMiddleware transaction)
    {
        _gateway = gateway;
        _transaction = transaction;
    }

    public async Task ProcessPayment(decimal amount, string token)
    {
        bool success = await _gateway.ProcessPaymentAsync(amount, token);
        if (!success) throw new Exception("Payment declined.");

        // Register rollback
        _transaction.RegisterCompensation(async () => await _gateway.RefundAsync(amount));
    }
}

// --- 5. Orchestrator ---

public class OrderOrchestrator
{
    private readonly InventoryConnector _inventory;
    private readonly IOrderCalculator _calculator;
    private readonly PaymentGatewayConnector _payment;
    private readonly TransactionScopeMiddleware _transaction;

    public OrderOrchestrator(InventoryConnector inventory, IOrderCalculator calculator, PaymentGatewayConnector payment, TransactionScopeMiddleware transaction)
    {
        _inventory = inventory;
        _calculator = calculator;
        _payment = payment;
        _transaction = transaction;
    }

    public async Task<string> ProcessOrderAsync(string sku, int qty, string token)
    {
        // The pipeline logic is encapsulated in the Middleware wrapper
        try
        {
            await _transaction.InvokeAsync(new Context(), async () =>
            {
                // Step 1: Inventory
                await _inventory.CheckAndReserve(sku, qty);

                // Step 2: Calculation
                decimal subtotal = 100 * qty; // Assume unit price
                decimal total = await _calculator.CalculateTotalAsync(subtotal);

                // Step 3: Payment
                await _payment.ProcessPayment(total, token);

                Console.WriteLine($"[Orchestrator] Order processed successfully. Total: {total}");
            });

            return "Order Completed Successfully";
        }
        catch (Exception ex)
        {
            return $"Order Failed: {ex.Message}";
        }
    }
}

// --- Main Execution ---
public class AdvancedProgram
{
    public static async Task Main()
    {
        // Setup
        var transaction = new TransactionScopeMiddleware();
        var inventory = new InventoryConnector(new MockInventory(), transaction);
        var calculator = new MockCalculator();
        var payment = new PaymentGatewayConnector(new MockPayment(), transaction);

        var orchestrator = new OrderOrchestrator(inventory, calculator, payment, transaction);

        // Scenario 1: Success
        Console.WriteLine("--- Scenario 1: Success ---");
        var result1 = await orchestrator.ProcessOrderAsync("Laptop", 2, "TOKEN_123");
        Console.WriteLine(result1);

        Console.WriteLine("\n--- Scenario 2: Payment Failure (Compensation) ---");
        // Scenario 2: Failure (Payment fails, inventory should be released)
        var result2 = await orchestrator.ProcessOrderAsync("Laptop", 2, "FAIL");
        Console.WriteLine(result2);
    }
}
