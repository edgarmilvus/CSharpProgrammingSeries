
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

// 1. Domain Model: Represents the external system (e.g., Inventory Database)
public class InventorySystem
{
    // Simulated database lookup
    public static int GetStockLevel(string sku)
    {
        // Mock data: In a real scenario, this queries SQL, NoSQL, or a legacy API
        var mockDatabase = new Dictionary<string, int>
        {
            { "A123", 42 },
            { "B456", 0 },
            { "C789", 15 }
        };

        return mockDatabase.TryGetValue(sku, out int stock) ? stock : -1;
    }
}

// 2. Tool Definition: Metadata describing the function for the AI
public class FunctionTool
{
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;

    [JsonPropertyName("parameters")]
    public FunctionParameters Parameters { get; set; } = new();
}

public class FunctionParameters
{
    [JsonPropertyName("type")]
    public string Type { get; set; } = "object";

    [JsonPropertyName("properties")]
    public Dictionary<string, PropertySchema> Properties { get; set; } = new();

    [JsonPropertyName("required")]
    public List<string> Required { get; set; } = new();
}

public class PropertySchema
{
    [JsonPropertyName("type")]
    public string Type { get; set; } = string.Empty;

    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;
}

// 3. The 'Connector' Engine: Handles Tool Registration and Execution
public class ToolConnector
{
    private readonly Dictionary<string, Func<string, string>> _registeredTools = new();

    // Register a tool with its metadata and execution logic
    public void RegisterTool(string name, string description, FunctionParameters parameters, Func<string, string> implementation)
    {
        _registeredTools[name] = implementation;
        // In a real system, we would store the 'description' and 'parameters' 
        // to send to the LLM during the handshake.
    }

    // Executes a tool given a name and JSON arguments
    public string Invoke(string toolName, string jsonArguments)
    {
        if (!_registeredTools.ContainsKey(toolName))
            return $"Error: Tool '{toolName}' not found.";

        try
        {
            // Execute the registered function
            return _registeredTools[toolName](jsonArguments);
        }
        catch (Exception ex)
        {
            return $"Error executing tool: {ex.Message}";
        }
    }
}

// 4. Main Program: Simulating the AI Interaction Loop
public class Program
{
    public static void Main()
    {
        // Initialize the connector
        var connector = new ToolConnector();

        // Register the 'get_stock' tool
        connector.RegisterTool(
            name: "get_stock",
            description: "Retrieves the current stock quantity for a specific product SKU.",
            parameters: new FunctionParameters
            {
                Properties = new Dictionary<string, PropertySchema>
                {
                    ["sku"] = new PropertySchema { Type = "string", Description = "The product stock keeping unit" }
                },
                Required = new List<string> { "sku" }
            },
            implementation: (args) =>
            {
                // Deserialize arguments passed by the AI
                using var doc = JsonDocument.Parse(args);
                if (!doc.RootElement.TryGetProperty("sku", out var skuElement))
                    return "Missing 'sku' parameter.";

                string sku = skuElement.GetString()!;
                int stock = InventorySystem.GetStockLevel(sku);
                return stock >= 0 ? $"Stock for {sku}: {stock}" : $"SKU {sku} not found.";
            }
        );

        // --- SIMULATION START ---
        Console.WriteLine("System: AI Assistant initialized.");
        Console.WriteLine("User: What is the stock level for product A123?");
        
        // Step A: The AI (External LLM) analyzes the request and decides to call the tool.
        // In a real system, the LLM would return a JSON object like:
        // { "tool": "get_stock", "arguments": { "sku": "A123" } }
        string aiResponseJson = """
        {
            "tool": "get_stock",
            "arguments": { "sku": "A123" }
        }
        """;

        Console.WriteLine($"\nAI Decision (Simulated): Decided to call tool.\nPayload: {aiResponseJson}");

        // Step B: The Connector parses the decision and invokes the tool.
        using var decisionDoc = JsonDocument.Parse(aiResponseJson);
        string toolName = decisionDoc.RootElement.GetProperty("tool").GetString()!;
        string arguments = decisionDoc.RootElement.GetProperty("arguments").GetRawText();

        string result = connector.Invoke(toolName, arguments);

        // Step C: The result is returned to the user (or back to the LLM for summarization).
        Console.WriteLine($"\nSystem: Tool executed successfully.");
        Console.WriteLine($"Result: {result}");
    }
}
