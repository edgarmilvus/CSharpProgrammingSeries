
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using LegacyInventoryClient; // Reference to Exercise 1 types

namespace LegacyInventoryStateful
{
    public class StatefulInventoryClient : IDisposable
    {
        private readonly HttpClient _httpClient;
        private readonly string _serviceUrl;
        private string _sessionCookie;
        private bool _isLoggedIn = false;
        private readonly SemaphoreSlim _lock = new SemaphoreSlim(1, 1); // Thread safety

        public StatefulInventoryClient(string serviceUrl)
        {
            _serviceUrl = serviceUrl;
            _httpClient = new HttpClient(); // In production, use IHttpClientFactory
        }

        // 1. & 2. Login Method
        public async Task<bool> LoginAsync(string username, string password)
        {
            await _lock.WaitAsync();
            try
            {
                if (_isLoggedIn) return true;

                // Simulate a Login SOAP request (specific to legacy system)
                var loginRequest = new HttpRequestMessage(HttpMethod.Post, _serviceUrl);
                loginRequest.Content = new StringContent($"<Login><User>{username}</User><Pass>{password}</Pass></Login>", Encoding.UTF8, "text/xml");
                
                var response = await _httpClient.SendAsync(loginRequest);
                
                if (response.IsSuccessStatusCode && response.Headers.TryGetValues("Set-Cookie", out var cookies))
                {
                    // Store the session cookie securely
                    _sessionCookie = string.Join("; ", cookies);
                    _isLoggedIn = true;
                    return true;
                }
                return false;
            }
            finally
            {
                _lock.Release();
            }
        }

        // 3. Stateful Request Method
        public async Task<string> CheckStockAsync(int itemId)
        {
            // Edge Case Handling: Retry with Refresh Logic
            return await ExecuteWithSessionRefresh(async () =>
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _serviceUrl);
                
                // Attach Session Cookie
                if (!string.IsNullOrEmpty(_sessionCookie))
                {
                    request.Headers.Add("Cookie", _sessionCookie);
                }

                request.Content = new StringContent($"<CheckStock><ItemID>{itemId}</ItemID></CheckStock>", Encoding.UTF8, "text/xml");

                var response = await _httpClient.SendAsync(request);
                
                // 5. Detect Session Expiration (401)
                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    // Signal that session refresh is needed
                    throw new SessionExpiredException("Session timed out.");
                }

                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            });
        }

        // 4. Logout Method
        public async Task LogoutAsync()
        {
            await _lock.WaitAsync();
            try
            {
                if (_isLoggedIn)
                {
                    // Call logout endpoint
                    var request = new HttpRequestMessage(HttpMethod.Post, _serviceUrl + "/logout");
                    request.Headers.Add("Cookie", _sessionCookie);
                    await _httpClient.SendAsync(request);

                    // Clear state
                    _sessionCookie = null;
                    _isLoggedIn = false;
                }
            }
            finally
            {
                _lock.Release();
            }
        }

        // 5. Pseudo-code Logic for Retry-with-Refresh
        private async Task<T> ExecuteWithSessionRefresh<T>(Func<Task<T>> action)
        {
            int retries = 0;
            while (retries < 2) // Try once, then refresh, then try once more
            {
                try
                {
                    return await action();
                }
                catch (SessionExpiredException)
                {
                    if (retries == 1) throw; // Already retried, fail now

                    // Re-authenticate
                    // Note: In a real app, we'd need stored credentials or a refresh token.
                    // Here we assume we have them cached or passed in originally.
                    // For this example, we'll assume a method 'ReAuthenticate' exists.
                    await ReAuthenticate(); 
                    retries++;
                }
            }
            throw new InvalidOperationException("Operation failed after re-authentication attempt.");
        }

        private async Task ReAuthenticate()
        {
            // Logic to call LoginAsync again with cached credentials
            // await LoginAsync(_cachedUser, _cachedPass);
            _isLoggedIn = false; // Force re-login
            // In a real scenario, update _sessionCookie here
        }

        public void Dispose()
        {
            _httpClient?.Dispose();
            _lock?.Dispose();
        }
    }

    // Custom exception for flow control
    public class SessionExpiredException : Exception
    {
        public SessionExpiredException(string message) : base(message) { }
    }
}
