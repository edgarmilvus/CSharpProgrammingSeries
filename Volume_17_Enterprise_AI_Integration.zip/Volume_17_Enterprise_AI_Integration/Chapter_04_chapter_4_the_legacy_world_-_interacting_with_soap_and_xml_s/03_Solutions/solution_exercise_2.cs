
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Schema;
using Polly;
using Polly.Retry;

namespace LegacyInventoryManual
{
    public class SoapXmlBuilder
    {
        private const string ServiceNs = "http://tempuri.org/InventoryService";
        private const string SoapNs = "http://schemas.xmlsoap.org/soap/envelope/";

        // 1. & 2. Create SOAP Envelope
        public XDocument BuildUpdateStockRequest(int itemId, string warehouseCode, decimal newQuantity)
        {
            var doc = new XDocument(
                new XElement(XName.Get("Envelope", SoapNs),
                    new XAttribute(XNamespace.Xmlns + "soap", SoapNs),
                    new XElement(XName.Get("Body", SoapNs),
                        new XElement(XName.Get("UpdateStockLevel", ServiceNs),
                            new XElement(XName.Get("ItemID", ServiceNs), itemId),
                            new XElement(XName.Get("WarehouseCode", ServiceNs), warehouseCode),
                            new XElement(XName.Get("NewQuantity", ServiceNs), newQuantity)
                        )
                    )
                )
            );
            return doc;
        }

        // 3. & 4. Validate against XSD
        public void ValidateXml(XDocument doc, string xsdSchema)
        {
            var schemas = new XmlSchemaSet();
            schemas.Add(ServiceNs, XmlReader.Create(new System.IO.StringReader(xsdSchema)));
            
            bool validationFailed = false;
            string validationMessage = "";

            doc.Validate(schemas, (o, e) =>
            {
                validationFailed = true;
                validationMessage = e.Message;
            });

            if (validationFailed)
            {
                throw new InvalidOperationException($"XML Validation Error: {validationMessage}");
            }
        }
    }

    public class ResilientSoapClient
    {
        private readonly HttpClient _httpClient;
        private readonly AsyncRetryPolicy _retryPolicy;

        public ResilientSoapClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
            
            // Interactive Challenge: Retry Policy with Exponential Backoff
            _retryPolicy = Policy
                .Handle<HttpRequestException>() // Network errors
                .Or<TaskCanceledException>()    // Timeouts
                .OrResult<HttpResponseMessage>(r => r.StatusCode == System.Net.HttpStatusCode.InternalServerError 
                                                 || r.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
                .WaitAndRetryAsync(
                    retryCount: 3,
                    sleepDurationProvider: attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)) > TimeSpan.FromSeconds(30) 
                        ? TimeSpan.FromSeconds(30) 
                        : TimeSpan.FromSeconds(Math.Pow(2, attempt)), // Exponential backoff capped at 30s
                    onRetry: (outcome, timespan, retryCount, context) =>
                    {
                        Console.WriteLine($"Retry {retryCount} after {timespan.TotalSeconds}s due to: {outcome.Exception?.Message ?? outcome.Result.StatusCode.ToString()}");
                    });
        }

        // 5. Helper extension method simulation (implemented as instance method here for clarity)
        public async Task<string> SendSoapRequestAsync(XDocument soapXml, CancellationToken ct)
        {
            // Construct the HTTP Request
            var httpContent = new StringContent(soapXml.ToString(), Encoding.UTF8, "text/xml");
            httpContent.Headers.Add("SOAPAction", "http://tempuri.org/InventoryService/UpdateStockLevel");

            // Execute with Polly Retry Policy
            var response = await _retryPolicy.ExecuteAsync(async (token) => 
            {
                return await _httpClient.PostAsync("https://legacy-inventory.corp.internal/InventoryService.svc", httpContent, token);
            }, ct);

            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync(ct);
        }
    }
}
