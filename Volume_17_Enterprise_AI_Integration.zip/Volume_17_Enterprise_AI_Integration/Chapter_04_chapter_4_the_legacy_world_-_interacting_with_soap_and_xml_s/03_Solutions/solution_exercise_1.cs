
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;

namespace LegacyInventoryClient
{
    // 1. & 2. Generated Proxy (Simulated for this exercise context)
    // In a real scenario, run: dotnet-svcutil https://legacy-inventory.corp.internal/InventoryService.svc
    // The generated code would typically reside in a separate namespace/project.
    
    [ServiceContract(Namespace = "http://tempuri.org/InventoryService")]
    public interface IInventoryService
    {
        [OperationContract(Action = "http://tempuri.org/InventoryService/UpdateStockLevel", ReplyAction = "http://tempuri.org/InventoryService/UpdateStockLevelResponse")]
        Task<UpdateStockLevelResponse> UpdateStockLevelAsync(UpdateStockLevelRequest request);
    }

    [MessageContract(IsWrapped = false)]
    public class UpdateStockLevelRequest
    {
        [MessageBodyMember(Name = "UpdateStockLevel", Namespace = "http://tempuri.org/InventoryService")]
        public UpdateStockLevelData Data { get; set; }
    }

    public class UpdateStockLevelData
    {
        public int ItemID { get; set; }
        public string WarehouseCode { get; set; }
        public decimal NewQuantity { get; set; }
    }

    [MessageContract(IsWrapped = false)]
    public class UpdateStockLevelResponse
    {
        [MessageBodyMember(Name = "UpdateStockLevelResponse", Namespace = "http://tempuri.org/InventoryService")]
        public UpdateStockLevelResult Result { get; set; }
    }

    public class UpdateStockLevelResult
    {
        public bool Result { get; set; }
    }

    // Complex Type for Fault
    [DataContract(Namespace = "http://tempuri.org/InventoryService")]
    public class InventoryFault
    {
        [DataMember]
        public int ErrorCode { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }
    }

    public class InventoryClientService
    {
        private readonly IInventoryService _channel;

        public InventoryClientService()
        {
            // 4. Configure BasicHttpBinding with SecurityMode.Transport and Timeouts
            var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
            binding.SendTimeout = TimeSpan.FromMinutes(2);
            binding.ReceiveTimeout = TimeSpan.FromMinutes(3);

            // Endpoint address from WSDL
            var endpoint = new EndpointAddress("https://legacy-inventory.corp.internal/InventoryService.svc");

            // Create Channel Factory
            var factory = new ChannelFactory<IInventoryService>(binding, endpoint);
            _channel = factory.CreateChannel();
        }

        // 3. Method to construct request and call service
        public async Task<bool> UpdateStockLevelAsync(int itemId, string warehouseCode, decimal newQuantity)
        {
            try
            {
                var request = new UpdateStockLevelRequest
                {
                    Data = new UpdateStockLevelData
                    {
                        ItemID = itemId,
                        WarehouseCode = warehouseCode,
                        NewQuantity = newQuantity
                    }
                };

                // Call the SOAP service
                var response = await _channel.UpdateStockLevelAsync(request);
                return response.Result.Result;
            }
            // 5. Error Handling
            catch (FaultException<InventoryFault> ex)
            {
                // Handle specific SOAP faults
                Console.WriteLine($"SOAP Fault: Code={ex.Detail.ErrorCode}, Msg={ex.Detail.ErrorMessage}");
                throw; // Re-throw or handle as needed
            }
            catch (TimeoutException ex)
            {
                // Handle timeouts
                Console.WriteLine($"Request timed out: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                // Handle other communication errors
                Console.WriteLine($"Communication error: {ex.Message}");
                throw;
            }
        }
    }
}
