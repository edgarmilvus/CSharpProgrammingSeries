
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.IdentityModel.Tokens;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Xml;

namespace LegacyInventorySecurity
{
    // 1. Custom Message Inspector
    public class WsSecurityMessageInspector : IClientMessageInspector
    {
        private readonly string _username;
        private readonly string _password;

        public WsSecurityMessageInspector(string username, string password)
        {
            _username = username;
            _password = password;
        }

        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            // Create the WS-Security Header
            var securityHeader = CreateSecurityHeader();
            
            // Add header to the request
            request.Headers.Add(securityHeader);

            return null; // Correlation state (not needed here)
        }

        private MessageHeader CreateSecurityHeader()
        {
            // 2. Generate Nonce (Random Bytes) and Created Timestamp
            byte[] nonceBytes = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(nonceBytes);
            }
            string nonceBase64 = Convert.ToBase64String(nonceBytes);
            string created = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"); // ISO 8601

            // 3. Construct the XML manually for the header
            // We use a generic MessageHeader that writes raw XML
            return MessageHeader.CreateHeader(
                "Security", 
                "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", 
                new SecurityHeaderBody(_username, _password, nonceBase64, created)
            );
        }

        public void AfterReceiveReply(ref Message reply, object correlationState) { }

        // Helper class to serialize the header content
        private class SecurityHeaderBody
        {
            private readonly string _username, _password, _nonce, _created;
            public SecurityHeaderBody(string u, string p, string n, string c) 
            { 
                _username = u; _password = p; _nonce = n; _created = c; 
            }

            public void WriteXml(XmlWriter writer)
            {
                writer.WriteStartElement("UsernameToken", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
                writer.WriteAttributeString("xmlns", "wsse", null, "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
                writer.WriteAttributeString("xmlns", "wsu", null, "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");

                writer.WriteElementString("wsse", "Username", null, _username);
                
                writer.WriteStartElement("wsse", "Password", null);
                writer.WriteAttributeString("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
                writer.WriteString(_password);
                writer.WriteEndElement();

                writer.WriteElementString("wsse", "Nonce", null, _nonce);
                writer.WriteElementString("wsu", "Created", null, _created);

                writer.WriteEndElement();
            }
        }
    }

    // 1. Custom Endpoint Behavior
    public class WsSecurityBehavior : IEndpointBehavior
    {
        private readonly string _username;
        private readonly string _password;

        public WsSecurityBehavior(string username, string password)
        {
            _username = username;
            _password = password;
        }

        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters) { }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            clientRuntime.ClientMessageInspectors.Add(new WsSecurityMessageInspector(_username, _password));
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher) { }

        public void Validate(ServiceEndpoint endpoint) { }
    }
}

// 4. Unit Test (xUnit Example)
/*
using Xunit;
using Moq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

public class WsSecurityMessageInspectorTests
{
    [Fact]
    public void BeforeSendRequest_ShouldInjectSecurityHeader()
    {
        // Arrange
        var inspector = new WsSecurityMessageInspector("testuser", "testpass");
        var request = Message.CreateMessage(MessageVersion.Soap11, "http://tempuri.org/Action");
        var channelMock = new Mock<IClientChannel>();

        // Act
        inspector.BeforeSendRequest(ref request, channelMock.Object);

        // Assert
        Assert.Equal(1, request.Headers.Count);
        Assert.Equal("Security", request.Headers[0].Name);
        Assert.Equal("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", request.Headers[0].Namespace);
    }
}
*/
