
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using Microsoft.AspNetCore.Mvc;
using System.ServiceModel;
using System.Threading.Tasks;
using LegacyInventoryClient; // Reference to Exercise 1 types

namespace LegacyBridge.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InventoryController : ControllerBase
    {
        private readonly InventoryClientService _soapClient;

        public InventoryController(InventoryClientService soapClient)
        {
            _soapClient = soapClient;
        }

        // 2. POST /api/inventory/update
        [HttpPost("update")]
        public async Task<IActionResult> UpdateInventory([FromBody] InventoryUpdateRequest request)
        {
            // 3. Map JSON request to SOAP call
            try
            {
                bool result = await _soapClient.UpdateStockLevelAsync(
                    request.ItemId, 
                    request.WarehouseCode, 
                    request.NewQuantity
                );

                return Ok(new { Success = result });
            }
            // 4. Global Exception Handling (Middleware simulation in controller for brevity)
            catch (FaultException<InventoryFault> ex)
            {
                // Translate SOAP Fault to HTTP 400
                var errorResponse = new 
                { 
                    Error = "Inventory Update Failed", 
                    Code = ex.Detail.ErrorCode, 
                    Message = ex.Detail.ErrorMessage 
                };
                return BadRequest(errorResponse);
            }
            catch (TimeoutException)
            {
                return StatusCode(504, "Gateway Timeout: Legacy service did not respond.");
            }
        }
    }

    // DTO for JSON Request
    public record InventoryUpdateRequest(int ItemId, string WarehouseCode, decimal NewQuantity);
}

// 5. Sequence Diagram (DOT Format)
/*
digraph SequenceDiagram {
    rankdir=LR;
    node [shape=box];

    Client [shape=circle]
    REST_Controller [label="ASP.NET Core\nInventoryController"]
    SOAP_Client [label="Generated SOAP Proxy\n(Exercise 1)"]
    Legacy_Service [label="Legacy SOAP Service\n(InventoryService.svc)"]

    Client -> REST_Controller [label="POST /api/inventory/update\nJSON Body"]
    REST_Controller -> SOAP_Client [label="Map DTO to SOAP Request\nCall UpdateStockLevelAsync"]
    SOAP_Client -> Legacy_Service [label="SOAP Envelope (HTTPS)"]
    Legacy_Service --> SOAP_Client [label="SOAP Response / Fault"]
    SOAP_Client --> REST_Controller [label="Return Result / Exception"]
    REST_Controller --> Client [label="HTTP 200 OK / HTTP 400 BadRequest\n(JSON)"]
}
*/
