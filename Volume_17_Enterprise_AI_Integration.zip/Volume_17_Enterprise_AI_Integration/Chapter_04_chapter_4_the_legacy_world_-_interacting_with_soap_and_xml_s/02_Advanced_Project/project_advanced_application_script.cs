
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;

namespace LegacySoapIntegration
{
    // REAL-WORLD CONTEXT:
    // A financial institution needs to automate the retrieval of stock quotes for a portfolio dashboard.
    // The institution relies on a legacy SOAP service (simulated here via a local file) that requires
    // specific XML formatting and WS-Security headers. The goal is to build a robust C# console application
    // that constructs a valid SOAP request, parses the XML response, and handles potential errors gracefully.
    // This mimics the integration of an LLM-based agent that needs to fetch real-time data from an internal API.

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Legacy SOAP Integration Application...");

            // 1. SETUP: Define the target stock symbol and mock service endpoint.
            string stockSymbol = "MSFT";
            string serviceUrl = "http://legacy-finance-service/StockQuote.svc"; // In a real scenario, this is a live URL.
            
            // For this demonstration, we will simulate the SOAP response by reading from a local XML file.
            // In a production environment, we would use HttpWebRequest to send the SOAP message.
            string mockResponseXml = File.ReadAllText("MockStockResponse.xml");

            // 2. EXECUTION: Attempt to process the stock quote.
            try
            {
                // Step A: Construct the SOAP Envelope
                string soapRequest = BuildSoapRequest(stockSymbol);

                // Step B: Send Request (Simulated here by reading the mock file)
                // In a real app, you would use HttpWebRequest.GetResponse()
                Console.WriteLine($"Sending SOAP request for symbol: {stockSymbol}...");

                // Step C: Parse the XML Response
                double stockPrice = ParseStockQuoteResponse(mockResponseXml);

                // Step D: Output Result
                Console.WriteLine($"SUCCESS: Retrieved quote for {stockSymbol}: ${stockPrice:F2}");
            }
            catch (Exception ex)
            {
                // 3. ERROR HANDLING: Catch specific parsing or network errors.
                Console.WriteLine($"ERROR: Failed to retrieve stock quote. Details: {ex.Message}");
            }

            Console.WriteLine("Application execution completed.");
        }

        // BLOCK 1: SOAP REQUEST CONSTRUCTION
        // PURPOSE: Manually construct a valid SOAP 1.1 envelope using basic string concatenation.
        // This simulates how an LLM agent might generate the necessary XML payload.
        static string BuildSoapRequest(string symbol)
        {
            // We use StringBuilder for efficient string manipulation, a standard practice in C#.
            StringBuilder sb = new StringBuilder();

            // Start of SOAP Envelope
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            sb.AppendLine("<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">");
            
            // WS-Security Header Block (Simulated)
            // Legacy systems often require specific security tokens in the header.
            sb.AppendLine("  <soap:Header>");
            sb.AppendLine("    <Security xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">");
            sb.AppendLine("      <UsernameToken>");
            sb.AppendLine("        <Username>ServiceUser</Username>");
            sb.AppendLine("        <Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">SecretPass123</Password>");
            sb.AppendLine("      </UsernameToken>");
            sb.AppendLine("    </Security>");
            sb.AppendLine("  </soap:Header>");

            // Body containing the specific request parameters
            sb.AppendLine("  <soap:Body>");
            sb.AppendLine("    <GetQuote xmlns=\"http://tempuri.org/\">");
            sb.AppendLine($"      <symbol>{symbol}</symbol>");
            sb.AppendLine("    </GetQuote>");
            sb.AppendLine("  </soap:Body>");
            
            sb.AppendLine("</soap:Envelope>");

            return sb.ToString();
        }

        // BLOCK 2: XML RESPONSE PARSING
        // PURPOSE: Extract specific data points from a raw XML string using XmlDocument.
        // This mimics the "Schema Mapping" concept where we map legacy XML to modern data structures.
        static double ParseStockQuoteResponse(string xmlContent)
        {
            // Load the XML string into an XmlDocument object.
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlContent);

            // Define the XML Namespace Manager to handle namespaces in the SOAP response.
            // This is crucial because SOAP responses use namespaces (e.g., soap:Body).
            XmlNamespaceManager nsManager = new XmlNamespaceManager(doc.NameTable);
            nsManager.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
            nsManager.AddNamespace("m", "http://tempuri.org/"); // The service-specific namespace

            // Navigate the XML Tree using XPath.
            // Path: Envelope -> Body -> GetQuoteResponse -> GetQuoteResult
            XmlNode resultNode = doc.SelectSingleNode("//soap:Envelope/soap:Body/m:GetQuoteResponse/m:GetQuoteResult", nsManager);

            if (resultNode == null)
            {
                throw new InvalidOperationException("SOAP Response does not contain the expected 'GetQuoteResult' node.");
            }

            // Validate and Parse the data
            string rawValue = resultNode.InnerText;
            if (double.TryParse(rawValue, out double price))
            {
                return price;
            }
            else
            {
                throw new FormatException($"The retrieved value '{rawValue}' could not be parsed as a number.");
            }
        }
    }
}
