
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

public class IdempotentInventoryService : IInventoryService
{
    private readonly IInventoryService _innerService;
    private readonly ICacheService _cache;

    public IdempotentInventoryService(IInventoryService inner, ICacheService cache)
    {
        _innerService = inner;
        _cache = cache;
    }

    public async Task<string> CheckStockAsync(InventoryRequest request)
    {
        // Generate a deterministic key based on the request content
        var idempotencyKey = $"{request.ItemId}-{request.Quantity}-{request.WarehouseCode}";
        
        if (await _cache.ExistsAsync(idempotencyKey))
        {
            return await _cache.GetAsync(idempotencyKey);
        }

        var result = await _innerService.CheckStockAsync(request);
        await _cache.SetAsync(idempotencyKey, result, TimeSpan.FromMinutes(5));
        return result;
    }
}
