
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Xml;
using System.Xml.XPath;

// This example demonstrates a manual construction of a SOAP 1.1 request to a legacy service.
// We will interact with a hypothetical 'InventoryService' to get a stock level.
// The service requires a custom 'AuthHeader' and a WS-Security 'UsernameToken'.
// We will use a self-signed certificate for TLS, common in internal enterprise environments.

public class Program
{
    // The entry point of our application.
    public static async Task Main(string[] args)
    {
        Console.WriteLine("--- Legacy SOAP Integration Example ---");

        // 1. SETUP: Define the target endpoint and the part number we need to query.
        // In a real scenario, this URL would be provided by the legacy system team.
        string endpointUrl = "https://legacy-inventory.internal.corp/InventoryService.svc"; 
        string partNumber = "CN-54321";

        // 2. CLIENT CONFIGURATION: In enterprise environments, you often encounter self-signed certificates.
        // This handler bypasses certificate validation for this example ONLY. DO NOT use in production.
        var handler = new HttpClientHandler();
        handler.ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true;

        // 3. HTTP CLIENT: Instantiate the HttpClient with our custom handler.
        // We wrap it in a 'using' statement to ensure proper disposal of resources.
        using (var client = new HttpClient(handler))
        {
            // 4. CONSTRUCT THE SOAP ENVELOPE: This is the core of the interaction.
            // We build the raw XML string that the legacy service expects.
            // This includes the Body (our payload) and Header (metadata & security).
            string soapRequest = BuildSoapRequest(partNumber);

            Console.WriteLine("\n[INFO] Sending SOAP Request:");
            Console.WriteLine(soapRequest);

            // 5. PREPARE THE HTTP REQUEST: SOAP is typically sent via HTTP POST.
            var httpContent = new StringContent(soapRequest, Encoding.UTF8, "text/xml");

            // 6. ADD CRITICAL HEADERS: SOAP Actions are often specified in HTTP headers.
            // The 'SOAPAction' header tells the server what operation to perform.
            httpContent.Headers.Add("SOAPAction", "http://tempuri.org/IInventoryService/GetStockLevel");

            try
            {
                // 7. EXECUTE THE REQUEST: Send the request asynchronously and await the response.
                HttpResponseMessage response = await client.PostAsync(endpointUrl, httpContent);

                // 8. CHECK FOR SUCCESS: Ensure the HTTP call itself was successful (e.g., 200 OK).
                response.EnsureSuccessStatusCode();

                // 9. READ THE RESPONSE: Get the raw XML string from the response body.
                string responseBody = await response.Content.ReadAsStringAsync();
                Console.WriteLine("\n[INFO] Received SOAP Response:");
                Console.WriteLine(responseBody);

                // 10. PARSE THE XML: Use modern C# XML tools to extract the data we need.
                // We are looking for the 'GetStockLevelResult' element.
                XDocument doc = XDocument.Parse(responseBody);
                XNamespace ns = "http://tempuri.org/"; // The default namespace of the SOAP body

                // 11. EXTRACT THE VALUE: Use LINQ to XML to query the document.
                // We navigate the XML tree to find the result element and get its value.
                string stockLevel = doc.Descendants(ns + "GetStockLevelResult").FirstOrDefault()?.Value;

                if (stockLevel != null)
                {
                    Console.WriteLine($"\n[SUCCESS] Part Number: {partNumber}, Stock Level: {stockLevel}");
                }
                else
                {
                    Console.WriteLine("\n[ERROR] Could not parse stock level from response.");
                }
            }
            catch (HttpRequestException e)
            {
                // 12. ERROR HANDLING: Network or HTTP-level errors.
                Console.WriteLine($"\n[EXCEPTION] Network Error: {e.Message}");
            }
            catch (Exception e)
            {
                // 13. GENERAL ERROR HANDLING: Parsing or other logical errors.
                Console.WriteLine($"\n[EXCEPTION] General Error: {e.Message}");
            }
        }
    }

    /// <summary>
    /// Manually constructs the SOAP 1.1 XML envelope.
    /// This is a common pattern when a WSDL is too complex for auto-generated proxies.
    /// </summary>
    private static string BuildSoapRequest(string partNumber)
    {
        // We use a C# interpolated string to build the XML.
        // Note the namespaces and structure required for SOAP 1.1.
        // The 'soap' prefix maps to http://schemas.xmlsoap.org/soap/envelope/
        return $"""
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
           <soap:Header>
              <!-- Custom Authentication Header required by the legacy system -->
              <AuthHeader xmlns="http://tempuri.org/">
                 <Username>svc_inventory_user</Username>
                 <Password>SuperSecretPassword123</Password>
              </AuthHeader>
              <!-- WS-Security UsernameToken (a common standard) -->
              <wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" 
                             xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
                 <wsse:UsernameToken>
                    <wsse:Username>api_user</wsse:Username>
                    <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">api_password</wsse:Password>
                 </wsse:UsernameToken>
              </wsse:Security>
           </soap:Header>
           <soap:Body>
              <tem:GetStockLevel>
                 <tem:PartNumber>{partNumber}</tem:PartNumber>
              </tem:GetStockLevel>
           </soap:Body>
        </soap:Envelope>
        """;
    }
}
