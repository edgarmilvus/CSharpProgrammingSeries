
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace EnterpriseAI_Connector
{
    // Real-world context: A Customer Support Dashboard where an AI assistant 
    // helps agents query customer data. The AI generates SQL, but the system 
    // must ensure it never accesses sensitive PII (Personally Identifiable Information) 
    // or executes destructive commands.

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Enterprise AI SQL Connector Simulation ---");
            Console.WriteLine("Initializing Safety Protocols...\n");

            // 1. Setup the Mock Database Schema (Dynamic Schema Introspection)
            var schemaIntrospector = new DatabaseSchemaIntrospector();
            schemaIntrospector.LoadSchema();

            // 2. Initialize the Safety Guardrails
            var securityGuard = new QuerySecurityGuard();

            // 3. Initialize the Query Engine
            var queryEngine = new QueryEngine(schemaIntrospector, securityGuard);

            // 4. Simulate Incoming Natural Language Requests from the AI/Agent
            string[] userRequests = new string[4];
            userRequests[0] = "Get the email address for user John Doe."; // VIOLATION: PII Access
            userRequests[1] = "Delete all records from the Customers table."; // VIOLATION: Destructive Command
            userRequests[2] = "Show me all orders placed in the last 7 days."; // VALID: Safe Read-Only
            userRequests[3] = "SELECT * FROM Users WHERE Username = 'admin';"; // VIOLATION: Direct SQL Injection attempt

            foreach (var request in userRequests)
            {
                Console.WriteLine($"\n[Input]: \"{request}\"");
                
                // Simulate Text-to-SQL Generation (Mocked for this exercise)
                string generatedSql = MockTextToSql(request);
                Console.WriteLine($"[AI Generated SQL]: {generatedSql}");

                // Execute the Safe Pipeline
                queryEngine.ExecuteRequest(generatedSql);
            }
        }

        // Mocking the LLM's Text-to-SQL capability
        static string MockTextToSql(string text)
        {
            if (text.Contains("email")) return "SELECT Email FROM Customers WHERE Name = 'John Doe';";
            if (text.Contains("Delete")) return "DELETE FROM Customers;";
            if (text.Contains("last 7 days")) return "SELECT OrderID, OrderDate FROM Orders WHERE OrderDate >= DATEADD(day, -7, GETDATE());";
            if (text.Contains("SELECT *")) return "SELECT * FROM Users WHERE Username = 'admin';";
            return "SELECT 1;";
        }
    }

    // --- COMPONENT 1: Dynamic Schema Introspection ---
    // Simulates fetching metadata about the database structure.
    public class DatabaseSchemaIntrospector
    {
        // Stores allowed tables and their columns
        private Dictionary<string, List<string>> _schema;

        public DatabaseSchemaIntrospector()
        {
            _schema = new Dictionary<string, List<string>>();
        }

        public void LoadSchema()
        {
            // In a real system, this would query INFORMATION_SCHEMA.COLUMNS
            _schema.Add("Customers", new List<string> { "CustomerID", "Name", "JoinDate" }); // Note: 'Email' is intentionally missing from allowed list
            _schema.Add("Orders", new List<string> { "OrderID", "CustomerID", "OrderDate", "Amount" });
            _schema.Add("Users", new List<string> { "UserID", "Username", "Role" });
        }

        public bool IsValidTable(string tableName)
        {
            return _schema.ContainsKey(tableName);
        }

        public bool IsValidColumn(string tableName, string columnName)
        {
            if (_schema.TryGetValue(tableName, out var columns))
            {
                return columns.Contains(columnName);
            }
            return false;
        }

        public List<string> GetAllowedColumns(string tableName)
        {
            if (_schema.TryGetValue(tableName, out var columns)) return columns;
            return new List<string>();
        }
    }

    // --- COMPONENT 2: Query Security Guard (RBAC & Validation) ---
    // Enforces strict rules on what queries can run.
    public class QuerySecurityGuard
    {
        private readonly List<string> _blacklistedKeywords;
        private readonly List<string> _allowedTables;

        public QuerySecurityGuard()
        {
            // Keywords that are strictly forbidden in AI-generated SQL
            _blacklistedKeywords = new List<string> { "DROP", "DELETE", "UPDATE", "INSERT", "EXEC", "--", "/*", "*/", "XP_" };
            
            // Only these tables are accessible to the AI
            _allowedTables = new List<string> { "Customers", "Orders", "Users" };
        }

        public ValidationResult Validate(string sql, DatabaseSchemaIntrospector schema)
        {
            // 1. Keyword Blacklist Check (Sanitization)
            string upperSql = sql.ToUpper();
            foreach (var keyword in _blacklistedKeywords)
            {
                if (upperSql.Contains(keyword))
                {
                    return new ValidationResult(false, $"Security Violation: Forbidden keyword detected '{keyword}'.");
                }
            }

            // 2. Basic Structure Check (Naive Parser)
            if (!upperSql.StartsWith("SELECT"))
            {
                return new ValidationResult(false, "Syntax Error: Only SELECT statements are permitted.");
            }

            // 3. Table Whitelist & Schema Awareness
            // We extract table names. In a real parser, this is complex. Here we do basic string matching.
            string[] parts = sql.Split(new char[] { ' ', ',', '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
            
            bool foundAllowedTable = false;
            foreach (var part in parts)
            {
                // Check if the part is a table name
                if (schema.IsValidTable(part))
                {
                    if (!_allowedTables.Contains(part))
                    {
                        return new ValidationResult(false, $"Access Denied: Table '{part}' is not whitelisted.");
                    }
                    foundAllowedTable = true;
                }
            }

            if (!foundAllowedTable)
            {
                return new ValidationResult(false, "Semantic Error: No valid table referenced.");
            }

            // 4. Column Validation (Preventing PII leaks like 'Email', 'SSN')
            // This is the most critical step for "Safe SQL Access"
            foreach (var part in parts)
            {
                // Check if part is a column in any table
                foreach (var table in _allowedTables)
                {
                    if (schema.IsValidColumn(table, part))
                    {
                        // Check if this column is sensitive
                        if (IsSensitiveColumn(part))
                        {
                            return new ValidationResult(false, $"Privacy Violation: Column '{part}' is restricted from AI access.");
                        }
                    }
                }
            }

            return new ValidationResult(true, "Validation Passed.");
        }

        private bool IsSensitiveColumn(string column)
        {
            // In a real system, this would be metadata-driven
            string[] sensitive = { "Email", "Password", "SSN", "CreditCard" };
            foreach (var s in sensitive)
            {
                if (column.Equals(s, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }
    }

    public struct ValidationResult
    {
        public bool IsValid { get; }
        public string Message { get; }

        public ValidationResult(bool isValid, string message)
        {
            IsValid = isValid;
            Message = message;
        }
    }

    // --- COMPONENT 3: Query Orchestrator ---
    // Coordinates the flow between Schema, Security, and Execution.
    public class QueryEngine
    {
        private DatabaseSchemaIntrospector _schema;
        private QuerySecurityGuard _security;

        public QueryEngine(DatabaseSchemaIntrospector schema, QuerySecurityGuard security)
        {
            _schema = schema;
            _security = security;
        }

        public void ExecuteRequest(string sql)
        {
            // Step 1: Validate
            ValidationResult result = _security.Validate(sql, _schema);

            if (!result.IsValid)
            {
                Console.WriteLine($"[BLOCKED]: {result.Message}");
                return;
            }

            // Step 2: Semantic Caching (Mocked)
            // If we have seen this exact query recently, return cached result.
            if (CheckCache(sql))
            {
                Console.WriteLine("[CACHE HIT]: Returning pre-computed result.");
                return;
            }

            // Step 3: Sandboxed Execution
            // In a real app, this would run in a restricted DB user context with read-only permissions.
            Console.WriteLine("[EXECUTION]: Query sent to DB.");
            Console.WriteLine("[RESULT]: Data fetched successfully.");
            
            // Step 4: Cache the result
            AddToCache(sql);
        }

        // Simple array-based cache for demonstration
        private string[] _cache = new string[10];
        private int _cacheIndex = 0;

        private bool CheckCache(string sql)
        {
            foreach (var entry in _cache)
            {
                if (entry == sql) return true;
            }
            return false;
        }

        private void AddToCache(string sql)
        {
            if (_cacheIndex < 10)
            {
                _cache[_cacheIndex] = sql;
                _cacheIndex++;
            }
        }
    }
}
