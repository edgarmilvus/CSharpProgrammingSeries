
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace AISQLConnector.Exercise1
{
    // Data structure for column metadata
    public class ColumnMetadata
    {
        public string ColumnName { get; set; } = string.Empty;
        public string DataType { get; set; } = string.Empty;
        public bool IsNullable { get; set; }
        public bool IsPrimaryKey { get; set; }
    }

    public class SchemaMismatchException : Exception
    {
        public SchemaMismatchException(string message) : base(message) { }
    }

    public class DatabaseSchemaInspector
    {
        private readonly string _connectionString;

        public DatabaseSchemaInspector(IConfiguration configuration)
        {
            // Securely retrieve connection string
            _connectionString = configuration.GetConnectionString("DefaultConnection") 
                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
        }

        public async Task<Dictionary<string, List<ColumnMetadata>>> GetSchemaAsync()
        {
            var schema = new Dictionary<string, List<ColumnMetadata>>(StringComparer.OrdinalIgnoreCase);

            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // Retrieve tables
            var tables = await connection.GetSchemaAsync("Tables");
            
            foreach (DataRow tableRow in tables.Rows)
            {
                string tableName = tableRow["TABLE_NAME"].ToString()!;
                string tableSchema = tableRow["TABLE_SCHEMA"].ToString()!;

                // Full qualified name handling
                string fullTableName = $"[{tableSchema}].[{tableName}]";

                // Retrieve columns for this table
                var columns = await connection.GetSchemaAsync("Columns", new[] { null, tableSchema, tableName });
                var columnMetadataList = new List<ColumnMetadata>();

                foreach (DataRow colRow in columns.Rows)
                {
                    columnMetadataList.Add(new ColumnMetadata
                    {
                        ColumnName = colRow["COLUMN_NAME"].ToString()!,
                        DataType = colRow["DATA_TYPE"].ToString()!,
                        IsNullable = colRow["IS_NULLABLE"].ToString() == "YES"
                    });
                }

                // Retrieve Primary Keys (simplified approach for SQL Server)
                // Note: In a production scenario, we might query INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                var primaryKeys = await connection.GetSchemaAsync("PrimaryKeys", new[] { null, tableSchema, tableName });
                foreach (DataRow pkRow in primaryKeys.Rows)
                {
                    string pkColName = pkRow["COLUMN_NAME"].ToString()!;
                    var meta = columnMetadataList.FirstOrDefault(c => c.ColumnName == pkColName);
                    if (meta != null) meta.IsPrimaryKey = true;
                }

                schema[fullTableName] = columnMetadataList;
            }

            return schema;
        }
    }

    public class QuerySanitizer
    {
        // Regex to identify table and column references (simplified)
        // Looks for words that might be entities, ignoring common SQL keywords
        private static readonly Regex EntityRegex = new Regex(@"\b([A-Z][a-zA-Z]+)\b", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        public (string SqlSkeleton, List<string> ValidatedTables) Sanitize(string naturalLanguage, Dictionary<string, List<ColumnMetadata>> schema)
        {
            var validTables = new List<string>();
            var tableNames = schema.Keys.Select(k => k.Replace("[", "").Replace("]", "")).ToList(); // Clean names for comparison
            
            // 1. Extract potential entities
            var matches = EntityRegex.Matches(naturalLanguage);
            
            // 2. Validate against schema
            foreach (Match match in matches)
            {
                string potentialEntity = match.Value;
                
                // Check if it matches a table name (case-insensitive)
                var matchedTable = tableNames.FirstOrDefault(t => t.Equals(potentialEntity, StringComparison.OrdinalIgnoreCase));
                
                if (matchedTable != null)
                {
                    // Re-bracket the table name for SQL safety
                    string safeTableName = $"[{matchedTable.Split('.')[0]}].[{matchedTable.Split('.')[1]}]";
                    if (!validTables.Contains(safeTableName))
                    {
                        validTables.Add(safeTableName);
                    }
                }
            }

            if (validTables.Count == 0)
            {
                throw new SchemaMismatchException("No valid table names found in the natural language query.");
            }

            // 3. Generate Basic SELECT Skeleton
            // For simplicity, we pick the first identified table. 
            // In a real LLM scenario, the LLM would map columns, but here we validate the table existence.
            string selectedTable = validTables.First();
            var columns = schema[selectedTable];
            
            // Select all columns for the skeleton (or specific ones if parsed)
            var columnList = string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"));

            string sql = $"SELECT TOP 100 {columnList} FROM {selectedTable};";

            return (sql, validTables);
        }
    }
}
