
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

namespace AISQLConnector.Exercise3
{
    // Mock Vector Database Client
    public interface IVectorStore
    {
        Task StoreAsync(string hashKey, float[] vector, DataTable result, DateTime expiry);
        Task<(float[] Vector, DataTable Result, DateTime Expiry)> RetrieveAsync(string hashKey);
    }

    public class MockVectorStore : IVectorStore
    {
        // In-memory storage for demo
        private readonly Dictionary<string, (float[] Vector, DataTable Result, DateTime Expiry)> _store = new();

        public Task StoreAsync(string hashKey, float[] vector, DataTable result, DateTime expiry)
        {
            _store[hashKey] = (vector, result, expiry);
            return Task.CompletedTask;
        }

        public Task<(float[] Vector, DataTable Result, DateTime Expiry)> RetrieveAsync(string hashKey)
        {
            if (_store.TryGetValue(hashKey, out var item))
            {
                return Task.FromResult(item);
            }
            return Task.FromResult((null, null, DateTime.MinValue));
        }
    }

    public class SemanticCache
    {
        private readonly IVectorStore _vectorStore;
        private const double SimilarityThreshold = 0.95;
        private const int CacheTTLMinutes = 30;

        public SemanticCache(IVectorStore vectorStore)
        {
            _vectorStore = vectorStore;
        }

        // Mock embedding generator
        private float[] GenerateEmbedding(string text)
        {
            // In reality, this calls an AI model (e.g., Azure OpenAI).
            // Here, we generate a deterministic vector based on string length and hash for simulation.
            var rng = new Random(text.GetHashCode());
            var vector = new float[128];
            for (int i = 0; i < 128; i++)
            {
                vector[i] = (float)rng.NextDouble();
            }
            return vector;
        }

        private float CosineSimilarity(float[] vecA, float[] vecB)
        {
            if (vecA.Length != vecB.Length) return 0;

            float dotProduct = 0;
            float magnitudeA = 0;
            float magnitudeB = 0;

            for (int i = 0; i < vecA.Length; i++)
            {
                dotProduct += vecA[i] * vecB[i];
                magnitudeA += vecA[i] * vecA[i];
                magnitudeB += vecB[i] * vecB[i];
            }

            magnitudeA = (float)Math.Sqrt(magnitudeA);
            magnitudeB = (float)Math.Sqrt(magnitudeB);

            if (magnitudeA == 0 || magnitudeB == 0) return 0;

            return dotProduct / (magnitudeA * magnitudeB);
        }

        public async Task<DataTable> CheckCacheAsync(string naturalLanguageQuery)
        {
            var inputVector = GenerateEmbedding(naturalLanguageQuery);
            
            // In a real vector DB, we would query for top-k nearest neighbors.
            // Here, we simulate by iterating our mock store.
            var allEntries = await _vectorStore.RetrieveAsync("ALL_KEYS"); // Mock retrieval of all keys

            // Since our mock is simple, we assume we can iterate a hidden internal store or 
            // we rely on the specific key retrieval. For this exercise, we will simulate
            // a search by iterating a hypothetical list of cached entries.
            
            // *Simulation of Vector Search:*
            // In a real scenario, we would query the DB: SELECT * FROM Cache ORDER BY cosine_similarity DESC LIMIT 1
            // Here, we assume the store returns a list (not implemented in interface for brevity).
            
            // Let's assume we have a way to get all entries for this demo (not production ready)
            // For the purpose of the exercise, we will just check if the exact text hash exists first,
            // then simulate a similarity check against a "last stored" item.
            
            // **Proper Implementation Logic:**
            // 1. Query Vector DB for nearest neighbors.
            // 2. Filter by TTL.
            // 3. Calculate similarity.
            
            // *Mocking the result for the exercise solution:*
            // We will assume the VectorStore returns a candidate list.
            // Since we can't implement a full vector DB in one file, we will implement the logic 
            // assuming we retrieved a candidate.
            
            // For this code to run, we need a list of candidates. Let's assume we store one.
            if (_cachedItem == null) return null;

            if (DateTime.UtcNow > _cachedItem.Value.Expiry)
            {
                _cachedItem = null; // Expired
                return null;
            }

            float similarity = CosineSimilarity(inputVector, _cachedItem.Value.Vector);

            if (similarity >= SimilarityThreshold)
            {
                return _cachedItem.Value.Result;
            }

            return null;
        }
        
        // Helper to store a single item for the demo (since we don't have a full DB)
        private (float[] Vector, DataTable Result, DateTime Expiry)? _cachedItem;

        public async Task StoreResultAsync(string naturalLanguageQuery, DataTable result)
        {
            var vector = GenerateEmbedding(naturalLanguageQuery);
            var expiry = DateTime.UtcNow.AddMinutes(CacheTTLMinutes);
            
            // In real app: await _vectorStore.StoreAsync(hashKey, vector, result, expiry);
            _cachedItem = (vector, result, expiry);
            
            await Task.CompletedTask;
        }
    }
}
