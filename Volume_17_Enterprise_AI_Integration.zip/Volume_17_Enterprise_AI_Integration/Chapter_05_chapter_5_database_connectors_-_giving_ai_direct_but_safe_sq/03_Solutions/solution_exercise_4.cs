
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using Microsoft.Data.SqlClient;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using Dapper; // Using Dapper for simplified mapping

namespace AISQLConnector.Exercise4
{
    public class QueryExecutor
    {
        private readonly string _connectionString;
        private const int MaxRows = 1000;
        private const int TimeoutSeconds = 5;

        public QueryExecutor(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<DataTable> ExecuteAsync(string sql, CancellationToken cancellationToken)
        {
            // 1. Enforce Max Rows Policy
            // We prepend TOP to the SELECT statement if not already present.
            // Note: This is a simplistic approach. A robust solution would parse the SQL AST.
            if (sql.Trim().ToUpper().StartsWith("SELECT") && !sql.Trim().ToUpper().Contains("TOP"))
            {
                sql = sql.Replace("SELECT", $"SELECT TOP {MaxRows}", StringComparison.OrdinalIgnoreCase);
            }

            // 2. Dry Run Check (Simulated)
            if (sql.Contains("--DRY_RUN"))
            {
                var cost = await AnalyzeExecutionPlanAsync(sql);
                if (cost > 100) // Arbitrary threshold
                    throw new InvalidOperationException("Query cost too high. Execution rejected.");
                
                return new DataTable(); // Return empty for dry run
            }

            await using var connection = new SqlConnection(_connectionString);
            
            // 3. Timeout Policy
            // Note: Dapper handles cancellation tokens, but we also set command timeout.
            var commandDefinition = new CommandDefinition(
                command: sql,
                cancellationToken: cancellationToken,
                commandTimeout: TimeoutSeconds
            );

            try
            {
                await connection.OpenAsync(cancellationToken);
                
                // Execute using Dapper to map to DataTable
                using var reader = await connection.ExecuteReaderAsync(commandDefinition);
                var dataTable = new DataTable();
                dataTable.Load(reader);
                
                return dataTable;
            }
            catch (OperationCanceledException)
            {
                throw new TimeoutException($"Query execution exceeded the {TimeoutSeconds} second limit.");
            }
            catch (SqlException ex)
            {
                // 4. Safe Exception Mapping
                // Prevent leaking internal paths or sensitive info
                var userMessage = ex.Number switch
                {
                    -2 => "Query timed out.",
                    547 => "Referenced data does not exist (Foreign Key violation).",
                    2627 => "Duplicate key violation.",
                    _ => $"Database error occurred (Code: {ex.Number})."
                };
                throw new Exception(userMessage, ex);
            }
        }

        private async Task<int> AnalyzeExecutionPlanAsync(string sql)
        {
            // Simulate parsing XML execution plan
            // In reality: Execute "SET SHOWPLAN_XML ON" then run query to get XML back
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();
            
            // Mock XML plan
            string mockXml = @"<ShowPlanXML><BatchSequence><Batch><RelOp AvgRowSize=""100"" EstimateRows=""5000"" PhysicalOp=""Clustered Index Scan"" /></Batch></BatchSequence></ShowPlanXML>";
            
            var doc = XDocument.Parse(mockXml);
            var op = doc.Descendants("RelOp").FirstOrDefault();
            var rows = int.Parse(op?.Attribute("EstimateRows")?.Value ?? "0");

            return rows; // Returning estimated rows as "cost"
        }
    }
}
