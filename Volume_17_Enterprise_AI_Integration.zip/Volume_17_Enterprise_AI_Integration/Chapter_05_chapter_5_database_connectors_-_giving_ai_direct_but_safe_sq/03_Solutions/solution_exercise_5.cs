
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace AISQLConnector.Exercise5
{
    // Interfaces for dependency injection
    public interface IAISQLConnector
    {
        Task<QueryResult> ExecuteNaturalLanguageQueryAsync(string query, UserContext context, CancellationToken ct = default);
    }

    public class QueryResult
    {
        public DataTable? Data { get; set; }
        public string? ErrorMessage { get; set; }
        public bool IsCached { get; set; }
        public long ExecutionTimeMs { get; set; }
        public bool Success => ErrorMessage == null;
    }

    public class SessionContext
    {
        // Stores results of previous execution for Query Chaining
        public Dictionary<string, object> Memory { get; set; } = new();
    }

    public class AISQLConnector : IAISQLConnector
    {
        // Dependencies (In a real app, inject these via Constructor)
        private readonly SemanticCache _cache;
        private readonly DatabaseSchemaInspector _schemaInspector;
        private readonly SecureQueryRewriter _securityRewriter;
        private readonly QueryValidator _validator;
        private readonly QueryExecutor _executor;
        private readonly SessionContext _session;
        
        // Mock LLM Service
        private readonly MockLLMService _llmService;

        public AISQLConnector(IConfiguration config, SessionContext session)
        {
            _cache = new SemanticCache(new MockVectorStore());
            _schemaInspector = new DatabaseSchemaInspector(config);
            _securityRewriter = new SecureQueryRewriter(new SecurityPolicyEngine());
            _validator = new QueryValidator();
            _executor = new QueryExecutor(config.GetConnectionString("DefaultConnection"));
            _session = session;
            _llmService = new MockLLMService();
        }

        public async Task<QueryResult> ExecuteNaturalLanguageQueryAsync(string query, UserContext context, CancellationToken ct = default)
        {
            var result = new QueryResult();
            var stopwatch = Stopwatch.StartNew();

            try
            {
                // 1. Query Chaining: Pre-process placeholders
                query = PreProcessQuery(query);

                // 2. Check Semantic Cache
                var cachedData = await _cache.CheckCacheAsync(query);
                if (cachedData != null)
                {
                    result.Data = cachedData;
                    result.IsCached = true;
                    result.ExecutionTimeMs = stopwatch.ElapsedMilliseconds;
                    return result;
                }

                // 3. Inspect Schema
                var schema = await _schemaInspector.GetSchemaAsync();

                // 4. Generate SQL (Mock LLM)
                // In reality, LLM would use schema + query to generate SQL.
                // Here we use a basic sanitizer to identify table and generate a skeleton.
                var sanitizer = new Exercise1.QuerySanitizer(); // Reusing logic from Ex 1
                var (sqlSkeleton, _) = sanitizer.Sanitize(query, schema);
                
                // Let's pretend the LLM refined this to a specific query
                string rawSql = _llmService.GenerateSql(query, schema, sqlSkeleton);

                // 5. Validate (Check for malicious keywords)
                _validator.Validate(rawSql, context);

                // 6. Apply Security (RLS + RBAC)
                string safeSql = _securityRewriter.Rewrite(rawSql, context);

                // 7. Execute via Sandbox
                result.Data = await _executor.ExecuteAsync(safeSql, ct);

                // 8. Store in Cache
                await _cache.StoreResultAsync(query, result.Data);

                // Store in Session for chaining
                if (result.Data.Rows.Count > 0)
                {
                    // Simple logic: Store the first row's ID if available for chaining demo
                    _session.Memory["LAST_RESULT"] = result.Data.Rows[0]; 
                }
            }
            catch (Exception ex)
            {
                result.ErrorMessage = ex.Message;
            }
            finally
            {
                stopwatch.Stop();
                result.ExecutionTimeMs = stopwatch.ElapsedMilliseconds;
            }

            return result;
        }

        private string PreProcessQuery(string query)
        {
            // Simple placeholder replacement for Query Chaining
            if (query.Contains("{LAST_RESULT") && _session.Memory.TryGetValue("LAST_RESULT", out var lastRow))
            {
                var row = (DataRow)lastRow;
                // Replace {LAST_RESULT.ID} with actual value
                if (row.Table.Columns.Contains("ID"))
                {
                    query = query.Replace("{LAST_RESULT.ID}", row["ID"].ToString());
                }
            }
            return query;
        }
    }

    // Mock LLM Service for the exercise
    public class MockLLMService
    {
        public string GenerateSql(string naturalLanguage, Dictionary<string, List<Exercise1.ColumnMetadata>> schema, string skeleton)
        {
            // In a real scenario, this calls an LLM API.
            // Here, we just return the skeleton or a slightly modified version based on keywords.
            if (naturalLanguage.ToLower().Contains("active"))
            {
                return skeleton.Replace(";", " WHERE Status = 'Active';");
            }
            return skeleton;
        }
    }

    // --- Graphviz DOT Visualization ---
    /*
    digraph Pipeline {
        rankdir=LR;
        node [shape=box, style=rounded];

        Start [label="Natural Language Input"];
        CacheCheck [label="Semantic Cache Check"];
        SchemaInspect [label="Schema Inspection"];
        LLMGen [label="LLM SQL Generation"];
        Security [label="Security Rewriter (RLS/RBAC)"];
        Validate [label="Query Validator"];
        Execute [label="Sandboxed Execution"];
        StoreCache [label="Store Result"];
        End [label="Return Result"];

        Start -> CacheCheck;
        CacheCheck -> SchemaInspect [label="Miss"];
        CacheCheck -> End [label="Hit"];
        SchemaInspect -> LLMGen;
        LLMGen -> Security;
        Security -> Validate;
        Validate -> Execute;
        Execute -> StoreCache;
        StoreCache -> End;
        
        // Error handling visualization (implicit in code)
    }
    */
}
