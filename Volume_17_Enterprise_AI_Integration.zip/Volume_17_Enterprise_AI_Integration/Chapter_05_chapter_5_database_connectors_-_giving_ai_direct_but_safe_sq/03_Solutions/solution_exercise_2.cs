
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace AISQLConnector.Exercise2
{
    public class UserContext
    {
        public string UserId { get; set; } = string.Empty;
        public List<string> Roles { get; set; } = new();
        public string DepartmentId { get; set; } = string.Empty;
        public string TenantId { get; set; } = string.Empty;
    }

    public class SecurityPolicyEngine
    {
        public string GetPredicate(UserContext context)
        {
            // Priority: Tenant Isolation > Role Restrictions > Auditor (No Restriction)
            
            // 1. Tenant Isolation (Multi-tenancy)
            string tenantClause = $"TenantId = '{context.TenantId}'";

            // 2. Role-based restrictions
            if (context.Roles.Contains("Employee"))
            {
                return $"{tenantClause} AND CreatedBy = '{context.UserId}'";
            }
            
            if (context.Roles.Contains("Manager"))
            {
                return $"{tenantClause} AND DepartmentId = '{context.DepartmentId}'";
            }

            if (context.Roles.Contains("Auditor"))
            {
                // Auditors see all data within the tenant
                return tenantClause;
            }

            // Default restriction if no specific role matches
            return $"{tenantClause} AND 1=0"; // Fail safe: show nothing
        }
    }

    public class QueryValidator
    {
        private static readonly HashSet<string> DisallowedKeywords = new(StringComparer.OrdinalIgnoreCase)
        {
            "DROP", "DELETE", "UPDATE", "INSERT", "GRANT", "REVOKE", "TRUNCATE", "ALTER"
        };

        public void Validate(string sql, UserContext context)
        {
            // Check for disallowed keywords
            foreach (var keyword in DisallowedKeywords)
            {
                if (Regex.IsMatch(sql, $@"\b{keyword}\b"))
                {
                    // Auditors are strictly read-only
                    if (context.Roles.Contains("Auditor") && keyword == "SELECT") continue;
                    
                    throw new SecurityException($"Query contains disallowed keyword: {keyword}");
                }
            }

            // Role-specific checks
            if (context.Roles.Contains("Auditor") && !sql.Trim().ToUpper().StartsWith("SELECT"))
            {
                throw new SecurityException("Auditors are only allowed SELECT statements.");
            }
        }
    }

    public class SecureQueryRewriter
    {
        private readonly SecurityPolicyEngine _policyEngine;

        public SecureQueryRewriter(SecurityPolicyEngine policyEngine)
        {
            _policyEngine = policyEngine;
        }

        public string Rewrite(string sql, UserContext context)
        {
            // 1. Inject Security Predicates (RLS)
            string securityPredicate = _policyEngine.GetPredicate(context);
            
            // Parse SQL to inject WHERE clause safely
            // Note: This is a simplified parser. In production, use a SQL AST parser.
            string finalSql;
            
            if (sql.ToUpper().Contains("WHERE"))
            {
                // Append AND to existing WHERE
                // Regex looks for "WHERE ..." at the end of the string (simplified)
                finalSql = Regex.Replace(sql, @"WHERE\s+(.*?)(;|$)", $"WHERE $1 AND {securityPredicate}$2", RegexOptions.IgnoreCase);
            }
            else
            {
                // Add WHERE clause
                finalSql = Regex.Replace(sql, @"(FROM\s+\[?\w+\]?(?:\.\[?\w+\]?)?)(;|$)", $"$1 WHERE {securityPredicate}$2", RegexOptions.IgnoreCase);
            }

            return finalSql;
        }
    }

    public class SecurityException : Exception
    {
        public SecurityException(string message) : base(message) { }
    }
}
