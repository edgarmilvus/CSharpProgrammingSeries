
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System.Data;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace SafeSqlExecutor
{
    // Represents a user's identity and their security context for database access.
    // In a real application, this would come from an authentication middleware (e.g., JWT claims).
    public record UserContext(string UserId, string Role, List<string> AllowedDepartments);

    // Represents the database schema structure needed for SQL generation.
    // This simulates dynamic schema introspection.
    public class TableSchema
    {
        public string Name { get; set; } = string.Empty;
        public List<ColumnSchema> Columns { get; set; } = new();
    }

    public class ColumnSchema
    {
        public string Name { get; set; } = string.Empty;
        public string DataType { get; set; } = string.Empty;
        public bool IsSensitive { get; set; } // Flag to mark PII columns
    }

    // The core engine for generating and executing safe SQL.
    public class SafeSqlExecutor
    {
        private readonly string _connectionString;
        private readonly Dictionary<string, TableSchema> _schemaCache;

        public SafeSqlExecutor(string connectionString)
        {
            _connectionString = connectionString;
            _schemaCache = new Dictionary<string, TableSchema>();
        }

        // 1. Schema Introspection: Dynamically fetch table structure.
        // This allows the AI to know what tables/columns exist without hardcoding.
        public async Task LoadSchemaAsync(string tableName)
        {
            if (_schemaCache.ContainsKey(tableName)) return;

            var schema = new TableSchema { Name = tableName };
            
            // In a real scenario, query INFORMATION_SCHEMA.COLUMNS.
            // Here we simulate it for the "Hello World" example.
            // We intentionally mark 'Salary' as sensitive.
            schema.Columns = new List<ColumnSchema>
            {
                new ColumnSchema { Name = "Id", DataType = "int", IsSensitive = false },
                new ColumnSchema { Name = "Name", DataType = "nvarchar", IsSensitive = false },
                new ColumnSchema { Name = "Department", DataType = "nvarchar", IsSensitive = false },
                new ColumnSchema { Name = "Salary", DataType = "decimal", IsSensitive = true }
            };

            _schemaCache[tableName] = schema;
        }

        // 2. Query Generation: Convert a natural language request into a SQL string.
        // In a real app, this would use an LLM prompt with the schema provided as context.
        // For this example, we simulate the LLM's output based on a simple mapping.
        public string GenerateSql(string naturalLanguageQuery, UserContext user)
        {
            // SIMULATION START: This block mimics what an LLM would output given the schema.
            string sql = "SELECT Name, Department, Salary FROM Employees";
            
            // Heuristic parsing for the example: 
            // If the user asks for "developers", add a WHERE clause.
            if (naturalLanguageQuery.ToLower().Contains("developer"))
            {
                sql += " WHERE Department = 'Engineering'";
            }
            // If the user asks for "high paid", add a filter.
            if (naturalLanguageQuery.ToLower().Contains("high paid"))
            {
                sql += " AND Salary > 100000";
            }
            // SIMULATION END

            return sql;
        }

        // 3. Security Validation: The critical safety layer.
        // Checks RBAC, Row-Level Security (RLS), and PII exposure.
        public void ValidateSql(string sql, UserContext user)
        {
            var sqlLower = sql.ToLower();

            // A. RBAC Check: Ensure user has read access.
            if (user.Role != "Admin" && user.Role != "Manager" && user.Role != "Analyst")
            {
                throw new UnauthorizedAccessException($"Role '{user.Role}' does not have read permissions.");
            }

            // B. Sensitive Column Check (PII Protection).
            // We scan the SQL for columns marked as 'Sensitive' in our schema.
            var sensitiveColumns = _schemaCache["Employees"].Columns
                .Where(c => c.IsSensitive)
                .Select(c => c.Name.ToLower())
                .ToList();

            foreach (var col in sensitiveColumns)
            {
                // Simple regex check to see if the sensitive column is selected.
                // Note: In production, use a proper SQL parser (e.g., Microsoft.SqlServer.TransactSql.ScriptDom).
                if (sqlLower.Contains(col.ToLower()) && !sqlLower.Contains($"where salary >")) 
                {
                    // Allow 'Salary' only if it's aggregated or strictly filtered (business rule).
                    // For this example, we block raw selection of Salary unless aggregated.
                    // However, our simulation selects it directly. Let's refine the rule:
                    // We will strictly block 'SELECT Salary' unless the user is Admin.
                    if (sqlLower.Contains("salary") && user.Role != "Admin")
                    {
                        throw new SecurityException($"User '{user.UserId}' attempted to access sensitive column 'Salary' without Admin privileges.");
                    }
                }
            }

            // C. Row-Level Security (RLS) Simulation.
            // Append a WHERE clause based on the user's allowed departments.
            // This ensures users only see data relevant to their scope.
            if (user.AllowedDepartments.Any() && user.Role != "Admin")
            {
                // This is a simplistic string manipulation. 
                // In production, this logic is often enforced via database policies or view definitions.
                string departmentFilter = string.Join(" OR ", user.AllowedDepartments.Select(d => $"Department = '{d}'"));
                
                if (sqlLower.Contains("where"))
                {
                    // Inject AND
                    sql += $" AND ({departmentFilter})";
                }
                else
                {
                    sql += $" WHERE ({departmentFilter})";
                }
            }

            // D. Destructive Command Prevention.
            if (sqlLower.Contains("drop") || sqlLower.Contains("delete") || sqlLower.Contains("update") || sqlLower.Contains("insert"))
            {
                throw new SecurityException("Only SELECT queries are allowed.");
            }
        }

        // 4. Execution: Run the validated query.
        public async Task<string> ExecuteQueryAsync(string sql)
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            using var command = new SqlCommand(sql, connection);
            using var reader = await command.ExecuteReaderAsync();

            var results = new List<Dictionary<string, object?>>();
            
            while (await reader.ReadAsync())
            {
                var row = new Dictionary<string, object?>();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                }
                results.Add(row);
            }

            return JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true });
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            // Setup: Connection string (using Trusted Connection for local dev)
            // In production, use Managed Identity or Secret Store.
            string connectionString = "Server=localhost;Database=EnterpriseDB;Trusted_Connection=True;TrustServerCertificate=True;";

            var executor = new SafeSqlExecutor(connectionString);

            // Simulate a user: An Analyst from the Engineering department.
            // They should NOT see salaries, but SHOULD see Engineering employees.
            var userContext = new UserContext(
                UserId: "alice_analyst",
                Role: "Analyst",
                AllowedDepartments: new List<string> { "Engineering" }
            );

            // Load Schema (Simulating dynamic introspection)
            await executor.LoadSchemaAsync("Employees");

            // Natural Language Input
            string userRequest = "Show me all developers in the engineering department.";

            Console.WriteLine($"User Request: {userRequest}");
            Console.WriteLine($"User Role: {userContext.Role}");
            Console.WriteLine("-----------------------------------");

            try
            {
                // Step 1: Generate SQL (LLM Step)
                string generatedSql = executor.GenerateSql(userRequest, userContext);
                Console.WriteLine($"Generated SQL: {generatedSql}");

                // Step 2: Validate & Secure (Safety Step)
                // This modifies the SQL to enforce RLS and checks permissions.
                executor.ValidateSql(generatedSql, userContext);
                Console.WriteLine($"Validated SQL: {generatedSql} (RLS Applied)");
                Console.WriteLine("-----------------------------------");

                // Step 3: Execute
                string jsonResult = await executor.ExecuteQueryAsync(generatedSql);
                Console.WriteLine("Query Results:");
                Console.WriteLine(jsonResult);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Error: {ex.Message}");
                Console.ResetColor();
            }
        }
    }
}
