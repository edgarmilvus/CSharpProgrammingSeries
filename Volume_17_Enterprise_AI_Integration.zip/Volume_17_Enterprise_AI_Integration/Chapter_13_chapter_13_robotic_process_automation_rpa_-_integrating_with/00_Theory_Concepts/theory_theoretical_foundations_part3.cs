
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.cs
// Description: Theoretical Foundations
// ==========================================

using System;

namespace EnterpriseAI.Rpa.Core
{
    public enum DocumentStatus { Valid, Suspicious, Invalid, RequiresReview }

    public class DocumentResult
    {
        public DocumentStatus Status { get; set; }
        public double ConfidenceScore { get; set; }
        public string ExtractedEntity { get; set; }
    }

    public class WorkflowRouter
    {
        public string RouteDocument(DocumentResult result)
        {
            // Modern C# pattern matching allows us to deconstruct and evaluate
            // complex conditions in a single, readable expression.
            // This replaces nested if-else blocks that are common in legacy RPA scripts.
            return result switch
            {
                // If status is Invalid, immediate rejection.
                { Status: DocumentStatus.Invalid } => "Reject",

                // If status is Valid AND confidence is high, auto-process.
                { Status: DocumentStatus.Valid, ConfidenceScore: > 0.95 } => "AutoProcess",

                // If status is Valid BUT confidence is borderline, route to review.
                { Status: DocumentStatus.Valid, ConfidenceScore: > 0.80 and <= 0.95 } => "RouteToReviewQueue",

                // If status is Suspicious or low confidence, trigger manual audit.
                { Status: DocumentStatus.Suspicious } or { ConfidenceScore: < 0.80 } => "TriggerAudit",

                // Default fallback.
                _ => "LogError"
            };
        }
    }
}
