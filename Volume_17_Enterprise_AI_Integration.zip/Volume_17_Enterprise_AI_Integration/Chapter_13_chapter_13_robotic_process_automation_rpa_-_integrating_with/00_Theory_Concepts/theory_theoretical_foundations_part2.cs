
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.cs
// Description: Theoretical Foundations
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnterpriseAI.Rpa.Core
{
    public class DocumentProcessor
    {
        private readonly ILlmProcessor _llmProcessor;

        public DocumentProcessor(ILlmProcessor llmProcessor)
        {
            _llmProcessor = llmProcessor;
        }

        // Using IAsyncEnumerable allows the RPA bot to process data as it arrives,
        // rather than waiting for the entire batch to complete. This is crucial for 
        // maintaining responsiveness in UI automation.
        public async IAsyncEnumerable<string> StreamPageAnalysisAsync(IEnumerable<string> pages)
        {
            foreach (var page in pages)
            {
                // Simulate sending a page to the LLM and awaiting the analysis.
                // In a real scenario, this might involve an HTTP call to an AI endpoint.
                var analysis = await _llmProcessor.ProcessAsync("Extract invoice total", page);
                
                // Yield return allows the caller (the RPA bot) to act on this result
                // immediately before the next page is processed.
                yield return analysis;
            }
        }
    }
}
