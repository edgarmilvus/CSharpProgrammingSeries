
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace EventListener
{
    // 1. Order Event Definition
    public record OrderEvent(
        [property: JsonPropertyName("order_id")] string OrderId,
        [property: JsonPropertyName("customer_tier")] string CustomerTier,
        [property: JsonPropertyName("payload")] string Payload
    );

    public class PriorityEventListener : BackgroundService
    {
        private readonly ServiceBusClient _client;
        private readonly IConnectionMultiplexer _redis;
        private readonly HttpClient _httpClient;
        private readonly ILogger<PriorityEventListener> _logger;
        private readonly Channel<OrderEvent> _highPriorityChannel;
        private const string StandardQueue = "erp-order-events";
        private const string PriorityQueue = "erp-order-events-priority";

        public PriorityEventListener(ServiceBusClient client, IConnectionMultiplexer redis, ILogger<PriorityEventListener> logger)
        {
            _client = client;
            _redis = redis;
            _logger = logger;
            _httpClient = new HttpClient();
            
            // 6. Buffer for burst traffic
            _highPriorityChannel = Channel.CreateBounded<OrderEvent>(new BoundedChannelOptions(1000)
            {
                SingleWriter = false,
                SingleReader = true
            });
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // Start the priority processor
            var processorTask = ProcessPriorityChannel(stoppingToken);

            // Listen to both queues
            var standardProcessor = _client.CreateProcessor(StandardQueue, new ServiceBusProcessorOptions { AutoCompleteMessages = false });
            var priorityProcessor = _client.CreateProcessor(PriorityQueue, new ServiceBusProcessorOptions { AutoCompleteMessages = false });

            standardProcessor.ProcessMessageAsync += args => HandleMessage(args, isPriority: false);
            priorityProcessor.ProcessMessageAsync += args => HandleMessage(args, isPriority: true);

            await Task.WhenAll(
                standardProcessor.StartProcessingAsync(stoppingToken),
                priorityProcessor.StartProcessingAsync(stoppingToken),
                processorTask
            );
        }

        private async Task HandleMessage(ProcessMessageEventArgs args, bool isPriority)
        {
            try
            {
                var body = args.Message.Body.ToString();
                var orderEvent = JsonSerializer.Deserialize<OrderEvent>(body);

                // 4. Idempotency Check (Redis)
                var db = _redis.GetDatabase();
                if (await db.StringGetAsync($"processed:{orderEvent.OrderId}") == true)
                {
                    _logger.LogInformation($"Order {orderEvent.OrderId} already processed. Skipping.");
                    await args.CompleteMessageAsync(args.Message);
                    return;
                }

                // 6. Priority Routing Logic
                if (isPriority || orderEvent.CustomerTier == "Platinum")
                {
                    // Buffer high priority events to handle bursts
                    await _highPriorityChannel.Writer.WriteAsync(orderEvent, args.CancellationToken);
                }
                else
                {
                    // Standard processing
                    await TriggerUiPathJob(orderEvent);
                }

                // Mark as processed (TTL 5 mins)
                await db.StringSetAsync($"processed:{orderEvent.OrderId}", true, TimeSpan.FromMinutes(5));
                await args.CompleteMessageAsync(args.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing message");
                await args.AbandonMessageAsync(args.Message);
            }
        }

        private async Task ProcessPriorityChannel(CancellationToken ct)
        {
            await foreach (var orderEvent in _highPriorityChannel.Reader.ReadAllAsync(ct))
            {
                // In a real scenario, we might batch these for the Orchestrator API
                await TriggerUiPathJob(orderEvent);
            }
        }

        private async Task TriggerUiPathJob(OrderEvent orderEvent)
        {
            // 3. & 4. Trigger UiPath Orchestrator API
            var request = new HttpRequestMessage(HttpMethod.Post, "https://platform.uipath.com/odata/Jobs/UiPath.Server.Core.OData.StartJobs");
            var payload = new 
            { 
                startInfo = new 
                { 
                    ReleaseKey = "your-release-key", 
                    InputArguments = $"{{'OrderId': '{orderEvent.OrderId}'}}" 
                } 
            };
            
            request.Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json");

            var response = await _httpClient.SendAsync(request);
            
            if (!response.IsSuccessStatusCode)
            {
                // 5. DLQ Handling logic would go here (logging to DLQ topic)
                var error = await response.Content.ReadAsStringAsync();
                _logger.LogError($"UiPath API Error: {error}");
                throw new Exception($"UiPath API failed: {response.StatusCode}");
            }

            _logger.LogInformation($"Triggered UiPath Job for Order {orderEvent.OrderId}");
        }
    }
}
