
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.CircuitBreaker;

namespace HybridController
{
    public record SharePointFileEvent(string FileName, string FileUrl, string EventType);

    public class HybridControllerFunction
    {
        private readonly ILogger<HybridControllerFunction> _logger;
        private readonly IAsyncPolicy<HttpResponseMessage> _circuitBreakerPolicy;
        private readonly HttpClient _httpClient;

        public HybridControllerFunction(ILogger<HybridControllerFunction> logger)
        {
            _logger = logger;
            _httpClient = new HttpClient();

            // 6. Circuit Breaker Policy: Open after 5 failures, wait 30s
            _circuitBreakerPolicy = Policy<HttpResponseMessage>
                .Handle<HttpRequestException>()
                .OrResult(r => (int)r.StatusCode >= 500)
                .CircuitBreakerAsync(
                    exceptionsAllowedBeforeBreaking: 5,
                    durationOfBreak: TimeSpan.FromSeconds(30),
                    onBreak: (result, breakDelay) => 
                        _logger.LogWarning($"Circuit Breaker opened for {breakDelay.TotalSeconds}s. Reason: {result.Exception?.Message ?? result.Result.StatusCode.ToString()}"),
                    onReset: () => _logger.LogInformation("Circuit Breaker reset.")
                );
        }

        [Function("FileRouter")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequestData req)
        {
            // 1. Parse Payload
            var body = await new StreamReader(req.Body).ReadToEndAsync();
            var fileEvent = JsonSerializer.Deserialize<SharePointFileEvent>(body);

            // 2. Classify File
            if (Path.GetExtension(fileEvent.FileName).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
            {
                // Route to UiPath
                var result = await RouteToUiPath(fileEvent);
                return result;
            }
            else if (Path.GetExtension(fileEvent.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
            {
                // Route to C# Service (Excel Processing)
                return await ProcessExcelDirectly(fileEvent);
            }

            return new BadRequestObjectResult("Unsupported file type.");
        }

        private async Task<IActionResult> RouteToUiPath(SharePointFileEvent fileEvent)
        {
            // 4. Async Response Logic
            // We return Accepted immediately and process in background (or trigger orchestrator)
            // For this demo, we execute the call but wrapped in Circuit Breaker
            
            try
            {
                // Execute API call with Circuit Breaker
                var response = await _circuitBreakerPolicy.ExecuteAsync(async () =>
                {
                    _logger.LogInformation($"Attempting to start UiPath job for {fileEvent.FileName}");
                    
                    var request = new HttpRequestMessage(HttpMethod.Post, "https://platform.uipath.com/odata/Jobs/UiPath.Server.Core.OData.StartJobs");
                    // Construct payload...
                    request.Content = new StringContent(JsonSerializer.Serialize(new { /* payload */ }), System.Text.Encoding.UTF8, "application/json");
                    
                    return await _httpClient.SendAsync(request);
                });

                if (response.IsSuccessStatusCode)
                {
                    // 5. Webhook listener would handle completion, but here we acknowledge receipt
                    return new AcceptedResult();
                }
            }
            catch (BrokenCircuitException)
            {
                // 6. Circuit is open: Fail gracefully
                _logger.LogError("UiPath API is currently unavailable (Circuit Open). Routing to Manual Review.");
                
                // Logic to add item to "Manual Review" SharePoint list
                await AddToManualReviewList(fileEvent);
                
                return new ObjectResult("Service temporarily unavailable. Item routed to Manual Review.") { StatusCode = 503 };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error triggering UiPath job.");
                return new StatusCodeResult(500);
            }

            return new OkResult();
        }

        private async Task<IActionResult> ProcessExcelDirectly(SharePointFileEvent fileEvent)
        {
            // 3. Direct C# processing (e.g., using ClosedXML or EPPlus)
            _logger.LogInformation($"Processing Excel file {fileEvent.FileName} directly in Azure Function.");
            
            // Simulate processing
            await Task.Delay(500);
            
            // Update SharePoint via Graph API
            await UpdateSharePointMetadata(fileEvent, "Processed by Cloud Function");

            return new OkObjectResult(new { Status = "Processed", Source = "Cloud" });
        }

        private async Task AddToManualReviewList(SharePointFileEvent fileEvent)
        {
            // Logic to post to SharePoint List "Manual Review"
            await Task.CompletedTask;
        }

        private async Task UpdateSharePointMetadata(SharePointFileEvent fileEvent, string status)
        {
            // Logic to patch SharePoint item metadata via Graph API
            await Task.CompletedTask;
        }
    }
}
