
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.AI.ChatCompletion;

namespace EmailExtractor
{
    // 1. Strict JSON Schema for LLM output
    public record InvoiceData(
        [property: JsonPropertyName("invoice_number")] string InvoiceNumber,
        [property: JsonPropertyName("vendor_name")] string VendorName,
        [property: JsonPropertyName("total_amount")] decimal TotalAmount,
        [property: JsonPropertyName("line_items")] List<LineItem> LineItems
    );

    public record LineItem(string Description, decimal Amount);

    // Simulated UiPath DU Object
    public class DocumentData 
    {
        public string DocumentType { get; set; }
        public Dictionary<string, object> Fields { get; set; } = new();
    }

    public class HumanInterventionTask
    {
        public string OriginalEmail { get; set; }
        public string BestAttemptJson { get; set; }
        public List<string> ValidationErrors { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class LlmExtractor
    {
        private readonly IChatCompletionService _chatService;
        private readonly Kernel _kernel;

        public LlmExtractor(Kernel kernel)
        {
            _kernel = kernel;
            _chatService = kernel.GetService<IChatCompletionService>();
        }

        // 4. Guardrail Mechanism
        private bool ValidateOutput(string json, out List<string> errors)
        {
            errors = new List<string>();
            
            // Regex check for basic JSON structure and required fields
            if (!Regex.IsMatch(json, @"""invoice_number""\s*:\s*""[^""]+"""))
                errors.Add("Missing or invalid invoice_number");
            
            if (!Regex.IsMatch(json, @"""total_amount""\s*:\s*\d+"))
                errors.Add("Missing or invalid total_amount");

            // Strict Schema validation via Deserialization
            try
            {
                JsonSerializer.Deserialize<InvoiceData>(json);
            }
            catch (JsonException ex)
            {
                errors.Add($"JSON Schema violation: {ex.Message}");
            }

            return errors.Count == 0;
        }

        // 2. & 5. LLM Processing with Retry
        public async Task<object> ExtractOrFallbackAsync(string emailBody)
        {
            int retries = 0;
            int maxRetries = 3;
            string lastResponse = string.Empty;
            List<string> lastErrors = new List<string>();

            while (retries < maxRetries)
            {
                // Construct prompt
                var prompt = $"""
                    Extract invoice details from the following email. 
                    Return ONLY valid JSON matching this schema: 
                    {{"invoice_number": "string", "vendor_name": "string", "total_amount": number, "line_items": [...]}}

                    Email: {emailBody}
                    """;
                
                if (retries > 0)
                {
                    prompt += $"\n\nPrevious attempt was invalid. Errors: {string.Join(", ", lastErrors)}. Fix these issues.";
                }

                // Call LLM (Simulated via Semantic Kernel)
                var chatHistory = new ChatHistory();
                chatHistory.AddUserMessage(prompt);
                var result = await _chatService.GetChatMessageContentsAsync(chatHistory);
                string responseContent = result.Content;

                // Validate
                if (ValidateOutput(responseContent, out lastErrors))
                {
                    // Success: Map to UiPath DU Object
                    var invoice = JsonSerializer.Deserialize<InvoiceData>(responseContent);
                    return MapToUiPathDu(invoice);
                }

                lastResponse = responseContent;
                retries++;
            }

            // 6. Human-in-the-Loop Fallback
            return new HumanInterventionTask
            {
                OriginalEmail = emailBody,
                BestAttemptJson = lastResponse,
                ValidationErrors = lastErrors,
                CreatedAt = DateTime.UtcNow
            };
        }

        // Mapping to UiPath DU Taxonomy
        private DocumentData MapToUiPathDu(InvoiceData invoice)
        {
            return new DocumentData
            {
                DocumentType = "Invoice",
                Fields = new Dictionary<string, object>
                {
                    { "InvoiceNumber", invoice.InvoiceNumber },
                    { "VendorName", invoice.VendorName },
                    { "TotalAmount", invoice.TotalAmount },
                    { "LineItems", invoice.LineItems }
                }
            };
        }
    }

    // Main Execution Context
    public class Program
    {
        public static async Task Main(string[] args)
        {
            // Setup Semantic Kernel (Mocked for this exercise)
            var kernel = new KernelBuilder().Build();
            var extractor = new LlmExtractor(kernel);
            
            string unstructuredEmail = "Hi, please see invoice INV-999 from ACME Corp for total $500.00. Line item: Consulting services $500.";
            
            var result = await extractor.ExtractOrFallbackAsync(unstructuredEmail);

            if (result is HumanInterventionTask task)
            {
                Console.WriteLine($"[Fallback] Human intervention required. Task created at {task.CreatedAt}");
                // Logic to send to Logic Apps / Task Management
            }
            else if (result is DocumentData doc)
            {
                Console.WriteLine($"[Success] Extracted {doc.Fields["InvoiceNumber"]}");
                // Pass to UiPath Bot
            }
        }
    }
}
