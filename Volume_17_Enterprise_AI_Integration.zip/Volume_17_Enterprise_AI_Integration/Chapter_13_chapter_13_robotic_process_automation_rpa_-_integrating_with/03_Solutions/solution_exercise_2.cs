
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.DurableTask;
using Microsoft.Extensions.Logging;

namespace InvoiceOrchestrator
{
    // DTOs
    public record ExtractedInvoice(string InvoiceId, decimal Amount, string Vendor);
    public record ValidationRequest(string InvoiceId);
    public record ValidationResult(bool IsValid, string ErrorMessage);
    public record CounterEntity(long Value, string ETag);

    public static class InvoiceProcessor
    {
        private static readonly HttpClient _httpClient = new HttpClient();
        private static readonly JsonSerializerOptions _jsonOptions = new() { PropertyNameCaseInsensitive = true };

        // 1. Orchestrator Function
        [Function(nameof(OrchestrateInvoices))]
        public static async Task<List<string>> OrchestrateInvoices(
            [OrchestrationTrigger] TaskOrchestrationContext context)
        {
            var logger = context.CreateReplaySafeLogger(nameof(OrchestrateInvoices));
            var invoiceStreams = context.GetInput<List<Stream>>() ?? new List<Stream>();
            var results = new List<string>();
            var processedIds = new List<string>();

            try
            {
                // 2. Fan-out: Start 5 concurrent tasks (or based on input list)
                var tasks = invoiceStreams.Select((stream, index) => 
                    context.CallActivityAsync<ValidationResult>($"ProcessInvoice_{index}", stream)
                ).ToList();

                // 3. Fan-in: Wait for all to complete
                var validationResults = await Task.WhenAll(tasks);

                // Process results
                foreach (var result in validationResults)
                {
                    if (result.IsValid)
                    {
                        // 4. Increment Counter Entity (ETag handled in Activity)
                        await context.CallActivityAsync("IncrementCounter", result.InvoiceId);
                        
                        // 5. Send Webhook to Power Automate
                        await context.CallActivityAsync("SendWebhook", result);
                        
                        results.Add($"Processed {result.InvoiceId}");
                        processedIds.Add(result.InvoiceId);
                    }
                    else
                    {
                        // 6. Compensate if validation failed (Saga Pattern)
                        // Since we are in a concurrent batch, we must rollback any successful ones
                        logger.LogError($"Validation failed for {result.InvoiceId}: {result.ErrorMessage}");
                        throw new Exception($"Batch failed due to {result.InvoiceId}");
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError($"Orchestration failed: {ex.Message}");
                // Compensate all successful items in this batch
                var compensateTasks = processedIds.Select(id => 
                    context.CallActivityAsync("DecrementCounter", id)
                );
                await Task.WhenAll(compensateTasks);
                throw; // Re-throw to fail the orchestration
            }

            return results;
        }

        // Activity: Extract & Validate (Simulated)
        [Function(nameof(ProcessInvoice))]
        public static async Task<ValidationResult> ProcessInvoice(
            [ActivityTrigger] Stream stream,
            FunctionContext executionContext)
        {
            // Simulate AI extraction
            // In real scenario: var extracted = await _aiService.ExtractAsync(stream);
            var extracted = new ExtractedInvoice(Guid.NewGuid().ToString(), 1000m, "VendorA");

            // Simulate SQL Validation
            bool isValid = await ValidateAgainstDb(extracted);

            return new ValidationResult(isValid, isValid ? "" : "Duplicate Invoice");
        }

        // Activity: Increment Counter with ETag Optimistic Concurrency
        [Function(nameof(IncrementCounter))]
        public static async Task IncrementCounter(
            [ActivityTrigger] string invoiceId,
            [DurableClient] IDurableEntityClient client)
        {
            var entityId = new EntityId("CounterEntity", "global");
            
            // Retry loop for ETag conflict
            for (int i = 0; i < 3; i++)
            {
                var stateResponse = await client.GetEntityStateAsync<CounterEntity>(entityId);
                var currentState = stateResponse.EntityState ?? new CounterEntity(0, stateResponse.ETag);
                
                var newValue = currentState.Value + 1;
                var operation = new EntityOperation(nameof(CounterEntity), "Set", new { Value = newValue, ETag = currentState.ETag });

                try
                {
                    await client.SignalEntityAsync(entityId, operation);
                    break; // Success
                }
                catch (Microsoft.Azure.WebJobs.Extensions.DurableTask.Entities.EntityCommandFailedException ex) when (ex.Message.Contains("Precondition failed"))
                {
                    // ETag mismatch, retry
                    continue;
                }
            }
        }

        // Activity: Decrement Counter (Compensation)
        [Function(nameof(DecrementCounter))]
        public static async Task DecrementCounter(
            [ActivityTrigger] string invoiceId,
            [DurableClient] IDurableEntityClient client)
        {
            var entityId = new EntityId("CounterEntity", "global");
            await client.SignalEntityAsync(entityId, "Decrement");
        }

        // Activity: Send Webhook
        [Function(nameof(SendWebhook))]
        public static async Task SendWebhook(
            [ActivityTrigger] ValidationResult result)
        {
            var payload = JsonSerializer.Serialize(result);
            var content = new StringContent(payload, System.Text.Encoding.UTF8, "application/json");
            // Replace with actual Power Automate webhook URL
            await _httpClient.PostAsync("https://prod-00.westus.logic.azure.com:443/workflows/...", content);
        }

        // Mock DB Validation
        private static async Task<bool> ValidateAgainstDb(ExtractedInvoice invoice)
        {
            await Task.Delay(100); // Simulate network latency
            // Simulate a failure condition for testing
            return invoice.InvoiceId.GetHashCode() % 2 != 0; 
        }
    }
}
