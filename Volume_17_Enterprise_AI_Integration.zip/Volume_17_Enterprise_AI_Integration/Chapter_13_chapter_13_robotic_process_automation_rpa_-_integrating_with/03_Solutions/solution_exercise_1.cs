
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;
using UiPath.Platform.Diagnostics;
using UiPath.Platform.Workflow;
using UiPath.Robot.Activities.Design;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Runtime;

namespace LegacyAdapter
{
    // 1. Strongly-typed record for the invoice data
    public record InvoiceRecord(string InvoiceNumber, decimal Amount, DateTime DueDate);

    // 2. Service class handling TCP communication and parsing
    public class LegacySocketClient : IDisposable
    {
        private readonly TcpClient _client;
        private readonly ILogger<LegacySocketClient> _logger;
        private readonly AsyncRetryPolicy _retryPolicy;
        private const int BufferSize = 50; // Fixed width per record

        public LegacySocketClient(ILogger<LegacySocketClient> logger)
        {
            _client = new TcpClient();
            _logger = logger;
            
            // 6. Polly retry policy for connection resilience
            _retryPolicy = Policy
                .Handle<IOException>()
                .Or<SocketException>()
                .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                    onRetry: (exception, timeSpan, retryCount, context) =>
                    {
                        _logger.LogWarning(exception, "Retry {RetryCount} after {Delay}s due to connection issue.", retryCount, timeSpan.TotalSeconds);
                    });
        }

        // 4. Asynchronous data reading using Channels
        public async IAsyncEnumerable<InvoiceRecord> GetInvoicesAsync(string host, int port, CancellationToken ct)
        {
            await _retryPolicy.ExecuteAsync(async () => 
            {
                if (!_client.Connected)
                    await _client.ConnectAsync(host, port, ct);
            });

            var stream = _client.GetStream();
            var channel = Channel.CreateBounded<InvoiceRecord>(new BoundedChannelOptions(100) { SingleReader = true });

            // Producer task: Read raw bytes from socket
            var producer = Task.Run(async () =>
            {
                try
                {
                    // Simulate reading a stream of fixed-width records
                    // In a real scenario, this would read until the stream ends or cancellation
                    byte[] buffer = new byte[BufferSize];
                    while (!ct.IsCancellationRequested)
                    {
                        int bytesRead = await stream.ReadAsync(buffer, 0, BufferSize, ct);
                        if (bytesRead == 0) break;

                        // Parse using Span<T> (Zero-allocation parsing)
                        var record = ParseFixedWidth(buffer.AsSpan(0, bytesRead));
                        await channel.Writer.WriteAsync(record, ct);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error reading from socket.");
                }
                finally
                {
                    channel.Writer.Complete();
                }
            }, ct);

            // Consumer: Yield records from channel
            await foreach (var record in channel.Reader.ReadAllAsync(ct))
            {
                yield return record;
            }

            await producer;
        }

        // 5. High-performance parsing using Span<T>
        private InvoiceRecord ParseFixedWidth(ReadOnlySpan<byte> buffer)
        {
            // Encoding.ASCII is assumed for legacy mainframe data
            var text = Encoding.ASCII.GetString(buffer);

            // 0-10: InvoiceNumber, 11-25: Amount, 26-35: DueDate
            // Using Span<char> on the string to avoid substring allocations
            var span = text.AsSpan();
            
            string invoiceNumber = span.Slice(0, 10).ToString().Trim();
            string amountStr = span.Slice(10, 15).ToString().Trim();
            string dateStr = span.Slice(25, 10).ToString().Trim();

            if (!decimal.TryParse(amountStr, out decimal amount))
                amount = 0;
            
            if (!DateTime.TryParse(dateStr, out DateTime dueDate))
                dueDate = DateTime.MinValue;

            return new InvoiceRecord(invoiceNumber, amount, dueDate);
        }

        public void Dispose()
        {
            _client?.Dispose();
        }
    }

    // 3. & 6. UiPath Custom Activity Wrapper
    [DisplayName("Read Legacy Invoices")]
    [Description("Connects to a legacy TCP socket and returns a list of InvoiceRecords.")]
    public class ReadLegacyInvoicesActivity : AsyncCodeActivity<IEnumerable<InvoiceRecord>>
    {
        [RequiredArgument]
        [Description("Target Host IP")]
        public InArgument<string> Host { get; set; }

        [RequiredArgument]
        [Description("Target Port")]
        public InArgument<int> Port { get; set; }

        [Description("Timeout in seconds")]
        public InArgument<int> TimeoutSeconds { get; set; } = 30;

        protected override async Task<IEnumerable<InvoiceRecord>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            var logger = new UiPathLogger(); // Adapter for UiPath logging
            var host = Host.Get(context);
            var port = Port.Get(context);
            var timeout = TimeoutSeconds.Get(context);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeout));
            using var linkedToken = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, cts.Token);
            using var client = new LegacySocketClient(logger);

            var invoices = new List<InvoiceRecord>();
            
            // 6. Execution with timeout handling
            try
            {
                await foreach (var invoice in client.GetInvoicesAsync(host, port, linkedToken.Token))
                {
                    invoices.Add(invoice);
                    // In a real stream, we might limit how many we read per execution
                    if (invoices.Count >= 10) break; 
                }
            }
            catch (OperationCanceledException)
            {
                logger.LogError("Operation timed out or was cancelled.");
                throw new TimeoutException("Failed to read from legacy socket within the allotted time.");
            }

            return invoices;
        }
    }

    // Helper to bridge standard ILogger to UiPath logs
    public class UiPathLogger : ILogger<LegacySocketClient>
    {
        public IDisposable BeginScope<TState>(TState state) => null;
        public bool IsEnabled(LogLevel logLevel) => true;
        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            var msg = formatter(state, exception);
            if (logLevel >= LogLevel.Error)
                TraceSource.LogCritical(msg);
            else if (logLevel >= LogLevel.Warning)
                TraceSource.LogWarn(msg);
            else
                TraceSource.LogInfo(msg);
        }
    }
}
