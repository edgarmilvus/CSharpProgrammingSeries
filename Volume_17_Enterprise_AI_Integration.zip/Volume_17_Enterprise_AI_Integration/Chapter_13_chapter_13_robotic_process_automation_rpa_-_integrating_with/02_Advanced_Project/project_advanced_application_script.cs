
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace EnterpriseRPAIntegration
{
    // Real-world context: An insurance company receives thousands of claim forms daily.
    // Some arrive digitally (PDFs), others are scanned images (JPEGs).
    // The legacy system requires manual data entry into a CSV file for batch processing.
    // This application simulates an AI-enhanced RPA bot that:
    // 1. Monitors a folder for new documents (Input Simulation).
    // 2. Uses an LLM (simulated via API call) to extract structured data from unstructured text.
    // 3. Validates the extracted data against business rules.
    // 4. Writes the clean data to a legacy-compatible CSV file.
    // 5. Archives the processed document.

    class Program
    {
        // Configuration constants for the RPA Bot
        private const string InputDirectory = "./InputClaims";
        private const string ArchiveDirectory = "./ArchiveClaims";
        private const string OutputFilePath = "./LegacySystem_Batch.csv";
        private const string LlmApiEndpoint = "https://api.enterprise-llm.com/v1/extract"; // Placeholder

        static async Task Main(string[] args)
        {
            Console.WriteLine("Initializing Enterprise RPA Bot (AI-Enhanced)...");
            
            // Ensure directories exist
            Directory.CreateDirectory(InputDirectory);
            Directory.CreateDirectory(ArchiveDirectory);

            // Initialize the RPA Orchestrator
            var orchestrator = new RpaOrchestrator(InputDirectory, ArchiveDirectory, OutputFilePath, LlmApiEndpoint);
            
            // Start the automation loop
            await orchestrator.RunAutomationCycle();
        }
    }

    // Orchestrator class manages the workflow state and transitions
    public class RpaOrchestrator
    {
        private readonly string _inputDir;
        private readonly string _archiveDir;
        private readonly string _outputFile;
        private readonly string _llmEndpoint;
        private readonly HttpClient _httpClient;
        private readonly List<string> _processedFiles;

        public RpaOrchestrator(string inputDir, string archiveDir, string outputFile, string llmEndpoint)
        {
            _inputDir = inputDir;
            _archiveDir = archiveDir;
            _outputFile = outputFile;
            _llmEndpoint = llmEndpoint;
            _httpClient = new HttpClient();
            _processedFiles = new List<string>();
        }

        public async Task RunAutomationCycle()
        {
            Console.WriteLine("Scanning for new documents...");
            
            // 1. Monitor Input Directory
            string[] files = Directory.GetFiles(_inputDir);
            
            if (files.Length == 0)
            {
                Console.WriteLine("No new documents found. Waiting...");
                return;
            }

            Console.WriteLine($"Found {files.Length} documents to process.");

            // 2. Process each file sequentially (Simulating a bot queue)
            foreach (var filePath in files)
            {
                try
                {
                    await ProcessSingleDocument(filePath);
                }
                catch (Exception ex)
                {
                    // Error handling for RPA resilience
                    Console.WriteLine($"[Error] Failed to process {Path.GetFileName(filePath)}: {ex.Message}");
                    // In a real UiPath/PowerAutomate flow, this would trigger a 'Retry Scope' or 'Set Status' activity
                }
            }

            // 3. Finalize Batch
            if (_processedFiles.Count > 0)
            {
                Console.WriteLine($"Batch complete. {_processedFiles.Count} items processed.");
            }
        }

        private async Task ProcessSingleDocument(string filePath)
        {
            string fileName = Path.GetFileName(filePath);
            Console.WriteLine($"--> Processing: {fileName}");

            // Step A: Read Unstructured Data (OCR Simulation)
            // In a real scenario, this would be an OCR engine output or PDF text extraction.
            string rawText = SimulateOcrExtraction(filePath);

            // Step B: Intelligent Extraction via LLM
            // We send raw text to the LLM to get structured JSON data.
            var extractedData = await CallLlmForExtraction(rawText);
            
            if (extractedData == null)
            {
                Console.WriteLine("   [Warning] LLM failed to return valid data.");
                return;
            }

            // Step C: Business Logic Validation (Legacy Constraints)
            // The legacy system requires specific formats and non-empty fields.
            if (ValidateExtractedData(extractedData))
            {
                // Step D: Write to Legacy Output (CSV Format)
                AppendToLegacyCsv(extractedData);

                // Step E: Archive Processed Document
                ArchiveFile(filePath);

                _processedFiles.Add(fileName);
                Console.WriteLine($"   [Success] {fileName} archived and data exported.");
            }
            else
            {
                Console.WriteLine($"   [Validation Failed] Data for {fileName} did not meet legacy constraints.");
                // In a real bot, this would move the file to a 'Exception' folder for human review.
            }
        }

        // Simulates an external LLM API call
        private async Task<ClaimData> CallLlmForExtraction(string text)
        {
            // Simulate network delay
            await Task.Delay(200); 

            // In a real implementation, we would use HttpClient.PostAsync with JSON payload
            // var payload = new { text = text };
            // var response = await _httpClient.PostAsync(_llmEndpoint, new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json"));
            
            // SIMULATION: Parsing the text to find patterns (Mocking LLM capability)
            // An LLM would understand context like "Date:", "Amount:", etc., even if unstructured.
            var data = new ClaimData();
            
            // Heuristics to simulate LLM extraction for this demo
            if (text.Contains("Date:")) data.ClaimDate = ExtractValue(text, "Date:");
            if (text.Contains("Amount:")) data.Amount = ExtractValue(text, "Amount:");
            if (text.Contains("Policy:")) data.PolicyNumber = ExtractValue(text, "Policy:");
            if (text.Contains("Type:")) data.ClaimType = ExtractValue(text, "Type:");

            return data;
        }

        // Helper to simulate extracting values based on keywords
        private string ExtractValue(string text, string keyword)
        {
            int startIndex = text.IndexOf(keyword) + keyword.Length;
            if (startIndex < keyword.Length) return "";
            
            // Simple extraction logic
            string remaining = text.Substring(startIndex).Trim();
            int endIndex = remaining.IndexOf('\n');
            if (endIndex == -1) endIndex = remaining.Length;
            
            return remaining.Substring(0, endIndex).Trim();
        }

        // Simulates OCR output by reading file content
        private string SimulateOcrExtraction(string filePath)
        {
            // In reality, this calls Tesseract or Azure Form Recognizer
            return File.ReadAllText(filePath);
        }

        // Business Rule Validation
        private bool ValidateExtractedData(ClaimData data)
        {
            // Rule 1: Policy Number must be present and 6 chars long
            if (string.IsNullOrEmpty(data.PolicyNumber) || data.PolicyNumber.Length < 6) return false;

            // Rule 2: Amount must be a valid positive number
            if (!decimal.TryParse(data.Amount, out decimal amount) || amount <= 0) return false;

            // Rule 3: Date must be present
            if (string.IsNullOrEmpty(data.ClaimDate)) return false;

            return true;
        }

        // Writes to a CSV file compatible with legacy mainframes
        private void AppendToLegacyCsv(ClaimData data)
        {
            // Legacy systems often expect pipe-delimited or comma-delimited files without headers
            string csvLine = $"{data.PolicyNumber}|{data.ClaimDate}|{data.ClaimType}|{data.Amount}{Environment.NewLine}";
            
            // Append mode ensures we don't overwrite previous batch entries
            File.AppendAllText(_outputFile, csvLine);
        }

        // Moves file to archive to prevent reprocessing
        private void ArchiveFile(string sourcePath)
        {
            string fileName = Path.GetFileName(sourcePath);
            string destPath = Path.Combine(_archiveDir, fileName);
            
            // Ensure unique filename in archive to avoid overwrites
            if (File.Exists(destPath))
            {
                string uniqueDest = Path.Combine(_archiveDir, $"{Path.GetFileNameWithoutExtension(fileName)}_{Guid.NewGuid()}{Path.GetExtension(fileName)}");
                File.Move(sourcePath, uniqueDest);
            }
            else
            {
                File.Move(sourcePath, destPath);
            }
        }
    }

    // Data Transfer Object (DTO) for the Claim
    // Using a simple class instead of a Record (as per constraints)
    public class ClaimData
    {
        public string PolicyNumber { get; set; }
        public string ClaimDate { get; set; }
        public string Amount { get; set; }
        public string ClaimType { get; set; }
    }
}
