
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RpaLlmIntegrationDemo
{
    // Represents the data structure for an invoice extracted from a document.
    public class InvoiceData
    {
        public string InvoiceNumber { get; set; }
        public string VendorName { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsValid { get; set; }
        public List<string> ValidationErrors { get; set; } = new List<string>();
    }

    // Represents the response from the LLM API.
    public class LlmResponse
    {
        public string Content { get; set; }
    }

    // A mock service simulating an LLM (e.g., Azure OpenAI, GPT-4).
    // In a real scenario, this would make an HTTP request to an external API.
    public class MockLlmService
    {
        private readonly HttpClient _httpClient;

        public MockLlmService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> ExtractInvoiceDataAsync(string documentText)
        {
            // Simulate network latency
            await Task.Delay(100);

            // In a real implementation, this would be a structured prompt sent to the LLM
            // and the response would be parsed from JSON.
            // For this demo, we simulate a successful extraction.
            Console.WriteLine("LLM: Analyzing document text...");
            
            var simulatedResponse = new
            {
                InvoiceNumber = "INV-2023-001",
                VendorName = "Contoso Ltd.",
                TotalAmount = 1500.75m,
                DueDate = "2023-12-31",
                IsValid = true,
                ValidationErrors = new List<string>()
            };

            return JsonSerializer.Serialize(simulatedResponse);
        }
    }

    // Simulates the RPA Bot (e.g., UiPath Robot or Power Automate Desktop).
    // This class orchestrates the process: Read -> Extract -> Validate -> Act.
    public class RpaOrchestrator
    {
        private readonly MockLlmService _llmService;

        public RpaOrchestrator(MockLlmService llmService)
        {
            _llmService = llmService;
        }

        public async Task ProcessInvoiceDocumentAsync(string rawDocumentText)
        {
            // 1. Intake: Receive raw, unstructured data (e.g., from OCR or email body)
            Console.WriteLine($"RPA Bot: Received document with {rawDocumentText.Length} characters.");

            // 2. Intelligence: Pass data to LLM for semantic extraction
            string llmResultJson = await _llmService.ExtractInvoiceDataAsync(rawDocumentText);
            
            // 3. Parsing: Convert LLM string output into a strongly-typed object
            InvoiceData invoice = JsonSerializer.Deserialize<InvoiceData>(llmResultJson);

            // 4. Decision Making: Business logic validation
            ValidateInvoice(invoice);

            // 5. Action: Based on validation, trigger downstream RPA actions
            if (invoice.IsValid)
            {
                await SubmitToErpSystemAsync(invoice);
            }
            else
            {
                await FlagForManualReviewAsync(invoice);
            }
        }

        private void ValidateInvoice(InvoiceData invoice)
        {
            // Basic business rule validation
            if (invoice.TotalAmount <= 0)
            {
                invoice.IsValid = false;
                invoice.ValidationErrors.Add("Total amount must be greater than zero.");
            }

            if (invoice.DueDate < DateTime.Now)
            {
                invoice.IsValid = false;
                invoice.ValidationErrors.Add("Due date cannot be in the past.");
            }
        }

        private async Task SubmitToErpSystemAsync(InvoiceData invoice)
        {
            // Simulate API call to legacy ERP system
            Console.WriteLine($"RPA Bot: Submitting Invoice {invoice.InvoiceNumber} to ERP System...");
            await Task.Delay(200); // Simulate processing time
            Console.WriteLine($"RPA Bot: Success! Invoice {invoice.InvoiceNumber} posted.");
        }

        private async Task FlagForManualReviewAsync(InvoiceData invoice)
        {
            // Simulate creating a ticket in a helpdesk system
            Console.WriteLine($"RPA Bot: Validation failed for Invoice {invoice.InvoiceNumber}.");
            Console.WriteLine($"RPA Bot: Creating manual review ticket. Errors: {string.Join(", ", invoice.ValidationErrors)}");
            await Task.Delay(100);
        }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            // Setup dependencies
            var httpClient = new HttpClient();
            var llmService = new MockLlmService(httpClient);
            var orchestrator = new RpaOrchestrator(llmService);

            // Simulate a raw text input from an OCR engine or email parser
            string rawInvoiceText = @"
                INVOICE
                From: Contoso Ltd.
                Invoice #: INV-2023-001
                Total: $1,500.75
                Due Date: 12/31/2023
            ";

            // Execute the RPA workflow
            Console.WriteLine("--- Starting RPA Workflow ---");
            await orchestrator.ProcessInvoiceDocumentAsync(rawInvoiceText);
            Console.WriteLine("--- Workflow Completed ---");
        }
    }
}
