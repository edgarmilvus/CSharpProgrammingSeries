
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/... or
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.cs
# Description: Solution for Exercise 1
# ==========================================

using System;
using System.Collections.Generic;

namespace ChatSystem.Core
{
    // 1. Define the generic record using positional syntax or init properties
    public record ChatMessage<T>
    {
        public Guid Id { get; init; }
        public string Role { get; init; }
        public T Content { get; init; }
        public DateTime Timestamp { get; init; }
    }

    public class MessageProcessor
    {
        // 4. Challenge: Redaction logic
        public static ChatMessage<T> RedactContent<T>(ChatMessage<T> message, string redactionToken)
        {
            // Since records are immutable, we use the 'with' expression to create a copy
            // with modified properties.
            
            // We must handle the generic Content modification carefully. 
            // We check if T is string to perform the append operation.
            if (message.Content is string textContent)
            {
                // Cast the modified string back to T
                T newContent = (T)(object)$"{textContent} {redactionToken}";
                
                return message with 
                { 
                    Content = newContent,
                    // Usually, redaction might imply a new audit ID, but keeping ID same is also valid.
                    // Let's generate a new ID to signify a distinct event in the log.
                    Id = Guid.NewGuid() 
                };
            }

            // If T is not a string, we cannot append text. 
            // We return a shallow copy of the record (effectively a clone).
            return message with { };
        }
    }

    public class Exercise1Runner
    {
        public static void Run()
        {
            var msg = new ChatMessage<string>
            {
                Id = Guid.NewGuid(),
                Role = "User",
                Content = "My API key is 12345",
                Timestamp = DateTime.Now
            };

            var redacted = MessageProcessor.RedactContent(msg, "[REDACTED]");

            Console.WriteLine($"Original: {msg.Content}");
            Console.WriteLine($"Redacted: {redacted.Content}");
            
            // Verify Immutability
            Console.WriteLine($"Same Reference? {ReferenceEquals(msg, redacted)}"); // False
        }
    }
}
