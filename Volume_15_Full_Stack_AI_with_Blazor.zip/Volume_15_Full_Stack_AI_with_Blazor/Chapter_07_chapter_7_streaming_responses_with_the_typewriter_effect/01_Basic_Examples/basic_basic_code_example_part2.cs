
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.cs
// Description: Basic Code Example
// ==========================================

// Pages/Index.razor
@page "/"
@using Microsoft.AspNetCore.SignalR.Client
@implements IAsyncDisposable

<PageTitle>Typewriter Stream</PageTitle>

<h1>AI Typewriter Effect</h1>

<div class="card">
    <div class="card-body">
        <p>@displayedText</p>
    </div>
</div>

<button @onclick="StartStream" disabled="@_isStreaming">Start Streaming</button>

@code {
    private string displayedText = "";
    private bool _isStreaming = false;
    private HubConnection? hubConnection;
    
    // Mock Backend Service (Simulating the Server for this standalone example)
    [Inject] private NavigationManager Navigation { get; set; } = null!;

    protected override async Task OnInitializedAsync()
    {
        // NOTE: In a real scenario, you connect to a remote hub. 
        // Here, we simulate the server logic locally to make this code 
        // executable as a single file without a backend project.
        await ConnectAndMockServer();
    }

    private async Task StartStream()
    {
        if (_isStreaming) return;
        
        _isStreaming = true;
        displayedText = ""; // Clear previous text
        
        // In a real app, we would invoke the server:
        // await hubConnection.InvokeAsync("SendMessage");
        
        // For this standalone demo, we trigger the local mock method:
        await SimulateServerStreamingResponse();
    }

    // --- SIMULATION LOGIC (To make the example self-contained) ---
    // In a real app, this logic resides on the Server.
    private async Task SimulateServerStreamingResponse()
    {
        var message = "Hello! This is a real-time streamed response from the AI.";
        
        foreach (var character in message)
        {
            // Simulate network latency
            await Task.Delay(50); 
            
            // Send the character to the client (simulating SignalR server push)
            // In a real app, this is: await Clients.All.SendAsync("ReceiveMessage", character.ToString());
            await ReceiveStream(character.ToString());
        }
        
        _isStreaming = false;
        StateHasChanged();
    }

    // --- CLIENT LOGIC ---
    // This method acts as the SignalR client receiver
    private async Task ReceiveStream(string character)
    {
        // Append the new character to the display
        displayedText += character;
        
        // Notify Blazor to re-render the UI
        await InvokeAsync(StateHasChanged);
    }

    // Mocking the connection setup for the standalone example
    private async Task ConnectAndMockServer()
    {
        // In a real app, you would start the connection here:
        // await hubConnection.StartAsync();
        
        // For this demo, we are just ensuring the component is ready.
        // The "Mock" server logic is triggered by the button click.
        await Task.CompletedTask;
    }

    public async ValueTask DisposeAsync()
    {
        if (hubConnection is not null)
        {
            await hubConnection.DisposeAsync();
        }
    }
}
