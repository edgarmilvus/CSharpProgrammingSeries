
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// 1. The Service (Singleton)
using System.Threading.Channels;

public class StreamBufferService
{
    private readonly Channel<string> _channel;
    private int _bufferSize = 5; // Default buffer size

    public StreamBufferService()
    {
        // Create an unbounded channel to handle high throughput without blocking the producer
        _channel = Channel.CreateUnbounded<string>();
    }

    public ChannelReader<string> Reader => _channel.Reader;
    public ChannelWriter<string> Writer => _channel.Writer;

    // Dynamic buffer size property
    public int BufferSize
    {
        get => _bufferSize;
        set => _bufferSize = Math.Clamp(value, 1, 20);
    }
}

// 2. Component Implementation (StreamingChat.razor - Updated)
@page "/streaming-chat-buffered"
@using Microsoft.AspNetCore.SignalR.Client
@inject NavigationManager Navigation
@inject StreamBufferService BufferService
@implements IAsyncDisposable

<h3>Buffered Streaming (Debounced)</h3>

<!-- Interactive Challenge: UI Slider for Buffer Size -->
<div class="mb-3">
    <label>Buffer Size: @BufferService.BufferSize</label>
    <input type="range" min="1" max="20" @bind="BufferService.BufferSize" @bind:after="OnBufferSizeChanged" />
</div>

<div class="border p-3" style="min-height: 200px; font-family: monospace;">
    @displayText
</div>

@code {
    private string displayText = "";
    private HubConnection? hubConnection;
    private CancellationTokenSource? cts;
    private bool isStreaming = false;

    protected override async Task OnInitializedAsync()
    {
        hubConnection = new HubConnectionBuilder()
            .WithUrl(Navigation.ToAbsoluteUri("/aiHub"))
            .Build();

        await hubConnection.StartAsync();
    }

    private async Task StartBufferedStream()
    {
        if (isStreaming) return;
        isStreaming = true;
        cts = new CancellationTokenSource();
        
        // Start the background consumer task
        _ = ConsumeBufferAsync(cts.Token);

        // Start the producer (SignalR stream)
        // Note: We write to the BufferService.Writer here
        _ = Task.Run(async () =>
        {
            try
            {
                float temp = 0.5f;
                await foreach (var token in hubConnection!.StreamAsync<string>("StreamResponse", "Buffered Prompt", temp, cts.Token))
                {
                    // Write to the channel (non-blocking)
                    await BufferService.Writer.WriteAsync(token, cts.Token);
                }
                // Signal end of stream
                BufferService.Writer.Complete();
            }
            catch (Exception ex)
            {
                BufferService.Writer.Complete(ex);
            }
        }, cts.Token);
    }

    private async Task ConsumeBufferAsync(CancellationToken token)
    {
        var buffer = new List<string>();
        
        // Read from the channel
        await foreach (var tokenItem in BufferService.Reader.ReadAllAsync(token))
        {
            buffer.Add(tokenItem);

            // Flush if buffer size reached
            if (buffer.Count >= BufferService.BufferSize)
            {
                AppendAndRender(buffer);
                buffer.Clear();
            }
        }

        // Flush remaining items if stream ended
        if (buffer.Count > 0)
        {
            AppendAndRender(buffer);
        }
        
        isStreaming = false;
    }

    private void AppendAndRender(List<string> tokens)
    {
        // Batch append
        foreach(var t in tokens)
        {
            displayText += t;
        }
        // Single render call per batch
        InvokeAsync(StateHasChanged);
    }

    private void OnBufferSizeChanged()
    {
        // Visual feedback or logic trigger if needed
        // The service property is already updated
    }

    public async ValueTask DisposeAsync()
    {
        cts?.Cancel();
        cts?.Dispose();
        if (hubConnection is not null) await hubConnection.DisposeAsync();
    }
}
