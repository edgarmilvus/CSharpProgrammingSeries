
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Microsoft.AspNetCore.SignalR;
using System.Runtime.CompilerServices;

namespace StreamingApp.Hubs
{
    public class AiResponseHub : Hub
    {
        // Interactive Challenge: Modified to accept Temperature parameter
        public async IAsyncEnumerable<string> StreamResponse(
            string prompt, 
            float temperature, 
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            // Simulation parameters based on temperature
            // Higher temp = faster delay (lower ms) and more erratic token count
            int baseDelay = (int)(200 - (temperature * 150)); // 50ms to 200ms
            int tokenCount = 10 + (int)(temperature * 20); // 10 to 30 tokens

            // Simulate processing delay
            await Task.Delay(500, cancellationToken);

            // Define a vocabulary for simulation
            string[] vocabulary = { "The", "quick", "brown", "fox", "jumps", "over", "the", "lazy", "dog.", 
                                    "However,", "in", "contrast,", "streaming", "responses", "are", "superior.", 
                                    "Specifically,", "C#", "and", "SignalR", "enable", "real-time", "communication." };

            Random rnd = new Random();

            for (int i = 0; i < tokenCount; i++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                // Simulate variable delay (jitter) based on temperature
                int jitter = (int)(rnd.NextDouble() * (temperature * 50));
                await Task.Delay(baseDelay + jitter, cancellationToken);

                // Pick a random word
                string token = vocabulary[rnd.Next(vocabulary.Length)];

                // Add space if not punctuation (simple simulation)
                if (!token.EndsWith('.') && !token.EndsWith(','))
                    token += " ";

                yield return token;
            }
        }
    }
}
