
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HybridAIOrchestrator
{
    // PROBLEM CONTEXT:
    // A healthcare application processes patient notes. Some notes contain sensitive PII (Personally Identifiable Information).
    // Compliance requires that PII processing happens locally (On-Device/Edge) to ensure privacy.
    // General medical terminology extraction can happen via Cloud AI for higher accuracy.
    // The application must route requests dynamically based on content sensitivity.

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("--- Hybrid AI Router System Initializing ---");

            // Initialize the two inference providers
            IInferenceProvider localProvider = new LocalOnnxProvider();
            IInferenceProvider cloudProvider = new AzureOpenAIProvider();

            // Initialize the Router with a sensitivity threshold
            var router = new AIRouter(localProvider, cloudProvider, sensitivityThreshold: 0.5);

            // Simulate a stream of incoming patient notes
            string[] incomingNotes = new string[]
            {
                "Patient John Doe (SSN: 123-45-6789) reports mild headache.",
                "General checkup: Patient reports feeling well.",
                "Emergency: Patient Jane Smith (ID: 998877) admitted with severe chest pain.",
                "Routine blood work results are normal."
            };

            // Process each note through the hybrid router
            foreach (var note in incomingNotes)
            {
                Console.WriteLine($"\nProcessing Note: \"{note}\"");
                
                // The router decides where to send the data
                string result = await router.ProcessRequestAsync(note);
                
                Console.WriteLine($"Result: {result}");
            }

            Console.WriteLine("\n--- Batch Processing Complete ---");
        }
    }

    // ---------------------------------------------------------
    // 1. Interface Definition (Abstraction)
    // ---------------------------------------------------------
    // Defines the contract that both Local and Cloud providers must follow.
    // This allows the Router to switch providers without changing its logic.
    public interface IInferenceProvider
    {
        Task<string> AnalyzeTextAsync(string text);
    }

    // ---------------------------------------------------------
    // 2. Local Provider (Edge/Onnx Simulation)
    // ---------------------------------------------------------
    // Simulates a lightweight, privacy-focused model running in the browser/WASM.
    // In a real scenario, this would wrap ONNX Runtime or TensorFlow.js.
    public class LocalOnnxProvider : IInferenceProvider
    {
        public async Task<string> AnalyzeTextAsync(string text)
        {
            // Simulate network latency for local processing (usually faster)
            await Task.Delay(100); 
            
            // Logic: Check for PII patterns (simulated)
            bool hasPii = text.Contains("SSN") || text.Contains("ID:");
            
            if (hasPii)
            {
                return "[Local/Onnx] PII Detected. Data processed securely on device. Masked output generated.";
            }
            
            return "[Local/Onnx] Text analyzed. No sensitive data found.";
        }
    }

    // ---------------------------------------------------------
    // 3. Cloud Provider (Azure OpenAI Simulation)
    // ---------------------------------------------------------
    // Simulates a high-capacity cloud inference endpoint.
    // Used for complex tasks that require heavy computation or broader context.
    public class AzureOpenAIProvider : IInferenceProvider
    {
        public async Task<string> AnalyzeTextAsync(string text)
        {
            // Simulate network latency for cloud processing (higher latency)
            await Task.Delay(500); 
            
            // Logic: Complex medical terminology extraction (simulated)
            bool isComplex = text.Contains("chest pain") || text.Contains("emergency");
            
            if (isComplex)
            {
                return "[Cloud/Azure] Complex medical terminology extracted. Diagnosis code suggested.";
            }

            return "[Cloud/Azure] Text analyzed using standard model.";
        }
    }

    // ---------------------------------------------------------
    // 4. Semantic Cache (Optimization Layer)
    // ---------------------------------------------------------
    // Stores previous results to avoid redundant API calls (Cost/Performance optimization).
    // Uses a simple Dictionary for storage.
    public class SemanticCache
    {
        private Dictionary<string, string> _cache = new Dictionary<string, string>();

        public bool TryGet(string text, out string result)
        {
            // In a real app, this would use vector similarity, not exact string matching.
            // For this chapter's scope, we use exact matching for simplicity.
            return _cache.TryGetValue(text, out result);
        }

        public void Store(string text, string result)
        {
            if (!_cache.ContainsKey(text))
            {
                _cache.Add(text, result);
            }
        }
    }

    // ---------------------------------------------------------
    // 5. The Hybrid Router (Core Logic)
    // ---------------------------------------------------------
    // Orchestrates traffic between Local and Cloud based on rules.
    public class AIRouter
    {
        private readonly IInferenceProvider _localProvider;
        private readonly IInferenceProvider _cloudProvider;
        private readonly double _sensitivityThreshold;
        private readonly SemanticCache _cache;

        public AIRouter(IInferenceProvider local, IInferenceProvider cloud, double sensitivityThreshold)
        {
            _localProvider = local;
            _cloudProvider = cloud;
            _sensitivityThreshold = sensitivityThreshold;
            _cache = new SemanticCache();
        }

        // The "Brain" of the application
        public async Task<string> ProcessRequestAsync(string input)
        {
            // 1. Check Cache first (Performance Optimization)
            if (_cache.TryGet(input, out string cachedResult))
            {
                return $"[Cache Hit] {cachedResult}";
            }

            // 2. Analyze Input for Sensitivity (Metadata Analysis)
            // In a real app, this might be a lightweight local model or regex scanner.
            double sensitivityScore = CalculateSensitivityScore(input);

            string finalResult;

            // 3. Routing Logic (The Hybrid Decision)
            if (sensitivityScore > _sensitivityThreshold)
            {
                // High Sensitivity: Route to Local/Edge for Privacy
                Console.WriteLine($"  > Routing to LOCAL (Score: {sensitivityScore})");
                finalResult = await _localProvider.AnalyzeTextAsync(input);
            }
            else
            {
                // Low Sensitivity: Route to Cloud for Power/Cost-efficiency (if local is expensive)
                Console.WriteLine($"  > Routing to CLOUD (Score: {sensitivityScore})");
                finalResult = await _cloudProvider.AnalyzeTextAsync(input);
            }

            // 4. Store in Cache
            _cache.Store(input, finalResult);

            return finalResult;
        }

        // Simple heuristic for scoring sensitivity
        private double CalculateSensitivityScore(string text)
        {
            int sensitiveKeywords = 0;
            
            // Basic keyword scanning (looping through array)
            string[] piiKeywords = { "SSN", "ID:", "Name:", "Address", "Emergency" };
            
            foreach (var keyword in piiKeywords)
            {
                if (text.Contains(keyword))
                {
                    sensitiveKeywords++;
                }
            }

            // Normalize score between 0.0 and 1.0
            double score = (double)sensitiveKeywords / piiKeywords.Length;
            
            return score;
        }
    }
}
