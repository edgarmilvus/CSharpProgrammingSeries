
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;

public class InferenceFunction
{
    private readonly ICacheService _cache;
    private readonly IOpenAIService _openAIService;

    public InferenceFunction(ICacheService cache, IOpenAIService openAIService)
    {
        _cache = cache;
        _openAIService = openAIService;
    }

    [Function("Inference")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
    {
        // 1. Parse Request
        var request = await req.ReadFromJsonAsync<InferenceRequest>();
        
        // 2. Semantic Cache Check
        var cachedResult = await _cache.GetAsync(request.Prompt);
        if (cachedResult != null)
        {
            return CreateResponse(req, new InferenceResponse(cachedResult, "Cache"));
        }

        // 3. Route to AI
        // In a real app, we might check UseLocalFallback to run ONNX inside the Function
        // (e.g., using Azure Container Apps or ACI with GPU), but here we assume Cloud.
        string result = await _openAIService.GenerateAsync(request.Prompt);

        // 4. Store in Cache
        await _cache.SetAsync(request.Prompt, result);

        // 5. Return
        return CreateResponse(req, new InferenceResponse(result, "Azure OpenAI"));
    }

    private HttpResponseData CreateResponse(HttpRequestData req, InferenceResponse response)
    {
        var res = req.CreateResponse(HttpStatusCode.OK);
        res.WriteAsJsonAsync(response);
        return res;
    }
}
