
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

// 1. Define Request and Response models
public class AIRequest
{
    public string Prompt { get; set; }
    public bool IsSensitive { get; set; }
    public int ComplexityScore { get; set; }
}

public class AIResponse
{
    public string Result { get; set; }
    public string ProviderUsed { get; set; }
}

// 2. Define Provider Interface
public interface IInferenceProvider
{
    Task<AIResponse> ProcessAsync(AIRequest request);
}

// 3. Define Orchestrator Interface
public interface IAIOrchestrator
{
    Task<AIResponse> RouteRequestAsync(AIRequest request);
}

// 4. Implement Local Provider
public class LocalOnnxProvider : IInferenceProvider
{
    public async Task<AIResponse> ProcessAsync(AIRequest request)
    {
        // Simulate async processing
        await Task.Delay(50); 
        return new AIResponse 
        { 
            Result = $"Local processing complete for: {request.Prompt}", 
            ProviderUsed = "Local ONNX" 
        };
    }
}

// 5. Implement Cloud Provider
public class CloudOpenAiProvider : IInferenceProvider
{
    public async Task<AIResponse> ProcessAsync(AIRequest request)
    {
        // Simulate async processing
        await Task.Delay(100);
        return new AIResponse 
        { 
            Result = $"Cloud processing complete for: {request.Prompt}", 
            ProviderUsed = "Azure OpenAI" 
        };
    }
}

// 6. Implement the Hybrid Orchestrator
public class HybridAIOrchestrator : IAIOrchestrator
{
    private readonly IInferenceProvider _localProvider;
    private readonly IInferenceProvider _cloudProvider;

    // Injecting specific implementations via constructor
    public HybridAIOrchestrator(LocalOnnxProvider localProvider, CloudOpenAiProvider cloudProvider)
    {
        _localProvider = localProvider;
        _cloudProvider = cloudProvider;
    }

    public async Task<AIResponse> RouteRequestAsync(AIRequest request)
    {
        // Routing Logic
        if (request.IsSensitive)
        {
            // Rule 1: Sensitive data stays local
            return await _localProvider.ProcessAsync(request);
        }

        if (request.ComplexityScore > 7)
        {
            // Rule 2: High complexity goes to cloud
            return await _cloudProvider.ProcessAsync(request);
        }

        // Default: Local processing
        return await _localProvider.ProcessAsync(request);
    }
}

// 7. Service Registration (Simulating Program.cs)
public static class ServiceConfiguration
{
    public static IServiceCollection AddHybridAI(this IServiceCollection services)
    {
        // Register providers as distinct types
        services.AddSingleton<LocalOnnxProvider>();
        services.AddSingleton<CloudOpenAiProvider>();

        // Register the orchestrator
        services.AddSingleton<IAIOrchestrator, HybridAIOrchestrator>();

        return services;
    }
}

// 8. Usage Example
public class Program
{
    public static async Task Main()
    {
        var services = new ServiceCollection();
        services.AddHybridAI();
        var serviceProvider = services.BuildServiceProvider();

        var orchestrator = serviceProvider.GetRequiredService<IAIOrchestrator>();

        // Test Case 1: Sensitive Data -> Local
        var sensitiveRequest = new AIRequest { Prompt = "User SSN", IsSensitive = true, ComplexityScore = 5 };
        var response1 = await orchestrator.RouteRequestAsync(sensitiveRequest);
        Console.WriteLine($"Route: {response1.ProviderUsed}"); // Expected: Local ONNX

        // Test Case 2: High Complexity -> Cloud
        var complexRequest = new AIRequest { Prompt = "Quantum Physics", IsSensitive = false, ComplexityScore = 9 };
        var response2 = await orchestrator.RouteRequestAsync(complexRequest);
        Console.WriteLine($"Route: {response2.ProviderUsed}"); // Expected: Azure OpenAI

        // Test Case 3: Standard -> Local
        var standardRequest = new AIRequest { Prompt = "Hello", IsSensitive = false, ComplexityScore = 2 };
        var response3 = await orchestrator.RouteRequestAsync(standardRequest);
        Console.WriteLine($"Route: {response3.ProviderUsed}"); // Expected: Local ONNX
    }
}
