
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public interface IEmbeddingGenerator
{
    float[] GetEmbedding(string text);
}

public class MockEmbeddingGenerator : IEmbeddingGenerator
{
    // Deterministic mock: Generates a vector based on string length and sum of chars.
    // This ensures "How do I reset?" and "Steps to recover" might have similar vectors 
    // if we implemented a real hash, but here we simulate fixed vectors for testing.
    public float[] GetEmbedding(string text)
    {
        // In a real scenario, this calls an ONNX model.
        // For this exercise, we return a pseudo-random but deterministic vector.
        var seed = text.Sum(c => (int)c);
        var random = new Random(seed);
        
        var vector = new float[5]; // 5-dimensional vector for simplicity
        for (int i = 0; i < 5; i++)
        {
            vector[i] = (float)random.NextDouble();
        }
        return vector;
    }
}

public class SemanticCache
{
    private readonly List<(float[] Vector, string Response)> _cache = new();
    private readonly IEmbeddingGenerator _embeddingGenerator;

    public SemanticCache(IEmbeddingGenerator embeddingGenerator)
    {
        _embeddingGenerator = embeddingGenerator;
    }

    public void Store(string prompt, string response)
    {
        var vector = _embeddingGenerator.GetEmbedding(prompt);
        _cache.Add((vector, response));
    }

    public async Task<(bool found, string response)> TryGetCachedAsync(string prompt, float threshold)
    {
        if (!_cache.Any()) return (false, null);

        // Generate embedding for the incoming prompt
        var inputVector = await Task.FromResult(_embeddingGenerator.GetEmbedding(prompt));

        foreach (var (storedVector, storedResponse) in _cache)
        {
            var similarity = CosineSimilarity(inputVector, storedVector);
            
            // Check if similarity meets the threshold
            if (similarity >= threshold)
            {
                return (true, storedResponse);
            }
        }

        return (false, null);
    }

    // Helper method to calculate Cosine Similarity
    private float CosineSimilarity(float[] vectorA, float[] vectorB)
    {
        if (vectorA.Length != vectorB.Length)
            throw new ArgumentException("Vectors must be of the same dimension");

        float dotProduct = 0.0f;
        float magnitudeA = 0.0f;
        float magnitudeB = 0.0f;

        for (int i = 0; i < vectorA.Length; i++)
        {
            dotProduct += vectorA[i] * vectorB[i];
            magnitudeA += vectorA[i] * vectorA[i];
            magnitudeB += vectorB[i] * vectorB[i];
        }

        magnitudeA = (float)Math.Sqrt(magnitudeA);
        magnitudeB = (float)Math.Sqrt(magnitudeB);

        if (magnitudeA == 0 || magnitudeB == 0) return 0;

        return dotProduct / (magnitudeA * magnitudeB);
    }
}

// Usage Simulation
public class CacheDemo 
{
    public static async Task Run()
    {
        var generator = new MockEmbeddingGenerator();
        var cache = new SemanticCache(generator);

        // 1. Store a response
        cache.Store("How do I reset my password?", "Go to settings > security > reset.");

        // 2. Try to retrieve exact match (deterministic mock will return same vector)
        var (found, response) = await cache.TryGetCachedAsync("How do I reset my password?", 0.95f);
        Console.WriteLine($"Found: {found}, Response: {response}");

        // 3. Try similar query (MockEmbeddingGenerator uses sum of chars, 
        // so "How do I reset my password?" and "How do I reset my account?" 
        // will have slightly different vectors, testing the logic).
        var (foundSim, responseSim) = await cache.TryGetCachedAsync("How do I reset my account?", 0.95f);
        Console.WriteLine($"Found Similar: {foundSim}"); // Likely false with strict threshold
    }
}
