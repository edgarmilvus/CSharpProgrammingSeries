
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Collections.ObjectModel;
using System.Threading.Tasks;

public class ChatMessage
{
    public string Text { get; set; }
    public bool IsUser { get; set; }
}

public class ChatStateContainer
{
    private readonly IAIOrchestrator _orchestrator;
    private readonly SemanticCache _cache;

    // ObservableCollection automatically notifies UI of changes
    public ObservableCollection<ChatMessage> Messages { get; } = new();

    public ChatStateContainer(IAIOrchestrator orchestrator, SemanticCache cache)
    {
        _orchestrator = orchestrator;
        _cache = cache;
    }

    public async Task SendMessageAsync(string userText)
    {
        // 1. Add User Message
        Messages.Add(new ChatMessage { Text = userText, IsUser = true });

        // 2. Check Cache
        var (isCached, cachedResponse) = await _cache.TryGetCachedAsync(userText, threshold: 0.95f);

        if (isCached)
        {
            Messages.Add(new ChatMessage { Text = cachedResponse, IsUser = false });
            return;
        }

        // 3. Route via Orchestrator
        var request = new AIRequest 
        { 
            Prompt = userText, 
            IsSensitive = false, // Simplified for this example
            ComplexityScore = 5 
        };

        var response = await _orchestrator.RouteRequestAsync(request);

        // 4. Store in Cache
        _cache.Store(userText, response.Result);

        // 5. Update UI
        Messages.Add(new ChatMessage { Text = response.Result, IsUser = false });
    }
}
