
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System;
using System.Threading.Tasks;

public enum DeploymentProfile { Local, Staging, Production }

public class DeploymentConfig
{
    public DeploymentProfile Profile { get; set; }
}

public interface ISecretManager
{
    Task<string> GetApiKeyAsync();
}

// Simulates retrieving a key from Browser LocalStorage or an Auth Token
public class LocalStorageSecretManager : ISecretManager
{
    public Task<string> GetApiKeyAsync()
    {
        // In a real WASM app: await JSRuntime.InvokeAsync<string>("localStorage.getItem", "apiKey");
        // Here, we simulate a retrieved key.
        return Task.FromResult("sk-proj-123456-retrieved-from-storage");
    }
}

public class ConfigAwareOrchestrator
{
    private readonly DeploymentConfig _config;
    private readonly ISecretManager _secretManager;
    private readonly LocalOnnxProvider _localProvider;
    private readonly CloudOpenAiProvider _cloudProvider;

    public ConfigAwareOrchestrator(
        DeploymentConfig config, 
        ISecretManager secretManager,
        LocalOnnxProvider localProvider,
        CloudOpenAiProvider cloudProvider)
    {
        _config = config;
        _secretManager = secretManager;
        _localProvider = localProvider;
        _cloudProvider = cloudProvider;
    }

    public async Task<AIResponse> RouteRequestAsync(AIRequest request)
    {
        // Production Logic: Bypass local entirely
        if (_config.Profile == DeploymentProfile.Production)
        {
            // Even if IsSensitive is true, in Production we might route via a secure backend
            // or enforce a different policy. Here, we simulate forcing cloud usage.
            // We can also check if we have a valid key.
            var apiKey = await _secretManager.GetApiKeyAsync();
            if (string.IsNullOrEmpty(apiKey))
            {
                return new AIResponse { Result = "Error: No API Key found in Production.", ProviderUsed = "None" };
            }
            
            return await _cloudProvider.ProcessAsync(request);
        }

        // Local/Staging Logic: Use standard hybrid routing
        // (Reusing logic from Exercise 1)
        if (request.IsSensitive)
        {
            return await _localProvider.ProcessAsync(request);
        }
        
        if (request.ComplexityScore > 7)
        {
            return await _cloudProvider.ProcessAsync(request);
        }

        return await _localProvider.ProcessAsync(request);
    }
}

// Test Simulation
public class ConfigTest
{
    public static async Task Run()
    {
        var localProvider = new LocalOnnxProvider();
        var cloudProvider = new CloudOpenAiProvider();
        var secretManager = new LocalStorageSecretManager();

        // Scenario 1: Local Profile
        var localConfig = new DeploymentConfig { Profile = DeploymentProfile.Local };
        var localOrchestrator = new ConfigAwareOrchestrator(localConfig, secretManager, localProvider, cloudProvider);
        
        var req1 = new AIRequest { Prompt = "Test", IsSensitive = false, ComplexityScore = 2 };
        var res1 = await localOrchestrator.RouteRequestAsync(req1);
        Console.WriteLine($"Local Profile Result: {res1.ProviderUsed}"); // Expected: Local ONNX

        // Scenario 2: Production Profile
        var prodConfig = new DeploymentConfig { Profile = DeploymentProfile.Production };
        var prodOrchestrator = new ConfigAwareOrchestrator(prodConfig, secretManager, localProvider, cloudProvider);

        var req2 = new AIRequest { Prompt = "Test", IsSensitive = true, ComplexityScore = 2 }; // Even sensitive
        var res2 = await prodOrchestrator.RouteRequestAsync(req2);
        Console.WriteLine($"Production Profile Result: {res2.ProviderUsed}"); // Expected: Azure OpenAI
    }
}
