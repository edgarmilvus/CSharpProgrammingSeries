
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System;
using System.Threading.Tasks;

namespace HybridBlazorApp
{
    // 1. Define the input request. 
    // Using a 'record' provides immutability and value-based equality, perfect for data transfer.
    public record InferenceRequest(string Prompt, ComplexityLevel Complexity);

    // 2. Define the complexity levels. 
    // Using an enum ensures type safety over using raw strings or integers.
    public enum ComplexityLevel
    {
        Low,    // e.g., classification, simple retrieval
        High    // e.g., summarization, generation
    }

    // 3. Define the unified response structure.
    public record InferenceResponse(string Answer, string ProviderUsed);

    // 4. The Core Router Logic.
    // This service encapsulates the decision-making strategy.
    public class HybridInferenceRouter
    {
        // Dependency injection placeholders (simulated for this standalone example)
        private readonly ILocalAiProvider _localProvider;
        private readonly ICloudAiProvider _cloudProvider;

        public HybridInferenceRouter(ILocalAiProvider local, ICloudAiProvider cloud)
        {
            _localProvider = local;
            _cloudProvider = cloud;
        }

        // The routing logic using a modern switch expression.
        public async Task<InferenceResponse> RouteRequestAsync(InferenceRequest request)
        {
            // Strategy: Route based on complexity.
            // In a real Blazor app, this could also consider network status or privacy flags.
            return request.Complexity switch
            {
                ComplexityLevel.Low => await _localProvider.QueryAsync(request),
                ComplexityLevel.High => await _cloudProvider.QueryAsync(request),
                _ => throw new InvalidOperationException("Unknown complexity level.")
            };
        }
    }

    // 5. Abstractions for Providers.
    // This allows us to swap implementations without changing the Router.
    public interface ILocalAiProvider
    {
        Task<InferenceResponse> QueryAsync(InferenceRequest request);
    }

    public interface ICloudAiProvider
    {
        Task<InferenceResponse> QueryAsync(InferenceRequest request);
    }

    // 6. Implementation: Local Browser AI (Simulated ONNX)
    // In a real scenario, this would wrap ONNX Runtime or TensorFlow.NET.
    public class SimulatedOnnxProvider : ILocalAiProvider
    {
        public async Task<InferenceResponse> QueryAsync(InferenceRequest request)
        {
            // Simulate local inference latency (usually very fast, 10-50ms)
            await Task.Delay(50); 
            
            // Simulate a deterministic, rule-based response (typical of small models)
            return new InferenceResponse(
                Answer: $"[Local Model] Analysis: '{request.Prompt}' is a standard item.",
                ProviderUsed: "Local ONNX (Browser)"
            );
        }
    }

    // 7. Implementation: Cloud AI (Simulated Azure OpenAI)
    // In a real scenario, this would use HttpClient to call the Azure OpenAI REST API.
    public class SimulatedAzureOpenAiProvider : ICloudAiProvider
    {
        public async Task<InferenceResponse> QueryAsync(InferenceRequest request)
        {
            // Simulate network latency (usually 500ms - 2000ms)
            await Task.Delay(1000); 
            
            // Simulate a creative, generative response
            return new InferenceResponse(
                Answer: $"[Cloud Model] Creative Generation: Here is a summary of '{request.Prompt}'...",
                ProviderUsed: "Azure OpenAI (Cloud)"
            );
        }
    }

    // 8. Main Program Execution (Entry Point)
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("--- Hybrid AI Router Demo ---\n");

            // Initialize dependencies (In Blazor, this happens in Program.cs via DI)
            var localProvider = new SimulatedOnnxProvider();
            var cloudProvider = new SimulatedAzureOpenAiProvider();
            var router = new HybridInferenceRouter(localProvider, cloudProvider);

            // Scenario A: Low Complexity (Privacy Critical)
            // User asks to categorize an item. Fast, no data sent to cloud.
            var simpleRequest = new InferenceRequest("Identify category: Wireless Mouse", ComplexityLevel.Low);
            Console.WriteLine($"Request: '{simpleRequest.Prompt}' (Complexity: {simpleRequest.Complexity})");
            
            var responseA = await router.RouteRequestAsync(simpleRequest);
            Console.WriteLine($"Response: {responseA.Answer}");
            Console.WriteLine($"Provider: {responseA.ProviderUsed}\n");

            // Scenario B: High Complexity (Creative Task)
            // User asks to write a description. Requires heavy LLM.
            var complexRequest = new InferenceRequest("Write a poem about a wireless mouse", ComplexityLevel.High);
            Console.WriteLine($"Request: '{complexRequest.Prompt}' (Complexity: {complexRequest.Complexity})");

            var responseB = await router.RouteRequestAsync(complexRequest);
            Console.WriteLine($"Response: {responseB.Answer}");
            Console.WriteLine($"Provider: {responseB.ProviderUsed}");
        }
    }
}
