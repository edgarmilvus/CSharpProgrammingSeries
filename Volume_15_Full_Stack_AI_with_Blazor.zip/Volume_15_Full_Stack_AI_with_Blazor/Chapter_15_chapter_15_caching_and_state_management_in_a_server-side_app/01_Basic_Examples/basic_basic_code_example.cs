
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/copilot-chat"
@using Microsoft.Extensions.Caching.Distributed
@using System.Text.Json
@inject IDistributedCache Cache

<h3>AI Copilot Chat (State Persisted in Redis)</h3>

<div style="border: 1px solid #ccc; padding: 10px; height: 300px; overflow-y: auto; margin-bottom: 10px;">
    @foreach (var msg in conversationHistory)
    {
        <div><strong>@msg.Role:</strong> @msg.Content</div>
    }
</div>

<div style="display: flex; gap: 10px;">
    <input @bind="userInput" placeholder="Ask the AI..." style="flex-grow: 1;" />
    <button @onclick="SendMessageAsync">Send</button>
    <button @onclick="ClearCacheAsync" style="background-color: #ffcccc;">Reset State</button>
</div>

@code {
    // 1. State definition
    private string? userInput;
    private List<ChatMessage> conversationHistory = new();

    // 2. Unique key for this user's cache entry
    // In a real app, this would be derived from the user's authentication context
    private string CacheKey => $"chat_session:{NavigationManager.Uri}"; 

    [Inject] private NavigationManager NavigationManager { get; set; } = null!;

    // 3. Load state from Redis when the component initializes
    protected override async Task OnInitializedAsync()
    {
        await LoadStateFromCacheAsync();
    }

    // 4. Business logic: Add message and persist
    private async Task SendMessageAsync()
    {
        if (string.IsNullOrWhiteSpace(userInput)) return;

        // Add user message
        conversationHistory.Add(new ChatMessage("User", userInput));
        
        // Simulate AI response
        conversationHistory.Add(new ChatMessage("AI", $"Echoing: {userInput}"));

        userInput = string.Empty;

        // Persist the updated list to Redis
        await SaveStateToCacheAsync();
    }

    // 5. Redis Interaction: Serialization and Storage
    private async Task SaveStateToCacheAsync()
    {
        var options = new DistributedCacheEntryOptions
        {
            // Keep the chat alive for 30 minutes of inactivity
            SlidingExpiration = TimeSpan.FromMinutes(30) 
        };

        // Serialize the list to JSON
        string serializedData = JsonSerializer.Serialize(conversationHistory);
        
        // Store in Redis via the IDistributedCache abstraction
        await Cache.SetStringAsync(CacheKey, serializedData, options);
    }

    // 6. Redis Interaction: Retrieval and Deserialization
    private async Task LoadStateFromCacheAsync()
    {
        // Attempt to retrieve the string
        string? serializedData = await Cache.GetStringAsync(CacheKey);

        if (!string.IsNullOrEmpty(serializedData))
        {
            // Deserialize back to our list structure
            conversationHistory = JsonSerializer.Deserialize<List<ChatMessage>>(serializedData) 
                                 ?? new List<ChatMessage>();
        }
    }

    // 7. Helper to demonstrate clearing state
    private async Task ClearCacheAsync()
    {
        await Cache.RemoveAsync(CacheKey);
        conversationHistory.Clear();
    }

    // 8. Simple model for the chat message
    public record ChatMessage(string Role, string Content);
}
