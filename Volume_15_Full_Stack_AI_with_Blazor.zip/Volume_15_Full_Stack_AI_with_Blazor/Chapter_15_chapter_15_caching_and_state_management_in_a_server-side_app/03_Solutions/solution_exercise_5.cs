
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using Microsoft.JSInterop;
using Microsoft.Extensions.Caching.Distributed;
using Blazored.LocalStorage; // Assuming Blazored.LocalStorage package
using System.Text.Json;

public class HybridStateProvider
{
    private readonly ILocalStorageService _localStorage;
    private readonly IDistributedCache _redis;
    private readonly IJSRuntime _jsRuntime;
    private readonly ILogger<HybridStateProvider> _logger;

    public HybridStateProvider(ILocalStorageService localStorage, IDistributedCache redis, IJSRuntime jsRuntime, ILogger<HybridStateProvider> logger)
    {
        _localStorage = localStorage;
        _redis = redis;
        _jsRuntime = jsRuntime;
        _logger = logger;
    }

    // Helper class for versioning
    private class VersionedState<T>
    {
        public T Data { get; set; }
        public long VersionTicks { get; set; } // Timestamp in ticks
    }

    public async Task<T> GetStateAsync<T>(string key)
    {
        // 1. Check network status
        var isOnline = await IsOnline();

        // 2. Try Local Storage first (Speed)
        var localData = await _localStorage.GetItemAsync<VersionedState<T>>(key);

        if (localData != null)
        {
            if (isOnline)
            {
                // 3. If online, check Redis for newer version (Conflict Resolution)
                var redisData = await _redis.GetStringAsync(key);
                if (!string.IsNullOrEmpty(redisData))
                {
                    var remoteVersion = JsonSerializer.Deserialize<VersionedState<T>>(redisData);
                    
                    // If remote version is newer, update local and return remote
                    if (remoteVersion.VersionTicks > localData.VersionTicks)
                    {
                        _logger.LogInformation("Local state stale. Updating from Redis.");
                        await _localStorage.SetItemAsync(key, remoteVersion);
                        return remoteVersion.Data;
                    }
                }
            }
            
            // Return local if it's the freshest or we are offline
            return localData.Data;
        }

        // 4. Fallback to Redis if Local is missing
        if (isOnline && !string.IsNullOrEmpty(await _redis.GetStringAsync(key)))
        {
            var redisData = JsonSerializer.Deserialize<VersionedState<T>>(await _redis.GetStringAsync(key));
            // Sync to local for future speed
            await _localStorage.SetItemAsync(key, redisData);
            return redisData.Data;
        }

        return default;
    }

    public async Task SetStateAsync<T>(string key, T value)
    {
        var timestamp = DateTime.UtcNow.Ticks;
        var versionedState = new VersionedState<T> { Data = value, VersionTicks = timestamp };
        
        // 1. Always write to Local Storage (Optimistic UI)
        await _localStorage.SetItemAsync(key, versionedState);

        // 2. Handle Online/Offline
        var isOnline = await IsOnline();
        if (isOnline)
        {
            // Push to Redis immediately
            await PushToRedis(key, versionedState);
        }
        else
        {
            // Queue for later (Simulated queue logic)
            _logger.LogWarning("Offline: State saved locally, queued for sync.");
            // In a real app, store this in a specific "pending sync" queue in LocalStorage
        }
    }

    public async Task SyncAsync()
    {
        // Called when connection is restored
        var keys = await _localStorage.KeysAsync(); // Requires Blazored.LocalStorage support
        foreach (var key in keys)
        {
            // In a real app, iterate over keys that need syncing
            // For this demo, we assume we know the key or scan for pending changes
            var data = await _localStorage.GetItemAsync<VersionedState<object>>(key);
            await PushToRedis(key, data);
        }
        _logger.LogInformation("Sync complete.");
    }

    private async Task PushToRedis<T>(string key, VersionedState<T> data)
    {
        var json = JsonSerializer.Serialize(data);
        await _redis.SetStringAsync(key, json, new DistributedCacheEntryOptions 
        { 
            SlidingExpiration = TimeSpan.FromDays(1) 
        });
    }

    private async Task<bool> IsOnline()
    {
        try
        {
            // Use JS interop to check navigator.onLine
            return await _jsRuntime.InvokeAsync<bool>("eval", "navigator.onLine");
        }
        catch
        {
            return true; // Default to online if check fails
        }
    }
}
