
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System.Text.Json;
using Microsoft.Extensions.Caching.Distributed;

// 1. Define the interface and model
public class ChatMessage
{
    public string Role { get; set; } // "User" or "Assistant"
    public string Content { get; set; }
    public DateTimeOffset Timestamp { get; set; }
}

public interface IConversationStore
{
    Task<List<ChatMessage>> GetHistoryAsync(string sessionId);
    Task SaveHistoryAsync(string sessionId, List<ChatMessage> history);
}

// 2. Implementation using IDistributedCache
public class CachedConversationStore : IConversationStore
{
    private readonly IDistributedCache _cache;
    private readonly JsonSerializerOptions _jsonOptions;

    public CachedConversationStore(IDistributedCache cache)
    {
        _cache = cache;
        // Configure JSON options for consistency
        _jsonOptions = new JsonSerializerOptions 
        { 
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase 
        };
    }

    public async Task<List<ChatMessage>> GetHistoryAsync(string sessionId)
    {
        // Retrieve the raw bytes from Redis
        var bytes = await _cache.GetAsync(sessionId);
        
        if (bytes == null)
        {
            return new List<ChatMessage>(); // Return empty list if not found
        }

        // Deserialize JSON back to the object model
        var json = System.Text.Encoding.UTF8.GetString(bytes);
        return JsonSerializer.Deserialize<List<ChatMessage>>(json, _jsonOptions) 
               ?? new List<ChatMessage>();
    }

    public async Task SaveHistoryAsync(string sessionId, List<ChatMessage> history)
    {
        // Serialize the list to JSON
        var json = JsonSerializer.Serialize(history, _jsonOptions);
        var bytes = System.Text.Encoding.UTF8.GetBytes(json);

        // Configure cache options: Sliding Expiration of 30 minutes
        var options = new DistributedCacheEntryOptions
        {
            SlidingExpiration = TimeSpan.FromMinutes(30)
        };

        // Save to distributed cache
        await _cache.SetAsync(sessionId, bytes, options);
    }
}

// 3. Registration in Program.cs (Conceptual)
/*
public void ConfigureServices(IServiceCollection services)
{
    services.AddStackExchangeRedisCache(options =>
    {
        options.Configuration = "localhost:6379"; // Retrieved from config
        options.InstanceName = "BlazorCopilot_";
    });

    services.AddScoped<IConversationStore, CachedConversationStore>();
}
*/
