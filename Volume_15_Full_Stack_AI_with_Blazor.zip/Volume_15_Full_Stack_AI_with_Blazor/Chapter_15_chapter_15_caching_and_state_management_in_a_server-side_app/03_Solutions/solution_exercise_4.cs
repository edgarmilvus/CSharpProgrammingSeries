
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Caching.Distributed;
using System.Threading.Channels;
using System.Text.Json;

// 1. The Refactored Service (Scoped to the user circuit)
public class ScalableCopilotService : IAsyncDisposable
{
    private readonly IDistributedCache _cache;
    private readonly IHubContext<ChatHub> _hubContext; // To notify UI
    private readonly Channel<ChatMessage> _messageChannel;
    private readonly string _sessionId;
    private readonly CancellationTokenSource _cts;

    public ScalableCopilotService(IDistributedCache cache, IHubContext<ChatHub> hubContext, NavigationManager nav)
    {
        _cache = cache;
        _hubContext = hubContext;
        // Unique session ID based on user/connection
        _sessionId = nav.Uri; // Simplified for demo
        
        // Initialize Channel for high-throughput
        _messageChannel = Channel.CreateUnbounded<ChatMessage>();
        _cts = new CancellationTokenSource();

        // Start the background processor
        Task.Run(() => ProcessChannelLoop(_cts.Token));
    }

    // UI calls this to send a message
    public async Task SendPromptAsync(string prompt)
    {
        // 1. Add User Message to Channel (Non-blocking)
        var userMsg = new ChatMessage { Role = "User", Content = prompt, Timestamp = DateTimeOffset.UtcNow };
        await _messageChannel.Writer.WriteAsync(userMsg);

        // 2. Simulate AI Response (In real app, this is async call)
        var response = await CallAiApi(prompt);
        var assistantMsg = new ChatMessage { Role = "Assistant", Content = response, Timestamp = DateTimeOffset.UtcNow };

        // 3. Add Assistant Message to Channel
        await _messageChannel.Writer.WriteAsync(assistantMsg);
    }

    // Background loop processing the channel
    private async Task ProcessChannelLoop(CancellationToken token)
    {
        var history = new List<ChatMessage>(); // Local buffer for context window logic

        await foreach (var message in _messageChannel.Reader.ReadAllAsync(token))
        {
            // 1. Context Window Management (Keep last 20)
            history.Add(message);
            if (history.Count > 20) history.RemoveAt(0);

            // 2. Persist to Redis
            await SaveHistoryToRedis(history);

            // 3. Notify UI via SignalR (or State Container)
            // We use the HubContext to push updates to the specific client
            await _hubContext.Clients.All.SendAsync("ReceiveMessage", message, token);
        }
    }

    private async Task SaveHistoryToRedis(List<ChatMessage> history)
    {
        var json = JsonSerializer.Serialize(history);
        await _cache.SetStringAsync(_sessionId, json, new DistributedCacheEntryOptions 
        { 
            SlidingExpiration = TimeSpan.FromMinutes(30) 
        });
    }

    private async Task<string> CallAiApi(string prompt)
    {
        await Task.Delay(300); // Simulate network
        return "Processed response via Channel";
    }

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _messageChannel.Writer.Complete();
    }
}

// Mock Hub for context
public class ChatHub : Hub { }

// 5. Architectural Decision: Singleton vs Scoped
/*
   DECISION: The `ScalableCopilotService` should be registered as SCOPED.
   
   JUSTIFICATION:
   1. Blazor Server uses SignalR circuits. Each user has their own circuit.
   2. If we register as Singleton, a single instance would be shared across ALL users, 
      leading to data leakage (User A seeing User B's chat).
   3. By using Scoped, we ensure one instance per user session.
   4. The `Channel` is created per Scoped service. This is correct because the background 
      loop needs to be isolated per user to process their specific queue.
   5. `IDistributedCache` is safe to be Singleton/Scoped because it connects to an external 
      Redis store, handling concurrency internally.
*/
