
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

// 1. Define the abstract base component
public abstract partial class StatefulBlazorComponent<TState> : ComponentBase where TState : class, new()
{
    [Inject]
    protected IDistributedCache Cache { get; set; } = null!;

    [Inject]
    protected NavigationManager Navigation { get; set; } = null!;

    protected TState ComponentState { get; private set; } = new();

    // Unique key based on component type and a user/session identifier
    private string CacheKey => $"{GetType().Name}_{NavigationManagerExtensions.GetUserId(Navigation)}";

    protected override async Task OnInitializedAsync()
    {
        // Attempt to restore state
        var bytes = await Cache.GetAsync(CacheKey);
        
        if (bytes != null)
        {
            var json = System.Text.Encoding.UTF8.GetString(bytes);
            ComponentState = JsonSerializer.Deserialize<TState>(json) ?? new TState();
        }
        else
        {
            // Fallback to default state (already initialized)
            ComponentState = new TState();
        }

        await base.OnInitializedAsync();
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            // Persist initial state if it was newly created (optional, but good for consistency)
            await PersistStateAsync();
        }
        await base.OnAfterRenderAsync(firstRender);
    }

    // 2. State Reactivity Method
    protected async Task UpdateState(Func<TState, TState> modifier)
    {
        // Apply modification
        ComponentState = modifier(ComponentState);
        
        // Trigger UI refresh
        StateHasChanged();

        // Asynchronously persist without blocking UI
        _ = PersistStateAsync();
    }

    private async Task PersistStateAsync()
    {
        var json = JsonSerializer.Serialize(ComponentState);
        var bytes = System.Text.Encoding.UTF8.GetBytes(json);
        
        var options = new DistributedCacheEntryOptions
        {
            SlidingExpiration = TimeSpan.FromDays(1) // Keep state alive while user is active
        };

        await Cache.SetAsync(CacheKey, bytes, options);
    }
}

// 3. Concrete Implementation: Counter Component
public class CounterComponent : StatefulBlazorComponent<CounterState>
{
    private void IncrementCount()
    {
        // Use the UpdateState method to ensure reactivity and persistence
        UpdateState(current => current with { Count = current.Count + 1 });
    }

    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        builder.OpenElement(0, "p");
        builder.AddContent(1, $"Current count: {ComponentState.Count}");
        builder.CloseElement();

        builder.OpenElement(2, "button");
        builder.AddAttribute(3, "onclick", EventCallback.Factory.Create(this, IncrementCount));
        builder.AddContent(4, "Click me");
        builder.CloseElement();
    }
}

// 4. State Record
public record CounterState
{
    public int Count { get; init; }
}

// Helper to get a stable user ID (simplified for demo)
public static class NavigationManagerExtensions
{
    public static string GetUserId(NavigationManager nav)
    {
        // In a real app, use AuthenticationState or a persistent cookie
        // Here we simulate using a query param or local storage ID
        return "anonymous_user"; 
    }
}
