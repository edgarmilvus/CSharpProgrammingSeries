
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace BlazorServerStateManagementDemo
{
    // Program Entry Point
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Blazor Server State & Caching Simulator ---");
            Console.WriteLine("Simulating a distributed Redis-like cache for AI Copilot sessions.\n");

            // 1. Initialize the Distributed Cache (Simulated)
            // In a real Blazor Server app, this would be IDistributedCache (Redis, SQL Server)
            var distributedCache = new InMemoryDistributedCache();

            // 2. Initialize the State Management Service
            // This service bridges the gap between the SignalR connection and the persistent cache
            var stateService = new CopilotSessionStateService(distributedCache);

            // 3. Simulate User Sessions (Simulating multiple users connecting via SignalR)
            var user1SessionId = "user-session-abc-123";
            var user2SessionId = "user-session-xyz-789";

            Console.WriteLine($"[System] User 1 connected: {user1SessionId}");
            Console.WriteLine($"[System] User 2 connected: {user2SessionId}\n");

            // 4. Simulate AI Interaction Flow
            // Scenario: User asks a complex question, the AI processes it, and we cache the result
            // to avoid expensive API calls on refresh or subsequent related questions.

            // --- User 1 Interaction ---
            ProcessUserInteraction(stateService, user1SessionId, "What is the capital of France?");
            ProcessUserInteraction(stateService, user1SessionId, "What is the population of that capital?");

            // --- User 2 Interaction ---
            ProcessUserInteraction(stateService, user2SessionId, "Explain Quantum Computing.");

            // --- Simulate Cache Hit (Performance Optimization) ---
            // User 1 refreshes the page (SignalR reconnects), asking the same question.
            Console.WriteLine("\n--- Simulating Cache Hit (User 1 Refresh) ---");
            ProcessUserInteraction(stateService, user1SessionId, "What is the capital of France?");

            // --- Simulate Cache Eviction (Scaling/Storage Limits) ---
            Console.WriteLine("\n--- Simulating Cache Eviction (LRU Policy) ---");
            Console.WriteLine("Cache is full. Adding new item to trigger eviction...");
            ProcessUserInteraction(stateService, user2SessionId, "Write a poem about code.");

            Console.WriteLine("\n--- End Simulation ---");
        }

        // Helper method to simulate the request lifecycle
        static void ProcessUserInteraction(CopilotSessionStateService stateService, string sessionId, string prompt)
        {
            Console.WriteLine($"\n[User {sessionId.Substring(0, 8)}...] Prompt: \"{prompt}\"");

            // Attempt to retrieve from cache first
            var cachedResponse = stateService.GetCachedResponse(sessionId, prompt);

            if (cachedResponse != null)
            {
                Console.WriteLine($"[Cache HIT] Retrieved from memory: \"{cachedResponse}\"");
            }
            else
            {
                Console.WriteLine("[Cache MISS] Processing via AI Model...");
                var aiResponse = SimulateExpensiveAiCall(prompt);
                Console.WriteLine($"[AI Response] \"{aiResponse}\"");

                // Store in state/cache for future reference
                stateService.StoreResponse(sessionId, prompt, aiResponse);
            }
        }

        // Simulates an expensive AI API call (e.g., GPT-4)
        static string SimulateExpensiveAiCall(string prompt)
        {
            Thread.Sleep(500); // Simulate network latency
            return $"Processed: {prompt}";
        }
    }

    // ---------------------------------------------------------
    // CORE CONCEPT 1: Distributed Cache Interface
    // Mimics IDistributedCache from Microsoft.Extensions.Caching.Distributed
    // ---------------------------------------------------------
    public interface IDistributedCache
    {
        void Set(string key, byte[] value, DistributedCacheEntryOptions options);
        byte[] Get(string key);
        void Remove(string key);
    }

    public class DistributedCacheEntryOptions
    {
        public TimeSpan? SlidingExpiration { get; set; }
    }

    // ---------------------------------------------------------
    // CORE CONCEPT 2: In-Memory Implementation of Distributed Cache
    // In production, this is replaced by Redis or SQL Server.
    // Uses basic arrays and loops to manage storage (simulating low-level memory management).
    // ---------------------------------------------------------
    public class InMemoryDistributedCache : IDistributedCache
    {
        // Fixed size array to simulate limited cache memory
        private CacheEntry[] _cacheStorage;
        private int _maxCapacity;
        private object _lock = new object();

        public InMemoryDistributedCache(int capacity = 5)
        {
            _maxCapacity = capacity;
            _cacheStorage = new CacheEntry[capacity];
        }

        public void Set(string key, byte[] value, DistributedCacheEntryOptions options)
        {
            lock (_lock)
            {
                // Check if key already exists
                int existingIndex = FindIndex(key);
                if (existingIndex != -1)
                {
                    // Update existing
                    _cacheStorage[existingIndex].Value = value;
                    _cacheStorage[existingIndex].LastAccessed = DateTime.UtcNow;
                    Console.WriteLine($"[Cache] Updated key: {key}");
                    return;
                }

                // Check for space
                int emptyIndex = FindEmptySlot();
                if (emptyIndex != -1)
                {
                    _cacheStorage[emptyIndex] = new CacheEntry 
                    { 
                        Key = key, 
                        Value = value, 
                        LastAccessed = DateTime.UtcNow,
                        Expiration = options.SlidingExpiration 
                    };
                    Console.WriteLine($"[Cache] Stored key: {key} at index {emptyIndex}");
                }
                else
                {
                    // Eviction Policy: Least Recently Used (LRU)
                    // Simple loop to find the oldest entry
                    EvictLruEntry();
                    // Retry insertion
                    Set(key, value, options);
                }
            }
        }

        public byte[] Get(string key)
        {
            lock (_lock)
            {
                int index = FindIndex(key);
                if (index != -1)
                {
                    // Check expiration
                    var entry = _cacheStorage[index];
                    if (entry.Expiration != null)
                    {
                        // Simple sliding expiration check
                        if (DateTime.UtcNow - entry.LastAccessed > entry.Expiration.Value)
                        {
                            // Expired
                            _cacheStorage[index] = null;
                            return null;
                        }
                    }

                    // Update access time
                    entry.LastAccessed = DateTime.UtcNow;
                    return entry.Value;
                }
                return null;
            }
        }

        public void Remove(string key)
        {
            lock (_lock)
            {
                int index = FindIndex(key);
                if (index != -1)
                {
                    _cacheStorage[index] = null;
                }
            }
        }

        // Helper: Linear search for key (O(N) complexity)
        private int FindIndex(string key)
        {
            for (int i = 0; i < _maxCapacity; i++)
            {
                if (_cacheStorage[i] != null && _cacheStorage[i].Key == key)
                {
                    return i;
                }
            }
            return -1;
        }

        // Helper: Find first null slot
        private int FindEmptySlot()
        {
            for (int i = 0; i < _maxCapacity; i++)
            {
                if (_cacheStorage[i] == null) return i;
            }
            return -1;
        }

        // Helper: Evict Least Recently Used entry
        private void EvictLruEntry()
        {
            int lruIndex = 0;
            DateTime oldestTime = DateTime.MaxValue;

            for (int i = 0; i < _maxCapacity; i++)
            {
                if (_cacheStorage[i] != null && _cacheStorage[i].LastAccessed < oldestTime)
                {
                    oldestTime = _cacheStorage[i].LastAccessed;
                    lruIndex = i;
                }
            }

            Console.WriteLine($"[Cache] Evicting key: {_cacheStorage[lruIndex].Key} (LRU)");
            _cacheStorage[lruIndex] = null;
        }

        private class CacheEntry
        {
            public string Key { get; set; }
            public byte[] Value { get; set; }
            public DateTime LastAccessed { get; set; }
            public TimeSpan? Expiration { get; set; }
        }
    }

    // ---------------------------------------------------------
    // CORE CONCEPT 3: State Management Service
    // Manages user context, serialization, and cache interaction.
    // ---------------------------------------------------------
    public class CopilotSessionStateService
    {
        private readonly IDistributedCache _cache;

        public CopilotSessionStateService(IDistributedCache cache)
        {
            _cache = cache;
        }

        // Stores the AI response associated with a specific user session and prompt
        public void StoreResponse(string sessionId, string prompt, string response)
        {
            // Create a unique cache key combining session and prompt
            string cacheKey = $"{sessionId}:{prompt}";

            // Serialize data (simulated by converting string to bytes)
            byte[] data = System.Text.Encoding.UTF8.GetBytes(response);

            // Define caching strategy: Sliding Expiration
            // The cache entry lives as long as the user keeps interacting (sliding window)
            var options = new DistributedCacheEntryOptions
            {
                SlidingExpiration = TimeSpan.FromMinutes(10)
            };

            _cache.Set(cacheKey, data, options);
        }

        // Retrieves the response if available
        public string GetCachedResponse(string sessionId, string prompt)
        {
            string cacheKey = $"{sessionId}:{prompt}";
            
            byte[] data = _cache.Get(cacheKey);

            if (data == null) return null;

            return System.Text.Encoding.UTF8.GetString(data);
        }
    }
}
