
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// ChatMessage.razor
@page "/chat-message"
@inject IJSRuntime JSRuntime
@implements IAsyncDisposable

<div class="message-container" @onclick="ToggleExpand">
    <div class="bubble @(IsUser ? "user" : "ai")">
        @Message
    </div>
    
    @if (isExpanded)
    {
        <div class="actions" @onclick:stopPropagation="true">
            <button @onclick="CopyToClipboard">Copy</button>
            <button @onclick="DeleteMessage">Delete</button>
        </div>
    }
</div>

@code {
    [Parameter] public string Message { get; set; } = string.Empty;
    [Parameter] public bool IsUser { get; set; }
    
    private bool isExpanded = false;
    private DotNetObjectReference<ChatMessage>? dotNetRef;
    private string clickListenerId = Guid.NewGuid().ToString();

    private void ToggleExpand()
    {
        isExpanded = !isExpanded;
    }

    private async Task CopyToClipboard()
    {
        await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", Message);
    }

    private void DeleteMessage()
    {
        // Logic to delete message would go here
        isExpanded = false;
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            dotNetRef = DotNetObjectReference.Create(this);
            await JSRuntime.InvokeVoidAsync("addGlobalClickListener", clickListenerId, dotNetRef);
        }
    }

    [JSInvokable]
    public void HandleGlobalClick(string clickedElementId)
    {
        // If the click was outside this specific component's area, close the actions
        // Note: In a real app, you might pass the actual element ID to verify
        // For this exercise, we assume any global click not on the actions closes it
        if (isExpanded)
        {
            isExpanded = false;
            StateHasChanged();
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (dotNetRef != null)
        {
            await JSRuntime.InvokeVoidAsync("removeGlobalClickListener", clickListenerId);
            dotNetRef.Dispose();
        }
    }
}
