
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_13.cs
// Description: Solution for Exercise 13
// ==========================================

// CodeSnippet.razor
@inject VoteStateContainer VoteContainer
@implements IDisposable

<div class="code-block">
    <pre>Snippet ID: @SnippetId</pre>
    <div class="votes">
        <button @onclick="HandleUpvote" disabled="@isProcessing">Upvote (@currentCount)</button>
        @if (isProcessing)
        {
            <span class="spinner">Saving...</span>
        }
        @if (!string.IsNullOrEmpty(errorMessage))
        {
            <span class="error">@errorMessage</span>
        }
    </div>
</div>

@code {
    [Parameter] public string SnippetId { get; set; } = string.Empty;
    [Parameter] public int InitialVoteCount { get; set; }

    private int currentCount;
    private bool isProcessing = false;
    private string errorMessage = string.Empty;

    protected override void OnInitialized()
    {
        currentCount = InitialVoteCount;
        // Sync with global state if available, otherwise use local param
        var globalCount = VoteContainer.GetVote(SnippetId);
        if (globalCount != 0) currentCount = globalCount;
        
        VoteContainer.OnVotesChanged += HandleExternalVoteChange;
    }

    private async Task HandleUpvote()
    {
        isProcessing = true;
        errorMessage = string.Empty;
        int previousCount = currentCount;

        // 1. Optimistic Update
        currentCount++;
        VoteContainer.UpdateVote(SnippetId, currentCount);
        StateHasChanged(); // Ensure UI updates immediately

        try
        {
            // 2. Simulate Network Call
            await Task.Delay(500); // Simulate latency

            // 3. Random Failure Simulation
            if (new Random().Next(0, 2) == 0) 
                throw new Exception("Network error: Failed to save vote.");

            // Success: State is already correct via optimistic update
        }
        catch (Exception ex)
        {
            // 4. Rollback Mechanism
            currentCount = previousCount;
            VoteContainer.UpdateVote(SnippetId, currentCount);
            errorMessage = $"Failed to vote: {ex.Message}";
        }
        finally
        {
            isProcessing = false;
            StateHasChanged();
        }
    }

    private void HandleExternalVoteChange(string id, int count)
    {
        if (id == SnippetId)
        {
            currentCount = count;
            StateHasChanged();
        }
    }

    public void Dispose()
    {
        VoteContainer.OnVotesChanged -= HandleExternalVoteChange;
    }
}
