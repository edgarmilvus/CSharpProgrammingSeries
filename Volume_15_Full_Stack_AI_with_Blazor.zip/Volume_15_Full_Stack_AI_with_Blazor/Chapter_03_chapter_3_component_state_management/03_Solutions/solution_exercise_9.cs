
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.cs
// Description: Solution for Exercise 9
// ==========================================

// State/CopilotState.cs
public record CopilotState
{
    public string CurrentPrompt { get; init; } = string.Empty;
    public bool IsGenerating { get; init; }
    public List<string> GeneratedResponses { get; init; } = new();
}

// Actions/Actions.cs
public record StartGenerationAction;
public record FinishGenerationAction(string Response);
public record UpdatePromptAction(string Prompt);

// State/CopilotReducers.cs
public static class CopilotReducers
{
    [ReducerMethod]
    public static CopilotState ReduceStartGeneration(CopilotState state, StartGenerationAction action)
        => state with { IsGenerating = true };

    [ReducerMethod]
    public static CopilotState ReduceFinishGeneration(CopilotState state, FinishGenerationAction action)
        => state with 
        { 
            IsGenerating = false, 
            GeneratedResponses = state.GeneratedResponses.Append(action.Response).ToList() 
        };

    [ReducerMethod]
    public static CopilotState ReduceUpdatePrompt(CopilotState state, UpdatePromptAction action)
        => state with { CurrentPrompt = action.Prompt };
}

// Effects/GenerateResponseEffect.cs
public class GenerateResponseEffect
{
    [EffectMethod]
    public async Task HandleStartGeneration(StartGenerationAction action, IDispatcher dispatcher)
    {
        // Simulate API call
        await Task.Delay(2000);
        dispatcher.Dispatch(new FinishGenerationAction($"Simulated Response at {DateTime.Now:T}"));
    }
}
