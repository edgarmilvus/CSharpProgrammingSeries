
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace StateManagementCopilot
{
    // The StateContainer pattern is a foundational technique for sharing state between sibling components
    // without prop drilling. In a Blazor WASM AI Copilot, this is critical for managing the conversation
    // context, UI state (like loading indicators), and user preferences across different views.
    public class CopilotStateContainer
    {
        // 1. Internal State: Encapsulated fields ensure data integrity.
        // We use basic arrays to store the conversation history and UI flags.
        private string[] _conversationHistory;
        private int _messageCount;
        private bool _isProcessing;
        private string _systemStatus;

        // 2. Events: The mechanism for reactivity. When state changes, components listening
        // to these events will be notified and can trigger a re-render.
        public event Action OnStateChange;

        // Constructor: Initializes the state with default values.
        public CopilotStateContainer()
        {
            _conversationHistory = new string[10]; // Fixed size buffer for simplicity
            _messageCount = 0;
            _isProcessing = false;
            _systemStatus = "Ready";
        }

        // 3. State Mutators: Methods to update state safely.
        // We do not expose public setters; we control changes through methods.
        public void AddMessage(string role, string content)
        {
            if (_messageCount < _conversationHistory.Length)
            {
                string formattedMessage = $"[{role}]: {content}";
                _conversationHistory[_messageCount] = formattedMessage;
                _messageCount++;
                NotifyStateChanged();
            }
            else
            {
                // Simple circular buffer logic (manual implementation without LINQ)
                // Shift existing messages to make room
                for (int i = 0; i < _conversationHistory.Length - 1; i++)
                {
                    _conversationHistory[i] = _conversationHistory[i + 1];
                }
                _conversationHistory[_conversationHistory.Length - 1] = $"[{role}]: {content}";
                NotifyStateChanged();
            }
        }

        public void SetProcessingState(bool isProcessing)
        {
            _isProcessing = isProcessing;
            _systemStatus = isProcessing ? "AI is thinking..." : "Ready";
            NotifyStateChanged();
        }

        // 4. Accessors: Read-only access to state properties.
        // Components can observe the state but cannot modify it directly.
        public string[] GetHistorySnapshot()
        {
            // Return a copy to prevent external modification of the internal array
            string[] snapshot = new string[_messageCount];
            for (int i = 0; i < _messageCount; i++)
            {
                snapshot[i] = _conversationHistory[i];
            }
            return snapshot;
        }

        public bool IsProcessing() => _isProcessing;
        public string GetStatus() => _systemStatus;

        // 5. Notification Logic: Invokes the event to signal subscribers.
        private void NotifyStateChanged() => OnStateChange?.Invoke();
    }

    // Simulating a Blazor Component (UI Layer)
    // In a real app, this would inherit from ComponentBase. Here we simulate the lifecycle.
    public class ChatWindowComponent
    {
        private readonly CopilotStateContainer _state;
        private string[] _localHistory;

        public ChatWindowComponent(CopilotStateContainer state)
        {
            _state = state;
            // Subscribe to state changes for reactivity
            _state.OnStateChange += HandleStateChange;
            // Initial render simulation
            Render();
        }

        // Reactive Handler: Called whenever the StateContainer updates
        private void HandleStateChange()
        {
            Console.WriteLine("   [UI Event] State changed detected. Re-rendering Chat Window...");
            Render();
        }

        public void Render()
        {
            // In Blazor, this triggers the Virtual DOM diffing. Here we simulate UI output.
            Console.WriteLine("\n--- Chat Window UI ---");
            string[] history = _state.GetHistorySnapshot();
            
            if (history.Length == 0)
            {
                Console.WriteLine("(No messages yet)");
            }
            else
            {
                for (int i = 0; i < history.Length; i++)
                {
                    if (history[i] != null)
                    {
                        Console.WriteLine(history[i]);
                    }
                }
            }
            Console.WriteLine($"Status: {_state.GetStatus()}");
            Console.WriteLine("----------------------\n");
        }

        // Cleanup: Always unsubscribe from events to prevent memory leaks in Blazor WASM
        ~ChatWindowComponent()
        {
            _state.OnStateChange -= HandleStateChange;
        }
    }

    // Simulating a Status Bar Component (Sibling Component)
    // This component shares the same StateContainer but displays different data.
    public class StatusBarComponent
    {
        private readonly CopilotStateContainer _state;

        public StatusBarComponent(CopilotStateContainer state)
        {
            _state = state;
            _state.OnStateChange += HandleStateChange;
            Render();
        }

        private void HandleStateChange()
        {
            Console.WriteLine("   [UI Event] State changed detected. Re-rendering Status Bar...");
            Render();
        }

        public void Render()
        {
            Console.WriteLine("--- Status Bar ---");
            Console.WriteLine($"System: {_state.GetStatus()}");
            Console.WriteLine($"Messages: {_state.GetHistorySnapshot().Length}");
            Console.WriteLine("------------------\n");
        }

        ~StatusBarComponent()
        {
            _state.OnStateChange -= HandleStateChange;
        }
    }

    // The "Brain" of the AI Copilot. In a real app, this would handle API calls.
    // Here, it simulates processing logic that modifies the shared state.
    public class CopilotLogic
    {
        private readonly CopilotStateContainer _state;

        public CopilotLogic(CopilotStateContainer state)
        {
            _state = state;
        }

        // Simulates an asynchronous AI response generation
        public void ProcessUserRequest(string userMessage)
        {
            // 1. Update State: Immediate feedback to UI
            _state.SetProcessingState(true);
            _state.AddMessage("User", userMessage);

            // 2. Simulate Processing Delay (Blocking for console demo purposes)
            Console.WriteLine("   [System] Processing AI response...");
            System.Threading.Thread.Sleep(1000); // Simulate 1 second latency

            // 3. Generate Mock Response
            string aiResponse = GenerateMockResponse(userMessage);

            // 4. Update State: Final result
            _state.AddMessage("Assistant", aiResponse);
            _state.SetProcessingState(false);
        }

        private string GenerateMockResponse(string input)
        {
            // Basic logic without LINQ or Lambdas
            if (input.Contains("hello")) return "Hello! How can I assist you with Blazor today?";
            if (input.Contains("state")) return "State management is crucial for reactive UIs.";
            return "I understand. Let me process that information.";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Initializing State Management Demo...\n");

            // 1. Dependency Injection Setup (Simulated)
            // In Blazor, we register services in Program.cs (Singleton/Scoped).
            // Here we instantiate the shared state container manually.
            var sharedState = new CopilotStateContainer();

            // 2. Component Instantiation
            // Components receive the shared state via constructor injection.
            var chatWindow = new ChatWindowComponent(sharedState);
            var statusBar = new StatusBarComponent(sharedState);

            // 3. Logic Layer Instantiation
            var copilotBrain = new CopilotLogic(sharedState);

            // 4. Simulation Loop
            string[] testInputs = { "hello", "explain state management" };
            
            foreach (var input in testInputs)
            {
                Console.WriteLine($"\n>>> User Input Received: {input}");
                // The logic modifies the state, which automatically notifies the components
                copilotBrain.ProcessUserRequest(input);
                
                // Simulate a pause between interactions
                System.Threading.Thread.Sleep(500);
            }

            Console.WriteLine("\nDemo Complete.");
        }
    }
}
