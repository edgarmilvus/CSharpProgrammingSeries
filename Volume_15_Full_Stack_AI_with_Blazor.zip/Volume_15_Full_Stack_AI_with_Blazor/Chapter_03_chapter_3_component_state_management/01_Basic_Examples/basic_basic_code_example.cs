
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

// File: StateContainerExample.razor
// Context: In a Blazor AI Copilot, we often have a "ChatSession" component that displays messages
// and a "MessageInput" component that sends new messages. The state (the list of messages)
// must be shared between these sibling components without passing parameters through a common parent,
// which can become cumbersome in complex UIs.

using Microsoft.AspNetCore.Components;

// 1. The State Container Service
// This is a simple, singleton service that holds the shared state.
// It uses the observer pattern to notify subscribers when the state changes.
public class ChatStateService
{
    // The state data: a list of messages.
    // We use a List<string> for simplicity, but in a real app, this would be a List<ChatMessage>.
    private List<string> _messages = new();

    // The event that components will subscribe to.
    // We use Action for simplicity, but in a real app, consider using a more robust event pattern
    // or a library like Fluxor for complex state transitions.
    public event Action? OnChange;

    // Property to expose the messages immutably.
    // This prevents external components from modifying the list directly without going through the service.
    public IReadOnlyList<string> Messages => _messages.AsReadOnly();

    // Method to add a message.
    // This is the ONLY way to modify the state from outside the service.
    public void AddMessage(string message)
    {
        _messages.Add(message);
        NotifyStateChanged();
    }

    // Method to clear the messages.
    public void ClearMessages()
    {
        _messages.Clear();
        NotifyStateChanged();
    }

    // Private helper to invoke the event.
    // The ?.Invoke pattern ensures we don't get a NullReferenceException if no one is subscribed.
    private void NotifyStateChanged() => OnChange?.Invoke();
}

// 2. The Parent Component (ChatContainer)
// This component registers the ChatStateService in the DI container and renders the child components.
// It acts as the root for this specific state management example.
@page "/chat-state-example"
@inject ChatStateService ChatService

<h3>AI Copilot Chat Interface</h3>
<p>This example demonstrates sharing state between sibling components using a State Container pattern.</p>

<div class="chat-container">
    <!-- Child Component 1: Displays the messages -->
    <ChatSession />

    <!-- Child Component 2: Handles user input -->
    <MessageInput />
</div>

@code {
    // We don't need any code here for this simple example,
    // but in a real app, you might want to dispose of the service or handle lifecycle events.
}

// 3. The Child Component (ChatSession)
// This component displays the list of messages.
// It subscribes to the ChatStateService to update its UI when the state changes.
@implements IDisposable
@inject ChatStateService ChatService

<div class="chat-display">
    <h4>Conversation Log:</h4>
    @if (!ChatService.Messages.Any())
    {
        <p><em>No messages yet. Start a conversation!</em></p>
    }
    else
    {
        <ul>
            @foreach (var msg in ChatService.Messages)
            {
                <li>@msg</li>
            }
        </ul>
    }
</div>

@code {
    protected override void OnInitialized()
    {
        // Subscribe to the OnChange event.
        // When the event fires, we call our StateHasChanged method to re-render the component.
        ChatService.OnChange += StateHasChanged;
    }

    // CRITICAL: Unsubscribe from the event to prevent memory leaks.
    // This is called when the component is removed from the UI.
    public void Dispose()
    {
        ChatService.OnChange -= StateHasChanged;
    }
}

// 4. The Child Component (MessageInput)
// This component provides a text input and a button to send a message.
// It modifies the shared state through the ChatStateService.
@inject ChatStateService ChatService

<div class="message-input">
    <input type="text" 
           @bind="newMessage" 
           @bind:event="oninput" 
           placeholder="Type your message to the AI..." />
    <button @onclick="SendMessage" disabled="@(string.IsNullOrWhiteSpace(newMessage))">
        Send
    </button>
    <button @onclick="ClearChat" class="btn-secondary">
        Clear Chat
    </button>
</div>

@code {
    private string newMessage = "";

    private void SendMessage()
    {
        if (!string.IsNullOrWhiteSpace(newMessage))
        {
            // Modify the shared state by calling the service method.
            // This will trigger the OnChange event, which the ChatSession component is listening to.
            ChatService.AddMessage($"User: {newMessage}");
            newMessage = ""; // Clear the input field
        }
    }

    private void ClearChat()
    {
        ChatService.ClearMessages();
    }
}

// 5. Program.cs Setup
// In a real Blazor application, you must register the state container service
// in the dependency injection container so it can be injected into components.
// This code would typically be in your Program.cs file.

/*
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

// Register the ChatStateService as a Singleton.
// This ensures that all components in the application share the same instance of the service.
builder.Services.AddSingleton<ChatStateService>();

await builder.Build().RunAsync();
*/
