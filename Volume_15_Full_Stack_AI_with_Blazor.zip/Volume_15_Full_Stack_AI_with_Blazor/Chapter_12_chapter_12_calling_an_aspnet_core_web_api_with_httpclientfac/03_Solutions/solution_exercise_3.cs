
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Text;
using System.Text.Json;

public interface IChatCompletionService
{
    // Existing method
    Task<string> GetCompletionAsync(string prompt, CancellationToken cancellationToken = default);
    
    // New streaming method
    IAsyncEnumerable<string> StreamCompletionAsync(string prompt, CancellationToken cancellationToken);
}

public class ChatCompletionService : IChatCompletionService
{
    private readonly HttpClient _httpClient;

    public ChatCompletionService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // ... GetCompletionAsync implementation ...

    public async IAsyncEnumerable<string> StreamCompletionAsync(string prompt, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, $"stream?prompt={Uri.EscapeDataString(prompt)}");
        
        // Use ResponseHeadersRead to avoid buffering the entire response
        using var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        response.EnsureSuccessStatusCode();

        using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        using var reader = new StreamReader(stream, Encoding.UTF8);

        // Buffer to handle partial JSON chunks
        var buffer = new char[4096];
        var remainingData = string.Empty;

        while (!reader.EndOfStream)
        {
            cancellationToken.ThrowIfCancellationRequested();

            int bytesRead = await reader.ReadAsync(buffer, 0, buffer.Length);
            if (bytesRead == 0) break;

            var chunk = new string(buffer, 0, bytesRead);
            var dataToProcess = remainingData + chunk;

            // Simple parsing logic: assuming the stream sends JSON objects like {"content":"text"}\n
            // We split by newlines to isolate complete objects
            var lines = dataToProcess.Split('\n', StringSplitOptions.RemoveEmptyEntries);

            // The last line might be incomplete, so keep it in the buffer
            remainingData = lines.LastOrDefault() ?? string.Empty;
            
            // If we have more than one line, the last one is potentially incomplete
            // so we process all except the last.
            var linesToProcess = lines.Length > 1 ? lines[..^1] : Array.Empty<string>();

            foreach (var line in linesToProcess)
            {
                try
                {
                    using var doc = JsonDocument.Parse(line);
                    if (doc.RootElement.TryGetProperty("content", out var contentElement))
                    {
                        yield return contentElement.GetString() ?? string.Empty;
                    }
                }
                catch (JsonException)
                {
                    // Handle malformed JSON chunks gracefully (log or ignore)
                    continue;
                }
            }
        }
        
        // Process any remaining complete data in the buffer
        if (!string.IsNullOrEmpty(remainingData))
        {
             try
             {
                using var doc = JsonDocument.Parse(remainingData);
                if (doc.RootElement.TryGetProperty("content", out var contentElement))
                {
                    yield return contentElement.GetString() ?? string.Empty;
                }
             }
             catch (JsonException) { /* Ignore incomplete trailing data */ }
        }
    }
}
