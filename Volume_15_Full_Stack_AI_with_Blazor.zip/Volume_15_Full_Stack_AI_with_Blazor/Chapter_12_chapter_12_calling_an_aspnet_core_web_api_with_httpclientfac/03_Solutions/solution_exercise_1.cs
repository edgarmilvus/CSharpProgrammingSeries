
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System.Net.Http.Json;
using System.Text.Json;

// 1. The DTO definition
public record CopilotConfigDto(string ModelName, double Temperature, int MaxTokens);

// 2. The interface definition
public interface ICopilotConfigService
{
    Task<CopilotConfigDto> GetConfigurationAsync(CancellationToken cancellationToken = default);
}

// 3. The implementation using a typed HttpClient
public class CopilotConfigService : ICopilotConfigService
{
    private readonly HttpClient _httpClient;

    public CopilotConfigService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<CopilotConfigDto> GetConfigurationAsync(CancellationToken cancellationToken = default)
    {
        // Assuming the endpoint is configured in the BaseAddress of the typed client
        // We append the specific path segment for the config endpoint
        var response = await _httpClient.GetAsync("config", cancellationToken);
        
        response.EnsureSuccessStatusCode();

        // Use System.Text.Json for modern, high-performance deserialization
        var config = await response.Content.ReadFromJsonAsync<CopilotConfigDto>(
            cancellationToken: cancellationToken);

        if (config is null)
        {
            throw new InvalidOperationException("Failed to deserialize configuration.");
        }

        return config;
    }
}

// 4. Configuration in Program.cs (Blazor WASM)
// Note: This code goes in the Main method of Program.cs
using Microsoft.Extensions.DependencyInjection;

// ... inside Main(args) ...
var builder = WebAssemblyHostBuilder.CreateDefault(args);

// Register the typed HttpClient
// The BaseAddress is set here to the backend root
builder.Services.AddHttpClient<ICopilotConfigService, CopilotConfigService>(client =>
{
    client.BaseAddress = new Uri("https://localhost:7000/api/copilot/");
});

// ... builder.Build().RunAsync(); ...
