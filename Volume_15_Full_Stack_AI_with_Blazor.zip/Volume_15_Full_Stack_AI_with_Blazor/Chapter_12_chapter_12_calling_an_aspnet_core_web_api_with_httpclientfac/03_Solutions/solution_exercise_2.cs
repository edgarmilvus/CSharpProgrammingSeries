
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System.Net;
using Microsoft.Extensions.Http;
using Polly;
using Polly.CircuitBreaker;
using Polly.Timeout;
using Polly.Retry;

// Custom Exception
public class CopilotServiceUnavailableException : Exception
{
    public CopilotServiceUnavailableException(string message, Exception innerException) 
        : base(message, innerException) { }
}

public interface IChatCompletionService
{
    Task<string> GetCompletionAsync(string prompt, CancellationToken cancellationToken = default);
}

public class ChatCompletionService : IChatCompletionService
{
    private readonly HttpClient _httpClient;

    public ChatCompletionService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<string> GetCompletionAsync(string prompt, CancellationToken cancellationToken = default)
    {
        try
        {
            // In a real scenario, we would send the prompt in the body.
            // For this exercise, we assume a GET request for simplicity.
            var response = await _httpClient.GetAsync($"completion?prompt={Uri.EscapeDataString(prompt)}", cancellationToken);
            
            response.EnsureSuccessStatusCode();
            
            return await response.Content.ReadAsStringAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is HttpRequestException || ex is TimeoutRejectedException || ex is BrokenCircuitException)
        {
            // Transform technical exceptions into a domain-specific exception
            throw new CopilotServiceUnavailableException("The Copilot service is currently unavailable.", ex);
        }
    }
}

// 4. Configuration in Program.cs (Blazor WASM)
using Polly;
using Polly.Extensions.Http;

// ... inside Main(args) ...
var builder = WebAssemblyHostBuilder.CreateDefault(args);

// Define the resilience pipeline
AsyncRetryPolicy<HttpResponseMessage> retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError() // Handles 5xx and 408
    .OrResult(msg => msg.StatusCode == HttpStatusCode.TooManyRequests) // Handle 429
    .WaitAndRetryAsync(
        sleepDurationProvider: retryAttempt => 
            TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)) + TimeSpan.FromMilliseconds(new Random().Next(0, 1000)), // Jittered exponential backoff
        onRetry: (outcome, timespan, retryCount, context) =>
        {
            Console.WriteLine($"Retry {retryCount} after {timespan.TotalSeconds}s due to: {outcome.Result?.StatusCode}");
        });

AsyncCircuitBreakerPolicy<HttpResponseMessage> circuitBreakerPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .CircuitBreakerAsync(
        handledEventsAllowedBeforeBreaking: 5, 
        durationOfBreak: TimeSpan.FromSeconds(30));

AsyncTimeoutPolicy timeoutPolicy = Policy.TimeoutAsync(TimeSpan.FromSeconds(10));

builder.Services.AddHttpClient<IChatCompletionService, ChatCompletionService>(client =>
{
    client.BaseAddress = new Uri("https://localhost:7000/api/copilot/");
    client.Timeout = TimeSpan.FromSeconds(10); // Client-side timeout
})
.AddPolicyHandler(retryPolicy)
.AddPolicyHandler(circuitBreakerPolicy)
.AddPolicyHandler(timeoutPolicy);

// ... builder.Build().RunAsync(); ...
