
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Net.Http.Json;
using System.Text.Json;

// 1. Domain Models
// Represents the structure of the data we expect from the external API.
public record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary);

// 2. External API Response DTO
// Matches the JSON structure returned by the external mock service.
public record ExternalWeatherResponse(
    string location,
    double temperature,
    string description
);

// 3. Service Interface
// Abstraction for dependency injection. This allows us to mock the service in tests.
public interface IWeatherService
{
    Task<WeatherForecast?> GetForecastAsync(string city, CancellationToken ct = default);
}

// 4. Service Implementation
// Uses HttpClientFactory to manage the HTTP connection lifecycle.
public class WeatherService : IWeatherService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<WeatherService> _logger;

    public WeatherService(HttpClient httpClient, ILogger<WeatherService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<WeatherForecast?> GetForecastAsync(string city, CancellationToken ct = default)
    {
        try
        {
            // In a real scenario, the base URL is configured in Program.cs
            // We are calling a mock external endpoint here.
            _logger.LogInformation("Requesting weather for {City}", city);

            var response = await _httpClient.GetFromJsonAsync<ExternalWeatherResponse>(
                $"weather/{city}", 
                ct
            );

            if (response is null)
            {
                return null;
            }

            // Map external model to our domain model
            return new WeatherForecast(
                Date: DateOnly.FromDateTime(DateTime.UtcNow),
                TemperatureC: (int)Math.Round(response.temperature),
                Summary: response.description
            );
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Network error fetching weather for {City}", city);
            throw; // Re-throw to let the caller handle the UI feedback
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Invalid JSON received for {City}", city);
            throw;
        }
    }
}

// 5. Program.cs (Console App Simulation)
// This simulates the ASP.NET Core startup process to demonstrate DI configuration.
public class Program
{
    public static async Task Main(string[] args)
    {
        // Create the Host builder (Standard ASP.NET Core pattern)
        var builder = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                // CRITICAL: Configuring HttpClientFactory
                services.AddHttpClient<IWeatherService, WeatherService>(client =>
                {
                    // 1. Set the Base Address for the external API
                    // In a real Blazor WASM app, this would be your backend API URL.
                    // Here, we point to a mock public API for demonstration.
                    client.BaseAddress = new Uri("https://api.mockweather.com/");
                    
                    // 2. Set Default Headers (e.g., User-Agent, Accept)
                    client.DefaultRequestHeaders.Accept.Add(
                        new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                })
                // 3. Resilience: Add a standard retry policy (Polly integration)
                // This handles transient network errors automatically.
                .AddPolicyHandler(Polly.Policy<HttpResponseMessage>
                    .Handle<HttpRequestException>()
                    .OrResult(msg => msg.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt))));
            });

        var host = builder.Build();

        // Simulate a request from a Blazor component or Controller
        using var scope = host.Services.CreateScope();
        var weatherService = scope.ServiceProvider.GetRequiredService<IWeatherService>();

        try
        {
            // Fetch data
            var forecast = await weatherService.GetForecastAsync("London");
            
            if (forecast != null)
            {
                Console.WriteLine($"Success: {forecast.Date} | {forecast.TemperatureC}°C | {forecast.Summary}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Critical Error: {ex.Message}");
        }
    }
}
