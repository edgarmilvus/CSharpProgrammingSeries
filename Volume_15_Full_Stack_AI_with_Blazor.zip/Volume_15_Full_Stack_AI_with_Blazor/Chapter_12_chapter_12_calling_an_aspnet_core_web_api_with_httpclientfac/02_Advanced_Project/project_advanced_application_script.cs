
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BlazorCopilotInventorySystem
{
    // Real-world context:
    // A warehouse management system for a Blazor WASM Copilot application.
    // The Copilot needs to query inventory levels and update stock counts via a REST API.
    // This console application simulates the backend service logic that the Blazor WASM app would call.
    // We use HttpClientFactory to manage HTTP connections efficiently, avoiding socket exhaustion.
    // We implement a custom retry policy to handle transient network failures (common in distributed systems).

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== Blazor Inventory Copilot - Backend Service Simulator ===");
            Console.WriteLine("Simulating API calls with HttpClientFactory and Resilience Policies...\n");

            // 1. Dependency Injection Simulation:
            // In a real ASP.NET Core app, IHttpClientFactory is injected via the constructor.
            // Here, we manually instantiate the factory to demonstrate its usage pattern.
            // We wrap the factory in our custom 'InventoryApiClient' to encapsulate logic.
            var httpClientFactory = new MockHttpClientFactory();
            var inventoryService = new InventoryApiClient(httpClientFactory);

            // 2. Simulating User Requests (The Copilot Interaction):
            // The Copilot parses user intent and calls specific API endpoints.
            string[] productIds = { "PROD-001", "PROD-002", "PROD-999" }; // PROD-999 will trigger a 404

            Console.WriteLine("--- Step 1: Fetching Inventory Levels ---");
            foreach (var id in productIds)
            {
                try
                {
                    var stockLevel = await inventoryService.GetStockLevelAsync(id);
                    Console.WriteLine($"[Success] Product {id}: {stockLevel} units in stock.");
                }
                catch (HttpRequestException ex)
                {
                    // Robust Error Handling: Catching specific HTTP exceptions allows for user-friendly feedback.
                    Console.WriteLine($"[Error] Failed to fetch {id}: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Critical] Unexpected error: {ex.Message}");
                }
            }

            Console.WriteLine("\n--- Step 2: Updating Stock (Resilient Retry) ---");
            // Simulating a network glitch that requires a retry.
            // The HttpClientFactory combined with the retry policy handles this automatically.
            try
            {
                await inventoryService.UpdateStockAsync("PROD-001", 50);
                Console.WriteLine("[Success] Stock updated successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Error] Update failed after retries: {ex.Message}");
            }

            Console.WriteLine("\n=== Simulation Complete ===");
        }
    }

    // ---------------------------------------------------------
    // CONCEPT: Typed HttpClient
    // ---------------------------------------------------------
    // Instead of using raw HttpClient (which leads to socket exhaustion),
    // we define a typed client. This class encapsulates all logic for communicating
    // with a specific resource (Inventory API).
    public class InventoryApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly int _maxRetries = 3;

        public InventoryApiClient(IHttpClientFactory httpClientFactory)
        {
            // The factory creates a named or typed HttpClient instance.
            // We configure base address and headers centrally (usually in Program.cs).
            _httpClient = httpClientFactory.CreateClient("InventoryAPI");
        }

        // ---------------------------------------------------------
        // CONCEPT: Asynchronous API Responses
        // ---------------------------------------------------------
        // Using async/await ensures the calling thread (UI thread in Blazor) is not blocked
        // while waiting for the network response.
        public async Task<int> GetStockLevelAsync(string productId)
        {
            // Constructing the endpoint dynamically.
            string endpoint = $"/api/inventory/{productId}";

            // Simulating network latency
            await Task.Delay(200);

            // ---------------------------------------------------------
            // CONCEPT: Robust Error Handling
            // ---------------------------------------------------------
            // We check the HTTP status code manually to throw meaningful exceptions.
            // In a real app, we might use a middleware like Polly for this.
            HttpResponseMessage response = await _httpClient.GetAsync(endpoint);

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                // Parsing the simulated JSON response (simplified for this exercise).
                // In a real app, we would use System.Text.Json.
                // "StockLevel": 100 -> We extract '100'.
                if (int.TryParse(content, out int stock))
                {
                    return stock;
                }
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                throw new HttpRequestException($"Product ID '{productId}' not found on server.");
            }
            else
            {
                throw new HttpRequestException($"API Error: {response.StatusCode}");
            }

            return 0;
        }

        // ---------------------------------------------------------
        // CONCEPT: Resilience (Custom Retry Policy)
        // ---------------------------------------------------------
        // Since we cannot use external libraries (like Polly) in this constrained exercise,
        // we implement a manual retry loop. This is a fundamental pattern for handling
        // transient faults in distributed systems.
        public async Task UpdateStockAsync(string productId, int newQuantity)
        {
            string endpoint = $"/api/inventory/update";
            var payload = new StringContent($"{{\"id\":\"{productId}\",\"qty\":{newQuantity}}}", Encoding.UTF8, "application/json");

            for (int attempt = 1; attempt <= _maxRetries; attempt++)
            {
                try
                {
                    Console.WriteLine($"Attempt {attempt}/{_maxRetries} to update {productId}...");
                    
                    // Simulate a transient error on the first attempt
                    if (attempt == 1) 
                    {
                        Console.WriteLine("   (Simulating network timeout...)");
                        throw new HttpRequestException("The remote server is not responding");
                    }

                    HttpResponseMessage response = await _httpClient.PutAsync(endpoint, payload);

                    if (response.IsSuccessStatusCode)
                    {
                        return; // Success
                    }
                }
                catch (HttpRequestException)
                {
                    // If this is the last attempt, rethrow the exception
                    if (attempt == _maxRetries)
                    {
                        throw new HttpRequestException("Update failed after all retry attempts.");
                    }
                    
                    // Exponential Backoff Simulation:
                    // Wait longer between retries to give the server time to recover.
                    int delay = 500 * attempt; 
                    Console.WriteLine($"   Waiting {delay}ms before retry...");
                    await Task.Delay(delay);
                }
            }
        }
    }

    // ---------------------------------------------------------
    // CONCEPT: IHttpClientFactory Implementation
    // ---------------------------------------------------------
    // In a real ASP.NET Core app, this is handled by the built-in DI container.
    // We implement a mock factory here to demonstrate how the client is configured.
    public interface IHttpClientFactory
    {
        HttpClient CreateClient(string name);
    }

    public class MockHttpClientFactory : IHttpClientFactory
    {
        public HttpClient CreateClient(string name)
        {
            // Create a handler that simulates the backend API responses.
            var handler = new MockHttpMessageHandler();
            var client = new HttpClient(handler)
            {
                // Base Address configuration
                BaseAddress = new Uri("https://api.warehouse.local")
            };

            // Standard headers configuration
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            
            return client;
        }
    }

    // ---------------------------------------------------------
    // MOCK INFRASTRUCTURE
    // ---------------------------------------------------------
    // Simulates the remote ASP.NET Core Web API.
    // This allows the code to run without an actual external server.
    public class MockHttpMessageHandler : HttpMessageHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            // Simulate network latency
            await Task.Delay(100, cancellationToken);

            var uri = request.RequestUri;
            var method = request.Method;

            // Logic for GET /api/inventory/{id}
            if (method == HttpMethod.Get && uri.AbsolutePath.StartsWith("/api/inventory/"))
            {
                var id = uri.AbsolutePath.Replace("/api/inventory/", "");
                if (id == "PROD-001")
                    return new HttpResponseMessage(System.Net.HttpStatusCode.OK) { Content = new StringContent("100") };
                if (id == "PROD-002")
                    return new HttpResponseMessage(System.Net.HttpStatusCode.OK) { Content = new StringContent("25") };
                
                // Simulate Not Found
                return new HttpResponseMessage(System.Net.HttpStatusCode.NotFound);
            }

            // Logic for PUT /api/inventory/update
            if (method == HttpMethod.Put && uri.AbsolutePath == "/api/inventory/update")
            {
                // Simulate Accepted
                return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);
            }

            return new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
        }
    }
}
