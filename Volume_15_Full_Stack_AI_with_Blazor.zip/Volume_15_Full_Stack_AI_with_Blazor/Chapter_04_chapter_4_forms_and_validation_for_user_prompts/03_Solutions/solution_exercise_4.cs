
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// 1. Data Models
public enum FieldType { String, Integer, Boolean, Complex }

public class SchemaField
{
    public string Name { get; set; } = string.Empty;
    public FieldType Type { get; set; }
    public List<SchemaField> Properties { get; set; } = new(); // For Complex types
    public bool IsRequired { get; set; }
}

// 2. Reusable Child Component (SchemaFieldEditor.razor)
@using System.Text.Json

<div class="card mb-2 p-2 border">
    <div class="row g-2 align-items-center">
        <div class="col-md-3">
            <input type="text" class="form-control" @bind="Field.Name" @bind:event="oninput" 
                   placeholder="Field Name" />
            @if (IsDuplicate)
            {
                <div class="text-danger small">Duplicate name</div>
            }
        </div>
        <div class="col-md-2">
            <select class="form-select" @bind="Field.Type">
                @foreach (var t in Enum.GetValues<FieldType>())
                {
                    <option value="@t">@t</option>
                }
            </select>
        </div>
        <div class="col-md-2 form-check">
            <input type="checkbox" class="form-check-input" @bind="Field.IsRequired" />
            <label class="form-check-label">Required</label>
        </div>
        <div class="col-md-2">
            <button type="button" class="btn btn-sm btn-danger" @onclick="OnRemove">Remove</button>
        </div>
    </div>

    @if (Field.Type == FieldType.Complex)
    {
        <div class="ms-4 mt-2 border-start border-primary">
            <small class="text-muted">Nested Properties:</small>
            @foreach (var prop in Field.Properties)
            {
                <SchemaFieldEditor Field="prop" OnRemove="() => RemoveProperty(prop)" 
                                   AllFields="AllFields" /> 
            }
            <button type="button" class="btn btn-sm btn-outline-primary mt-1" @onclick="AddProperty">+ Add Property</button>
        </div>
    }
</div>

@code {
    [Parameter] public SchemaField Field { get; set; } = null!;
    [Parameter] public EventCallback OnRemove { get; set; }
    [Parameter] public List<SchemaField> AllFields { get; set; } = null!; // Reference for duplicate check

    // Check for duplicates within the immediate parent's scope
    public bool IsDuplicate => AllFields.Count(f => f.Name == Field.Name) > 1;

    private void AddProperty() => Field.Properties.Add(new SchemaField());
    private void RemoveProperty(SchemaField prop) => Field.Properties.Remove(prop);
}

// 3. Main Component (SchemaBuilder.razor)
@page "/schema-builder"
@using System.Text.Json
@using System.Text.Json.Nodes

<h3>JSON Schema Builder</h3>

<div class="row">
    <div class="col-md-6">
        <h5>Definition</h5>
        <button class="btn btn-sm btn-success mb-2" @onclick="AddField">+ Add Root Field</button>
        
        @foreach (var field in rootFields)
        {
            <SchemaFieldEditor Field="field" OnRemove="() => RemoveField(field)" AllFields="rootFields" />
        }

        <hr />
        <label>Import from JSON (Paste object)</label>
        <textarea class="form-control" rows="4" @bind="importJson" placeholder="{ 'name': 'test', 'age': 30 }"></textarea>
        <button class="btn btn-secondary mt-2" @onclick="ParseImport">Import</button>
        @if (!string.IsNullOrEmpty(importError))
        {
            <div class="text-danger mt-1">@importError</div>
        }
    </div>

    <div class="col-md-6">
        <h5>Generated JSON Schema</h5>
        <textarea class="form-control bg-dark text-light" rows="20" readonly>@generatedSchema</textarea>
    </div>
</div>

@code {
    private List<SchemaField> rootFields = new();
    private string generatedSchema = "{}";
    private string importJson = "";
    private string importError = "";

    protected override void OnInitialized() => AddField();

    private void AddField() => rootFields.Add(new SchemaField());
    private void RemoveField(SchemaField field) => rootFields.Remove(field);

    // Recursively generate JSON Schema
    protected override void OnParametersSet()
    {
        var schemaObj = new Dictionary<string, object>
        {
            ["type"] = "object",
            ["properties"] = new Dictionary<string, object>(),
            ["required"] = new List<string>()
        };

        var props = (Dictionary<string, object>)schemaObj["properties"];
        var reqs = (List<string>)schemaObj["required"];

        BuildSchema(rootFields, props, reqs);

        var options = new JsonSerializerOptions { WriteIndented = true };
        generatedSchema = JsonSerializer.Serialize(schemaObj, options);
    }

    private void BuildSchema(List<SchemaField> fields, Dictionary<string, object> props, List<string> reqs)
    {
        foreach (var field in fields)
        {
            if (string.IsNullOrWhiteSpace(field.Name)) continue;

            var fieldDef = new Dictionary<string, object>();
            
            if (field.Type == FieldType.Complex)
            {
                fieldDef["type"] = "object";
                var nestedProps = new Dictionary<string, object>();
                var nestedReqs = new List<string>();
                BuildSchema(field.Properties, nestedProps, nestedReqs);
                fieldDef["properties"] = nestedProps;
                if (nestedReqs.Count > 0) fieldDef["required"] = nestedReqs;
            }
            else
            {
                fieldDef["type"] = field.Type.ToString().ToLower();
            }

            props[field.Name] = fieldDef;
            if (field.IsRequired) reqs.Add(field.Name);
        }
    }

    private void ParseImport()
    {
        importError = "";
        try
        {
            if (string.IsNullOrWhiteSpace(importJson)) return;
            
            // Parse the JSON object to infer structure
            using JsonDocument doc = JsonDocument.Parse(importJson);
            rootFields.Clear();
            
            // Simple inference for root level properties
            if (doc.RootElement.ValueKind == JsonValueKind.Object)
            {
                foreach (var prop in doc.RootElement.EnumerateObject())
                {
                    var field = new SchemaField { Name = prop.Name };
                    InferType(prop.Value, field);
                    rootFields.Add(field);
                }
            }
        }
        catch (Exception ex)
        {
            importError = $"Parsing failed: {ex.Message}";
        }
    }

    private void InferType(JsonElement element, SchemaField field)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.String:
                field.Type = FieldType.String;
                break;
            case JsonValueKind.Number:
                field.Type = FieldType.Integer;
                break;
            case JsonValueKind.True:
            case JsonValueKind.False:
                field.Type = FieldType.Boolean;
                break;
            case JsonValueKind.Object:
                field.Type = FieldType.Complex;
                foreach (var prop in element.EnumerateObject())
                {
                    var nestedField = new SchemaField { Name = prop.Name };
                    InferType(prop.Value, nestedField);
                    field.Properties.Add(nestedField);
                }
                break;
            default:
                field.Type = FieldType.String;
                break;
        }
    }
}
