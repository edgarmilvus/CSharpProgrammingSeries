
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// 1. Model with Data Annotations
using System.ComponentModel.DataAnnotations;

public class SearchQueryModel
{
    [Required(ErrorMessage = "Search query is required.")]
    [StringLength(500, MinimumLength = 10, ErrorMessage = "Query must be between 10 and 500 characters.")]
    public string QueryText { get; set; } = string.Empty;

    // Property to control validation behavior
    public bool AllowWildcard { get; set; } = false;
}

// 2. Custom Validation Attribute
using System.ComponentModel.DataAnnotations;
using System.Linq;

public class NoSpecialOperatorsAttribute : ValidationAttribute
{
    // Define forbidden characters
    private static readonly char[] ForbiddenChars = { '*', '?', '+', '&', '|', '!', '(', ')', '{', '}', '[', ']', '^', '"', '~', ':', '\\', '/' };

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value is not string queryString) return ValidationResult.Success;

        // Get the model instance to check the AllowWildcard property
        if (validationContext.ObjectInstance is SearchQueryModel model)
        {
            var charsToCheck = ForbiddenChars;
            
            // If wildcards are allowed, filter them out from the check
            if (model.AllowWildcard)
            {
                charsToCheck = ForbiddenChars.Where(c => c != '*' && c != '?').ToArray();
            }

            var foundChars = queryString.Where(c => charsToCheck.Contains(c)).Distinct().ToArray();

            if (foundChars.Length > 0)
            {
                return new ValidationResult(
                    $"The query contains forbidden special operators: {string.Join(", ", foundChars)}");
            }
        }

        return ValidationResult.Success;
    }
}

// 3. Blazor Component (SearchQueryForm.razor)
@page "/search-query"
@using System.ComponentModel.DataAnnotations

<h3>Semantic Search Validator</h3>

<EditForm Model="@model" OnValidSubmit="@HandleValidSubmit" Context="editContext">
    <DataAnnotationsValidator />
    
    <div class="form-group mb-3">
        <label>Search Query:</label>
        <InputText @bind-Value="model.QueryText" class="form-control" disabled="@isSubmitting" />
        <ValidationMessage For="@(() => model.QueryText)" />
    </div>

    <div class="form-group mb-3 form-check">
        <InputCheckbox @bind-Value="model.AllowWildcard" id="allowWildcard" class="form-check-input" disabled="@isSubmitting" />
        <label for="allowWildcard" class="form-check-label">Allow Wildcards (* and ?)</label>
    </div>

    <button type="submit" class="btn btn-primary" disabled="@isSubmitting">
        @if (isSubmitting)
        {
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            <span> Searching...</span>
        }
        else
        {
            <span>Search</span>
        }
    </button>

    @if (successMessage != null)
    {
        <div class="alert alert-success mt-3">@successMessage</div>
    }
</EditForm>

@code {
    private SearchQueryModel model = new();
    private bool isSubmitting = false;
    private string? successMessage;

    private async Task HandleValidSubmit()
    {
        isSubmitting = true;
        successMessage = null;
        StateHasChanged(); // Ensure UI updates immediately

        // Simulate API call
        await Task.Delay(2000);

        successMessage = "Search completed successfully!";
        isSubmitting = false;
    }
}
