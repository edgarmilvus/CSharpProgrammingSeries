
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// 1. Token Service Interface
public interface ITokenService
{
    int EstimateTokenCount(string text);
}

// 2. Token Service Implementation
public class TokenService : ITokenService
{
    // Heuristic: 1 token ~= 4 chars
    public int EstimateTokenCount(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return 0;
        return (int)Math.Ceiling(text.Length / 4.0);
    }
}

// 3. Scoped State Service for Debouncing
using System.Reactive.Linq;
using System.Reactive.Subjects;

public class TokenStateService : IDisposable
{
    private readonly ITokenService _tokenService;
    private readonly Subject<(string Context, string Prompt)> _inputSubject;
    private IDisposable _subscription;

    public event Action<(int Context, int Prompt, int Total)>? OnTokensCalculated;

    public TokenStateService(ITokenService tokenService)
    {
        _tokenService = tokenService;
        _inputSubject = new Subject<(string, string)>();

        // Debounce: Wait 500ms after the last input
        _subscription = _inputSubject
            .Throttle(TimeSpan.FromMilliseconds(500))
            .Subscribe(tuple =>
            {
                var ctxTokens = _tokenService.EstimateTokenCount(tuple.Context);
                var promptTokens = _tokenService.EstimateTokenCount(tuple.Prompt);
                OnTokensCalculated?.Invoke((ctxTokens, promptTokens, ctxTokens + promptTokens));
            });
    }

    public void UpdateInput(string context, string prompt)
    {
        _inputSubject.OnNext((context, prompt));
    }

    public void Dispose()
    {
        _subscription?.Dispose();
        _inputSubject?.Dispose();
    }
}

// 4. Blazor Component (TokenForm.razor)
@page "/token-manager"
@inject ITokenService TokenService
@inject TokenStateService StateService
@implements IDisposable

<h3>Token Budget Manager (Max: 4096)</h3>

<div class="row">
    <div class="col-md-6">
        <label>Context (Document)</label>
        <textarea class="form-control" rows="10" @bind="contextText" @bind:event="oninput" 
                  placeholder="Paste your document here..."></textarea>
    </div>
    <div class="col-md-6">
        <label>Prompt</label>
        <textarea class="form-control" rows="10" @bind="promptText" @bind:event="oninput" 
                  placeholder="Enter your instruction..."></textarea>
    </div>
</div>

<div class="mt-3">
    <div class="d-flex justify-content-between">
        <span>Context Tokens: @contextTokens</span>
        <span>Prompt Tokens: @promptTokens</span>
        <strong>Total: @totalTokens / 4096</strong>
    </div>
    
    <!-- Visual Feedback -->
    @{
        var percentage = (double)totalTokens / 4096;
        var color = percentage > 1 ? "bg-danger" : (percentage > 0.8 ? "bg-warning" : "bg-success");
    }
    <div class="progress mt-2" style="height: 20px;">
        <div class="progress-bar @color" role="progressbar" style="width: @(Math.Min(percentage * 100, 100))%">
            @(percentage * 100)%
        </div>
    </div>
    
    @if (totalTokens > 4096)
    {
        <div class="text-danger mt-2">Error: Token limit exceeded!</div>
    }
</div>

@code {
    private string contextText = "";
    private string promptText = "";
    
    private int contextTokens;
    private int promptTokens;
    private int totalTokens;

    protected override void OnInitialized()
    {
        // Subscribe to the debounced calculation results
        StateService.OnTokensCalculated += HandleTokenUpdate;
    }

    // Trigger the service on every keystroke (debouncing happens inside the service)
    protected override void OnAfterRender(bool firstRender)
    {
        StateService.UpdateInput(contextText, promptText);
    }

    private void HandleTokenUpdate((int Context, int Prompt, int Total) data)
    {
        contextTokens = data.Context;
        promptTokens = data.Prompt;
        totalTokens = data.Total;
        StateHasChanged(); // Update UI after calculation
    }

    public void Dispose()
    {
        StateService.OnTokensCalculated -= HandleTokenUpdate;
    }
}
