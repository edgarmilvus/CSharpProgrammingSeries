
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

// 1. Mock Service Interface
public interface IRelevanceService
{
    Task<bool> IsRelevantAsync(string prompt, CancellationToken ct);
}

// 2. Mock Service Implementation
public class MockRelevanceService : IRelevanceService
{
    public async Task<bool> IsRelevantAsync(string prompt, CancellationToken ct)
    {
        // Simulate network delay
        await Task.Delay(800, ct);

        // Simple domain check
        var forbiddenTerms = new[] { "cooking", "recipes", "food" };
        return !forbiddenTerms.Any(term => prompt.ToLower().Contains(term));
    }
}

// 3. Blazor Component (RelevanceCheckForm.razor)
@page "/relevance-check"
@inject IRelevanceService RelevanceService

<h3>Context Relevance Validator</h3>

<EditForm Model="@model" OnValidSubmit="@HandleSubmit">
    <div class="form-group mb-3">
        <label>User Prompt:</label>
        <InputText @bind-Value="model.Prompt" @bind:event="oninput" class="form-control" disabled="@isChecking" />
    </div>

    <div class="d-flex align-items-center gap-2">
        <button type="submit" class="btn btn-primary" disabled="@isChecking || !isRelevant">
            @if (isChecking)
            {
                <span class="spinner-border spinner-border-sm"></span> <span>Checking...</span>
            }
            else
            {
                <span>Submit</span>
            }
        </button>

        @if (showStatus)
        {
            @if (isRelevant)
            {
                <span class="text-success">✔ Relevant</span>
            }
            else
            {
                <span class="text-danger">❌ Unrelated to Domain</span>
            }
        }
    </div>
</EditForm>

@if (submissionMessage != null)
{
    <div class="alert alert-info mt-3">@submissionMessage</div>
}

@code {
    private PromptModel model = new();
    private bool isChecking;
    private bool isRelevant = false; // Default to invalid until checked
    private bool showStatus = false;
    private string? submissionMessage;
    
    private CancellationTokenSource? _cts;

    private async Task HandleSubmit()
    {
        if (!isRelevant) return;
        submissionMessage = "Submitting to AI...";
        await Task.Delay(1000); // Simulate processing
        submissionMessage = "Success! Query processed.";
    }

    // We hook into the property setter or use an event handler for the InputText
    // Since InputText doesn't expose OnInput easily in EditForm context without custom binding,
    // we use a separate method invoked by the component lifecycle or a wrapper.
    // However, Blazor EditForm InputText usually binds via Value. 
    // To capture OnInput event, we might need to use plain <input> or a custom component.
    // Here, we will override OnParametersSet to watch the model.Prompt changes, 
    // but strictly speaking, we need an event. Let's use a timer pattern in a loop or a debounce service.
    
    // Better Approach for Debounce in Code-Behind:
    private System.Timers.Timer? _debounceTimer;

    protected override void OnInitialized()
    {
        _debounceTimer = new System.Timers.Timer(800);
        _debounceTimer.Elapsed += async (s, e) => 
        {
            _debounceTimer.Stop();
            await InvokeAsync(async () => await CheckRelevance());
        };
    }

    // We need to detect changes to model.Prompt. 
    // Since we are using EditForm, we can't easily hook 'oninput' in code behind without a custom event.
    // For this exercise, we will modify the UI to use a standard input with an oninput handler 
    // that calls a C# method, bypassing EditForm's InputText for the sake of the event.
    
    private async Task OnPromptInput(ChangeEventArgs e)
    {
        model.Prompt = e.Value?.ToString() ?? "";
        
        // Cancel previous check
        _cts?.Cancel();
        _cts = new CancellationTokenSource();

        // Reset status
        showStatus = false;
        isChecking = true;

        // Restart debounce timer
        _debounceTimer.Stop();
        _debounceTimer.Start();
    }

    private async Task CheckRelevance()
    {
        if (string.IsNullOrWhiteSpace(model.Prompt)) 
        {
            isChecking = false;
            return;
        }

        try
        {
            // Call the service
            isRelevant = await RelevanceService.IsRelevantAsync(model.Prompt, _cts.Token);
            showStatus = true;
        }
        catch (TaskCanceledException)
        {
            // Previous request was cancelled, do nothing
            return;
        }
        finally
        {
            isChecking = false;
            StateHasChanged();
        }
    }

    public void Dispose()
    {
        _debounceTimer?.Dispose();
        _cts?.Dispose();
    }

    public class PromptModel { public string Prompt { get; set; } = ""; }
}
