
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// 1. Model (Simplified for FluentValidation)
public class SupportTicket
{
    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public int Priority { get; set; }
    public bool IsCritical { get; set; }
}

// 2. FluentValidation Validator
using FluentValidation;

public class TicketValidator : AbstractValidator<SupportTicket>
{
    public TicketValidator()
    {
        // Step 1 Rules
        RuleFor(x => x.Subject).NotEmpty().Length(5, 100);
        RuleFor(x => x.Description).NotEmpty().MinimumLength(10);

        // Step 2 Rules
        RuleFor(x => x.Category).NotEmpty();

        // Step 3 Rules (Conditional Logic)
        RuleFor(x => x.Priority)
            .GreaterThan(0).LessThanOrEqualTo(10)
            .When(x => !x.IsCritical)
            .WithMessage("Priority must be between 1 and 10.");

        RuleFor(x => x.Priority)
            .GreaterThan(8)
            .When(x => x.IsCritical)
            .WithMessage("Critical tickets must have priority > 8.");
    }
}

// 3. Blazor Component (TicketForm.razor)
@page "/ticket-form"
@using FluentValidation.Blazor

<h3>Support Ticket Submission</h3>

<div class="mb-3">
    <span>Step @currentStep of 3</span>
    <div class="progress">
        <div class="progress-bar" style="width: @(currentStep * 33)%"></div>
    </div>
</div>

<EditForm Model="@ticket" OnValidSubmit="@HandleValidSubmit">
    <!-- Using FluentValidationValidator instead of DataAnnotationsValidator -->
    <FluentValidationValidator ValidatorType="typeof(TicketValidator)" />
    
    <!-- Step 1: Subject & Description -->
    @if (currentStep == 1)
    {
        <div class="form-group mb-3">
            <label>Subject</label>
            <InputText @bind-Value="ticket.Subject" class="form-control" />
            <ValidationMessage For="@(() => ticket.Subject)" />
        </div>
        <div class="form-group mb-3">
            <label>Description</label>
            <InputTextArea @bind-Value="ticket.Description" class="form-control" />
            <ValidationMessage For="@(() => ticket.Description)" />
        </div>
    }

    <!-- Step 2: Category -->
    @if (currentStep == 2)
    {
        <div class="form-group mb-3">
            <label>Category</label>
            <InputSelect @bind-Value="ticket.Category" class="form-select">
                <option value="">Select...</option>
                @foreach (var cat in categories)
                {
                    <option value="@cat">@cat</option>
                }
            </InputSelect>
            <ValidationMessage For="@(() => ticket.Category)" />
        </div>
    }

    <!-- Step 3: Priority & Urgency -->
    @if (currentStep == 3)
    {
        <div class="form-group mb-3 form-check">
            <InputCheckbox @bind-Value="ticket.IsCritical" class="form-check-input" />
            <label class="form-check-label">Is Critical?</label>
        </div>
        
        <div class="form-group mb-3">
            <label>Priority: @ticket.Priority</label>
            <input type="range" min="1" max="10" @bind="ticket.Priority" @bind:event="oninput" class="form-range" />
            <ValidationMessage For="@(() => ticket.Priority)" />
        </div>
    }

    <div class="d-flex justify-content-between">
        @if (currentStep > 1)
        {
            <button type="button" class="btn btn-secondary" @onclick="PrevStep">Previous</button>
        }
        else
        {
            <div></div>
        }

        @if (currentStep < 3)
        {
            <button type="button" class="btn btn-primary" @onclick="NextStep">Next</button>
        }
        else
        {
            <button type="submit" class="btn btn-success">Submit Ticket</button>
        }
    </div>
</EditForm>

@code {
    private SupportTicket ticket = new();
    private int currentStep = 1;
    private List<string> categories = new();

    protected override async Task OnInitializedAsync()
    {
        // Simulate fetching categories
        await Task.Delay(500);
        var json = @"[""Billing"", ""Technical Support"", ""Account Management""]";
        categories = System.Text.Json.JsonSerializer.Deserialize<List<string>>(json) ?? new();
    }

    private void NextStep()
    {
        // Manually trigger validation for the current step
        // In a real app, you might split validators by step or check specific properties
        // Here we rely on the UI showing errors, but for navigation we check if the specific step properties are valid.
        // Since FluentValidation validates the whole object, we check specific field validity.
        
        bool isValid = false;
        if (currentStep == 1) isValid = !string.IsNullOrWhiteSpace(ticket.Subject) && ticket.Subject.Length >= 5 && !string.IsNullOrWhiteSpace(ticket.Description);
        if (currentStep == 2) isValid = !string.IsNullOrWhiteSpace(ticket.Category);
        
        if (isValid) currentStep++;
    }

    private void PrevStep() => currentStep--;

    private void HandleValidSubmit()
    {
        // Handle submission
        Console.WriteLine("Ticket Submitted");
    }
}
