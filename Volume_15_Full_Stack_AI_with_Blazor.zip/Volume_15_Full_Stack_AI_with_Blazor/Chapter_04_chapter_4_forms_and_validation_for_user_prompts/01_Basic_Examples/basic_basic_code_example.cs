
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/copilot-chat"
@using System.ComponentModel.DataAnnotations

<h3>AI Copilot Chat</h3>

<EditForm Model="@PromptModel" OnValidSubmit="@HandleValidSubmit" FormName="CopilotPromptForm">
    <DataAnnotationsValidator />
    <ValidationSummary />

    <div class="form-group">
        <label for="promptInput">Ask the AI:</label>
        <InputText id="promptInput" @bind-Value="PromptModel.Prompt" class="form-control" 
                   disabled="@IsProcessing" placeholder="Type your question here..." />
    </div>

    <button type="submit" class="btn btn-primary mt-2" disabled="@IsProcessing">
        @if (IsProcessing)
        {
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            <span> Processing...</span>
        }
        else
        {
            <span>Send to AI</span>
        }
    </button>
</EditForm>

@if (AIResponse != null)
{
    <div class="alert alert-success mt-3" role="alert">
        <strong>AI Response:</strong>
        <p>@AIResponse</p>
    </div>
}

@code {
    // 1. The State Container
    [SupplyParameterFromForm(FormName = "CopilotPromptForm")]
    public PromptModel PromptModel { get; set; } = new();

    // 2. UI State Flags
    public bool IsProcessing { get; set; }
    public string? AIResponse { get; set; }

    // 3. The Submission Handler
    private async Task HandleValidSubmit()
    {
        IsProcessing = true;
        AIResponse = null;

        try
        {
            // Simulate an async AI API call
            await Task.Delay(2000); 
            
            AIResponse = $"Processed: '{PromptModel.Prompt}'";
            
            // Optional: Reset input after successful submission
            PromptModel.Prompt = string.Empty; 
        }
        finally
        {
            IsProcessing = false;
        }
    }

    // 4. The Validation Logic (Data Annotation)
    public class PromptModel
    {
        [Required(ErrorMessage = "Prompt cannot be empty. The AI needs something to work with.")]
        [StringLength(500, MinimumLength = 3, ErrorMessage = "Prompt must be between 3 and 500 characters.")]
        public string Prompt { get; set; } = "";
    }
}
