
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace AI_Copilot_Prompt_Validator
{
    // 1. DATA MODELS: Represents the data structure for a user prompt request.
    // We use basic classes to encapsulate data, mimicking the data transfer objects (DTOs) 
    // often used in Blazor forms (EditForm models).
    public class PromptRequest
    {
        public string UserInput { get; set; }
        public string ContextTags { get; set; }
        public int MaxTokens { get; set; }
        public bool IsSensitive { get; set; }
    }

    // 2. VALIDATION RESULT: A container for validation errors.
    // This mimics the Blazor ValidationSummary component logic but implemented manually for a console app.
    public class ValidationResult
    {
        public bool IsValid { get; set; } = true;
        public List<string> Errors { get; set; } = new List<string>();

        public void AddError(string error)
        {
            Errors.Add(error);
            IsValid = false;
        }
    }

    // 3. CORE LOGIC: The Prompt Validator Service.
    // This class contains the business logic that would typically reside in a Blazor component's code-behind
    // or a shared service library.
    public class PromptValidatorService
    {
        // Constants defining AI constraints (mimicking DataAnnotation attributes)
        private const int MIN_PROMPT_LENGTH = 5;
        private const int MAX_PROMPT_LENGTH = 500;
        private const int MAX_TOKEN_LIMIT = 2048;
        private const int MAX_CONTEXT_TAGS = 5;

        /// <summary>
        /// Validates the prompt request against AI-specific constraints.
        /// </summary>
        public ValidationResult ValidatePrompt(PromptRequest request)
        {
            ValidationResult result = new ValidationResult();

            // A. Null and Empty Checks (Basic Data Integrity)
            if (string.IsNullOrWhiteSpace(request.UserInput))
            {
                result.AddError("Prompt cannot be empty.");
            }
            else
            {
                // B. Length Constraints (Token Estimation)
                // In a real AI app, tokens are calculated differently, but length is a good proxy for this example.
                if (request.UserInput.Length < MIN_PROMPT_LENGTH)
                {
                    result.AddError($"Prompt is too short. Minimum {MIN_PROMPT_LENGTH} characters required.");
                }

                if (request.UserInput.Length > MAX_PROMPT_LENGTH)
                {
                    result.AddError($"Prompt exceeds maximum length ({MAX_PROMPT_LENGTH} chars). Please be more concise.");
                }
            }

            // C. Numeric Range Validation
            if (request.MaxTokens <= 0 || request.MaxTokens > MAX_TOKEN_LIMIT)
            {
                result.AddError($"MaxTokens must be between 1 and {MAX_TOKEN_LIMIT}.");
            }

            // D. Complex Logic: Context Tag Parsing and Validation
            // This simulates handling a comma-separated list of tags in a form field.
            if (!string.IsNullOrWhiteSpace(request.ContextTags))
            {
                string[] tags = request.ContextTags.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                
                if (tags.Length > MAX_CONTEXT_TAGS)
                {
                    result.AddError($"Too many context tags. Maximum allowed is {MAX_CONTEXT_TAGS}.");
                }

                // E. Custom Pattern Matching (Simulating Regex or specific format validation)
                foreach (string tag in tags)
                {
                    string cleanTag = tag.Trim();
                    if (cleanTag.Length < 2)
                    {
                        result.AddError($"Tag '{cleanTag}' is too short (min 2 chars).");
                    }
                    if (cleanTag.Contains(" "))
                    {
                        result.AddError($"Tag '{cleanTag}' cannot contain spaces.");
                    }
                }
            }

            // F. Conditional Validation (Business Rule)
            // If the request is marked as sensitive, we might enforce stricter token limits or content checks.
            if (request.IsSensitive && request.MaxTokens > 500)
            {
                result.AddError("Sensitive requests are limited to 500 tokens for security.");
            }

            return result;
        }

        /// <summary>
        /// Simulates the asynchronous submission of the prompt to an AI model.
        /// In Blazor, this would be an 'async Task' method called by an 'OnValidSubmit' handler.
        /// </summary>
        public async Task<string> SubmitPromptAsync(PromptRequest request)
        {
            // Simulate network latency (I/O bound operation)
            await Task.Delay(1500); 

            // Mock AI Response Generation
            StringBuilder response = new StringBuilder();
            response.AppendLine("AI Response Generated:");
            response.AppendLine($"- Context: {request.ContextTags}");
            response.AppendLine($"- Tokens Used: {request.MaxTokens / 2} (Simulated)");
            response.AppendLine($"- Input Processed: '{request.UserInput}'");
            
            if (request.IsSensitive)
            {
                response.AppendLine("- Security Flag: Applied encryption to output.");
            }

            return response.ToString();
        }
    }

    // 4. MAIN APPLICATION: The Console User Interface
    // This simulates the Blazor UI lifecycle: Input -> Validation -> State Change -> Output.
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== AI Copilot Prompt Validator Console App ===");
            Console.WriteLine("Simulating Blazor EditForm & Validation Logic\n");

            PromptValidatorService validator = new PromptValidatorService();
            bool keepRunning = true;

            while (keepRunning)
            {
                // 1. COLLECT USER INPUT (Simulating Form Inputs)
                PromptRequest currentRequest = new PromptRequest();

                Console.WriteLine("\n--- New Prompt Request ---");
                
                Console.Write("Enter User Prompt: ");
                currentRequest.UserInput = Console.ReadLine();

                Console.Write("Enter Context Tags (comma separated): ");
                currentRequest.ContextTags = Console.ReadLine();

                Console.Write("Max Tokens (e.g., 1024): ");
                string tokenInput = Console.ReadLine();
                // Basic parsing with error handling
                if (!int.TryParse(tokenInput, out currentRequest.MaxTokens))
                {
                    currentRequest.MaxTokens = 0; // Force validation failure
                }

                Console.Write("Is Sensitive? (y/n): ");
                string sensitiveInput = Console.ReadLine();
                currentRequest.IsSensitive = (sensitiveInput?.ToLower() == "y");

                // 2. RUN VALIDATION LOGIC
                // This mimics the Blazor DataAnnotationsValidator processing the model state.
                ValidationResult validation = validator.ValidatePrompt(currentRequest);

                // 3. HANDLE VALIDATION STATE
                if (!validation.IsValid)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n[VALIDATION FAILED]");
                    foreach (string error in validation.Errors)
                    {
                        Console.WriteLine($" - {error}");
                    }
                    Console.ResetColor();
                    Console.WriteLine("\nPlease correct the errors and try again.");
                    continue; // Skip submission
                }

                // 4. HANDLE SUBMISSION STATE (Loading/Processing)
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n[SUBMITTING...] Please wait while the AI processes your request.");
                Console.ResetColor();

                // Call the async service method
                string aiResult = await validator.SubmitPromptAsync(currentRequest);

                // 5. DISPLAY RESULT
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n[SUCCESS]");
                Console.WriteLine(aiResult);
                Console.ResetColor();

                // 6. LOOP CONTROL
                Console.Write("\nSubmit another prompt? (y/n): ");
                if (Console.ReadLine()?.ToLower() != "y")
                {
                    keepRunning = false;
                }
            }

            Console.WriteLine("\nApplication terminated.");
        }
    }
}
