
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/local-chat"
@using Microsoft.ML.OnnxRuntime
@using Microsoft.ML.OnnxRuntime.Tensors
@inject IJSRuntime JS

<h3>Private Local Chatbot (ONNX)</h3>

<div class="chat-container">
    @foreach (var msg in chatHistory)
    {
        <div class="message @msg.Sender">
            <strong>@msg.Sender:</strong> @msg.Text
        </div>
    }
</div>

<div class="input-area">
    <input @bind="userInput" placeholder="Type a message..." disabled="@isGenerating" />
    <button @onclick="SendMessageAsync" disabled="@isGenerating">Send</button>
</div>

@if (isGenerating)
{
    <div class="status">Generating locally...</div>
}

@code {
    // 1. State Management
    private string userInput = "";
    private bool isGenerating = false;
    private List<ChatMessage> chatHistory = new();
    private InferenceSession? _session; // ONNX Runtime Session

    // 2. Define a simple Message structure
    public class ChatMessage
    {
        public string Sender { get; set; } = "User";
        public string Text { get; set; } = "";
    }

    // 3. Lifecycle: Initialize the model
    protected override async Task OnInitializedAsync()
    {
        // In a real app, you would download the .onnx model file via HTTP first.
        // For this "Hello World", we simulate loading a model stream.
        // We assume the model file is located at "wwwroot/models/gpt2.onnx"
        
        try 
        {
            // NOTE: In Blazor WASM, we often load the model bytes directly into memory
            // or use specific WASM-compatible ONNX Runtime bindings.
            // Here we simulate the session creation.
            
            // Simulate loading delay
            await Task.Delay(1000); 
            
            // _session = new InferenceSession(modelBytes); 
            // For this example code to compile without the actual heavy model file, 
            // we will mock the session object.
            _session = new InferenceSession(); // Mock constructor
            
            chatHistory.Add(new ChatMessage { 
                Sender = "Bot", 
                Text = "Model loaded locally. Ready for private chat." 
            });
        }
        catch (Exception ex)
        {
            chatHistory.Add(new ChatMessage { 
                Sender = "System", 
                Text = $"Error loading model: {ex.Message}" 
            });
        }
    }

    // 4. Core Logic: Handle User Input and Generation
    private async Task SendMessageAsync()
    {
        if (string.IsNullOrWhiteSpace(userInput) || _session == null) return;

        // Add user message to UI
        chatHistory.Add(new ChatMessage { Sender = "User", Text = userInput });
        string currentPrompt = userInput;
        userInput = ""; // Clear input
        isGenerating = true;
        
        // Force UI update to show user message immediately
        StateHasChanged();

        try
        {
            // RUN THE MODEL LOCALLY
            // We offload the heavy computation to a background thread to prevent UI freezing
            string botResponse = await Task.Run(() => RunInferenceLocally(currentPrompt));

            // Add bot response to UI
            chatHistory.Add(new ChatMessage { Sender = "Bot", Text = botResponse });
        }
        catch (Exception ex)
        {
            chatHistory.Add(new ChatMessage { Sender = "System", Text = $"Generation Error: {ex.Message}" });
        }
        finally
        {
            isGenerating = false;
        }
    }

    // 5. The Inference Logic (Mocked for this example)
    private string RunInferenceLocally(string prompt)
    {
        // In a real scenario, this method performs:
        // 1. Tokenization (converting text to numbers)
        // 2. Input Tensor creation (preparing data for the neural network)
        // 3. Session.Run() (Executing the ONNX model)
        // 4. Decoding (Converting numbers back to text)

        // SIMULATED EXECUTION:
        // We pretend to run the model for 2 seconds to show non-blocking UI
        Thread.Sleep(2000); 

        // Simulated response based on prompt
        if (prompt.ToLower().Contains("hello"))
            return "Hello! I am running entirely inside your browser.";
        
        return "I processed your request locally. No data left your device.";
    }
}
