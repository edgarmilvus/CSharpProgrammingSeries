
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

// NAMESPACE: LocalFirstAI
// PURPOSE: Encapsulates the logic for a private, offline chatbot that simulates
// the core principles of ONNX Runtime integration and local state management.
// This console application demonstrates how to handle model inference,
// manage conversation history, and process user input without external APIs.
namespace LocalFirstAI
{
    // CLASS: LocalChatSession
    // RESPONSIBILITY: Manages the lifecycle of a single chat conversation.
    // It holds the context (history), handles the "inference" (simulated here),
    // and persists data to the local file system, mimicking browser LocalStorage.
    public class LocalChatSession
    {
        // Stores the conversation history. In a real ONNX scenario, this would be
        // tokenized and passed to the model's input tensor.
        private readonly StringBuilder _conversationHistory;
        private readonly string _storagePath;

        public LocalChatSession(string sessionId)
        {
            _conversationHistory = new StringBuilder();
            // Simulating Browser LocalStorage by using a local file.
            _storagePath = Path.Combine(Directory.GetCurrentDirectory(), $"{sessionId}.chatlog");
            LoadHistory();
        }

        // METHOD: SendMessage
        // PURPOSE: Simulates sending a prompt to a local LLM (like Phi-3 or Mistral)
        // running via ONNX Runtime. It calculates a "simulated" response based on
        // keyword matching to demonstrate logic flow without heavy dependencies.
        // ASYNC/AWAIT: Used here to mimic the non-blocking nature of WASM multithreading
        // during token generation.
        public async Task<string> SendMessageAsync(string userMessage)
        {
            // 1. Update Local State
            string formattedUserMsg = $"[USER]: {userMessage}";
            _conversationHistory.AppendLine(formattedUserMsg);
            Console.WriteLine($"\n> User Input Received: {userMessage}");

            // 2. Simulate Model Inference (The "AI" Logic)
            // In a real scenario, this block would call:
            // var inputs = new List<NamedOnnxValue> { ... };
            // var results = await session.RunAsync(inputs);
            Console.WriteLine("> [System]: Processing locally via ONNX Runtime...");
            
            // Simulate processing delay (Token generation speed)
            await Task.Delay(800); 

            string aiResponse = GenerateLocalResponse(userMessage);
            
            // 3. Update State with AI Response
            string formattedAiMsg = $"[AI]: {aiResponse}";
            _conversationHistory.AppendLine(formattedAiMsg);
            
            // 4. Persist to "Local Storage" (File System)
            SaveHistory();

            return aiResponse;
        }

        // METHOD: GenerateLocalResponse
        // PURPOSE: A rule-based logic engine to simulate an LLM.
        // It demonstrates prompt engineering logic suitable for resource-constrained environments.
        private string GenerateLocalResponse(string prompt)
        {
            // Basic keyword matching to simulate intent recognition
            if (prompt.ToLower().Contains("hello") || prompt.ToLower().Contains("hi"))
            {
                return "Hello! I am your private offline assistant. How can I help you today?";
            }
            else if (prompt.ToLower().Contains("time"))
            {
                return $"The current local time is: {DateTime.Now.ToShortTimeString()}";
            }
            else if (prompt.ToLower().Contains("history"))
            {
                return "I can see our previous messages in the local log. Would you like me to summarize them?";
            }
            else if (prompt.ToLower().Contains("exit"))
            {
                return "Goodbye! Your session data remains securely on this device.";
            }
            
            // Default response for unknown inputs (Simulating hallucination fallback)
            return "I understand you are asking about '" + prompt + "'. Since I am running locally with limited context, I suggest checking the documentation or refining your query.";
        }

        // METHOD: SaveHistory
        // PURPOSE: Persists the conversation state. In Blazor WASM, this maps to
        // 'localStorage.setItem'.
        private void SaveHistory()
        {
            try
            {
                File.WriteAllText(_storagePath, _conversationHistory.ToString());
                Console.WriteLine(">> [System]: State persisted to local storage.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Error]: Failed to save state: {ex.Message}");
            }
        }

        // METHOD: LoadHistory
        // PURPOSE: Retrieves previous state. In Blazor WASM, this maps to
        // 'localStorage.getItem'.
        private void LoadHistory()
        {
            if (File.Exists(_storagePath))
            {
                string history = File.ReadAllText(_storagePath);
                _conversationHistory.Append(history);
                Console.WriteLine(">> [System]: Previous session state loaded.");
            }
        }
    }

    // CLASS: Program
    // PURPOSE: The entry point of the application. Handles the main loop and UI.
    class Program
    {
        // ENTRY POINT: Main
        // PURPOSE: Initializes the chat session and runs the interaction loop.
        // This mimics the Blazor WASM startup lifecycle.
        static async Task Main(string[] args)
        {
            Console.WriteLine("=================================================");
            Console.WriteLine("  LOCAL-FIRST AI CHATBOT (ONNX SIMULATION)       ");
            Console.WriteLine("  Mode: Offline | Storage: Local File System     ");
            Console.WriteLine("=================================================");
            Console.WriteLine("  Type 'exit' to quit.");
            Console.WriteLine("=================================================");

            // Initialize the chat session with a unique ID (e.g., User ID)
            // In a web context, this might be derived from the browser fingerprint.
            var chatSession = new LocalChatSession("offline_user_session_001");

            // Main Application Loop
            while (true)
            {
                Console.Write("\n[You]: ");
                string input = Console.ReadLine();

                // Input validation
                if (string.IsNullOrWhiteSpace(input))
                {
                    continue;
                }

                // Handle exit command
                if (input.ToLower() == "exit")
                {
                    var farewell = await chatSession.SendMessageAsync("exit");
                    Console.WriteLine($"[AI]: {farewell}");
                    break;
                }

                // Process message and await response
                try
                {
                    string response = await chatSession.SendMessageAsync(input);
                    Console.WriteLine($"[AI]: {response}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Critical Error]: Application encountered an error: {ex.Message}");
                }
            }

            Console.WriteLine("\nSession ended. Data saved locally.");
        }
    }
}
