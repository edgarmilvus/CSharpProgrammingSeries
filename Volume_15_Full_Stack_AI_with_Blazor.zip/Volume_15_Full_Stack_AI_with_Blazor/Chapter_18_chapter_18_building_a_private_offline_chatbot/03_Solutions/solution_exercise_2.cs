
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System.Net.Http;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;

public enum ModelPrecision
{
    Float32,
    Float16,
    Int8,
    Unknown
}

public class ModelLoaderService
{
    private readonly HttpClient _httpClient;
    private const long Int8SizeThresholdFactor = 16; // Rough heuristic: Int8 is ~1/2 size of FP32, but we use conservative logic here
    
    public ModelLoaderService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<(InferenceSession Session, ModelPrecision Precision)> LoadModelAsync(string modelUrl)
    {
        ModelPrecision precision = DetectModelPrecision(modelUrl); // Heuristic check first
        
        // 1. Asynchronous Blob Loading
        // We use a stream to avoid loading the entire file into a byte array first if we could parse metadata,
        // but Ort.InferenceSession usually requires a byte array or file path.
        // For WASM, fetching as byte array is standard.
        byte[] modelBytes;
        
        try 
        {
            // Fetch the stream
            using var response = await _httpClient.GetAsync(modelUrl, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();
            
            // ReadAsStreamAsync is preferred for large files to avoid buffering in memory unnecessarily
            // but we need a byte array for Ort. We copy to a MemoryStream.
            await using var stream = await response.Content.ReadAsStreamAsync();
            using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);
            modelBytes = memoryStream.ToArray();
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to fetch model from {modelUrl}", ex);
        }

        // 2. Refine Precision Detection (if metadata was available, we'd parse it here)
        // Fallback logic based on size if not already determined
        if (precision == ModelPrecision.Unknown)
        {
            // Simple heuristic: If file is < 500MB, likely Int8 or Quantized. 
            // This is a placeholder for complex ONNX graph inspection.
            if (modelBytes.Length < 500 * 1024 * 1024) 
                precision = ModelPrecision.Int8;
            else
                precision = ModelPrecision.Float32;
        }

        // 3. Inference Session Configuration
        var options = new SessionOptions();

        // Optimization for WASM
        // Disable parallel execution by default in WASM to avoid overhead, or tune carefully.
        // Capping threads is crucial to prevent freezing the browser UI thread.
        int threads = Math.Min(Environment.ProcessorCount, 4);
        options.InterOpNumThreads = threads;
        options.IntraOpNumThreads = threads;

        // Platform specific optimizations
        // Note: Blazor WASM doesn't support SIMD or specific hardware acceleration flags like CUDA.
        // We use CPU Mem Arena for memory pooling (good for Int8)
        if (precision == ModelPrecision.Int8)
        {
            options.CpuMemArena = true; 
        }
        
        // For Float16, Sequential execution mode is often safer on varied hardware
        if (precision == ModelPrecision.Float16)
        {
            options.ExecutionMode = ExecutionMode.ORT_SEQUENTIAL;
        }

        try
        {
            // Load session
            var session = new InferenceSession(modelBytes, options);
            return (session, precision);
        }
        catch (OnnxRuntimeException ex)
        {
            // 4. Error Handling
            // Catch memory errors or invalid model formats
            throw new InvalidOperationException("The model could not be loaded. This might be due to browser memory limits.", ex);
        }
    }

    private ModelPrecision DetectModelPrecision(string modelPath)
    {
        // This is a placeholder for complex logic.
        // In a real scenario, you might read the ONNX protobuf header to inspect graph metadata.
        // Here we default to Unknown to trigger the size heuristic in LoadModelAsync.
        return ModelPrecision.Unknown;
    }
}
