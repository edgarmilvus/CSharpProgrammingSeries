
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System.Threading.Channels;
using System.Text.Json;
using Microsoft.JSInterop;

// Represents a single message in the chat history
public record ChatMessage(string Role, string Content);

// Enum to distinguish between immediate saves and debounced saves
public enum SaveTrigger
{
    Immediate,
    Debounced
}

public class ChatStateService : IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private readonly Channel<ChatMessage> _incomingChannel;
    private readonly CancellationTokenSource _processingCts;
    private readonly Task _processingTask;
    
    // In-memory state
    private readonly List<ChatMessage> _history = new();
    
    // Debouncing state
    private readonly object _debounceLock = new();
    private DateTime _lastWriteTime = DateTime.MinValue;
    private const int DebounceIntervalMs = 500;
    private bool _pendingWrite = false;

    public ChatStateService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
        
        // Create an unbounded channel for high throughput
        _incomingChannel = Channel.CreateUnbounded<ChatMessage>();
        
        _processingCts = new CancellationTokenSource();
        
        // Start the background processing loop
        _processingTask = ProcessUpdatesAsync(_processingCts.Token);
    }

    // Public method for UI/Inference engine to add messages
    public void AddMessage(ChatMessage message)
    {
        // Non-blocking write to the channel
        _incomingChannel.Writer.TryWrite(message);
    }

    // Expose history as an ObservableCollection for UI binding
    // Note: In a real Blazor WASM app, we might use a StateContainer or Notification pattern.
    // Here we return a copy to prevent external mutation, but for high-performance UI updates,
    // we would typically bind directly to an ObservableCollection updated by the processor.
    public IReadOnlyList<ChatMessage> GetHistory() => _history.AsReadOnly();

    private async Task ProcessUpdatesAsync(CancellationToken token)
    {
        try
        {
            // Continuously read from the channel
            await foreach (var message in _incomingChannel.Reader.ReadAllAsync(token))
            {
                // 1. Thread-safe mutation of in-memory state
                lock (_history)
                {
                    _history.Add(message);
                }

                // 2. Trigger debounced save
                TriggerDebouncedSave();
            }
        }
        catch (OperationCanceledException)
        {
            // Clean shutdown
        }
    }

    private void TriggerDebouncedSave()
    {
        lock (_debounceLock)
        {
            _pendingWrite = true;
            _lastWriteTime = DateTime.UtcNow;
        }

        // We don't await this; it runs on the timer loop
        _ = RunDebounceTimerAsync();
    }

    private async Task RunDebounceTimerAsync()
    {
        // Simple debounce implementation
        while (true)
        {
            await Task.Delay(DebounceIntervalMs);
            
            DateTime lastWrite;
            bool pending;
            
            lock (_debounceLock)
            {
                lastWrite = _lastWriteTime;
                pending = _pendingWrite;
            }

            if (!pending) return;

            var timeSinceLast = DateTime.UtcNow - lastWrite;
            if (timeSinceLast.TotalMilliseconds >= DebounceIntervalMs)
            {
                // Time to write
                await PersistToStorageAsync();
                
                lock (_debounceLock)
                {
                    _pendingWrite = false;
                }
                return;
            }
        }
    }

    private async Task PersistToStorageAsync()
    {
        // Clone history under lock to minimize time spent blocking
        List<ChatMessage> snapshot;
        lock (_history)
        {
            snapshot = new List<ChatMessage>(_history);
        }

        var json = JsonSerializer.Serialize(snapshot);
        
        // Use IJSRuntime for async access. 
        // If IJSInProcessRuntime is available, we could use it, but async is safer for WASM.
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", "chatHistory", json);
    }

    public async ValueTask DisposeAsync()
    {
        // Signal the channel to stop accepting new writes
        _incomingChannel.Writer.Complete();
        
        // Cancel the processing loop
        await _processingCts.CancelAsync();

        // Wait for the processing task to finish (ensure final save happens)
        if (_processingTask != null)
        {
            await _processingTask;
        }

        // Final persistence
        await PersistToStorageAsync();
        
        _processingCts.Dispose();
    }
}
