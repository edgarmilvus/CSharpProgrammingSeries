
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Threading.Channels;
using Microsoft.ML.OnnxRuntime;

public class InferenceService
{
    private readonly InferenceSession _session;
    private ChannelWriter<string> _writer;
    private CancellationTokenSource _currentCts;

    public InferenceService(InferenceSession session)
    {
        _session = session;
    }

    // Returns a ChannelReader that the UI can subscribe to
    public ChannelReader<string> GenerateAsync(string prompt, CancellationToken externalToken)
    {
        // Create a bounded channel for the stream
        var channel = Channel.CreateBounded<string>(10);
        _writer = channel.Writer;
        
        // Create a linked cancellation token source
        _currentCts = CancellationTokenSource.CreateLinkedTokenSource(externalToken);

        // Start the background inference loop
        _ = Task.Run(async () => 
        {
            try
            {
                // 1. Background Inference Loop
                // Ideally, we prepare inputs here. 
                // For brevity, assuming a simplified autoregressive loop:
                
                var inputs = new List<NamedOnnxValue> { /* ... prepared inputs ... */ };
                var tokens = new List<string>();

                // Simulate generation loop
                while (!_currentCts.Token.IsCancellationRequested)
                {
                    // 2. Yield control to browser event loop periodically
                    await Task.Yield(); 

                    // Run inference (Simplified)
                    // var results = _session.Run(inputs);
                    // var nextToken = ParseResult(results);
                    var nextToken = "mock_token"; // Placeholder

                    if (nextToken == "[END]") break;

                    // 3. Stream token to Channel
                    await _writer.WriteAsync(nextToken, _currentCts.Token);
                    
                    // Feed output back to input for next iteration (Autoregressive)
                    // Update 'inputs' with 'nextToken'
                }
            }
            catch (Exception ex)
            {
                // Propagate error to UI via channel if needed, or handle logging
                Console.WriteLine($"Inference Error: {ex.Message}");
            }
            finally
            {
                // Close the channel to signal completion to the UI
                _writer.TryComplete();
            }
        }, _currentCts.Token);

        return channel.Reader;
    }

    public void StopGeneration()
    {
        _currentCts?.Cancel();
    }
}
