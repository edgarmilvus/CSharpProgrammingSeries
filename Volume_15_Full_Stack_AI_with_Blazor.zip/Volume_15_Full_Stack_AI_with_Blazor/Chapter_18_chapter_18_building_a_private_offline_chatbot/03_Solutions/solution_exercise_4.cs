
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Text;

public class ContextWindowManager
{
    private readonly int _maxTokens;
    private readonly string _systemPrompt;
    private readonly Func<string, int> _tokenizer;

    public ContextWindowManager(int maxTokens, string systemPrompt, Func<string, int> tokenizer)
    {
        _maxTokens = maxTokens;
        _systemPrompt = systemPrompt;
        _tokenizer = tokenizer;
    }

    public List<ChatMessage> GetContextWindow(List<ChatMessage> history)
    {
        // 1. Calculate System Prompt Cost
        int systemTokens = _tokenizer(_systemPrompt);
        if (systemTokens > _maxTokens)
        {
            // Edge case: System prompt is too big, truncate it
            return new List<ChatMessage> { new ChatMessage("system", TruncateText(_systemPrompt, _maxTokens)) };
        }

        var context = new List<ChatMessage>();
        context.Add(new ChatMessage("system", _systemPrompt));
        
        int remainingTokens = _maxTokens - systemTokens;

        // 2. Sliding Window Logic (Iterate backwards)
        // We use a stack to reverse the order back to chronological after processing
        var stack = new Stack<ChatMessage>();
        
        // Iterate from the end of history to the beginning
        for (int i = history.Count - 1; i >= 0; i--)
        {
            var msg = history[i];
            int msgTokens = _tokenizer(msg.Content);

            // 3. Truncation Logic for a single large message
            if (msgTokens > remainingTokens)
            {
                // If the single message is larger than remaining space, truncate it
                // and stop (we cannot fit any older messages)
                string truncatedContent = TruncateText(msg.Content, remainingTokens);
                stack.Push(new ChatMessage(msg.Role, truncatedContent));
                remainingTokens = 0;
                break;
            }

            // Normal fit check
            if (msgTokens <= remainingTokens)
            {
                stack.Push(msg); // Add to stack to maintain order
                remainingTokens -= msgTokens;
            }
            else
            {
                // Not enough space for this message, and since we are iterating backwards,
                // we have reached the oldest messages we can fit.
                break;
            }
        }

        // Add messages back in chronological order
        context.AddRange(stack);
        return context;
    }

    private string TruncateText(string text, int maxTokens)
    {
        // Simple whitespace tokenizer approximation for truncation
        var words = text.Split(' ');
        var sb = new StringBuilder();
        int currentTokens = 0;

        foreach (var word in words)
        {
            // Estimate 1 token per word for this simple logic
            if (currentTokens + 1 > maxTokens) break;
            sb.Append(word + " ");
            currentTokens++;
        }

        return sb.ToString().Trim();
    }
}
