
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@using System.Text.Json

<h3>Chat History</h3>

<div class="chat-container">
    <Virtualize Items="@Messages" Context="msg" ItemSize="50">
        <div class="message-row @msg.Sender.ToLower()">
            <span class="sender">@msg.Sender:</span>
            <span class="content">@msg.Text</span>
        </div>
    </Virtualize>
</div>

@code {
    // Represents the data structure for a single chat message.
    // Using a record for immutability and value-based equality.
    public record ChatMessage(string Sender, string Text);

    // Injected or defined list of messages.
    // In a real app, this would come from a service or parent component.
    // Using the 'required' keyword (C# 11) to ensure data integrity.
    private List<ChatMessage> Messages { get; set; } = new()
    {
        new ChatMessage("User", "Hello, can you help me with Blazor?"),
        new ChatMessage("Assistant", "Absolutely! What specific aspect are you struggling with?"),
        new ChatMessage("User", "I'm trying to understand the Virtualize component."),
        new ChatMessage("Assistant", "The Virtualize component helps render large lists efficiently."),
        new ChatMessage("User", "Thanks! That helps a lot."),
        new ChatMessage("Assistant", "You're welcome! Let me know if you need more details.")
    };
}
