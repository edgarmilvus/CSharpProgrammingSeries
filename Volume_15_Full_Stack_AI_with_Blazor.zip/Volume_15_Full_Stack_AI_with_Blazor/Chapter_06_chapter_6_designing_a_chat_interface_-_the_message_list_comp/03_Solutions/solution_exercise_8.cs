
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_8.cs
// Description: Solution for Exercise 8
// ==========================================

// ContextMenuWrapper.razor (Global overlay)
@inject IContextMenuService MenuService
@inject IJSRuntime JSRuntime

@if (_isVisible)
{
    <!-- Backdrop to close menu -->
    <div class="context-backdrop" @onclick="CloseMenu" @oncontextmenu:preventDefault></div>

    <!-- The Menu -->
    <div class="context-menu" style="top: @_posYpx; left: @_posXpx;" tabindex="0" @ref="_menuRef">
        <ul>
            <li @onclick="CopyContent">Copy Text</li>
            <li @onclick="CopyJson">Copy JSON</li>
            <li @onclick="TogglePin">@(_targetMessage?.IsPinned == true ? "Unpin" : "Pin")</li>
        </ul>
    </div>
}

@code {
    private bool _isVisible = false;
    private Message _targetMessage;
    private double _posX, _posY;
    private ElementReference _menuRef;

    protected override void OnInitialized()
    {
        MenuService.OnOpen += (msg, e) =>
        {
            if (msg == null) { _isVisible = false; return; }
            
            _targetMessage = msg;
            _posX = e.ClientX;
            _posY = e.ClientY;
            _isVisible = true;
            StateHasChanged();
            
            // Focus for accessibility
            _menuRef.FocusAsync();
        };
    }

    private async Task CopyContent()
    {
        await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", _targetMessage.Content);
        CloseMenu();
    }

    private async Task CopyJson()
    {
        var json = System.Text.Json.JsonSerializer.Serialize(_targetMessage);
        await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", json);
        CloseMenu();
    }

    private void TogglePin()
    {
        _targetMessage.IsPinned = !_targetMessage.IsPinned;
        CloseMenu();
    }

    private void CloseMenu() => _isVisible = false;
}
