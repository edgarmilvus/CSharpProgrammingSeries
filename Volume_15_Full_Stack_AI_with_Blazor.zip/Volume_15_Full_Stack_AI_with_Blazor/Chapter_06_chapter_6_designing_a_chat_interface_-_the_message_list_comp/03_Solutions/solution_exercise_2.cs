
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;
using System.Collections.Generic;
using System.Threading.Tasks;

// VirtualizedMessageList.razor
<div class="message-list-container" @ref="_scrollContainer" style="height: 500px; overflow-y: auto;">
    <Virtualize @ref="_virtualizeComponent" 
                ItemsProvider="ProvideMessages" 
                OverscanCount="10" 
                ItemSize="80">
        
        <Placeholder>
            <!-- Skeleton Loader for async fetch -->
            <div class="message-bubble skeleton">
                <div class="skeleton-line"></div>
            </div>
        </Placeholder>

        <ItemContent>
            <!-- Render the message -->
            <MessageBubble Message="@context" />
        </ItemContent>

    </Virtualize>
</div>

@code {
    [Inject] private IJSRuntime JSRuntime { get; set; }
    [Inject] private ChatStateService ChatService { get; set; }

    private Virtualize<Message> _virtualizeComponent;
    private ElementReference _scrollContainer;
    private bool _isAtBottom = true;

    // 1. Custom Async ItemsProvider
    private async ValueTask<ItemsProviderResult<Message>> ProvideMessages(ItemsProviderRequest request)
    {
        // Calculate the slice of data needed
        // In a real app, this might query a database with Skip/Take
        var result = await ChatService.GetMessagesAsync(request.StartIndex, request.Count);
        
        return new ItemsProviderResult<Message>(result.Items, result.TotalCount);
    }

    // 2. Scroll Position Management
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            // Subscribe to scroll events to track if user is at bottom
            await JSRuntime.InvokeVoidAsync("addScrollListener", _scrollContainer, 
                DotNetObjectReference.Create(this));
        }

        if (!_isAtBottom)
        {
            // Logic to restore scroll position when loading items above
            // This requires calculating the difference in scrollHeight before/after update
            // Usually handled by JS, but here we assume a specific offset needs applying
            // For brevity, we rely on the Virtualize component's preservation, 
            // but strictly we would JSInterop to set _scrollContainer.scrollTop += delta.
        }
    }

    // JSInvokable callback for scroll detection
    [JSInvokable]
    public void OnScroll(double scrollTop, double scrollHeight, double clientHeight)
    {
        // Threshold of 50px from bottom
        _isAtBottom = (scrollHeight - scrollTop - clientHeight) < 50;
        
        // Context Awareness: Notify service if we are detached from live feed
        ChatService.SetLiveFeedMode(_isAtBottom);
    }

    // Triggered when a new message arrives externally
    public async Task OnNewMessageAdded()
    {
        if (_isAtBottom)
        {
            // Force refresh and scroll to bottom
            await _virtualizeComponent.RefreshDataAsync();
            await JSRuntime.InvokeVoidAsync("scrollToBottom", _scrollContainer);
        }
        else
        {
            // Show "New Message" badge (logic not shown)
        }
    }
}
