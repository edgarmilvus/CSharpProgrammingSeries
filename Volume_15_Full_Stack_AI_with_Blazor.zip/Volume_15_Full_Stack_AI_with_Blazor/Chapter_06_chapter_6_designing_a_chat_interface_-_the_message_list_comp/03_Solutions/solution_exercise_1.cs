
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Markdig.Syntax;
using Markdig.Syntax.Inlines;
using Markdig;
using System.Text.RegularExpressions;

// CustomMarkdownRenderer.razor
<div class="markdown-container">
    <CascadingValue Value="this">
        @foreach (var element in _parsedElements)
        {
            @RenderElement(element)
        }
    </CascadingValue>
</div>

@code {
    [Parameter, EditorRequired] public string Markdown { get; set; } = string.Empty;

    // Registry for custom component injection: Regex Pattern -> Component Type
    [Parameter] public Dictionary<string, Type> CustomComponentPatterns { get; set; } = new();

    private List<Block> _parsedElements = new();
    private MarkdownPipeline _pipeline;

    protected override void OnInitialized()
    {
        // Configure Markdig to support advanced features
        _pipeline = new MarkdownPipelineBuilder()
            .UseAdvancedExtensions()
            .UseEmphasisExtras()
            .Build();
    }

    protected override void OnParametersSet()
    {
        if (!string.IsNullOrEmpty(Markdown))
        {
            // Parse the Markdown into an AST (Abstract Syntax Tree)
            _parsedElements = Markdown.Parse(Markdown, _pipeline);
        }
    }

    private RenderFragment RenderElement(object element)
    {
        return builder =>
        {
            switch (element)
            {
                case CodeBlock codeBlock:
                    RenderCodeBlock(builder, codeBlock);
                    break;
                case LeafBlock leaf when leaf.Inline != null:
                    // Handles paragraphs, headers, etc. containing inlines
                    builder.OpenElement(0, "p");
                    foreach (var inline in leaf.Inline)
                    {
                        RenderInline(builder, inline);
                    }
                    builder.CloseElement();
                    break;
                case ListBlock listBlock:
                    RenderListBlock(builder, listBlock);
                    break;
                case BlockQuote blockQuote:
                    builder.OpenElement(0, "blockquote");
                    foreach (var child in blockQuote)
                    {
                        // Recursive call for nested blocks
                        var fragment = RenderElement(child);
                        fragment(builder);
                    }
                    builder.CloseElement();
                    break;
                default:
                    // Fallback for unhandled blocks (graceful degradation)
                    builder.AddContent(0, element.ToString());
                    break;
            }
        };
    }

    private void RenderCodeBlock(RenderTreeBuilder builder, CodeBlock codeBlock)
    {
        // 1. Extract language info if available (e.g., from FencedCodeBlock)
        string language = "text";
        if (codeBlock is FencedCodeBlock fenced)
        {
            language = fenced.Info ?? "text";
        }

        // 2. Extract raw code content
        var rawCode = codeBlock.Lines.ToString();
        
        // 3. Check for custom component injection syntax {{< Component >}}
        if (TryParseCustomComponent(rawCode, out var componentType, out var parameters))
        {
            builder.OpenComponent(0, componentType);
            foreach (var param in parameters)
            {
                builder.AddAttribute(1, param.Key, param.Value);
            }
            builder.CloseComponent();
            return;
        }

        // 4. Standard Code Rendering with Syntax Highlighting
        // Note: In a real scenario, you might use Blazor.SyntaxHighlight or JSInterop here.
        // For this example, we simulate a highlighter component wrapper.
        builder.OpenElement(2, "pre");
        builder.AddAttribute(3, "class", $"language-{language}");
        
        builder.OpenElement(4, "code");
        builder.AddContent(5, rawCode);
        builder.CloseElement(); // code
        
        builder.CloseElement(); // pre
    }

    private void RenderInline(RenderTreeBuilder builder, Inline inline)
    {
        switch (inline)
        {
            case LiteralInline literal:
                builder.AddContent(0, literal.Content.ToString());
                break;
            case CodeInline code:
                builder.OpenElement(1, "code");
                builder.AddContent(2, code.Content);
                builder.CloseElement();
                break;
            case LinkInline link:
                builder.OpenElement(3, "a");
                builder.AddAttribute(4, "href", link.Url);
                builder.AddContent(5, link.FirstChild?.ToString() ?? link.Url);
                builder.CloseElement();
                break;
            // Handle other inlines...
        }
    }

    private void RenderListBlock(RenderTreeBuilder builder, ListBlock listBlock)
    {
        var tag = listBlock.Ordered ? "ol" : "ul";
        builder.OpenElement(0, tag);
        foreach (var item in listBlock)
        {
            if (item is ListItemBlock listItem)
            {
                builder.OpenElement(1, "li");
                foreach (var subBlock in listItem)
                {
                    var fragment = RenderElement(subBlock);
                    fragment(builder);
                }
                builder.CloseElement();
            }
        }
        builder.CloseElement();
    }

    private bool TryParseCustomComponent(string content, out Type componentType, out Dictionary<string, object> parameters)
    {
        componentType = null;
        parameters = new Dictionary<string, object>();
        
        // Regex to find {{< MyComponent param="value" >}}
        var match = Regex.Match(content.Trim(), @"{{<\s*(\w+)\s*(.*?)\s*>}}");
        if (!match.Success) return false;

        var componentName = match.Groups[1].Value;
        var paramStr = match.Groups[2].Value;

        // Look up in registry
        var found = CustomComponentPatterns.FirstOrDefault(kvp => kvp.Key.Equals(componentName, StringComparison.OrdinalIgnoreCase));
        if (found.Key == null) return false;

        componentType = found.Value;

        // Parse parameters (simple key="value" parser)
        var paramMatches = Regex.Matches(paramStr, @"(\w+)=""([^""]*)""");
        foreach (Match p in paramMatches)
        {
            parameters[p.Groups[1].Value] = p.Groups[2].Value;
        }

        return true;
    }
}
