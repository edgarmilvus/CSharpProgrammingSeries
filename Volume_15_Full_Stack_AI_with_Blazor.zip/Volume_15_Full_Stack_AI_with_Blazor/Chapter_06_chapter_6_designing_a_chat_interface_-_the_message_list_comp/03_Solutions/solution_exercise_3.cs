
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// MessageBubble.razor
@using System.Text.Json

<div class="@GetBubbleClass()" 
     @onmouseover="() => _showActions = true" 
     @onmouseout="() => _showActions = false"
     @oncontextmenu="PreventDefault"
     style="position: relative;">

    <!-- Content Area -->
    @if (IsEditing)
    {
        <textarea @bind="EditBuffer" @bind:event="oninput" class="edit-area" />
        <button @onclick="SaveEdit">Save</button>
        <button @onclick="CancelEdit">Cancel</button>
    }
    else
    {
        <!-- Render Markdown Content -->
        <CustomMarkdownRenderer Markdown="@Message.Content" />
    }

    <!-- Action Overlay (Hover) -->
    @if (_showActions && !IsEditing && !IsLoading)
    {
        <div class="action-overlay">
            @if (Message.IsUser)
            {
                <button @onclick="StartEdit" title="Edit">✏️</button>
            }
            else
            {
                <button @onclick="TriggerRegenerate" title="Regenerate">🔄</button>
            }
        </div>
    }

    <!-- Loading Indicator -->
    @if (IsLoading)
    {
        <div class="loading-indicator">Generating...</div>
    }
</div>

@code {
    [Parameter] public Message Message { get; set; }
    [Parameter] public EventCallback<Message> OnRegenerate { get; set; }
    [Parameter] public EventCallback<Message> OnEdit { get; set; }
    [Parameter] public bool IsLoading { get; set; } // Passed from parent context

    private bool _showActions = false;
    public bool IsEditing { get; set; } = false;
    private string EditBuffer { get; set; }

    private string GetBubbleClass() => Message.IsUser ? "bubble-user" : "bubble-ai";

    // Edit Logic
    private void StartEdit()
    {
        EditBuffer = Message.Content;
        IsEditing = true;
    }

    private async Task SaveEdit()
    {
        // Update local state immediately (Optimistic UI)
        Message.Content = EditBuffer;
        IsEditing = false;
        
        // Notify parent to handle logic (regeneration of next AI message)
        await OnEdit.InvokeAsync(Message);
    }

    private void CancelEdit() => IsEditing = false;

    // Regenerate Logic
    private async Task TriggerRegenerate()
    {
        await OnRegenerate.InvokeAsync(Message);
    }

    private void PreventDefault(MouseEventArgs e) => e.preventDefault();
}
