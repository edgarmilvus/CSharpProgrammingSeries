
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

// MessageList.razor (Rendering Logic)
<div class="message-list" @ref="_listRef">
    @foreach (var msg in _state.Messages)
    {
        <MessageBubble Message="@msg" />
    }

    <!-- Typing Indicator -->
    @if (_state.IsStreaming)
    {
        <div class="typing-indicator">
            <span class="dot"></span><span class="dot"></span><span class="dot"></span>
            <button class="btn-stop" @onclick="StopStreaming">Stop</button>
        </div>
        
        <!-- Hidden render of the raw stream for text flow -->
        <div class="streaming-text">
            <CustomMarkdownRenderer Markdown="@_state.CurrentlyStreamingMessage.Content" />
        </div>
    }
</div>

@code {
    [Inject] private ChatState _state { get; set; }
    [Inject] private IJSRuntime _jsRuntime { get; set; }
    private ElementReference _listRef;
    private bool _userScrolledUp = false;

    protected override void OnInitialized()
    {
        _state.OnChange += StateHasChanged;
        // Hook into scroll events to set _userScrolledUp
    }

    private async Task StopStreaming()
    {
        // Inject service to call Stop
    }

    // This method is critical for the "Interleaved" requirement
    // It should be called whenever the streaming message content updates
    private async Task HandleStreamUpdate()
    {
        // Check if user is at bottom
        bool isAtBottom = await _jsRuntime.InvokeAsync<bool>("checkScrollBottom", _listRef);
        
        if (isAtBottom && _state.IsStreaming)
        {
            // Auto scroll
            await _jsRuntime.InvokeVoidAsync("scrollToBottom", _listRef);
        }
        else if (!isAtBottom && _state.IsStreaming)
        {
            _userScrolledUp = true;
            // Show "New Messages" badge (logic omitted)
        }
    }
}
