
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// ChatStateService.cs (Logic Backend)
public class ChatStateService
{
    public List<Message> Messages { get; private set; } = new();
    
    public async Task RegenerateMessageAsync(Message aiMessage)
    {
        // 1. Find Index
        int index = Messages.IndexOf(aiMessage);
        if (index <= 0) return; // Must have a user message before it

        // 2. Get Preceding User Message
        var userMessage = Messages[index - 1];

        // 3. Remove current AI response
        Messages.RemoveAt(index);

        // 4. Add placeholder or loading state
        var loadingMsg = new Message { IsUser = false, Content = "Regenerating...", IsLoading = true };
        Messages.Add(loadingMsg);
        
        // Notify UI (StateHasChanged equivalent)

        // 5. Call AI Service
        var newResponse = await _aiService.GenerateAsync(userMessage.Content);

        // 6. Update State
        Messages.Remove(loadingMsg);
        Messages.Add(new Message { IsUser = false, Content = newResponse });
    }

    public async Task EditAndRegenerateAsync(Message editedUserMessage)
    {
        // 1. Find Index
        int index = Messages.IndexOf(editedUserMessage);
        
        // 2. Remove all subsequent messages (branching history)
        Messages.RemoveAll(m => Messages.IndexOf(m) > index);

        // 3. Trigger AI generation for the new content
        await GenerateNextResponseAsync(editedUserMessage.Content);
    }
}
