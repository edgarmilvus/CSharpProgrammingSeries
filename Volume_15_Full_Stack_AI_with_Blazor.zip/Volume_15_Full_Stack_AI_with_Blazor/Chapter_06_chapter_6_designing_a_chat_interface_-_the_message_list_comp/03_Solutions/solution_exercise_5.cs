
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

// ChatState.cs (Shared Model)
public class ChatState
{
    public List<Message> Messages { get; set; } = new();
    public Message? CurrentlyStreamingMessage { get; set; }
    public bool IsStreaming => CurrentlyStreamingMessage != null;
    public CancellationTokenSource? StreamingCts { get; set; }
}

// StreamingService.cs (Logic)
public class StreamingService
{
    private readonly ChatState _state;

    public async Task StreamResponseAsync(string prompt)
    {
        // 1. Setup Cancellation
        _state.StreamingCts = new CancellationTokenSource();
        var token = _state.StreamingCts.Token;

        // 2. Create the streaming message object
        var streamingMsg = new Message { IsUser = false, Content = "" };
        _state.CurrentlyStreamingMessage = streamingMsg;
        _state.Messages.Add(streamingMsg);

        try
        {
            // 3. Simulate Streaming (e.g., from Azure OpenAI SDK)
            await foreach (var chunk in _aiClient.GetStreamingChunksAsync(prompt, token))
            {
                token.ThrowIfCancellationRequested();
                
                // Append chunk to content
                streamingMsg.Content += chunk;
                
                // Notify UI to render (simulated via StateHasChanged or Event)
                _state.NotifyStateChanged();
            }
        }
        catch (OperationCanceledException)
        {
            // Handle Stop Generation
            streamingMsg.Content += " [Generation Stopped]";
        }
        finally
        {
            _state.CurrentlyStreamingMessage = null;
            _state.StreamingCts = null;
            _state.NotifyStateChanged();
        }
    }

    public void StopGeneration()
    {
        _state.StreamingCts?.Cancel();
    }
}
