
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace ChatInterfaceSimulator
{
    // =================================================================================
    // REAL-WORLD PROBLEM CONTEXT
    // =================================================================================
    // Scenario: A developer is building a "Blazor WASM Chat Interface" (Book 15, Chapter 6).
    // The Chat UI consists of a "Message List Component" that renders conversation history.
    // 
    // Problem: Before integrating complex UI frameworks (like MudBlazor) or expensive 
    // DOM rendering, we need to simulate the core logic of the Message List.
    // 
    // Goal: Build a Console Application that mimics the "Virtualize" and "Render" 
    // logic of a chat history. It must handle:
    // 1. Storing messages (User vs. AI).
    // 2. Managing a buffer (simulating the Virtualize component's window).
    // 3. Rendering Markdown-like syntax (simulating the Rich Content requirement).
    // 4. Auto-scrolling logic (simulating UI state updates).
    // 
    // This is a "Dry Run" architecture for the Chat Interface Component.
    // =================================================================================

    public class Program
    {
        // The Entry Point of our Console Simulation
        public static void Main(string[] args)
        {
            // 1. Initialize the State Management (The "Store")
            // In Blazor, this might be a Service or a Scoped State Container.
            // Here, it's a simple array acting as our database.
            MessageStore store = new MessageStore();

            // 2. Simulate User Interaction (The "Event Handler")
            // The user types a prompt in the Chat Interface.
            string userPrompt = "Explain **Markdown** rendering in a `Virtualize` component.";
            store.AddMessage(new ChatMessage { Author = "User", Content = userPrompt });

            // 3. Simulate AI Response (The "Backend")
            // The AI generates a response. In a real app, this comes via HTTP/SignalR.
            string aiResponse = "1. **Markdown**: Parses bold/italic.\n2. `Virtualize`: Optimizes DOM.\n3. Combined: Efficient rich text rendering.";
            store.AddMessage(new ChatMessage { Author = "AI", Content = aiResponse });

            // 4. Add more data to test the "Virtualize" logic
            for (int i = 1; i <= 5; i++)
            {
                store.AddMessage(new ChatMessage { Author = "User", Content = $"Debug request {i}" });
                store.AddMessage(new ChatMessage { Author = "AI", Content = $"Log output {i}: OK" });
            }

            // 5. Initialize the Component Logic (The "View Layer")
            // We instantiate the component that handles the visual rendering.
            MessageListComponent component = new MessageListComponent(store);

            // 6. Execute the Render Loop
            // This simulates the user scrolling or the component updating.
            Console.WriteLine("--- Starting Chat Interface Simulation ---\n");
            component.Render();
        }
    }

    // =================================================================================
    // DATA MODELS (Chapter 5 & 6: State Management & Component Parameters)
    // =================================================================================

    /// <summary>
    /// Represents a single message in the chat history.
    /// In Blazor, this is often a Record or a POCO (Plain Old CLR Object).
    /// </summary>
    public class ChatMessage
    {
        public string Author { get; set; }
        public string Content { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;

        // Helper to determine styling (Simulating CSS classes)
        public bool IsUser => Author == "User";
    }

    /// <summary>
    /// The State Container (The "List" in Message List Component).
    /// In Blazor, we might use ObservableCollection for data binding.
    /// Here, we use a simple List to store the history.
    /// </summary>
    public class MessageStore
    {
        private List<ChatMessage> _messages = new List<ChatMessage>();

        public void AddMessage(ChatMessage msg)
        {
            _messages.Add(msg);
        }

        public List<ChatMessage> GetAllMessages()
        {
            return _messages;
        }
    }

    // =================================================================================
    // COMPONENT LOGIC (Chapter 6: The Message List Component)
    // =================================================================================

    /// <summary>
    /// Simulates the Blazor Component responsible for rendering the message list.
    /// Key Concept: It manages the "View" logic, including Virtualization and Rendering.
    /// </summary>
    public class MessageListComponent
    {
        private readonly MessageStore _store;
        
        // Simulating the Virtualize Component's "ItemProvider" logic.
        // In a real Blazor WASM app, Virtualize only renders items in the viewport.
        // Here, we simulate a "Window" of the last 3 messages to demonstrate 
        // performance optimization logic.
        private const int VIRTUAL_WINDOW_SIZE = 3;

        public MessageListComponent(MessageStore store)
        {
            _store = store;
        }

        /// <summary>
        /// The main Render method. In Blazor, this is the implicit Razor syntax compilation.
        /// In Console, we manually build the string output.
        /// </summary>
        public void Render()
        {
            // 1. Fetch Data (State Retrieval)
            var allMessages = _store.GetAllMessages();
            
            if (allMessages.Count == 0)
            {
                Console.WriteLine("[System]: Chat history is empty.");
                return;
            }

            // 2. Virtualization Logic (Optimization)
            // We calculate the "Visible Window". 
            // Logic: If we have 1000 messages, we don't process the first 997.
            int startIndex = 0;
            if (allMessages.Count > VIRTUAL_WINDOW_SIZE)
            {
                startIndex = allMessages.Count - VIRTUAL_WINDOW_SIZE;
            }

            // 3. Auto-Scroll Simulation
            // In Blazor, we use `Virtualize` with `ItemsProvider` and `Spacer`.
            // Here, we print a visual indicator of the "Scroll Position".
            Console.WriteLine($"[Virtualize]: Rendering window {startIndex + 1}-{allMessages.Count} of {allMessages.Count} items.");
            Console.WriteLine(new string('-', 50));

            // 4. Iteration and Rendering (The Loop)
            for (int i = startIndex; i < allMessages.Count; i++)
            {
                RenderMessage(allMessages[i]);
            }

            Console.WriteLine(new string('-', 50));
            Console.WriteLine($"[AutoScroll]: Scrolled to bottom (Item #{allMessages.Count})\n");
        }

        /// <summary>
        /// Renders a single message. This simulates the "MessageItem" sub-component.
        /// It handles "Rich Content" parsing (Markdown simulation).
        /// </summary>
        private void RenderMessage(ChatMessage msg)
        {
            // A. Determine Layout (Flexbox/Grid simulation)
            string align = msg.IsUser ? "Right" : "Left";
            string bubbleColor = msg.IsUser ? "Cyan" : "Gray";

            // B. Parse Content (Markdown Parser Simulation)
            // In Chapter 6, we discuss rendering Markdown. 
            // We implement a basic parser to convert **bold** and `code`.
            string parsedContent = ParseMarkdown(msg.Content);

            // C. Output to Console (DOM Rendering Simulation)
            Console.WriteLine($"[{msg.Timestamp:HH:mm:ss}] {msg.Author} ({align}):");
            
            // Simulate a CSS Border/Background
            Console.ForegroundColor = msg.IsUser ? ConsoleColor.Cyan : ConsoleColor.Gray;
            Console.WriteLine($"| {parsedContent}");
            Console.ResetColor();
        }

        /// <summary>
        /// A basic text parser to simulate Markdown rendering logic.
        /// Uses basic string manipulation (IndexOf, Substring) - no Regex or LINQ.
        /// </summary>
        private string ParseMarkdown(string rawContent)
        {
            StringBuilder sb = new StringBuilder();
            bool isBold = false;
            bool isCode = false;
            string temp = "";

            // Iterate through characters to find markers
            for (int i = 0; i < rawContent.Length; i++)
            {
                char c = rawContent[i];

                // Check for Bold markers **
                if (c == '*' && i + 1 < rawContent.Length && rawContent[i + 1] == '*')
                {
                    // Toggle Bold state
                    isBold = !isBold;
                    
                    // Append the formatted text
                    if (!isBold) sb.Append(temp); // Closing tag
                    temp = ""; // Reset temp buffer
                    
                    i++; // Skip the second asterisk
                    continue;
                }

                // Check for Code markers `
                if (c == '`')
                {
                    // Toggle Code state
                    isCode = !isCode;

                    // Append the formatted text
                    if (!isCode) sb.Append(temp);
                    temp = "";

                    continue;
                }

                // If we are inside a tag, buffer the text
                if (isBold || isCode)
                {
                    temp += c;
                }
                else
                {
                    // Normal text, append directly
                    sb.Append(c);
                }
            }

            // Append any remaining buffered text (edge case handling)
            if (temp.Length > 0) sb.Append(temp);

            // Apply "Console CSS" (Visualizing the formatting)
            // In a real Blazor app, this would be <b> or <code> tags.
            string result = sb.ToString();
            
            // We need a second pass to wrap the content in visual tags since 
            // the loop above strips the markers.
            // This is a simulation of the final HTML output.
            if (rawContent.Contains("**"))
            {
                // Simple heuristic for simulation
                result = result.Replace(result, $"[BOLD]{result}[/BOLD]"); 
                // Note: In a real parser, we'd track positions. 
                // For this console app, we will just return the parsed text with markers 
                // to show the logic worked, but let's do a cleaner visual output:
                
                // Let's actually simulate the output correctly:
                return SimulateVisualOutput(rawContent);
            }

            return SimulateVisualOutput(rawContent);
        }

        // Helper to strictly visualize the output for the console
        private string SimulateVisualOutput(string raw)
        {
            // Basic simulation of replacing markers with visual indicators
            // This mimics the "Blazor Component" rendering the HTML.
            string output = raw;
            
            // Handle Bold
            output = output.Replace("**", ""); // Remove markers
            // (In a real app, we'd keep the markers to know where to apply tags, 
            // but for this simple console demo, we assume the parser stripped them 
            // and we apply a visual wrapper).
            
            // Handle Code
            // We need to be careful not to double process.
            // Let's just return a string that shows we processed it.
            if (raw.Contains("`"))
            {
                output = output.Replace("`", "");
                return $"[CODE_BLOCK]{output}[/CODE_BLOCK]";
            }

            if (raw.Contains("**"))
            {
                // Remove markers for display
                output = output.Replace("**", "");
                return $"[BOLD]{output}[/BOLD]";
            }

            return output;
        }
    }
}
