
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.cs
// Description: Basic Code Example
// ==========================================

@page "/chat"
@using Microsoft.AspNetCore.SignalR.Client
@using System.Reactive.Linq
@inject NavigationManager Navigation

<h3>AI Chat Stream</h3>

<div>
    <input @bind="userPrompt" placeholder="Enter your prompt..." />
    <button @onclick="StartStream">Send</button>
</div>

<div style="margin-top: 20px; border: 1px solid #ccc; padding: 10px;">
    <strong>Response:</strong>
    <p>@displayedText</p>
</div>

@code {
    private string userPrompt = "";
    private string displayedText = "";
    private HubConnection? hubConnection;

    protected override async Task OnInitializedAsync()
    {
        // 1. Initialize the SignalR connection. 
        // IMPORTANT: In a real app, this URL points to your backend (e.g., https://localhost:7000/aiChatHub).
        hubConnection = new HubConnectionBuilder()
            .WithUrl(Navigation.ToAbsoluteUri("/aiChatHub")) 
            .Build();

        // 2. Start the connection. This must be done before calling server methods.
        await hubConnection.StartAsync();
    }

    private async Task StartStream()
    {
        if (hubConnection is null || string.IsNullOrWhiteSpace(userPrompt)) return;

        // 3. Clear previous text.
        displayedText = "";

        // 4. Invoke the server method and get the stream reader.
        // We use IAsyncEnumerable<string> to consume the stream.
        var stream = hubConnection.StreamAsync<string>("StreamResponse", userPrompt);

        // 5. Iterate over the stream as data arrives.
        // This loop pauses at 'await foreach' until the next token is received.
        await foreach (var token in stream)
        {
            // 6. Update the UI with the new token.
            // In a real app, you might use StateHasChanged or an Observable.
            displayedText += token + " "; 
            StateHasChanged(); // Force UI refresh (optional in Blazor WASM for simple updates, but good practice)
            
            // 7. Simulate typing delay for visual effect (optional).
            await Task.Delay(50); 
        }
    }

    // 8. Clean up the connection when the component is disposed.
    public async ValueTask DisposeAsync()
    {
        if (hubConnection is not null)
        {
            await hubConnection.DisposeAsync();
        }
    }
}
