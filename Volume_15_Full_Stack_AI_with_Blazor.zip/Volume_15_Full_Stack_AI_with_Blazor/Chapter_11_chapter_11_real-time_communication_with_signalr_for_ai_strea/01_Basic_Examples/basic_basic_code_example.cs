
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using Microsoft.AspNetCore.SignalR;
using System.Threading.Channels;

namespace BlazorCopilot.Server.Hubs
{
    // 1. Define the SignalR Hub. This class handles client-server communication.
    public class AiChatHub : Hub
    {
        // 2. Define a method that the client can call. This method returns a stream of data.
        // We use 'ChannelReader<string>' to create an asynchronous stream.
        public ChannelReader<string> StreamResponse(string prompt)
        {
            // 3. Create a channel to write tokens to. This acts as a buffer for the stream.
            var channel = Channel.CreateUnbounded<string>();

            // 4. Write the initial context to the client immediately.
            _ = channel.Writer.WriteAsync($"Processing: {prompt}...");

            // 5. Offload the heavy lifting (AI generation) to a background task so we don't block the hub.
            _ = Task.Run(async () =>
            {
                // 6. Simulate an AI generating text by yielding words one by one.
                var responseWords = new[] { "Hello", "from", "the", "cloud!", "Here", "is", "your", "answer." };
                
                foreach (var word in responseWords)
                {
                    // 7. Simulate network latency and processing time.
                    await Task.Delay(200); 
                    
                    // 8. Write the token (word) to the channel. The client receives this immediately.
                    await channel.Writer.WriteAsync(word);
                }

                // 9. Signal that the stream has finished sending data.
                channel.Writer.Complete();
            });

            // 10. Return the reader immediately so the client can start consuming the stream.
            return channel.Reader;
        }
    }
}
