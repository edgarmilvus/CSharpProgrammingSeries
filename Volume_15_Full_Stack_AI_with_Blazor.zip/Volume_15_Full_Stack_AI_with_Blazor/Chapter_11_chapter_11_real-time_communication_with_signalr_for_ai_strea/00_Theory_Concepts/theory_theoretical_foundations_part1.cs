
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.cs
// Description: Theoretical Foundations
// ==========================================

using Microsoft.AspNetCore.SignalR;
using System.Collections.Generic;
using System.Threading;

public class AiHub : Hub
{
    // Explicitly referencing the AI service pattern from previous chapters
    private readonly IAiStreamingService _aiService;

    public AiHub(IAiStreamingService aiService)
    {
        _aiService = aiService;
    }

    // The method returns an async stream, allowing the client to consume tokens one by one
    public async IAsyncEnumerable<string> StreamResponse(string prompt, [EnumeratorCancellation] CancellationToken ct)
    {
        // We simulate streaming tokens from an LLM
        await foreach (var token in _aiService.GenerateStreamAsync(prompt, ct))
        {
            // Yielding allows the server to push data immediately without buffering the whole response
            yield return token;
        }
    }
}
