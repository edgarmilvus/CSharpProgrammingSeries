
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SignalRStreamingSimulation
{
    // ---------------------------------------------------------
    // 1. Domain Models (Stateful Context)
    // ---------------------------------------------------------
    // Represents a single message in the conversation history.
    // We use a simple class to maintain state across the simulated connection.
    public class ChatMessage
    {
        public string Role { get; set; } // "User" or "AI"
        public string Content { get; set; }
        public DateTime Timestamp { get; set; }
    }

    // ---------------------------------------------------------
    // 2. Backend: AI Service (Simulated LLM)
    // ---------------------------------------------------------
    // Simulates an AI model that generates tokens one by one.
    // In a real scenario, this would call an external API (e.g., Azure OpenAI).
    public class AIModelService
    {
        // A predefined response to simulate context-aware generation.
        private const string FullResponse = "Blazor WASM combined with SignalR allows for real-time " +
            "streaming of AI tokens, creating a responsive user experience.";

        // Simulates a network call to an LLM.
        // Uses 'yield return' to stream tokens asynchronously.
        public async IAsyncEnumerable<string> GenerateStreamAsync(string prompt)
        {
            // Simulate processing delay (network latency)
            await Task.Delay(200);

            // Tokenize the response (split by space for simulation)
            string[] tokens = FullResponse.Split(' ');

            foreach (var token in tokens)
            {
                // Simulate variable generation speed
                await Task.Delay(50); 
                yield return token + " "; // Stream token back
            }
        }
    }

    // ---------------------------------------------------------
    // 3. Communication Layer: SignalR Hub Simulation
    // ---------------------------------------------------------
    // Simulates the SignalR Hub logic running on the server.
    // Handles connection lifecycle and broadcasting streams.
    public class ChatHub
    {
        private readonly AIModelService _aiService;
        // Simulates a persistent connection store (usually managed by SignalR internally)
        private readonly List<ChatMessage> _conversationHistory;

        public ChatHub()
        {
            _aiService = new AIModelService();
            _conversationHistory = new List<ChatMessage>();
        }

        // Simulates the Hub method invoked by the client.
        // In real SignalR: [HubMethodName("SendMessage")]
        public async Task SendMessageAsync(string userMessage)
        {
            // 1. Update Stateful Context
            _conversationHistory.Add(new ChatMessage 
            { 
                Role = "User", 
                Content = userMessage, 
                Timestamp = DateTime.Now 
            });

            // 2. Prepare Context for AI (Pass history to model)
            // For this simulation, we just pass the current user message.
            string context = string.Join(" ", _conversationHistory);

            // 3. Stream Generation
            // We yield tokens back to the caller (Client) as they are generated.
            await foreach (var token in _aiService.GenerateStreamAsync(context))
            {
                // In real SignalR: await Clients.Caller.SendAsync("ReceiveToken", token);
                OnTokenReceived?.Invoke(token);
                await Task.Delay(1); // Small delay to simulate network transmission
            }

            // 4. Finalize Message
            OnMessageComplete?.Invoke();
        }

        // Events to simulate SignalR's 'Clients.Caller.SendAsync'
        public event Action<string> OnTokenReceived;
        public event Action OnMessageComplete;
    }

    // ---------------------------------------------------------
    // 4. Client: Blazor WASM Service (Simulated)
    // ---------------------------------------------------------
    // Simulates the Blazor WASM component logic that subscribes to the hub.
    public class BlazorChatClient
    {
        private readonly ChatHub _hubConnection;
        private readonly List<string> _receivedTokens;
        private readonly List<ChatMessage> _uiState; // Represents the Component's State

        public BlazorChatClient(ChatHub hub)
        {
            _hubConnection = hub;
            _receivedTokens = new List<string>();
            _uiState = new List<ChatMessage>();

            // Subscribe to the "Stream" events (Simulating SignalR HubConnection.On)
            _hubConnection.OnTokenReceived += HandleTokenStream;
            _hubConnection.OnMessageComplete += HandleMessageCompletion;
        }

        // The core logic for handling streaming data (Typewriter effect simulation)
        private void HandleTokenStream(string token)
        {
            _receivedTokens.Add(token);
            
            // In a real Blazor WASM app, this would trigger StateHasChanged()
            // to re-render the UI incrementally.
            Console.Write(token); 
        }

        private void HandleMessageCompletion()
        {
            // Reconstruct the full message from the stream buffer
            string fullContent = string.Join("", _receivedTokens);
            
            // Update the UI State (Conversation History)
            _uiState.Add(new ChatMessage 
            { 
                Role = "AI", 
                Content = fullContent, 
                Timestamp = DateTime.Now 
            });

            // Clear buffer for next message
            _receivedTokens.Clear();
            Console.WriteLine("\n[Stream Complete]");
        }

        // Simulates the user typing in the UI and clicking "Send"
        public async Task SendUserMessageAsync(string message)
        {
            Console.WriteLine($"\n[User]: {message}");
            
            // Simulate UI loading state
            Console.Write("[AI]: ");
            
            // Invoke the Hub method (Network call)
            await _hubConnection.SendMessageAsync(message);
        }
    }

    // ---------------------------------------------------------
    // 5. Execution Entry Point
    // ---------------------------------------------------------
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== SignalR Streaming Simulation (Console App) ===");
            Console.WriteLine("Simulating Blazor WASM Client <-> SignalR Hub <-> AI Backend\n");

            // 1. Initialize Backend (Server)
            var hub = new ChatHub();

            // 2. Initialize Frontend (Client)
            var client = new BlazorChatClient(hub);

            // 3. Simulate Real-Time Interaction
            await client.SendUserMessageAsync("How does Blazor WASM streaming work?");

            // Simulate a second interaction to show state persistence
            Console.WriteLine("\n---------------------------------------------------");
            await client.SendUserMessageAsync("Can you explain latency?");
        }
    }
}
