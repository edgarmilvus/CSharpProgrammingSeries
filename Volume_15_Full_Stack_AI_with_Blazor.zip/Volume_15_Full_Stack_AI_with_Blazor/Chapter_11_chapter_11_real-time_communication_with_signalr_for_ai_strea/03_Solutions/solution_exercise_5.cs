
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

// Client-Side: OptimisticChatService.cs
public class OptimisticChatService
{
    private readonly HubConnection _connection;
    public event Action<string>? OnError;
    public event Action<long>? OnLatencyReport; // TTFT in ms

    public OptimisticChatService(HubConnection connection)
    {
        _connection = connection;
        
        // Handle connection loss specifically for rollback
        _connection.Closed += async (ex) =>
        {
            OnError?.Invoke("Connection lost. Please retry.");
            await Task.CompletedTask;
        };
    }

    public async Task<string?> SendPromptOptimistically(string prompt)
    {
        var sw = Stopwatch.StartNew();
        
        try
        {
            // 1. Trigger the server call
            await _connection.InvokeAsync("GenerateStream", prompt);
            
            // 2. Stop timer when first callback is received (handled in component or via callback)
            // In this architecture, we rely on the component to measure the first token arrival.
            return prompt; 
        }
        catch (Exception ex)
        {
            OnError?.Invoke($"Error: {ex.Message}");
            return null;
        }
    }
}

// Client-Side: OptimisticChat.razor
@implements IDisposable
@inject OptimisticChatService ChatService
@inject IJSRuntime JS // For scrolling

<div class="chat-container">
    @foreach (var msg in Messages)
    {
        <div class="msg @msg.Sender">
            @if (msg.IsLoading)
            {
                <span class="typing-indicator">...</span>
            }
            else
            {
                @msg.Content
            }
        </div>
    }
</div>

<div class="input-area">
    <input @bind="inputText" disabled="@_isProcessing" />
    <button @onclick="HandleSend" disabled="@_isProcessing">Send</button>
    <button @onclick="HandleRetry" disabled="!_hasError">Retry</button>
    
    @if (_ttft.HasValue)
    {
        <div class="metrics">TTFT: @_ttft ms</div>
    }
</div>

@code {
    private string inputText = "";
    private List<ChatMessageVM> Messages = new();
    private bool _isProcessing = false;
    private bool _hasError = false;
    private Stopwatch? _ttftStopwatch;
    private long? _ttft;

    protected override void OnInitialized()
    {
        ChatService.OnError += (msg) => 
        {
            _isProcessing = false;
            _hasError = true;
            // Rollback: Remove the loading placeholder
            var loadingMsg = Messages.FirstOrDefault(m => m.IsLoading);
            if (loadingMsg != null) Messages.Remove(loadingMsg);
            
            // Show error in UI
            Messages.Add(new ChatMessageVM { Content = $"Error: {msg}", Sender = "system" });
            InvokeAsync(StateHasChanged);
        };

        ChatService.OnLatencyReport += (ms) => 
        {
            _ttft = ms;
            InvokeAsync(StateHasChanged);
        };
    }

    private async Task HandleSend()
    {
        if (string.IsNullOrWhiteSpace(inputText)) return;

        _isProcessing = true;
        _hasError = false;
        _ttft = null;
        _ttftStopwatch = Stopwatch.StartNew();

        // 1. Optimistic Render: User Message
        Messages.Add(new ChatMessageVM { Content = inputText, Sender = "user" });

        // 2. Optimistic Render: AI Placeholder
        Messages.Add(new ChatMessageVM { Content = "", Sender = "ai", IsLoading = true });
        
        var prompt = inputText;
        inputText = ""; // Clear input immediately

        // 3. Execute Network Request
        var result = await ChatService.SendPromptOptimistically(prompt);

        // Note: In a real SignalR streaming scenario, the first token arrival 
        // would reset the _ttftStopwatch via an event handler attached to the stream observer.
        // Here we simulate the completion logic.
        
        _isProcessing = false;
    }

    private void HandleRetry()
    {
        // Re-insert the last user prompt (if any) for retry
        var lastUserMsg = Messages.LastOrDefault(m => m.Sender == "user");
        if (lastUserMsg != null)
        {
            inputText = lastUserMsg.Content;
            _hasError = false;
        }
    }

    public void Dispose()
    {
        // Cleanup events
    }

    class ChatMessageVM
    {
        public string Content { get; set; } = "";
        public string Sender { get; set; } = "";
        public bool IsLoading { get; set; }
    }
}
