
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// Server-Side: RaceHub.cs
public class RaceHub : Hub
{
    public async Task RaceModels(string prompt)
    {
        var caller = Clients.Caller;
        var connectionId = Context.ConnectionId;

        // Task A: Simulate Fast Model (e.g., GPT-3.5)
        var taskA = Task.Run(async () =>
        {
            await Task.Delay(1000); // Simulate latency
            await caller.SendAsync("ReceiveTokenA", "Model A (Fast): ");
            await caller.SendAsync("ReceiveTokenA", "I responded immediately.");
            await caller.SendAsync("StreamCompleteA");
        });

        // Task B: Simulate Slower Model (e.g., GPT-4)
        var taskB = Task.Run(async () =>
        {
            await Task.Delay(2500); // Simulate higher latency
            await caller.SendAsync("ReceiveTokenB", "Model B (Quality): ");
            await caller.SendAsync("ReceiveTokenB", "I take longer to think.");
            await caller.SendAsync("StreamCompleteB");
        });

        // We don't necessarily wait for both to finish to return, 
        // but we track them to handle errors.
        await Task.WhenAll(taskA, taskB);
    }
}

// Client-Side: RaceController.cs (Service)
public class RaceController
{
    private readonly HubConnection _connection;
    public string ModelAOutput { get; private set; } = "";
    public string ModelBOutput { get; private set; } = "";
    
    // Metrics
    public long? LatencyDiffMs { get; private set; }
    private Stopwatch? _stopwatchA;
    private Stopwatch? _stopwatchB;

    public RaceController(HubConnection connection)
    {
        _connection = connection;
        
        // Setup Handlers
        _connection.On<string>("ReceiveTokenA", (token) =>
        {
            if (_stopwatchA == null) 
            {
                _stopwatchA = Stopwatch.StartNew();
                // If B hasn't started yet, A is winning by default
            }
            ModelAOutput += token;
        });

        _connection.On<string>("ReceiveTokenB", (token) =>
        {
            if (_stopwatchB == null)
            {
                _stopwatchB = Stopwatch.StartNew();
                // Calculate Latency Diff immediately if A is already running
                if (_stopwatchA != null)
                {
                    LatencyDiffMs = _stopwatchB.ElapsedMilliseconds - _stopwatchA.ElapsedMilliseconds;
                }
            }
            ModelBOutput += token;
        });
    }

    public async Task StartRace(string prompt)
    {
        ModelAOutput = "";
        ModelBOutput = "";
        LatencyDiffMs = null;
        _stopwatchA = null;
        _stopwatchB = null;
        
        await _connection.InvokeAsync("RaceModels", prompt);
    }
}

// Client-Side: RaceView.razor
@inject RaceController RaceController

<div class="dashboard">
    <div class="controls">
        <input @bind="prompt" />
        <button @onclick="RunRace">Start Race</button>
    </div>

    <div class="split-view">
        <!-- Left Pane: Model A -->
        <div class="pane @(RaceController.LatencyDiffMs < 0 ? "winner" : "")">
            <h3>Model A (Speed)</h3>
            <div class="output">@((MarkupString)RaceController.ModelAOutput)</div>
        </div>

        <!-- Right Pane: Model B -->
        <div class="pane @(RaceController.LatencyDiffMs > 0 ? "winner" : "")">
            <h3>Model B (Quality)</h3>
            <div class="output">@((MarkupString)RaceController.ModelBOutput)</div>
        </div>
    </div>

    <!-- Overlay Metrics -->
    @if (RaceController.LatencyDiffMs.HasValue)
    {
        <div class="latency-overlay">
            Latency Diff: @Math.Abs(RaceController.LatencyDiffMs.Value) ms 
            @(RaceController.LatencyDiffMs.Value < 0 ? "(Model A Faster)" : "(Model B Faster)")
        </div>
    }
</div>

@code {
    private string prompt = "";

    private async Task RunRace()
    {
        await RaceController.StartRace(prompt);
    }
}
