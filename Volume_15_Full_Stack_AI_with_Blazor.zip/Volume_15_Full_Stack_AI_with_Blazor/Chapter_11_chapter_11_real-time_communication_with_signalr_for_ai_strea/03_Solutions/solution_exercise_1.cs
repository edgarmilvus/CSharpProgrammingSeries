
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// Server-Side: AiHub.cs
using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;

public class AiHub : Hub
{
    // Store cancellation tokens per connection to handle disconnects
    private static readonly ConcurrentDictionary<string, CancellationTokenSource> _activeStreams = new();

    public async Task GenerateStream(string prompt)
    {
        var cts = new CancellationTokenSource();
        // Register the stream against the connection ID
        _activeStreams[Context.ConnectionId] = cts;

        try
        {
            // Simulate passing the token to an external HTTP call (e.g., OpenAI)
            // In a real scenario, use HttpClient.SendAsync with HttpCompletionOption.ResponseHeadersRead
            using var responseStream = await GetLLMStreamAsync(prompt, cts.Token);
            
            // Read stream and send to client
            using var reader = new StreamReader(responseStream);
            while (!reader.EndOfStream)
            {
                var chunk = await reader.ReadLineAsync();
                if (!string.IsNullOrEmpty(chunk))
                {
                    // Check cancellation before sending
                    cts.Token.ThrowIfCancellationRequested();
                    await Clients.Caller.SendAsync("ReceiveToken", chunk);
                }
            }
        }
        catch (OperationCanceledException)
        {
            await Clients.Caller.SendAsync("StreamCanceled", "Generation stopped by user.");
        }
        finally
        {
            _activeStreams.TryRemove(Context.ConnectionId, out _);
        }
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        if (_activeStreams.TryRemove(Context.ConnectionId, out var cts))
        {
            // Cancel the backend processing immediately
            cts.Cancel();
            cts.Dispose();
            // Log the disconnection (using ILogger in production)
            Console.WriteLine($"Connection {Context.ConnectionId} disconnected. Reason: {exception?.Message ?? "Client initiated"}");
        }
        await base.OnDisconnectedAsync(exception);
    }

    // Helper to simulate the LLM stream call
    private async Task<Stream> GetLLMStreamAsync(string prompt, CancellationToken token)
    {
        // Simulate network latency
        await Task.Delay(500, token);
        // Return a mock stream
        var content = $"Simulated response for: {prompt}";
        return new MemoryStream(System.Text.Encoding.UTF8.GetBytes(content));
    }
}

// Client-Side: ChatService.cs (Blazor WASM)
using Microsoft.AspNetCore.SignalR.Client;
using System.Reactive.Subjects;

public class ChatService : IAsyncDisposable
{
    private HubConnection? _hubConnection;
    private CancellationTokenSource? _interactionCts;
    private readonly Subject<string> _tokenStream = new();
    
    public IObservable<string> TokenStream => _tokenStream.AsObservable();

    public async Task InitializeAsync()
    {
        _hubConnection = new HubConnectionBuilder()
            .WithUrl("https://your-api/aiHub")
            .WithAutomaticReconnect(new RetryPolicy()) // Custom retry policy
            .Build();

        // Handle Reconnection UI updates
        _hubConnection.Closed += async (error) =>
        {
            // Update UI state (e.g., show "Reconnecting..." banner)
            Console.WriteLine($"Connection closed: {error?.Message}");
            await Task.Delay(new Random().Next(0, 5) * 1000); // Exponential backoff logic handled by builder usually
            await _hubConnection.StartAsync();
        };

        _hubConnection.Reconnected += (connectionId) =>
        {
            Console.WriteLine($"Connection reestablished: {connectionId}");
            return Task.CompletedTask;
        };

        // Subscribe to tokens
        _hubConnection.On<string>("ReceiveToken", token => _tokenStream.OnNext(token));
        _hubConnection.On<string>("StreamCanceled", msg => _tokenStream.OnNext($"\n[{msg}]"));

        await _hubConnection.StartAsync();
    }

    public async Task SendPrompt(string prompt)
    {
        CancelPreviousGeneration(); // Cancel any ongoing stream before starting new

        _interactionCts = new CancellationTokenSource();
        
        // Pass the token to the server invocation (SignalR handles cancellation internally)
        // Note: SignalR hubs don't automatically pass CancellationToken from client to server method args,
        // but we rely on OnDisconnectedAsync on server, or explicit Cancel call.
        // For true bridging, we usually call a separate Cancel method or rely on connection abort.
        
        await _hubConnection.InvokeAsync("GenerateStream", prompt, _interactionCts.Token);
    }

    public void CancelPreviousGeneration()
    {
        if (_interactionCts != null && !_interactionCts.IsCancellationRequested)
        {
            _interactionCts.Cancel();
            _interactionCts.Dispose();
            _interactionCts = null;
            
            // In a robust SignalR setup, we might explicitly call a server 'Cancel' method
            // or abort the connection. Here we rely on the server detecting the disconnect 
            // or a specific cancellation endpoint. 
            // For strict requirement: "Trigger CancelPreviousGeneration":
            // We can abort the connection briefly or send a specific Cancel invocation.
            // However, standard practice is to abort the HTTP request on server via CancellationTokenSource
            // mapped to the connection ID.
            // To strictly bridge client intent: 
            _ = _hubConnection.SendAsync("CancelStream"); // Assume server implements this to trigger the CTS
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_interactionCts != null)
        {
            _interactionCts.Cancel();
            _interactionCts.Dispose();
        }
        if (_hubConnection is not null)
        {
            await _hubConnection.DisposeAsync();
        }
    }

    // Custom Retry Policy (Exponential Backoff)
    private class RetryPolicy : IRetryPolicy
    {
        public TimeSpan? NextRetryDelay(RetryContext retryContext)
        {
            // Start at 2 seconds, double up
            var delay = TimeSpan.FromSeconds(Math.Pow(2, retryContext.PreviousRetryCount));
            return delay > TimeSpan.FromSeconds(30) ? TimeSpan.FromSeconds(30) : delay;
        }
    }
}
