
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// Server-Side: ConversationState.cs
using System.Collections.Concurrent;
using System.Text;

public class ConversationState
{
    // Thread-safe storage for conversation history
    private static readonly ConcurrentDictionary<string, List<Message>> _history = new();
    private const int MaxTokenLimit = 4000; // Approximate limit
    private const int TruncateAmount = 500; // Tokens to remove when limit hit

    public void AddMessage(string connectionId, string role, string content)
    {
        var history = _history.GetOrAdd(connectionId, _ => new List<Message>());
        
        // Truncation Logic (FIFO)
        // Estimate tokens (roughly 4 chars per token) or use a tokenizer library
        var currentSize = history.Sum(m => m.Content.Length);
        if (currentSize > MaxTokenLimit * 4)
        {
            // Remove oldest messages until size is reduced
            int removed = 0;
            while (removed < TruncateAmount * 4 && history.Count > 0)
            {
                removed += history[0].Content.Length;
                history.RemoveAt(0);
            }
        }

        history.Add(new Message { Role = role, Content = content });
    }

    public string GetContextPrompt(string connectionId)
    {
        if (!_history.TryGetValue(connectionId, out var history))
            return string.Empty;

        // Format for LLM (e.g., "User: ...\nAI: ...")
        var sb = new StringBuilder();
        foreach (var msg in history)
        {
            sb.AppendLine($"{msg.Role}: {msg.Content}");
        }
        return sb.ToString();
    }

    public void ClearHistory(string connectionId)
    {
        _history.TryRemove(connectionId, out _);
    }

    public class Message
    {
        public string Role { get; set; } = "user";
        public string Content { get; set; } = "";
    }
}

// Server-Side: AiHub.cs (Integration)
public class AiHub : Hub
{
    private readonly ConversationState _conversationState;

    public AiHub(ConversationState conversationState)
    {
        _conversationState = conversationState;
    }

    public async Task GenerateStream(string userPrompt)
    {
        var connectionId = Context.ConnectionId;

        // 1. Append User Message to History
        _conversationState.AddMessage(connectionId, "user", userPrompt);

        // 2. Get Full Context
        var fullContext = _conversationState.GetContextPrompt(connectionId);

        // 3. Stream LLM Response
        var responseBuilder = new StringBuilder();
        
        // Simulate streaming
        var mockTokens = new[] { "Here", " is", " the", " context-aware", " response." };
        foreach (var token in mockTokens)
        {
            await Clients.Caller.SendAsync("ReceiveToken", token);
            responseBuilder.Append(token);
            await Task.Delay(100);
        }

        // 4. Append AI Response to History (Accumulate during stream or at end)
        _conversationState.AddMessage(connectionId, "assistant", responseBuilder.ToString());
    }
}
