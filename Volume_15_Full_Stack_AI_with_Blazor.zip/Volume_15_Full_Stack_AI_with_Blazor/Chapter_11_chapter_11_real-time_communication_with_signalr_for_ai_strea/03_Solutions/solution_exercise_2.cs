
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// Client-Side: TokenStreamObserver.cs
using System.Reactive.Linq;
using System.Reactive.Subjects;

public class TokenStreamObserver : IDisposable
{
    private readonly Subject<string> _tokenSubject = new();
    private IDisposable? _subscription;
    private readonly Subject<string> _bufferedStream = new();

    public IObservable<string> BufferedStream => _bufferedStream.AsObservable();

    public TokenStreamObserver()
    {
        // Buffer tokens every 50ms and flush them as a combined string
        // This drastically reduces UI render cycles
        _subscription = _tokenSubject
            .Buffer(TimeSpan.FromMilliseconds(50))
            .Where(tokens => tokens.Count > 0)
            .Select(tokens => string.Concat(tokens))
            .Subscribe(chunk =>
            {
                _bufferedStream.OnNext(chunk);
            });
    }

    public void PushToken(string token) => _tokenSubject.OnNext(token);

    public void Complete() => _tokenSubject.OnCompleted();

    public void Dispose()
    {
        _tokenSubject.OnCompleted();
        _subscription?.Dispose();
        _tokenSubject.Dispose();
        _bufferedStream.Dispose();
    }
}

// Client-Side: ChatWindow.razor
@implements IDisposable
@inject ChatService ChatService

<div class="chat-output">
    @foreach (var message in ChatMessages)
    {
        <div class="message @(message.IsUser ? "user" : "ai")">
            @message.Content
        </div>
    }
</div>

@code {
    private List<ChatMessage> ChatMessages = new();
    private TokenStreamObserver? _streamObserver;
    private IDisposable? _streamSubscription;

    protected override void OnInitialized()
    {
        // Initialize observer
        _streamObserver = new TokenStreamObserver();
        
        // Subscribe to the buffered stream
        _streamSubscription = _streamObserver.BufferedStream.Subscribe(async chunk =>
        {
            // Thread-safe UI update
            await InvokeAsync(() =>
            {
                // Update the last AI message in the collection
                var lastMsg = ChatMessages.LastOrDefault(m => !m.IsUser);
                if (lastMsg != null)
                {
                    lastMsg.Content += chunk;
                }
                else
                {
                    // Fallback if stream arrives before placeholder
                    ChatMessages.Add(new ChatMessage { IsUser = false, Content = chunk });
                }
                StateHasChanged();
            });
        });
    }

    public async Task HandleUserMessage(string prompt)
    {
        // RACE CONDITION HANDLING:
        // 1. Dispose previous subscription to stop updating the old UI state
        _streamSubscription?.Dispose();
        
        // 2. Reset observer for new stream
        _streamObserver?.Dispose();
        _streamObserver = new TokenStreamObserver();

        // 3. Re-subscribe
        _streamSubscription = _streamObserver.BufferedStream.Subscribe(async chunk => { /* ... same logic as above ... */ });

        // Add User Message
        ChatMessages.Add(new ChatMessage { IsUser = true, Content = prompt });
        
        // Add Placeholder for AI
        ChatMessages.Add(new ChatMessage { IsUser = false, Content = "" });
        
        // Start the SignalR stream
        await ChatService.SendPrompt(prompt);

        // Bridge SignalR events to the Observer
        // (In a real app, ChatService would expose the raw IObservable, 
        // but here we simulate the bridge)
        ChatService.TokenStream.Subscribe(token => _streamObserver?.PushToken(token));
    }

    public void Dispose()
    {
        _streamSubscription?.Dispose();
        _streamObserver?.Dispose();
    }

    class ChatMessage 
    { 
        public string Content { get; set; } = ""; 
        public bool IsUser { get; set; } 
    }
}
