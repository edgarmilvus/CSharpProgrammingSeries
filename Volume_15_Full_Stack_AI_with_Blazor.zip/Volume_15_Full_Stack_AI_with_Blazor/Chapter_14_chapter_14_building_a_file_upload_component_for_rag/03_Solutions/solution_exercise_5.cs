
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

// 1. Saga State Machine
public enum FileProcessState
{
    Uploaded,
    Validated,
    Vectorized,
    Stored,
    Failed
}

public class FileProcessSaga
{
    public string FileId { get; set; }
    public string TempPath { get; set; }
    public string PermanentPath { get; set; }
    public FileProcessState CurrentState { get; set; }
}

// 2. Saga Orchestrator (Simplified for single service context)
public class FileUploadSagaOrchestrator
{
    private readonly ILogger<FileUploadSagaOrchestrator> _logger;

    public FileUploadSagaOrchestrator(ILogger<FileUploadSagaOrchestrator> logger)
    {
        _logger = logger;
    }

    public async Task ExecuteSagaAsync(IFormFile file)
    {
        var saga = new FileProcessSaga
        {
            FileId = Guid.NewGuid().ToString(),
            TempPath = Path.GetTempFileName(),
            CurrentState = FileProcessState.Uploaded
        };

        try
        {
            // Step 1: Upload (Write to Temp)
            await Step_UploadAsync(file, saga);
            
            // Step 2: Validate
            await Step_ValidateAsync(saga);
            
            // Step 3: Vectorize (Simulate AI call)
            await Step_VectorizeAsync(saga);
            
            // Step 4: Store (Move to permanent)
            await Step_StoreAsync(saga);
            
            _logger.LogInformation("Saga completed successfully for {FileId}", saga.FileId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Saga failed at state {State}. Executing compensations.", saga.CurrentState);
            await ExecuteCompensationsAsync(saga);
        }
    }

    private async Task Step_UploadAsync(IFormFile file, FileProcessSaga saga)
    {
        saga.CurrentState = FileProcessState.Uploaded;
        await using var stream = new FileStream(saga.TempPath, FileMode.Create);
        await file.CopyToAsync(stream);
    }

    private async Task Step_ValidateAsync(FileProcessSaga saga)
    {
        saga.CurrentState = FileProcessState.Validated;
        // Simulate validation logic
        if (!File.Exists(saga.TempPath)) throw new InvalidOperationException("File missing.");
        await Task.Delay(100); 
    }

    private async Task Step_VectorizeAsync(FileProcessSaga saga)
    {
        saga.CurrentState = FileProcessState.Vectorized;
        // Simulate external API failure (e.g., 500 error)
        // throw new HttpRequestException("Embedding API timeout");
        await Task.Delay(200);
    }

    private async Task Step_StoreAsync(FileProcessSaga saga)
    {
        saga.CurrentState = FileProcessState.Stored;
        saga.PermanentPath = Path.Combine("uploads", saga.FileId + ".pdf");
        File.Move(saga.TempPath, saga.PermanentPath);
        await Task.Delay(50);
    }

    private async Task ExecuteCompensationsAsync(FileProcessSaga saga)
    {
        // Execute in reverse order based on current state
        if (saga.CurrentState >= FileProcessState.Stored)
        {
            // Compensation: Delete permanent file
            if (File.Exists(saga.PermanentPath)) File.Delete(saga.PermanentPath);
        }
        
        if (saga.CurrentState >= FileProcessState.Uploaded)
        {
            // Compensation: Delete temp file
            if (File.Exists(saga.TempPath)) File.Delete(saga.TempPath);
        }

        // Log failure to a persistent store for retry
        await LogFailureToDatabaseAsync(saga);
    }

    private Task LogFailureToDatabaseAsync(FileProcessSaga saga)
    {
        _logger.LogWarning("Compensation complete. Saga {FileId} rolled back.", saga.FileId);
        return Task.CompletedTask;
    }
}

// 3. Global Exception Filter (Middleware)
public class TransactionalExceptionFilter : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        if (context.Exception is InvalidOperationException || context.Exception is HttpRequestException)
        {
            // Standardize error response
            context.Result = new ObjectResult(new 
            { 
                error = "Processing failed", 
                correlationId = Guid.NewGuid(),
                detail = context.Exception.Message 
            })
            {
                StatusCode = 500
            };
            context.ExceptionHandled = true;
        }
    }
}
