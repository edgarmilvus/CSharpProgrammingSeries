
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// Client-Side: ProgressStream.cs
public class ProgressStream : Stream
{
    private readonly Stream _innerStream;
    private readonly IProgress<long> _progress;
    private long _bytesRead;

    public ProgressStream(Stream innerStream, IProgress<long> progress)
    {
        _innerStream = innerStream;
        _progress = progress;
    }

    public override async Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
    {
        var bytesRead = await _innerStream.ReadAsync(buffer, offset, count, cancellationToken);
        _bytesRead += bytesRead;
        _progress.Report(_bytesRead);
        return bytesRead;
    }

    // Override other necessary members (CanRead, Seek, etc.) delegating to _innerStream
    public override bool CanRead => _innerStream.CanRead;
    public override bool CanSeek => _innerStream.CanSeek;
    public override bool CanWrite => _innerStream.CanWrite;
    public override long Length => _innerStream.Length;
    public override long Position { get => _innerStream.Position; set => _innerStream.Position = value; }
    public override void Flush() => _innerStream.Flush();
    public override long Seek(long offset, SeekOrigin origin) => _innerStream.Seek(offset, origin);
    public override void SetLength(long value) => _innerStream.SetLength(value);
    public override void Write(byte[] buffer, int offset, int count) => _innerStream.Write(buffer, offset, count);
}

// Client-Side: UploadComponent.razor
@inject HttpClient Http

<input type="file" @onchange="OnFileSelected" />
<progress value="@_progressValue" max="@_maxProgress" class="w-full h-4"></progress>
<div>@_statusText</div>

@code {
    private long _progressValue;
    private long _maxProgress;
    private string _statusText = "Ready";
    private CancellationTokenSource? _uploadCts;

    private async Task OnFileSelected(InputFileChangeEventArgs e)
    {
        var file = e.File;
        if (file == null) return;

        // Setup Cancellation
        _uploadCts = new CancellationTokenSource();
        _statusText = "Uploading...";
        _progressValue = 0;
        _maxProgress = file.Size;

        try
        {
            using var stream = file.OpenReadStream(file.Size);
            var progress = new Progress<long>(bytes => 
            {
                _progressValue = bytes;
                StateHasChanged(); // Update UI
            });

            // Wrap stream for progress reporting
            var progressStream = new ProgressStream(stream, progress);

            using var content = new StreamContent(progressStream);
            
            // Thread Cancellation Token to HttpClient
            using var response = await Http.PostAsync("api/upload", content, _uploadCts.Token);
            
            response.EnsureSuccessStatusCode();
            _statusText = "Upload Complete!";
        }
        catch (OperationCanceledException)
        {
            _statusText = "Upload Cancelled by user.";
        }
        catch (Exception ex)
        {
            _statusText = $"Error: {ex.Message}";
        }
    }

    private void CancelUpload()
    {
        _uploadCts?.Cancel();
    }
}

// Server-Side: Upload Endpoint
[HttpPost("api/upload")]
public async Task<IActionResult> UploadFile(IFormFile file, [FromServices] ILogger<Program> logger, CancellationToken cancellationToken)
{
    if (file == null) return BadRequest();

    var tempPath = Path.GetTempFileName();
    
    try
    {
        await using var fileStream = new FileStream(tempPath, FileMode.Create, FileAccess.Write);
        
        // Check cancellation every 10MB (approx 10485760 bytes)
        var buffer = new byte[81920]; // 80KB buffer
        long totalBytesRead = 0;
        
        while (true)
        {
            // Explicitly check token
            cancellationToken.ThrowIfCancellationRequested();

            var bytesRead = await file.OpenReadStream().ReadAsync(buffer, 0, buffer.Length, cancellationToken);
            if (bytesRead == 0) break;
            
            await fileStream.WriteAsync(buffer, 0, bytesRead, cancellationToken);
            totalBytesRead += bytesRead;
        }

        // Move to permanent storage (Atomic operation simulation)
        var finalPath = Path.Combine("uploads", file.FileName);
        System.IO.File.Move(tempPath, finalPath);

        return Ok(new { Message = "Upload successful", Size = totalBytesRead });
    }
    catch (OperationCanceledException)
    {
        logger.LogInformation("Upload cancelled. Cleaning up temp file.");
        if (System.IO.File.Exists(tempPath)) System.IO.File.Delete(tempPath);
        return StatusCode(499, "Client Closed Request"); // 499 is a common status for client disconnect
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Upload failed.");
        if (System.IO.File.Exists(tempPath)) System.IO.File.Delete(tempPath);
        return StatusCode(500, "Internal Server Error");
    }
}
