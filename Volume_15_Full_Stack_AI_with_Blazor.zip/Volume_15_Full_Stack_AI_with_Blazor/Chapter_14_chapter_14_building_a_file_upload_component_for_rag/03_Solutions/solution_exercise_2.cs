
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// IStreamProcessor.cs & Implementation
public interface IStreamProcessor
{
    IAsyncEnumerable<DocumentChunk> ProcessStreamAsync(Stream stream, string fileName, CancellationToken cancellationToken);
}

public class DocumentChunk
{
    public int ChunkId { get; set; }
    public string Content { get; set; } = string.Empty;
    public long Offset { get; set; }
}

public class PdfStreamProcessor : IStreamProcessor
{
    private readonly ILogger<PdfStreamProcessor> _logger;

    public PdfStreamProcessor(ILogger<PdfStreamProcessor> logger)
    {
        _logger = logger;
    }

    public async IAsyncEnumerable<DocumentChunk> ProcessStreamAsync(Stream stream, string fileName, [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        // Simulating chunking logic (e.g., reading lines or pages)
        // In a real scenario, this would use a PDF library like PdfPig or iTextSharp
        using var reader = new StreamReader(stream, leaveOpen: true);
        char[] buffer = new char[4096];
        int bytesRead;
        int chunkId = 0;
        long currentOffset = 0;

        while ((bytesRead = await reader.ReadAsync(buffer, 0, buffer.Length)) > 0)
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            // Simulate processing time
            await Task.Delay(50, cancellationToken); 

            var content = new string(buffer, 0, bytesRead);
            currentOffset += bytesRead;

            yield return new DocumentChunk
            {
                ChunkId = chunkId++,
                Content = content,
                Offset = currentOffset
            };
        }
    }
}

// Program.cs (Minimal API)
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// DI Registration
builder.Services.AddSingleton<IStreamProcessor, PdfStreamProcessor>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.MapPost("/upload-stream", async (HttpContext context, IStreamProcessor processor, CancellationToken cancellationToken) =>
{
    // 1. Multipart Reading
    var boundary = MultipartRequestHelper.GetBoundary(
        context.Request.ContentType, 
        lengthLimit: 1024 * 1024 * 10); // 10MB limit
    
    var reader = new MultipartReader(boundary, context.Request.Body);
    var section = await reader.ReadNextSectionAsync(cancellationToken);

    while (section != null)
    {
        if (HasFileContentDisposition(section))
        {
            // 2. Streaming Logic (Direct to Temp File or Memory Stream)
            // Here we process the stream directly without buffering the whole file
            var fileName = section.GetFileName();
            var stream = section.Body;

            // 3. JSON Serialization & Async Processing
            context.Response.ContentType = "application/json";
            
            // 4. Return IAsyncEnumerable (Streaming JSON response)
            await Results.Stream(async (streamWriter) =>
            {
                var jsonWriter = new Utf8JsonWriter(streamWriter);
                jsonWriter.WriteStartArray();

                await foreach (var chunk in processor.ProcessStreamAsync(stream, fileName, cancellationToken))
                {
                    jsonWriter.WriteStartObject();
                    jsonWriter.WriteNumber("chunkId", chunk.ChunkId);
                    jsonWriter.WriteString("content", chunk.Content);
                    jsonWriter.WriteNumber("offset", chunk.Offset);
                    jsonWriter.WriteEndObject();
                    
                    // Flush periodically to ensure client receives data immediately
                    await jsonWriter.FlushAsync(cancellationToken);
                }

                jsonWriter.WriteEndArray();
                await jsonWriter.FlushAsync(cancellationToken);
            }, "application/json", cancellationToken: cancellationToken);
            
            return;
        }
        section = await reader.ReadNextSectionAsync(cancellationToken);
    }

    return Results.BadRequest("No file uploaded.");
}).DisableAntiforgery(); // Disable for API testing

app.Run();

// Helper methods
static bool HasFileContentDisposition(MultipartSection section)
{
    return section.ContentDisposition != null &&
           section.ContentDisposition.Contains("filename=");
}
