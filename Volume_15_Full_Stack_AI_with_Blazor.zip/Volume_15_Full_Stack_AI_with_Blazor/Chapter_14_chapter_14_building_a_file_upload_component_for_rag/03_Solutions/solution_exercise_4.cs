
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// 1. Notification Definition
public record FileUploadedNotification(string FilePath, string FileName) : INotification;

// 2. Notification Handler (The RAG Processor)
public class VectorizationHandler : INotificationHandler<FileUploadedNotification>
{
    private readonly IEmbeddingGenerator _embeddingGenerator;
    private readonly IVectorStore _vectorStore;
    private readonly ILogger<VectorizationHandler> _logger;

    public VectorizationHandler(IEmbeddingGenerator embeddingGenerator, IVectorStore vectorStore, ILogger<VectorizationHandler> logger)
    {
        _embeddingGenerator = embeddingGenerator;
        _vectorStore = vectorStore;
        _logger = logger;
    }

    public async Task Handle(FileUploadedNotification notification, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Starting vectorization for {File}", notification.FileName);

        // 1. Read File
        var text = await File.ReadAllTextAsync(notification.FilePath, cancellationToken);

        // 2. Split Text (RecursiveCharacterTextSplitter simulation)
        var chunks = SplitText(text, 1000); // Split into ~1000 char chunks

        // 3. Generate Embeddings & Store
        foreach (var chunk in chunks)
        {
            var embedding = await _embeddingGenerator.GenerateAsync(chunk, cancellationToken);
            await _vectorStore.UpsertAsync(new VectorRecord { Text = chunk, Vector = embedding }, cancellationToken);
        }

        _logger.LogInformation("Vectorization complete for {File}", notification.FileName);
    }

    private IEnumerable<string> SplitText(string text, int chunkSize)
    {
        // Simplified logic for demonstration
        for (int i = 0; i < text.Length; i += chunkSize)
        {
            yield return text.Substring(i, Math.Min(chunkSize, text.Length - i));
        }
    }
}

// 3. Upload Endpoint triggering Notification
[HttpPost("upload")]
public async Task<IActionResult> UploadAndProcess(IFormFile file, [FromServices] IMediator mediator)
{
    var path = Path.Combine("uploads", file.FileName);
    await using var stream = new FileStream(path, FileMode.Create);
    await file.CopyToAsync(stream);

    // Publish notification to decouple processing
    await mediator.Publish(new FileUploadedNotification(path, file.FileName));

    return Ok(new { Message = "File uploaded and processing started." });
}

// 4. Status Polling Endpoint
[HttpGet("status/{fileName}")]
public IActionResult GetStatus(string fileName)
{
    // In a real app, check a database or cache (e.g., Redis) for status
    // Here we simulate checking a background job state
    var isComplete = BackgroundJobStore.IsComplete(fileName);
    return Ok(new { Status = isComplete ? "Complete" : "Processing" });
}
