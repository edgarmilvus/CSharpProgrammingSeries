
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// FileValidationService.cs
using System.Text;
using Microsoft.Extensions.Configuration;

public interface IFileValidationService
{
    Task<ValidationResult> ValidateFileAsync(IBrowserFile file, CancellationToken cancellationToken);
}

public class FileValidationService : IFileValidationService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<FileValidationService> _logger;

    public FileValidationService(IConfiguration configuration, ILogger<FileValidationService> logger)
    {
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<ValidationResult> ValidateFileAsync(IBrowserFile file, CancellationToken cancellationToken)
    {
        try
        {
            // 1. Size Check (Configurable)
            var maxSizeBytes = _configuration.GetValue<long>("FileUpload:MaxSizeBytes", 10 * 1024 * 1024);
            if (file.Size > maxSizeBytes)
                return ValidationResult.Failure($"File size {file.Size} exceeds limit {maxSizeBytes}.");

            // 2. Type Check (Whitelist)
            var allowedTypes = new[] { "application/pdf", "text/plain", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" };
            if (!allowedTypes.Contains(file.ContentType))
                return ValidationResult.Failure($"Content type {file.ContentType} is not allowed.");

            // 3. Magic Number Check (Chunked Pre-validation)
            // Read only first 4KB to check header without loading full stream
            using var stream = file.OpenReadStream(maxSizeBytes);
            var buffer = new byte[4096];
            var bytesRead = await stream.ReadAsync(buffer, cancellationToken);
            
            if (bytesRead < 4)
                return ValidationResult.Failure("File is too small to contain a valid header.");

            // Check for PDF signature: "%PDF"
            if (file.ContentType == "application/pdf")
            {
                var header = Encoding.ASCII.GetString(buffer.AsSpan(0, 4));
                if (header != "%PDF")
                    return ValidationResult.Failure("Invalid PDF header. File extension may be spoofed.");
            }

            return ValidationResult.Success();
        }
        catch (OperationCanceledException)
        {
            return ValidationResult.Failure("Validation was cancelled.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validating file {FileName}", file.Name);
            return ValidationResult.Failure("An unexpected error occurred during validation.");
        }
    }
}

public record ValidationResult(bool IsValid, string? ErrorMessage)
{
    public static ValidationResult Success() => new(true, null);
    public static ValidationResult Failure(string message) => new(false, message);
}
