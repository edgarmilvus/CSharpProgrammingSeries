
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/upload"
@using System.Text.Json
@using System.Text

<h3>Document Upload for RAG Pipeline</h3>

<!-- 1. The Drag-and-Drop Upload Zone -->
<div @ondragover="OnDragOver" 
     @ondragleave="OnDragLeave" 
     @ondrop="OnDrop"
     style="border: 2px dashed @(IsDragging ? "#007bff" : "#ccc"); 
            padding: 40px; 
            text-align: center; 
            background-color: @(IsDragging ? "#f0f8ff" : "white"); 
            transition: all 0.2s ease;">
    
    <p>Drag & Drop files here or click to select.</p>
    <input type="file" @ref="fileInputReference" @onchange="HandleFileSelected" style="display:none" />
    <button class="btn btn-primary" @onclick="() => fileInputReference?.Click()">Select File</button>

</div>

<!-- 2. Status and Log Output -->
@if (isUploading)
{
    <div class="alert alert-info mt-3">
        <strong>Uploading...</strong> 
        <div class="progress">
            <div class="progress-bar" style="width: @(UploadPercentage)%"></div>
        </div>
        <small>@progressMessage</small>
    </div>
}

@if (serverResponse != null)
{
    <div class="alert alert-success mt-3">
        <strong>Server Response:</strong>
        <pre>@serverResponse</pre>
    </div>
}

@code {
    // 3. Component State and References
    private bool IsDragging = false;
    private bool isUploading = false;
    private double UploadPercentage = 0;
    private string? progressMessage;
    private string? serverResponse;
    private ElementReference fileInputReference;

    // 4. Drag-and-Drop UI Handlers
    private void OnDragOver(DragEventArgs e) 
    { 
        IsDragging = true; 
        e.preventDefault(); // Necessary to allow dropping
    }

    private void OnDragLeave(DragEventArgs e) 
    { 
        IsDragging = false; 
    }

    private async Task OnDrop(DragEventArgs e)
    {
        IsDragging = false;
        if (e.DataTransfer?.Files != null && e.DataTransfer.Files.Count > 0)
        {
            await ProcessFile(e.DataTransfer.Files[0]);
        }
    }

    private async Task HandleFileSelected(ChangeEventArgs e)
    {
        if (e.Value is not null)
        {
            // In Blazor Server, the input element returns a browser file reference
            // We need to use JS interop to read the stream, or rely on the browser's default handling.
            // However, for this specific example, we will simulate a stream from a mock input 
            // or assume a standard file input handling pattern. 
            // *Note: For pure C# streaming in Blazor Server without JSInterop, 
            // we typically rely on the <InputFile> component (Blazor WebAssembly) 
            // or handle the stream via an API endpoint. 
            // To keep this self-contained and strictly C#, we will rely on the Drop event logic 
            // or a simplified abstraction.*
            
            // For this "Hello World", we will assume the user uses Drag & Drop 
            // or we simulate a stream creation. 
            // To make it strictly work in a copy-paste scenario without extra setup:
            // We will trigger the logic via the Drop handler primarily.
        }
    }

    // 5. Core Streaming Logic
    private async Task ProcessFile(IBrowserFile file)
    {
        isUploading = true;
        progressMessage = $"Processing {file.Name}...";
        serverResponse = null;
        UploadPercentage = 0;
        StateHasChanged();

        try
        {
            // A. Create a stream from the browser file object
            // This stream is provided by the browser, usually a reference to a temporary file
            await using var stream = file.OpenReadStream(maxAllowedSize: 50 * 1024 * 1024); // 50MB limit

            // B. Create a StreamReader to read text data
            using var reader = new StreamReader(stream);

            // C. Prepare a buffer to simulate RAG chunking
            var buffer = new StringBuilder();
            var chunkSize = 0;
            const int targetChunkSize = 4096; // Simulate processing 4KB chunks

            // D. Read the stream asynchronously chunk by chunk
            char[] charBuffer = new char[1024];
            int bytesRead;

            while ((bytesRead = await reader.ReadAsync(charBuffer, 0, charBuffer.Length)) > 0)
            {
                // Append to our buffer
                buffer.Append(charBuffer, 0, bytesRead);
                chunkSize += bytesRead;

                // Update UI progress based on stream position (approximate)
                // Note: file.Size is the total size
                var percent = (double)stream.Position / file.Size * 100;
                UploadPercentage = Math.Round(percent, 2);
                progressMessage = $"Read {stream.Position} / {file.Size} bytes...";
                
                // E. Simulate RAG Processing when a chunk reaches target size
                if (chunkSize >= targetChunkSize)
                {
                    await SimulateRagEmbedding(buffer.ToString());
                    buffer.Clear();
                    chunkSize = 0;
                }

                // Force UI update periodically (optional, but good for large files)
                if (UploadPercentage % 10 == 0) StateHasChanged();
            }

            // F. Process remaining data in buffer
            if (buffer.Length > 0)
            {
                await SimulateRagEmbedding(buffer.ToString());
            }

            serverResponse = "✅ File processed successfully. Embeddings generated.";
        }
        catch (Exception ex)
        {
            serverResponse = $"❌ Error: {ex.Message}";
        }
        finally
        {
            isUploading = false;
            StateHasChanged();
        }
    }

    // 6. Mock Backend Service (Dependency Injection Simulation)
    private async Task SimulateRagEmbedding(string textChunk)
    {
        // Simulate network latency to backend AI service
        await Task.Delay(100); 
        
        // In a real app, this would be an HttpClient call to your Python/ML backend
        // or a direct call to a local ONNX model.
        // Example: await HttpClient.PostAsJsonAsync("api/embeddings", new { Text = textChunk });
        
        Console.WriteLine($"Processing chunk of {textChunk.Length} chars...");
    }
}
