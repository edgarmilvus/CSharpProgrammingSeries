
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace RAGFileProcessing
{
    /// <summary>
    /// Simulates a backend service responsible for receiving file streams, 
    /// validating them, and converting them into vector embeddings for RAG.
    /// This class demonstrates Dependency Injection (Chapter 14 concept) by 
    /// abstracting the storage and processing logic.
    /// </summary>
    public class DocumentProcessorService
    {
        private readonly IStorageProvider _storageProvider;
        private readonly IEmbeddingGenerator _embeddingGenerator;

        // Constructor Injection: We depend on abstractions, not concretions.
        public DocumentProcessorService(IStorageProvider storageProvider, IEmbeddingGenerator embeddingGenerator)
        {
            _storageProvider = storageProvider;
            _embeddingGenerator = embeddingGenerator;
        }

        /// <summary>
        /// Orchestrates the file processing pipeline.
        /// </summary>
        /// <param name="fileName">The name of the file being uploaded.</param>
        /// <param name="fileStream">The raw byte stream from the Blazor component.</param>
        /// <returns>A status message indicating success or failure.</returns>
        public async Task<string> ProcessFileAsync(string fileName, Stream fileStream)
        {
            // 1. Validate File Type (Basic Logic)
            if (!IsFileTypeValid(fileName))
            {
                return $"Error: Invalid file type for '{fileName}'. Only .txt and .md allowed.";
            }

            // 2. Validate File Size (Stream Safety)
            if (fileStream.Length > 10 * 1024 * 1024) // 10MB limit
            {
                return $"Error: File '{fileName}' exceeds the 10MB size limit.";
            }

            try
            {
                // 3. Store the file using the injected provider
                string storagePath = await _storageProvider.SaveStreamAsync(fileName, fileStream);
                
                // 4. Read content for processing (Simulating Text Extraction)
                // In a real scenario, this might be done by a separate TextExtractor service.
                string content;
                using (var reader = new StreamReader(fileStream, Encoding.UTF8, true, 1024, leaveOpen: true))
                {
                    content = await reader.ReadToEndAsync();
                    fileStream.Position = 0; // Reset stream position for potential future reads
                }

                // 5. Generate Embeddings (Simulating Vectorization)
                // This mimics the RAG pipeline integration where text is converted to vectors.
                var vectorEmbeddings = await _embeddingGenerator.GenerateAsync(content);

                // 6. Return Success Summary
                return $"Success: Processed '{fileName}'.\n" +
                       $" - Stored at: {storagePath}\n" +
                       $" - Vector Dimensions: {vectorEmbeddings.Length}";
            }
            catch (Exception ex)
            {
                return $"Error: Failed to process '{fileName}'. Details: {ex.Message}";
            }
        }

        /// <summary>
        /// Basic validation logic using string manipulation and conditional statements.
        /// </summary>
        private bool IsFileTypeValid(string fileName)
        {
            string ext = Path.GetExtension(fileName).ToLower();
            return ext == ".txt" || ext == ".md";
        }
    }

    /// <summary>
    /// Abstraction for file storage (Dependency Injection concept).
    /// </summary>
    public interface IStorageProvider
    {
        Task<string> SaveStreamAsync(string fileName, Stream stream);
    }

    /// <summary>
    /// Concrete implementation of local file storage.
    /// </summary>
    public class LocalFileSystemStorage : IStorageProvider
    {
        private readonly string _rootPath;

        public LocalFileSystemStorage(string rootPath)
        {
            _rootPath = rootPath;
            if (!Directory.Exists(_rootPath))
            {
                Directory.CreateDirectory(_rootPath);
            }
        }

        public async Task<string> SaveStreamAsync(string fileName, Stream stream)
        {
            string fullPath = Path.Combine(_rootPath, fileName);
            
            // Ensure we are reading from the start of the stream
            if (stream.CanSeek) stream.Position = 0;

            using (var fileStream = new FileStream(fullPath, FileMode.Create, FileAccess.Write, FileShare.None, 4096, useAsync: true))
            {
                await stream.CopyToAsync(fileStream);
            }
            
            return fullPath;
        }
    }

    /// <summary>
    /// Abstraction for AI Embedding generation.
    /// </summary>
    public interface IEmbeddingGenerator
    {
        Task<float[]> GenerateAsync(string text);
    }

    /// <summary>
    /// Mock implementation of an AI service (e.g., Azure OpenAI or local ONNX model).
    /// </summary>
    public class MockEmbeddingGenerator : IEmbeddingGenerator
    {
        public Task<float[]> GenerateAsync(string text)
        {
            // Simulate AI processing delay
            // In a real app, this calls an external API or runs a local model.
            // We return a fixed-size vector (e.g., 384 dimensions) based on text length.
            int dimensions = 384;
            var embeddings = new float[dimensions];
            
            // Simple deterministic "hash" to fill vector for demo purposes
            for (int i = 0; i < dimensions; i++)
            {
                embeddings[i] = (text.Length % 100) / 100.0f + (i % 10) * 0.1f;
            }

            return Task.FromResult(embeddings);
        }
    }

    /// <summary>
    /// Main Console Application entry point.
    /// Simulates the Blazor File Upload Component sending a stream to the backend.
    /// </summary>
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== RAG File Processing Simulation ===\n");

            // 1. Setup Dependency Injection manually (Simulating Startup.cs)
            // We instantiate the concrete services.
            IStorageProvider storage = new LocalFileSystemStorage("./UploadedDocs");
            IEmbeddingGenerator ai = new MockEmbeddingGenerator();
            var processor = new DocumentProcessorService(storage, ai);

            // 2. Simulate File Upload Scenarios
            await RunScenario(processor, "valid_document.txt", "This is a sample text document for RAG processing.");
            await RunScenario(processor, "invalid_image.png", "Binary data would go here...");
            await RunScenario(processor, "large_document.txt", new string('x', 15 * 1024 * 1024)); // 15MB string
        }

        /// <summary>
        /// Helper method to run a specific processing scenario.
        /// </summary>
        static async Task RunScenario(DocumentProcessorService processor, string fileName, string content)
        {
            Console.WriteLine($"--- Processing: {fileName} ---");
            
            // Convert string content to Stream (Simulating Blazor's InputFile stream)
            byte[] byteArray = Encoding.UTF8.GetBytes(content);
            using (var stream = new MemoryStream(byteArray))
            {
                string result = await processor.ProcessFileAsync(fileName, stream);
                Console.WriteLine(result);
            }
            Console.WriteLine();
        }
    }
}
