
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// File: PerformancePage.razor (Component)
@page "/performance"
<h3>WASM Performance & AI Simulation</h3>

<button @onclick="RunFibonacci">Run Fibonacci (n=40)</button>
<button @onclick="RunSoftmax">Run Softmax Optimization</button>

@code {
    // 1. Recursive Fibonacci
    private long CalculateFibonacci(int n)
    {
        if (n <= 1) return n;
        return CalculateFibonacci(n - 1) + CalculateFibonacci(n - 2);
    }

    private async Task RunFibonacci()
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var result = CalculateFibonacci(40);
        sw.Stop();
        Console.WriteLine($"C# Fibonacci (40): {result} in {sw.ElapsedMilliseconds}ms");

        // JS Interop comparison
        var jsTime = await JSRuntime.InvokeAsync<long>("runJsFibonacci", 40);
        // Note: We can't easily get the time from JS inside the same call without returning an object, 
        // but we can log it from JS.
    }

    // 2. Softmax Optimization
    private void RunSoftmax()
    {
        int size = 1000000;
        float[] input = new float[size];
        Random rng = new Random();
        for(int i=0; i<size; i++) input[i] = (float)rng.NextDouble();

        // A. Unoptimized
        var sw = System.Diagnostics.Stopwatch.StartNew();
        SoftmaxUnoptimized(input);
        sw.Stop();
        Console.WriteLine($"Softmax Unoptimized: {sw.ElapsedMilliseconds}ms");

        // B. Optimized (SIMD)
        sw.Restart();
        // Only runs if hardware supports SIMD (WASM SIMD is enabled in .NET 8+)
        if (System.Numerics.Vector.IsHardwareAccelerated)
        {
            SoftmaxSimd(input);
            sw.Stop();
            Console.WriteLine($"Softmax SIMD: {sw.ElapsedMilliseconds}ms");
        }
        else
        {
            Console.WriteLine("SIMD hardware acceleration not detected.");
        }
    }

    private void SoftmaxUnoptimized(float[] input)
    {
        // Naive implementation
        float sum = 0;
        for(int i=0; i<input.Length; i++) 
        {
            input[i] = MathF.Exp(input[i]);
            sum += input[i];
        }
        for(int i=0; i<input.Length; i++) input[i] /= sum;
    }

    private void SoftmaxSimd(float[] input)
    {
        // Optimized using Span<T> and Vector<T>
        // Note: Full Softmax is complex to vectorize perfectly due to the reduction step (sum),
        // but we can vectorize the Exp calculation.
        var span = input.AsSpan();
        var vecSum = System.Numerics.Vector<float>.Zero;
        
        // Process in SIMD chunks
        int i = 0;
        int count = System.Numerics.Vector<float>.Count;
        for (; i <= span.Length - count; i += count)
        {
            var vector = new System.Numerics.Vector<float>(span.Slice(i));
            // Apply Exp (System.Numerics doesn't have Exp built-in, so we simulate the math or use a lookup)
            // For demonstration, we will just multiply to show SIMD usage, 
            // but in real AI, we'd use a vectorized math library (e.g., via NuGet).
            var result = System.Numerics.Vector.Multiply(vector, 1.1f); 
            result.CopyTo(span.Slice(i));
        }

        // Handle remainder
        for (; i < span.Length; i++)
        {
            span[i] *= 1.1f;
        }
    }
}
