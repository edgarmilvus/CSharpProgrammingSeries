
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// File: Program.cs
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.JSInterop;
using System.Runtime.InteropServices;
using WasmRuntimeInspection;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");

// Register JS Runtime for interop
builder.Services.AddScoped(sp => sp.GetRequiredService<IJSRuntime>() as IJSInProcessRuntime);

var host = builder.Build();

// INTERACTIVE CHALLENGE: Logging Runtime and Environment Details
try
{
    // 1. Attempt to access Mono Runtime Version via Reflection (Internal API)
    // Note: This relies on internal Mono types which may change. 
    // In production, prefer standard version checking or JS interop for browser details.
    var runtimeType = Type.GetType("Mono.Runtime, System.Private.CoreLib");
    if (runtimeType != null)
    {
        var displayNameMethod = runtimeType.GetMethod("GetDisplayName", BindingFlags.NonPublic | BindingFlags.Static);
        if (displayNameMethod != null)
        {
            var version = displayNameMethod.Invoke(null, null) as string;
            Console.WriteLine($"[Mono Runtime] Version: {version}");
        }
    }
    else
    {
        Console.WriteLine("[.NET Runtime] Mono type not found (likely running on CoreCLR/JS interop fallback).");
    }

    // 2. Get Browser Details via JSInterop
    var jsRuntime = host.Services.GetRequiredService<IJSRuntime>();
    var jsInProcess = host.Services.GetRequiredService<IJSInProcessRuntime>();
    
    // Using InProcess for immediate synchronous execution if available, otherwise async
    var userAgent = await jsRuntime.InvokeAsync<string>("navigator.userAgent");
    var platform = await jsRuntime.InvokeAsync<string>("navigator.platform");
    
    Console.WriteLine($"[Browser Environment] User Agent: {userAgent}");
    Console.WriteLine($"[Browser Environment] Platform: {platform}");
}
catch (Exception ex)
{
    Console.WriteLine($"Error logging details: {ex.Message}");
}

await host.RunAsync();
