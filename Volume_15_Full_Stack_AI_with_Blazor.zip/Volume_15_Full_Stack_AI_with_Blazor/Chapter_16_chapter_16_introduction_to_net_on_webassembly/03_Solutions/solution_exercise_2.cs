
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// File: Program.cs
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using System.Diagnostics;
using WasmRuntimeInspection;

// 1. Timing Mechanism: Start stopwatch immediately
var startupStopwatch = Stopwatch.StartNew();

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");

builder.Services.AddScoped(sp => sp.GetRequiredService<IJSRuntime>());

var host = builder.Build();

// 2. Interop Logging: Log the time taken to reach this point
try
{
    var jsRuntime = host.Services.GetRequiredService<IJSRuntime>();
    // Log the timestamp from the browser's performance timeline
    var jsTimestamp = await jsRuntime.InvokeAsync<double>("performance.now");
    
    startupStopwatch.Stop();
    
    Console.WriteLine($"[Startup Timing] Managed Code Entry: {jsTimestamp:F2}ms");
    Console.WriteLine($"[Startup Timing] Time to Host Build: {startupStopwatch.ElapsedMilliseconds}ms");
    
    // Fire and forget a custom event to signal Blazor is ready
    await jsRuntime.InvokeVoidAsync("eval", "console.log('[Blazor] Managed code initialized');");
}
catch (Exception ex)
{
    Console.WriteLine($"Startup timing error: {ex.Message}");
}

await host.RunAsync();
