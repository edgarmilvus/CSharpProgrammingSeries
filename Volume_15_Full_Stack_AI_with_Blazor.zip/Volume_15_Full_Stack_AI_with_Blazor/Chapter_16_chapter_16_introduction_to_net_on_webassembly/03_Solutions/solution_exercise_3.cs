
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// File: InteropPage.razor (Component)
@page "/interop"
@inject IJSRuntime JSRuntime
@inject IJSInProcessRuntime JSInProcessRuntime
<h3>JSInterop Performance & Marshalling</h3>

<button @onclick="RunBenchmarks">Run Benchmarks</button>
<button @onclick="TestMarshalling">Test Marshalling</button>
<button @onclick="TestErrorHandling">Test Error Handling</button>

@code {
    private async Task RunBenchmarks()
    {
        Console.WriteLine("--- Starting Benchmarks ---");
        
        // 1. Fire-and-forget (Void Async)
        var sw = System.Diagnostics.Stopwatch.StartNew();
        for (int i = 0; i < 10000; i++)
        {
            await JSRuntime.InvokeVoidAsync("console.log", "Benchmark Void");
        }
        sw.Stop();
        Console.WriteLine($"Async Void Call (10k): {sw.ElapsedMilliseconds}ms");

        // 2. Awaiting a Task (No Return)
        sw.Restart();
        for (int i = 0; i < 10000; i++)
        {
            await JSRuntime.InvokeAsync<object>("eval", "null");
        }
        sw.Stop();
        Console.WriteLine($"Async Await Task (10k): {sw.ElapsedMilliseconds}ms");

        // 3. Returning a String
        sw.Restart();
        for (int i = 0; i < 10000; i++)
        {
            await JSRuntime.InvokeAsync<string>("eval", "'result'");
        }
        sw.Stop();
        Console.WriteLine($"Async Return String (10k): {sw.ElapsedMilliseconds}ms");
    }

    private async Task TestMarshalling()
    {
        // Define the complex object
        var person = new PersonData { Name = "Alice", Age = 30, Skills = new List<string> { "C#", "WASM" } };
        
        // Send to JS, process, and return
        var updatedPerson = await JSRuntime.InvokeAsync<PersonData>("processPerson", person);
        
        if (updatedPerson != null)
        {
            Console.WriteLine($"Received: {updatedPerson.Name}, Age: {updatedPerson.Age}, Verified: {updatedPerson.Verified}");
            Console.WriteLine($"Skills: {string.Join(", ", updatedPerson.Skills)}");
        }
    }

    private async Task TestErrorHandling()
    {
        try
        {
            await JSRuntime.InvokeVoidAsync("throwError");
        }
        catch (JSException ex)
        {
            Console.WriteLine($"Caught JS Exception: {ex.Message}");
        }
    }

    // Data structure for Marshalling
    public class PersonData
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public List<string> Skills { get; set; }
        public bool Verified { get; set; } // Added by JS
    }

    // Interactive Challenge: Synchronous DOM Manipulation
    private void SyncDomManipulation()
    {
        // Only works if using IJSInProcessRuntime (Mono WASM specific)
        // This bypasses the async queue and calls JS directly.
        try 
        {
            var element = JSInProcessRuntime.Invoke<string>("document.getElementById", "app");
            Console.WriteLine($"Found element via sync call: {element}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Sync DOM access failed (likely not in Blazor WASM or context mismatch): " + ex.Message);
        }
    }
}
