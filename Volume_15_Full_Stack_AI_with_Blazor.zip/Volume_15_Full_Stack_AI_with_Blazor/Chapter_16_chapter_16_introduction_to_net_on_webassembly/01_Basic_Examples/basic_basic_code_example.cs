
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/sentiment-analyzer"
@using System.Text.Json
@inject ILogger<SentimentAnalyzer> Logger

<h3>Client-Side Sentiment Analyzer</h3>

<div class="mb-3">
    <label for="feedbackText" class="form-label">Enter your feedback:</label>
    <textarea id="feedbackText" class="form-control" @bind="inputText" rows="3"></textarea>
</div>

<button class="btn btn-primary" @onclick="AnalyzeSentiment" disabled="@isAnalyzing">
    @if (isAnalyzing)
    {
        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
        <span> Analyzing...</span>
    }
    else
    {
        <span>Analyze Sentiment</span>
    }
</button>

@if (result != null)
{
    <div class="alert alert-info mt-3" role="alert">
        <strong>Analysis Result:</strong> @result. <br />
        <small>Processed locally via Blazor WASM.</small>
    </div>
}

@code {
    // 1. State Properties
    private string? inputText;
    private string? result;
    private bool isAnalyzing = false;

    // 2. The AI Service (Simulated for this example)
    // In a real scenario, this would load an ONNX model or call a specialized math library.
    private readonly LocalAiService _aiService = new();

    // 3. Event Handler for User Interaction
    private async Task AnalyzeSentiment()
    {
        if (string.IsNullOrWhiteSpace(inputText))
        {
            Logger.LogWarning("Input text was empty.");
            return;
        }

        isAnalyzing = true;
        // Force a render to update the UI immediately (show the spinner)
        StateHasChanged();

        try
        {
            // Simulate the heavy lifting of AI inference
            await Task.Delay(500); // Simulate network/compute latency

            // Execute the logic entirely in the browser's WASM runtime
            result = await _aiService.PredictAsync(inputText);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error during sentiment analysis.");
            result = "Error analyzing sentiment.";
        }
        finally
        {
            isAnalyzing = false;
        }
    }

    // 4. Internal Logic Class (Simulating an AI Model)
    // This class represents the "Brain" of the WASM application.
    public class LocalAiService
    {
        // A simple heuristic-based model for demonstration purposes.
        // Real implementations would use TensorFlow.NET or ONNX Runtime for WASM.
        public Task<string> PredictAsync(string text)
        {
            var lowerText = text.ToLowerInvariant();
            
            // Heuristic logic: Check for keywords
            if (lowerText.Contains("great") || lowerText.Contains("love") || lowerText.Contains("excellent"))
            {
                return Task.FromResult("Positive 😊");
            }
            if (lowerText.Contains("bad") || lowerText.Contains("hate") || lowerText.Contains("terrible"))
            {
                return Task.FromResult("Negative 😟");
            }

            return Task.FromResult("Neutral 😐");
        }
    }
}
