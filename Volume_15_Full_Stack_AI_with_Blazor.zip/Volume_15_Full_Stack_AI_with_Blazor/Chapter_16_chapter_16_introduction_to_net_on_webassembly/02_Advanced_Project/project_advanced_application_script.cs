
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BlazorWasmArchitectureSim
{
    // ============================================================================
    // 1. THE MONO RUNTIME SIMULATION
    // ============================================================================
    // In a real Blazor WASM app, the Mono Runtime is a pre-compiled .NET runtime
    // written in C/C++ that is loaded into the browser's WebAssembly memory space.
    // It acts as the bridge between the managed C# code and the native browser APIs.
    // 
    // This class simulates the behavior of the Mono Runtime's internal execution engine.
    // ============================================================================
    public class MonoRuntimeSimulator
    {
        private readonly Dictionary<string, object> _wasmMemoryHeap = new Dictionary<string, object>();

        public MonoRuntimeSimulator()
        {
            Console.WriteLine("[Mono Runtime] Initialized in WebAssembly Memory.");
        }

        // Simulates the Just-In-Time (JIT) compilation of CIL (Common Intermediate Language)
        // to WebAssembly instructions. In the browser, this happens during startup.
        public void CompileAssembly(string assemblyName)
        {
            Console.WriteLine($"[Mono Runtime] Loading assembly: {assemblyName}");
            Console.WriteLine($"[Mono Runtime] Compiling CIL to WASM binary format...");
            Console.WriteLine($"[Mono Runtime] Linking against System.Private.CoreLib...");
            Console.WriteLine($"[Mono Runtime] Assembly '{assemblyName}' successfully compiled to WASM.");
        }

        // Simulates the Mono garbage collector managing the WASM linear memory.
        public void AllocateMemory(string key, object data)
        {
            _wasmMemoryHeap[key] = data;
            Console.WriteLine($"[Mono Runtime] Allocated memory block '{key}' in WASM heap.");
        }

        public object GetMemory(string key)
        {
            return _wasmMemoryHeap.ContainsKey(key) ? _wasmMemoryHeap[key] : null;
        }
    }

    // ============================================================================
    // 2. JAVASCRIPT INTEROP BRIDGE (JS Interop)
    // ============================================================================
    // Blazor WASM cannot access browser APIs (DOM, Fetch, LocalStorage) directly
    // because WebAssembly is sandboxed. It must call JavaScript functions.
    // 
    // This class simulates the 'DotNetRuntime' JavaScript object that Blazor injects
    // into the browser window.
    // ============================================================================
    public class JavaScriptRuntime
    {
        // Simulates the JavaScript 'window' object
        private readonly Dictionary<string, string> _browserStorage = new Dictionary<string, string>();

        // Simulates the JavaScript 'console.log' function
        public void ConsoleLog(string message)
        {
            // In a real browser, this writes to the DevTools console.
            // Here, we just format it to look like a browser console.
            Console.WriteLine($"[Browser Console]: {message}");
        }

        // Simulates the 'localStorage' API
        public void SetLocalStorage(string key, string value)
        {
            _browserStorage[key] = value;
            Console.WriteLine($"[Browser API] localStorage['{key}'] = '{value}'");
        }

        public string GetLocalStorage(string key)
        {
            return _browserStorage.ContainsKey(key) ? _browserStorage[key] : null;
        }

        // Simulates a network request (e.g., Fetch API)
        public string SimulateFetch(string url)
        {
            // In a real app, this is an async XMLHttpRequest or Fetch call.
            // The result is marshalled back to C# as a string or JSON.
            Console.WriteLine($"[Browser API] Fetching data from: {url}...");
            return "{ \"status\": \"200 OK\", \"data\": \"Server Response Payload\" }";
        }
    }

    // ============================================================================
    // 3. THE APPLICATION LOGIC (C# running in WASM)
    // ============================================================================
    // This represents the actual Blazor Component or Service logic running
    // entirely on the client side, without a server round-trip.
    // ============================================================================
    public class ClientSideCopilotService
    {
        private readonly JavaScriptRuntime _jsRuntime;
        private readonly MonoRuntimeSimulator _monoRuntime;

        public ClientSideCopilotService(JavaScriptRuntime js, MonoRuntimeSimulator mono)
        {
            _jsRuntime = js;
            _monoRuntime = mono;
        }

        // This method demonstrates the full lifecycle of a WASM AI operation:
        // 1. Load data from browser storage (via JS Interop)
        // 2. Perform local computation (C# logic)
        // 3. Fetch external data (via JS Interop)
        // 4. Process results and update UI (Console logs)
        public async Task RunCopilotWorkflowAsync()
        {
            Console.WriteLine("\n--- Starting Client-Side Copilot Workflow ---");

            // Step 1: Access Browser APIs via JS Interop
            // Since C# cannot access localStorage directly, we call the JS bridge.
            string cachedContext = _jsRuntime.GetLocalStorage("copilot_context");
            
            if (string.IsNullOrEmpty(cachedContext))
            {
                _jsRuntime.ConsoleLog("No context found in storage. Initializing...");
                _jsRuntime.SetLocalStorage("copilot_context", "User_Initialized");
                cachedContext = "User_Initialized";
            }

            // Step 2: Execute AI Model Logic (Simulated)
            // In a real scenario, this would involve tensor operations using
            // Microsoft.ML.OnnxRuntime (running via WASM SIMD).
            // Here, we simulate a simple classification algorithm.
            string aiResult = AnalyzeInputLocally(cachedContext);

            // Step 3: Update State based on AI Output
            _monoRuntime.AllocateMemory("ai_inference_buffer", aiResult);

            // Step 4: Hybrid Operation - Fetch external data if needed
            // Blazor WASM can make HTTP requests directly to APIs.
            if (aiResult == "Needs_Update")
            {
                string jsonResponse = _jsRuntime.SimulateFetch("https://api.copilot.local/config");
                
                // Parsing the JSON response (Simulated)
                if (jsonResponse.Contains("200 OK"))
                {
                    _jsRuntime.ConsoleLog("Configuration updated successfully.");
                    _jsRuntime.SetLocalStorage("copilot_version", "v2.1");
                }
            }

            // Step 5: Render Output
            // In Blazor, this updates the DOM. Here, we log the final state.
            _jsRuntime.ConsoleLog($"Final Copilot State: {cachedContext} | AI Decision: {aiResult}");
            Console.WriteLine("--- Workflow Complete ---\n");
        }

        // Pure C# logic running inside the WASM sandbox
        private string AnalyzeInputLocally(string input)
        {
            // Simple simulation of an AI decision tree
            if (input.Contains("Initialized"))
            {
                return "Needs_Update";
            }
            return "Ready";
        }
    }

    // ============================================================================
    // 4. MAIN PROGRAM ENTRY POINT
    // ============================================================================
    // This simulates the browser's 'DOMContentLoaded' event where Blazor starts.
    // ============================================================================
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=============================================================");
            Console.WriteLine("  SIMULATION: .NET on WebAssembly Architecture");
            Console.WriteLine("  Chapter 16: Introduction to .NET on WebAssembly");
            Console.WriteLine("=============================================================\n");

            // 1. Browser loads the HTML and initializes the JS Runtime
            var jsRuntime = new JavaScriptRuntime();
            jsRuntime.ConsoleLog("Window Loaded");

            // 2. The Mono Runtime is instantiated in the WebAssembly linear memory
            var monoRuntime = new MonoRuntimeSimulator();

            // 3. The Blazor bootstrapper compiles the application DLLs
            monoRuntime.CompileAssembly("BlazorApp.dll");
            monoRuntime.CompileAssembly("System.Private.CoreLib.dll");

            // 4. Dependency Injection (Simulated)
            // In Blazor, services are registered in Program.cs and injected into components.
            var copilotService = new ClientSideCopilotService(jsRuntime, monoRuntime);

            // 5. Execute the application logic
            // Note: In Blazor WASM, async/await works seamlessly because the Mono
            // runtime implements the necessary threading scaffolding (TaskScheduler).
            await copilotService.RunCopilotWorkflowAsync();

            Console.WriteLine("\n[Process] Application execution finished. Browser tab remains open.");
        }
    }
}
