
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/threading-demo"
@inject IJSRuntime JS

<h3>Threading Demo: Offloading Work to a Web Worker</h3>

<p>Status: @StatusMessage</p>

<div class="mb-3">
    <button class="btn btn-primary" @onclick="StartHeavyTask" disabled="@IsProcessing">
        Start Heavy Calculation (Simulate AI Inference)
    </button>
    <button class="btn btn-secondary" @onclick="CheckResponsiveness" disabled="@!IsProcessing">
        Test UI Responsiveness (Click Me!)
    </button>
</div>

@if (Result != null)
{
    <div class="alert alert-success">
        <strong>Result:</strong> @Result
    </div>
}

@code {
    private string StatusMessage = "Ready to start.";
    private bool IsProcessing = false;
    private string? Result;
    private IJSObjectReference? workerModule;
    private IJSObjectReference? worker;

    // Initialize the JS module for the worker
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            // Import the JavaScript module that handles worker creation
            workerModule = await JS.InvokeAsync<IJSObjectReference>(
                "import", "./js/workerManager.js");
        }
    }

    private async Task StartHeavyTask()
    {
        if (workerModule is null) return;

        IsProcessing = true;
        StatusMessage = "Starting heavy calculation in background thread...";
        Result = null;
        StateHasChanged();

        // Create a new Web Worker via JS
        worker = await workerModule.InvokeAsync<IJSObjectReference>("createWorker");

        // Setup a listener for messages from the worker
        await workerModule.InvokeVoidAsync("listenForMessages", worker, 
            DotNetObjectReference.Create(this));

        // Send the "work" to the worker. 
        // In a real scenario, '100000000' might be model weights or image data.
        await workerModule.InvokeVoidAsync("postMessageToWorker", worker, 100000000);
    }

    private void CheckResponsiveness()
    {
        // This proves the UI thread is not blocked
        StatusMessage = $"UI is responsive! Checked at {DateTime.Now:HH:mm:ss.fff}";
        StateHasChanged();
    }

    // This method is called from JavaScript when the worker returns a result
    [JSInvokable]
    public void OnWorkerResult(string result)
    {
        StatusMessage = "Calculation complete.";
        Result = result;
        IsProcessing = false;
        StateHasChanged();
        
        // Clean up the worker
        if (worker != null)
        {
            _ = worker.DisposeAsync(); // Fire and forget cleanup
        }
    }
}
