
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// WorkerService.cs
using Microsoft.JSInterop;

public class WorkerService : IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _workerModule;
    private DotNetObjectReference<WorkerService>? _dotNetRef;
    private TaskCompletionSource<long>? _tcs;
    private CancellationTokenRegistration? _cancellationTokenRegistration;

    public WorkerService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public async Task InitializeAsync()
    {
        // Load the module that manages the worker lifecycle
        _workerModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/workerManager.js");
        _dotNetRef = DotNetObjectReference.Create(this);
        
        // Initialize the worker inside JS
        await _workerModule.InvokeVoidAsync("initWorker", _dotNetRef);
    }

    public async Task<long> ExecuteTaskAsync(int input, CancellationToken cancellationToken)
    {
        if (_workerModule is null) throw new InvalidOperationException("Worker not initialized.");

        _tcs = new TaskCompletionSource<long>();
        
        // Register cancellation callback
        _cancellationTokenRegistration = cancellationToken.Register(async () =>
        {
            // Notify JS to abort the calculation
            if (_workerModule is not null)
            {
                await _workerModule.InvokeVoidAsync("cancelWorker");
            }
            // Cancel the C# task
            _tcs.TrySetCanceled();
        });

        // Send input to worker
        await _workerModule.InvokeVoidAsync("postMessageToWorker", input);

        try
        {
            return await _tcs.Task;
        }
        finally
        {
            _cancellationTokenRegistration?.Dispose();
        }
    }

    // Called from JavaScript when the worker finishes
    [JSInvokable]
    public void OnResultReceived(long result)
    {
        _tcs?.TrySetResult(result);
    }

    // Called from JavaScript if the worker is cancelled or errors out
    [JSInvokable]
    public void OnError(string message)
    {
        _tcs?.TrySetException(new Exception(message));
    }

    public async ValueTask DisposeAsync()
    {
        if (_workerModule is not null)
        {
            await _workerModule.InvokeVoidAsync("terminateWorker");
            await _workerModule.DisposeAsync();
        }
        _dotNetRef?.Dispose();
    }
}
