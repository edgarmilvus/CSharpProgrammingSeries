
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// IInferenceService.cs
public interface IInferenceService
{
    Task<float[]> PredictAsync(float[] input);
    IAsyncEnumerable<string> PredictStreamAsync(string prompt, CancellationToken cancellationToken);
}

// MockInferenceService.cs (Worker Implementation)
using Microsoft.JSInterop;

public class MockInferenceService : IInferenceService, IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _module;

    public MockInferenceService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public async Task<float[]> PredictAsync(float[] input)
    {
        await EnsureModuleLoaded();
        // Simulate processing delay
        var result = await _module!.InvokeAsync<float[]>("runInference", input);
        return result;
    }

    public async IAsyncEnumerable<string> PredictStreamAsync(string prompt, [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        await EnsureModuleLoaded();
        
        // Create a DotNetObjectReference to receive streaming callbacks
        var dotNetRef = DotNetObjectReference.Create(new StreamingReceiver(this));
        
        // Start the streaming process in JS
        var streamTask = _module!.InvokeVoidAsync("startStreamingInference", prompt, dotNetRef);
        
        // We wait for the JS to signal completion via a tcs in the receiver
        // But we yield results as they come in via the receiver's event
        var tcs = StreamingReceiver.LastTcs;
        
        // Loop until the completion signal is received
        while (!tcs.Task.IsCompleted)
        {
            // Check cancellation
            if (cancellationToken.IsCancellationRequested) yield break;

            // Wait for the next chunk or timeout
            var nextChunk = await StreamingReceiver.GetNextChunkAsync(cancellationToken);
            if (nextChunk != null)
            {
                yield return nextChunk;
            }
        }
    }

    private async Task EnsureModuleLoaded()
    {
        if (_module == null)
        {
            _module = await _jsRuntime.InvokeAsync<IJSObjectReference>(
                "import", "./js/aiWorker.js");
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_module != null) await _module.DisposeAsync();
    }

    // Helper class to handle streaming callbacks
    private class StreamingReceiver
    {
        private static readonly Queue<string> _chunkQueue = new();
        private static TaskCompletionSource<bool> _currentTcs = new();
        
        public static TaskCompletionSource<bool> LastTcs => _currentTcs;

        public StreamingReceiver(MockInferenceService service) { }

        [JSInvokable]
        public static void OnChunk(string chunk)
        {
            _chunkQueue.Enqueue(chunk);
            // Signal that data is available
            if (_currentTcs.TrySetResult(true))
            {
                // Prepare next tcs for the next chunk
                _currentTcs = new TaskCompletionSource<bool>();
            }
        }

        [JSInvokable]
        public static void OnStreamComplete()
        {
            _currentTcs.TrySetResult(true); // Unblock the loop one last time
        }

        public static async Task<string?> GetNextChunkAsync(CancellationToken ct)
        {
            if (_chunkQueue.Count > 0) return _chunkQueue.Dequeue();
            
            // Wait for signal
            using var reg = ct.Register(() => _currentTcs.TrySetCanceled());
            await _currentTcs.Task;
            
            return _chunkQueue.Count > 0 ? _chunkQueue.Dequeue() : null;
        }
    }
}
