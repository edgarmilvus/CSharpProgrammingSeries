
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

<!-- AIChat.razor -->
@page "/ai-chat"
@inject IInferenceService InferenceService

<div class="chat-container">
    <div class="chat-history">
        @foreach (var msg in messages)
        {
            <div class="message @msg.Sender">@msg.Text</div>
        }
        @if (isThinking)
        {
            <div class="message bot">Thinking... <span class="spinner"></span></div>
        }
    </div>
    
    <div class="input-area">
        <input @bind="userInput" @bind:event="oninput" disabled="@isThinking" placeholder="Ask the AI..." />
        <button @onclick="SendMessage" disabled="@isThinking">Send</button>
    </div>
    
    <!-- Responsiveness Check -->
    <div class="mt-2">
        <input type="text" placeholder="Test typing here while AI thinks..." class="form-control" />
    </div>
</div>

@code {
    private string userInput = "";
    private bool isThinking = false;
    private List<ChatMessage> messages = new();
    private CancellationTokenSource? _streamCts;

    private async Task SendMessage()
    {
        if (string.IsNullOrWhiteSpace(userInput)) return;

        var prompt = userInput;
        userInput = "";
        messages.Add(new ChatMessage("User", prompt));
        
        isThinking = true;
        _streamCts = new CancellationTokenSource();
        
        // Create a placeholder for the bot response
        var botMsg = new ChatMessage("Bot", "");
        messages.Add(botMsg);

        try
        {
            // Use Streaming AsyncEnumerable
            await foreach (var chunk in InferenceService.PredictStreamAsync(prompt, _streamCts.Token))
            {
                // Append chunk to the last message
                botMsg.Text += chunk;
                StateHasChanged(); // Force UI update for every chunk
            }
        }
        catch (OperationCanceledException)
        {
            botMsg.Text += " [Cancelled]";
        }
        finally
        {
            isThinking = false;
            _streamCts?.Dispose();
        }
    }

    public class ChatMessage
    {
        public string Sender { get; set; }
        public string Text { get; set; }
        public ChatMessage(string sender, string text) { Sender = sender; Text = text; }
    }
}
