
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

// PinnedArrayManager.cs
using Microsoft.JSInterop;
using System.Runtime.InteropServices;

public class PinnedArrayManager : IDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private readonly byte[] _largeArray;
    private GCHandle _handle;
    private IJSObjectReference? _jsReference;
    private bool _disposed = false;

    public PinnedArrayManager(IJSRuntime jsRuntime, int size)
    {
        _jsRuntime = jsRuntime;
        _largeArray = new byte[size];
        
        // Pin the array in memory so GC doesn't move it
        // This is crucial if we want to pass a direct pointer to JS
        _handle = GCHandle.Alloc(_largeArray, GCHandleType.Pinned);
    }

    public async Task InitializeJsReferenceAsync()
    {
        // Simulate creating a JS wrapper for the array (e.g., for a WebGL texture upload)
        // In reality, we might pass the pointer to a C++ WASM module.
        // Here, we simulate holding a reference in a global JS variable.
        var pointer = _handle.AddrOfPinnedObject();
        
        // We assume a JS function that stores the pointer in a Map/WeakMap
        // For this example, we just store the pointer value to simulate the leak if not cleaned up.
        // In a real scenario, we would use JS interop to create a view.
        
        // Let's simulate a JS object reference that needs disposal
        // (e.g., a JS object that holds the buffer)
        _jsReference = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "createWrapperObject", pointer, _largeArray.Length);
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (_disposed) return;

        // 1. Release JS Reference
        // This is critical: We must tell JS to stop holding the reference to the data.
        if (_jsReference != null)
        {
            // Fire and forget is dangerous here; ideally use async disposal.
            // Since Dispose is synchronous, we usually block or rely on IAsyncDisposable.
            // For this pattern, we assume the JS runtime handles the sync context.
            _jsRuntime.InvokeVoidAsync("releaseWrapperObject", _jsReference).GetAwaiter().GetResult();
            _jsReference.DisposeAsync().AsTask().GetAwaiter().GetResult();
            _jsReference = null;
        }

        // 2. Release Pinned Memory
        if (_handle.IsAllocated)
        {
            _handle.Free();
        }

        _disposed = true;
    }

    // Finalizer (Destructor)
    ~PinnedArrayManager()
    {
        // WARNING: This runs on the GC thread. 
        // We cannot safely access JS interop here because the JS runtime might be shut down.
        // We only free the managed pin.
        if (_handle.IsAllocated)
        {
            _handle.Free();
        }
    }
}

// WorkerServiceRefactored.cs (Implementing IAsyncDisposable)
public class WorkerServiceRefactored : IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _workerModule;
    private IJSObjectReference? _workerInstance;

    public WorkerServiceRefactored(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public async Task InitAsync()
    {
        _workerModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/workerManager.js");
        
        // The module now returns the worker instance
        _workerInstance = await _workerModule.InvokeAsync<IJSObjectReference>("createWorker");
    }

    public async ValueTask DisposeAsync()
    {
        if (_workerInstance != null)
        {
            // Call terminate on the worker instance
            await _workerInstance.InvokeVoidAsync("terminate");
            await _workerInstance.DisposeAsync();
        }
        
        if (_workerModule != null)
        {
            await _workerModule.DisposeAsync();
        }
    }
}
