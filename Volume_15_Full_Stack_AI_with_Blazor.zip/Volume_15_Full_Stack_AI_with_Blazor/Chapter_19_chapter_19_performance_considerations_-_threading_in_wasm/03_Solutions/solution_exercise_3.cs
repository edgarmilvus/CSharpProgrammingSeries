
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// SharedMemoryService.cs
using System.Runtime.InteropServices;
using Microsoft.JSInterop;

[StructLayout(LayoutKind.Sequential)]
public struct SharedData
{
    public int StatusFlag; // 0: Idle, 1: Ready, 2: Processed
    public int InputValue;
    public long ResultValue;
}

public class SharedMemoryService : IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _module;
    private nint _bufferPtr;
    private SharedData? _sharedData;

    public SharedMemoryService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public async Task InitializeAsync()
    {
        _module = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/sharedMemoryManager.js");
        
        // Allocate SharedArrayBuffer (1024 bytes) via JS and get the memory view
        await _module.InvokeVoidAsync("allocateSharedBuffer", 1024);
    }

    public async Task<long> ProcessWithWorkerAsync(int input)
    {
        if (_module == null) throw new InvalidOperationException("Not initialized");

        // In a real scenario, we might pin the memory. 
        // For this interop example, we will write to the buffer via JS to ensure alignment 
        // with the Worker's view, though we can also use unsafe pointers if pinned correctly.
        
        // 1. Write input to shared memory
        await _module.InvokeVoidAsync("writeToSharedMemory", input);

        // 2. Signal Worker via Atomics.notify (or postMessage to wake worker loop)
        await _module.InvokeVoidAsync("signalWorker");

        // 3. Wait for completion (Simulated via JS because Atomics.waitAsync 
        // is not yet fully supported in all .NET WASM interop scenarios synchronously).
        // We use a TaskCompletionSource triggered by a JS callback.
        var tcs = new TaskCompletionSource<long>();
        
        // Register a callback listener for the "done" signal from the worker
        await _module.InvokeVoidAsync("waitForCompletion", 
            DotNetObjectReference.Create(new CallbackHelper(tcs)));

        return await tcs.Task;
    }

    public async ValueTask DisposeAsync()
    {
        if (_module != null)
        {
            await _module.InvokeVoidAsync("releaseBuffer");
            await _module.DisposeAsync();
        }
    }

    // Helper class to bridge JS callback to TaskCompletionSource
    public class CallbackHelper
    {
        private readonly TaskCompletionSource<long> _tcs;
        public CallbackHelper(TaskCompletionSource<long> tcs) => _tcs = tcs;
        
        [JSInvokable]
        public void OnComplete(long result) => _tcs.TrySetResult(result);
    }
}
