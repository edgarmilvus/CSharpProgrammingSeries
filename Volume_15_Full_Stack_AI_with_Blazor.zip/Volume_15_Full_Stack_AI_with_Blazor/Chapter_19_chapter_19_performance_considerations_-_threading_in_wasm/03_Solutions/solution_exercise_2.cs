
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// WorkerDemo.razor
@page "/worker-demo"
@implements IAsyncDisposable
@inject WorkerService WorkerService

<h3>Worker Demo</h3>

<div class="mb-3">
    <label>Input N (Fibonacci calculation):</label>
    <input type="number" @bind="inputN" class="form-control" />
</div>

<div class="mb-3">
    <button class="btn btn-primary" @onclick="RunCalculation" disabled="@isProcessing">Run Calculation</button>
    <button class="btn btn-danger" @onclick="CancelCalculation" disabled="@(!isProcessing)">Cancel</button>
</div>

<div class="mb-3">
    <strong>Status:</strong> <span>@statusText</span>
</div>

<div class="mb-3">
    <strong>Result:</strong> <span>@result</span>
</div>

<div class="mt-4 p-3 border bg-light">
    <h5>UI Responsiveness Check</h5>
    <p>Try typing in this input field while the calculation is running:</p>
    <input type="text" placeholder="Type here to test responsiveness..." class="form-control" />
    <p class="text-muted mt-2">If you can type without lag, the UI thread is free.</p>
</div>

@code {
    private int inputN = 40;
    private long result;
    private string statusText = "Idle";
    private bool isProcessing;
    private CancellationTokenSource? _cts;

    protected override async Task OnInitializedAsync()
    {
        await WorkerService.InitializeAsync();
    }

    private async Task RunCalculation()
    {
        isProcessing = true;
        statusText = "Processing...";
        result = 0;
        _cts = new CancellationTokenSource();

        try
        {
            // Run the calculation on the worker thread
            result = await WorkerService.ExecuteTaskAsync(inputN, _cts.Token);
            statusText = "Completed";
        }
        catch (OperationCanceledException)
        {
            statusText = "Cancelled";
        }
        catch (Exception ex)
        {
            statusText = $"Error: {ex.Message}";
        }
        finally
        {
            isProcessing = false;
            _cts?.Dispose();
            StateHasChanged();
        }
    }

    private void CancelCalculation()
    {
        _cts?.Cancel();
    }

    public async ValueTask DisposeAsync()
    {
        if (_cts != null) await _cts.CancelAsync();
        _cts?.Dispose();
    }
}
