
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Threading;
using System.Threading.Tasks;

namespace BlazorWasmThreadingDemo
{
    /// <summary>
    /// Represents a single unit of data to be processed by the AI inference engine.
    /// In a real Blazor WASM app, this could be a chunk of text, an image tile, or a numerical vector.
    /// </summary>
    public class InferenceDataPacket
    {
        public int PacketId { get; set; }
        public double[] InputValues { get; set; }

        public InferenceDataPacket(int id, double[] values)
        {
            PacketId = id;
            InputValues = values;
        }
    }

    /// <summary>
    /// Represents the result after processing an InferenceDataPacket.
    /// </summary>
    public class InferenceResult
    {
        public int PacketId { get; set; }
        public double ConfidenceScore { get; set; }
        public string PredictedLabel { get; set; }
    }

    /// <summary>
    /// Main Program entry point.
    /// Simulates a Blazor WASM Main Thread (UI Thread) offloading heavy AI work to a background thread.
    /// </summary>
    class Program
    {
        // Thread-safe queue to hold incoming data packets from the UI (Producer)
        private static readonly object _queueLock = new object();
        private static Queue<InferenceDataPacket> _pendingPackets = new Queue<InferenceDataPacket>();

        // Thread-safe queue to hold results from the AI Worker (Consumer)
        private static readonly object _resultLock = new object();
        private static Queue<InferenceResult> _completedResults = new Queue<InferenceResult>();

        // Signals the background worker that data is available or cancellation is requested
        private static ManualResetEventSlim _dataAvailableSignal = new ManualResetEventSlim(false);
        private static CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();

        static void Main(string[] args)
        {
            Console.WriteLine("--- [Main UI Thread] Application Started ---");
            Console.WriteLine("Simulating Blazor WASM UI Thread.");
            Console.WriteLine();

            // 1. Start the "Background Worker" (Simulating a Web Worker)
            // In real WASM, this would be a separate .wasm instance or a JS Web Worker.
            Thread workerThread = new Thread(BackgroundWorkerProcess);
            workerThread.IsBackground = true; // Ensure thread terminates when main app closes
            workerThread.Start();
            Console.WriteLine("[Main UI Thread] Background AI Worker Thread Started.");
            Console.WriteLine();

            // 2. Simulate UI User Interactions (Generating Data)
            // We generate data in bursts to simulate real-world usage patterns.
            SimulateUserInteraction();

            // 3. Process Results (Simulating UI updates based on worker output)
            ProcessResults();

            // 4. Cleanup
            Console.WriteLine();
            Console.WriteLine("[Main UI Thread] Shutting down application...");
            _cancellationTokenSource.Cancel();
            _dataAvailableSignal.Set(); // Wake up worker to let it see the cancellation token
            workerThread.Join(2000); // Wait for worker to finish
            Console.WriteLine("--- [Main UI Thread] Application Closed ---");
        }

        /// <summary>
        /// Simulates the UI thread generating data and pushing it to the worker.
        /// </summary>
        static void SimulateUserInteraction()
        {
            Console.WriteLine("[Main UI Thread] User started uploading images/text data...");

            for (int i = 1; i <= 5; i++)
            {
                // Create dummy data
                var data = new InferenceDataPacket(i, new double[] { i * 0.1, i * 0.2, i * 0.3 });
                
                // CRITICAL: Thread-safe enqueue
                lock (_queueLock)
                {
                    _pendingPackets.Enqueue(data);
                    Console.WriteLine($"[Main UI Thread] Enqueued Packet ID: {data.PacketId}");
                }

                // Signal the worker that data is ready
                _dataAvailableSignal.Set();

                // Simulate delay between user actions
                Thread.Sleep(500);
            }
        }

        /// <summary>
        /// Simulates the UI thread checking for results to render.
        /// In Blazor, this would be a timer or an event callback.
        /// </summary>
        static void ProcessResults()
        {
            Console.WriteLine();
            Console.WriteLine("[Main UI Thread] Polling for results...");
            
            int processedCount = 0;
            while (processedCount < 5)
            {
                InferenceResult result = null;

                // CRITICAL: Thread-safe dequeue
                lock (_resultLock)
                {
                    if (_completedResults.Count > 0)
                    {
                        result = _completedResults.Dequeue();
                    }
                }

                if (result != null)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"[Main UI Thread] RENDER UI: Packet {result.PacketId} -> Label: {result.PredictedLabel}, Confidence: {result.ConfidenceScore:P1}");
                    Console.ResetColor();
                    processedCount++;
                }
                else
                {
                    // Yield CPU to avoid burning cycles while waiting for worker
                    Thread.Sleep(100); 
                }
            }
        }

        /// <summary>
        /// This method runs on a separate thread. It mimics the behavior of a Web Worker
        /// running a .NET WASM module in isolation.
        /// </summary>
        static void BackgroundWorkerProcess()
        {
            Console.WriteLine("\t[Background Worker] Ready. Waiting for data...");

            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                // Wait for the signal from the Main Thread
                _dataAvailableSignal.Wait(_cancellationTokenSource.Token);

                if (_cancellationTokenSource.Token.IsCancellationRequested) break;

                // Process all available packets
                while (true)
                {
                    InferenceDataPacket packet = null;

                    // Lock to access shared queue
                    lock (_queueLock)
                    {
                        if (_pendingPackets.Count > 0)
                        {
                            packet = _pendingPackets.Dequeue();
                        }
                    }

                    if (packet == null)
                    {
                        // No more data currently, reset signal and wait
                        _dataAvailableSignal.Reset();
                        break; 
                    }

                    // --- INTENSIVE AI INFERENCE SIMULATION ---
                    // This mimics heavy matrix multiplication or model inference.
                    // Because this is on a background thread, the UI (Main Thread) remains responsive.
                    Console.WriteLine($"\t[Background Worker] Processing Packet ID: {packet.PacketId}...");
                    
                    // Simulate CPU work
                    Thread.Sleep(800); 

                    // Simulate AI Logic (Simple calculation for demo)
                    double sum = 0;
                    foreach (var val in packet.InputValues) sum += val;
                    double confidence = (sum / 10.0) + 0.5; // Fake logic
                    if (confidence > 1.0) confidence = 0.99;

                    string label = (confidence > 0.8) ? "Positive" : "Negative";

                    var result = new InferenceResult 
                    { 
                        PacketId = packet.PacketId, 
                        ConfidenceScore = confidence, 
                        PredictedLabel = label 
                    };

                    // Store result for Main Thread to pick up
                    lock (_resultLock)
                    {
                        _completedResults.Enqueue(result);
                    }
                    
                    Console.WriteLine($"\t[Background Worker] Finished Packet ID: {packet.PacketId}. Result queued.");
                }
            }

            Console.WriteLine("\t[Background Worker] Cancellation requested. Exiting.");
        }
    }

    /// <summary>
    /// A simple Queue implementation to avoid using Generics if the chapter 
    /// hasn't introduced System.Collections.Generic. 
    /// (Constraint check: "Focus on solid implementation using basic blocks").
    /// </summary>
    public class Queue<T>
    {
        private T[] _items = new T[100];
        private int _head = 0;
        private int _tail = 0;
        private int _count = 0;

        public void Enqueue(T item)
        {
            if (_count == _items.Length)
            {
                // Simple resize logic
                T[] newItems = new T[_items.Length * 2];
                Array.Copy(_items, _head, newItems, 0, _count);
                _items = newItems;
                _head = 0;
                _tail = _count;
            }
            _items[_tail] = item;
            _tail = (_tail + 1) % _items.Length;
            _count++;
        }

        public T Dequeue()
        {
            if (_count == 0) throw new InvalidOperationException("Queue is empty");
            T item = _items[_head];
            _items[_head] = default(T);
            _head = (_head + 1) % _items.Length;
            _count--;
            return item;
        }

        public int Count => _count;
    }
}
