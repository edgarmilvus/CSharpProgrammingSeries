
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Threading.Tasks;

/// <summary>
/// PROBLEM CONTEXT:
/// A small business uses a Blazor WASM-based internal chat tool to interact with an AI assistant.
/// Due to the client-side nature of the application and the high cost of AI token processing,
/// we need a robust mechanism to manage the conversation history.
///
/// GOAL:
/// Simulate a "Conversation History Manager" that optimizes context for the AI model.
/// It must:
/// 1. Store messages in a local storage simulation (State Container).
/// 2. Prune old messages automatically when the token count exceeds a limit (Optimization).
/// 3. Summarize a "session" to retain context while reducing token usage (Summarization).
///
/// CONSTRAINTS:
/// Using ONLY basic C# constructs (classes, arrays, loops, if/else, strings) to mimic
/// the architectural patterns of Chapter 10 without modern syntactic sugar.
/// </summary>
public class Program
{
    public static void Main(string[] args)
    {
        // 1. Setup the Simulation Environment
        // We simulate the "Local Storage" and the "State Container" pattern.
        var storage = new LocalStorageSimulator();
        var historyManager = new ConversationHistoryManager(storage);

        Console.WriteLine("--- Starting Conversation History Management Simulation ---");
        Console.WriteLine();

        // 2. Scenario 1: Normal Conversation (State Persistence)
        // The user interacts, and messages are stored.
        Console.WriteLine("[SCENARIO 1: Normal Interaction]");
        historyManager.AddMessage("User", "What is the weather forecast?");
        historyManager.AddMessage("AI", "It will be sunny today.");
        historyManager.DisplayHistory();
        Console.WriteLine();

        // 3. Scenario 2: Token Optimization (Pruning)
        // The user has a long conversation. We simulate hitting the token limit.
        // The system must prune the oldest messages to make room for new ones.
        Console.WriteLine("[SCENARIO 2: Token Limit Exceeded - Pruning Triggered]");
        // We add enough messages to exceed our hypothetical limit (e.g., 5 messages max)
        historyManager.AddMessage("User", "Tell me a joke.");
        historyManager.AddMessage("AI", "Why did the scarecrow win an award? Because he was outstanding in his field.");
        historyManager.AddMessage("User", "That was bad. Tell me another.");
        historyManager.AddMessage("AI", "What do you call a fake noodle? An Impasta.");
        historyManager.AddMessage("User", "Okay, last one.");
        historyManager.AddMessage("AI", "I'm running out of jokes.");
        // Now we add one more. This should trigger the pruning logic.
        historyManager.AddMessage("User", "What is 2+2?");
        historyManager.DisplayHistory(); 
        // Expectation: The very first 2 messages should be gone.
        Console.WriteLine();

        // 4. Scenario 3: Summarization (Context Compression)
        // To save tokens, we condense the entire history into a single summary block.
        Console.WriteLine("[SCENARIO 3: Summarization for Context Retention]");
        string summary = historyManager.SummarizeSession();
        Console.WriteLine("Generated Summary: " + summary);
        
        // Verify the storage was updated with the summary
        historyManager.DisplayHistory();
    }
}

/// <summary>
/// ARCHITECTURAL COMPONENT: Local Storage Abstraction
/// 
/// In a real Blazor WASM app, this would wrap 'Blazored.LocalStorage'.
/// Here, we simulate it with a simple string array to demonstrate the 
/// separation of concerns between storage logic and business logic.
/// </summary>
public class LocalStorageSimulator
{
    // Simulating a persistent key-value store on the client side.
    private string[] _storage = new string[10]; 
    private int _currentIndex = 0;

    public void Save(string key, string value)
    {
        // In a real app, this serializes JSON. Here, we just append to our array.
        // We simulate overwriting the 'history' key.
        if (key == "chat_history")
        {
            if (_currentIndex < _storage.Length)
            {
                _storage[_currentIndex] = value;
                _currentIndex++;
            }
            else
            {
                // Shift array to simulate a queue if we wanted to, 
                // but for this sim, we will rely on the Manager to clear/replace.
                Console.WriteLine("[Storage Warning]: Capacity reached.");
            }
        }
    }

    public string[] Load(string key)
    {
        if (key == "chat_history")
        {
            // Return a copy to prevent external modification of internal state
            string[] result = new string[_currentIndex];
            for (int i = 0; i < _currentIndex; i++)
            {
                result[i] = _storage[i];
            }
            return result;
        }
        return new string[0];
    }

    public void Clear(string key)
    {
        if (key == "chat_history")
        {
            _storage = new string[10];
            _currentIndex = 0;
        }
    }
}

/// <summary>
/// ARCHITECTURAL COMPONENT: Conversation History Manager
/// 
/// This class implements the core logic from Chapter 10:
/// 1. State Management: Holds the current list of messages.
/// 2. Optimization: Prunes messages based on resource constraints.
/// 3. Summarization: Condenses history to preserve context.
/// </summary>
public class ConversationHistoryManager
{
    private readonly LocalStorageSimulator _storage;
    private readonly string _storageKey = "chat_history";
    
    // Simulating a token limit. 
    // In reality, we count characters/tokens. Here, we count message entries for simplicity.
    private const int MAX_MESSAGES = 5; 

    public ConversationHistoryManager(LocalStorageSimulator storage)
    {
        _storage = storage;
    }

    /// <summary>
    /// Adds a message to the history and triggers the optimization check.
    /// </summary>
    public void AddMessage(string role, string content)
    {
        string formattedMessage = $"[{role}]: {content}";
        
        // 1. Load existing state
        string[] currentHistory = _storage.Load(_storageKey);
        
        // 2. Create new array with size + 1
        string[] newHistory = new string[currentHistory.Length + 1];
        
        // 3. Copy old data
        for (int i = 0; i < currentHistory.Length; i++)
        {
            newHistory[i] = currentHistory[i];
        }
        
        // 4. Add new message
        newHistory[newHistory.Length - 1] = formattedMessage;

        // 5. Check for Optimization (Pruning)
        // If we exceed the limit, we must prune before saving.
        if (newHistory.Length > MAX_MESSAGES)
        {
            Console.WriteLine(">> OPTIMIZATION TRIGGERED: Pruning oldest messages...");
            newHistory = PruneHistory(newHistory);
        }

        // 6. Persist to Storage
        // Clear old storage and save new array
        _storage.Clear(_storageKey);
        foreach (var msg in newHistory)
        {
            if (msg != null) _storage.Save(_storageKey, msg);
        }
    }

    /// <summary>
    /// CORE LOGIC: Pruning Strategy
    /// Removes the oldest messages to stay within the token/window limit.
    /// </summary>
    private string[] PruneHistory(string[] history)
    {
        // We want to keep the most recent MAX_MESSAGES.
        // Example: History size 6, Limit 5. We remove index 0.
        
        string[] pruned = new string[MAX_MESSAGES];
        
        // Calculate offset: (Total - Limit)
        int offset = history.Length - MAX_MESSAGES;
        
        int writeIndex = 0;
        for (int readIndex = offset; readIndex < history.Length; readIndex++)
        {
            pruned[writeIndex] = history[readIndex];
            writeIndex++;
        }
        
        return pruned;
    }

    /// <summary>
    /// CORE LOGIC: Summarization Strategy
    /// Condenses the entire conversation history into a single "System" message.
    /// This drastically reduces the number of tokens sent to the AI for context.
    /// </summary>
    public string SummarizeSession()
    {
        string[] history = _storage.Load(_storageKey);
        
        if (history.Length == 0)
        {
            return "Empty Session";
        }

        // Manual string concatenation (No String.Join allowed per constraints)
        string summaryContent = "Summary of previous interactions: ";
        
        for (int i = 0; i < history.Length; i++)
        {
            summaryContent += history[i];
            if (i < history.Length - 1)
            {
                summaryContent += " | ";
            }
        }

        // In a real app, we might send this to the AI to generate a semantic summary.
        // Here, we simulate that result by truncating it.
        if (summaryContent.Length > 100)
        {
            summaryContent = summaryContent.Substring(0, 97) + "...";
        }

        // Update State: Clear history and replace with summary
        _storage.Clear(_storageKey);
        _storage.Save(_storageKey, "[System]: " + summaryContent);

        return summaryContent;
    }

    /// <summary>
    /// Helper to display current state from storage.
    /// </summary>
    public void DisplayHistory()
    {
        string[] history = _storage.Load(_storageKey);
        Console.WriteLine("Current Storage State:");
        if (history.Length == 0)
        {
            Console.WriteLine("  (Empty)");
            return;
        }

        foreach (var msg in history)
        {
            Console.WriteLine("  " + msg);
        }
    }
}
