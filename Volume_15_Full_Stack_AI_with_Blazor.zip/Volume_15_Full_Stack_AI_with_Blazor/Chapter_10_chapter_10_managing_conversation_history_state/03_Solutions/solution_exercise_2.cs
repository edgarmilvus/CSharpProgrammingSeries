
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Blazored.LocalStorage;

namespace ConversationManager.Services;

public class PersistentChatManager
{
    private readonly ILocalStorageService _localStorage;
    private readonly StateContainer<ChatSession> _stateContainer;
    private readonly byte[] _encryptionKey; // In production, derive this securely

    public PersistentChatManager(
        ILocalStorageService localStorage, 
        StateContainer<ChatSession> stateContainer)
    {
        _localStorage = localStorage;
        _stateContainer = stateContainer;
        
        // SIMULATION: In a real app, derive this from a user passphrase using PBKDF2.
        // For WASM demo, we generate a random key per session (volatile).
        _encryptionKey = new byte[32]; 
        RandomNumberGenerator.Fill(_encryptionKey);
    }

    // Architectural Note: Client-side encryption protects data at rest 
    // (e.g., if browser cache is compromised), but the key is accessible 
    // to the running script. Server-side storage is generally more secure 
    // for sensitive data but requires network calls and backend infrastructure.

    public async Task SaveSessionAsync(ChatSession session)
    {
        // 1. Serialize
        var json = JsonSerializer.Serialize(session);
        
        // 2. Encrypt (AES-GCM)
        byte[] nonce = new byte[12]; // GCM recommended nonce size
        RandomNumberGenerator.Fill(nonce);
        
        byte[] ciphertext = new byte[Encoding.UTF8.GetByteCount(json)];
        byte[] tag = new byte[16]; // Authentication tag
        
        using (var aesGcm = new AesGcm(_encryptionKey))
        {
            aesGcm.Encrypt(nonce, Encoding.UTF8.GetBytes(json), ciphertext, tag);
        }

        // 3. Store structure (Nonce + Tag + Ciphertext)
        var storageModel = new EncryptedStorageModel(nonce, tag, ciphertext);
        await _localStorage.SetItemAsync($"chat_{session.Id}", storageModel);
    }

    // 4. Lazy Loading Strategy
    public async Task<List<ChatSessionMetadata>> LoadMetadataAsync()
    {
        // Only load IDs and Titles to display the list
        // In a real app, we might store a separate index file.
        // Here, we iterate keys (expensive in real storage, but fine for demo).
        var keys = await _localStorage.KeysAsync();
        var metadata = new List<ChatSessionMetadata>();

        foreach (var key in keys.Where(k => k.StartsWith("chat_")))
        {
            // We only decrypt the header/metadata here if we structured the data that way.
            // For this exercise, we assume we have a separate metadata store or 
            // we decrypt just enough to get the Title (simulated).
            
            // Simulated metadata retrieval (in reality, store a separate lightweight list)
            var session = await GetSessionHeaderAsync(key); 
            if(session != null)
                metadata.Add(new ChatSessionMetadata(session.Id, session.Title, session.CreatedAt));
        }
        return metadata;
    }

    public async Task<ChatSession?> LoadFullSessionAsync(Guid id)
    {
        var key = $"chat_{id}";
        var storageModel = await _localStorage.GetItemAsync<EncryptedStorageModel>(key);
        
        if (storageModel == null) return null;

        // Decrypt
        byte[] decryptedBytes = new byte[storageModel.Ciphertext.Length];
        
        using (var aesGcm = new AesGcm(_encryptionKey))
        {
            try 
            {
                aesGcm.Decrypt(storageModel.Nonce, storageModel.Ciphertext, storageModel.Tag, decryptedBytes);
            }
            catch (CryptographicException)
            {
                // Handle tampering or wrong key
                return null;
            }
        }

        var json = Encoding.UTF8.GetString(decryptedBytes);
        return JsonSerializer.Deserialize<ChatSession>(json);
    }

    // Helper for lazy loading simulation
    private async Task<ChatSession?> GetSessionHeaderAsync(string key)
    {
        // In a real optimized storage, we would have a separate JSON file 
        // containing only [ {Id, Title, Date} ].
        // For this exercise, we assume we can't load full messages yet.
        // We return null here to simulate that we are only loading metadata.
        return await _localStorage.GetItemAsync<ChatSession>(key); 
    }
}

// Helper records for storage
public record EncryptedStorageModel(byte[] Nonce, byte[] Tag, byte[] Ciphertext);
public record ChatSessionMetadata(Guid Id, string Title, DateTime CreatedAt);
