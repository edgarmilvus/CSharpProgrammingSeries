
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Collections.Immutable;

namespace ConversationManager.Components;

// 1. Refactored ChatSession using Record and Immutable Collections
public record ChatSession(
    Guid Id,
    string Title,
    DateTime CreatedAt,
    ImmutableList<string> Messages // Deep immutability
);

public class ChatHistoryComponent : ComponentBase, IDisposable
{
    [Inject] private StateContainer<ChatSession> StateContainer { get; set; } = null!;

    [Parameter]
    public ChatSession? Session { get; set; }

    [Parameter]
    public EventCallback<ChatSession> SessionChanged { get; set; }

    private ChatSession? _lastRenderedSession;

    protected override void OnInitialized()
    {
        // Subscribe to global state changes
        StateContainer.Subscribe(async (session) =>
        {
            // Update the parameter binding
            if (SessionChanged.HasDelegate)
            {
                await SessionChanged.InvokeAsync(session);
            }
            else
            {
                // Direct update if not using two-way binding
                Session = session;
            }
            
            // Request re-render
            StateHasChanged();
        });
    }

    // 2. Performance Optimization: ShouldRender
    protected override bool ShouldRender()
    {
        // Use pattern matching and Record structural equality
        // Records automatically implement value-based equality.
        // We only render if the reference changed AND the values are different.
        
        if (Session is null && _lastRenderedSession is null) return false;
        if (Session is null || _lastRenderedSession is null) return true;

        // If they are the same reference, don't render
        if (ReferenceEquals(Session, _lastRenderedSession)) return false;

        // Structural equality check (efficient in Records)
        bool areEqual = Session.Equals(_lastRenderedSession);
        
        return !areEqual;
    }

    protected override void OnAfterRender(bool firstRender)
    {
        // Update the cache of the last rendered session
        _lastRenderedSession = Session;
    }

    public void Dispose()
    {
        // In a real app, we would need to unsubscribe from StateContainer.
        // However, IObservable<T>.Subscribe returns an IDisposable.
        // Since we didn't store that token here, we rely on the service lifecycle.
        // Ideally: _subscription.Dispose();
    }
}

// 3. Interactive Challenge: Diff Viewer Component
public class ChatDiffViewer : ComponentBase
{
    [Parameter] public ChatSession? OldSession { get; set; }
    [Parameter] public ChatSession? NewSession { get; set; }

    protected override bool ShouldRender()
    {
        // Efficient check: if structural equality holds, no need to diff
        if (OldSession?.Equals(NewSession) ?? false) return false;
        return true;
    }

    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        if (OldSession is null || NewSession is null) return;

        // 4. Detecting Changes using SequenceEqual on Immutable Lists
        var oldMsgs = OldSession.Messages;
        var newMsgs = NewSession.Messages;

        int maxLen = Math.Max(oldMsgs.Count, newMsgs.Count);

        for (int i = 0; i < maxLen; i++)
        {
            string? oldMsg = i < oldMsgs.Count ? oldMsgs[i] : null;
            string? newMsg = i < newMsgs.Count ? newMsgs[i] : null;

            if (oldMsg == newMsg)
            {
                // Unchanged
                builder.OpenElement(0, "div");
                builder.AddAttribute(1, "class", "diff-unchanged");
                builder.AddContent(2, newMsg ?? oldMsg);
                builder.CloseElement();
            }
            else if (oldMsg is not null && newMsg is null)
            {
                // Removed
                builder.OpenElement(3, "div");
                builder.AddAttribute(4, "class", "diff-removed text-danger");
                builder.AddContent(5, $"- {oldMsg}");
                builder.CloseElement();
            }
            else if (oldMsg is null && newMsg is not null)
            {
                // Added
                builder.OpenElement(6, "div");
                builder.AddAttribute(7, "class", "diff-added text-success");
                builder.AddContent(8, $"+ {newMsg}");
                builder.CloseElement();
            }
            else
            {
                // Modified
                builder.OpenElement(9, "div");
                builder.AddAttribute(10, "class", "diff-modified");
                builder.AddContent(11, $"- {oldMsg}");
                builder.AddContent(12, $"+ {newMsg}");
                builder.CloseElement();
            }
        }
    }
}
