
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using System.Reactive.Subjects;
using System.Reactive.Linq;
using System.Collections.Concurrent;

namespace ConversationManager.Services;

// 1. Generic State Container implementing IObservable<T>
public class StateContainer<T> : IObservable<T>, IDisposable
{
    private readonly Subject<T> _stateSubject = new();
    private readonly ConcurrentStack<T> _undoStack = new();
    private readonly SemaphoreSlim _semaphore = new(1, 1);
    private T? _currentState;
    private const int MaxUndoHistory = 5;

    // 2. Modern Nullable Reference Types handling
    public T? CurrentState => _currentState;

    // 3. Thread-safe state setting with Undo capability
    public async Task SetStateAsync(T newState)
    {
        await _semaphore.WaitAsync();
        try
        {
            // Push current state to undo stack before changing
            if (_currentState is not null)
            {
                // Trim stack if necessary
                if (_undoStack.Count >= MaxUndoHistory)
                {
                    // Remove oldest items to maintain size limit
                    var temp = new T[MaxUndoHistory - 1];
                    _undoStack.CopyTo(temp, 0);
                    _undoStack.Clear();
                    foreach (var item in temp.Reverse()) _undoStack.Push(item);
                }
                _undoStack.Push(_currentState);
            }

            _currentState = newState;
            _stateSubject.OnNext(newState);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    // 4. Undo functionality
    public async Task<bool> UndoAsync()
    {
        await _semaphore.WaitAsync();
        try
        {
            if (_undoStack.TryPop(out var previousState))
            {
                _currentState = previousState;
                _stateSubject.OnNext(previousState);
                return true;
            }
            return false;
        }
        finally
        {
            _semaphore.Release();
        }
    }

    // 5. Subscription management (IObservable implementation)
    public IDisposable Subscribe(IObserver<T> observer)
    {
        // Return the subscription so the component can dispose it
        return _stateSubject.Subscribe(observer);
    }

    // 6. Cleanup
    public void Dispose()
    {
        _stateSubject.OnCompleted();
        _stateSubject.Dispose();
        _semaphore.Dispose();
        GC.SuppressFinalize(this);
    }
}

// 7. Specific implementation for ChatSession
public record ChatSession(
    Guid Id, 
    string Title, 
    DateTime CreatedAt, 
    List<string> Messages);

// 8. Registration in Program.cs (Simulated)
/*
    builder.Services.AddSingleton(typeof(StateContainer<>));
*/
