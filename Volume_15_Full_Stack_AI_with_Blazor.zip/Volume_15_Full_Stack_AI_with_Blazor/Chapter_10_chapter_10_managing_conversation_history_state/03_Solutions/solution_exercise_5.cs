
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using Microsoft.AspNetCore.Components;
using Blazored.LocalStorage;
using System.Reactive.Linq;

namespace ConversationManager.Advanced;

// 1. Event Aggregator / Notification Service
public class ChatEventService
{
    // Using .NET Events for simplicity, or use a library like MediatR
    public event Action? OnHistoryPruned;
    public void NotifyPruned() => OnHistoryPruned?.Invoke();
}

// 2. Main Layout with Resource Management
public class MainLayout : LayoutComponentBase, IDisposable
{
    [Inject] private StateContainer<ChatSession> StateContainer { get; set; } = null!;
    [Inject] private PersistentChatManager StorageManager { get; set; } = null!;
    [Inject] private ILocalStorageService LocalStorage { get; set; } = null!;

    // Store subscription tokens
    private IDisposable? _stateSubscription;
    private bool _isProcessingEvent = false; // Debounce flag

    protected override void OnInitialized()
    {
        // Subscribe to state changes to auto-save
        _stateSubscription = StateContainer.Subscribe(async session =>
        {
            await StorageManager.SaveSessionAsync(session);
        });

        // 3. Multi-Tab Synchronization
        // Blazored.LocalStorage provides an event wrapper around browser storage events
        LocalStorage.Changed += OnLocalStorageChanged;
    }

    private async void OnLocalStorageChanged(object? sender, Blazored.LocalStorage.ChangeEventArgs e)
    {
        // CRITICAL: Prevent Ping-Pong Loop
        if (_isProcessingEvent) return;
        
        // Check if the change is a chat session update
        if (e.Key?.StartsWith("chat_") == true && e.NewValue is not null)
        {
            _isProcessingEvent = true;

            try
            {
                // In a real app, we might only update if the ID matches the currently viewed session
                // or update a global list of sessions.
                var updatedSession = JsonSerializer.Deserialize<ChatSession>(e.NewValue.ToString());
                
                if (updatedSession != null)
                {
                    // Update the state container (which triggers UI updates)
                    await StateContainer.SetStateAsync(updatedSession);
                }
            }
            finally
            {
                // Debounce release (simple delay to allow the event loop to settle)
                await Task.Delay(100);
                _isProcessingEvent = false;
            }
        }
    }

    public void Dispose()
    {
        // 4. Cleanup to prevent memory leaks
        _stateSubscription?.Dispose();
        LocalStorage.Changed -= OnLocalStorageChanged;
    }
}

// 5. Decoupled Chat Page
public class ChatPage : ComponentBase
{
    [Inject] private StateContainer<ChatSession> StateContainer { get; set; } = null!;
    [Inject] private ConversationHistoryManager HistoryManager { get; set; } = null!;
    [Inject] private ChatEventService EventService { get; set; } = null!;

    private ChatSession? _currentSession;
    private IDisposable? _subscription;

    protected override void OnInitialized()
    {
        // Reactive subscription
        _subscription = StateContainer.Subscribe(session =>
        {
            _currentSession = session;
            StateHasChanged();
        });
    }

    private async Task AddMessage(string message)
    {
        if (_currentSession is null) return;

        // Update state via container (triggers save and UI update)
        var newMsgs = new List<string>(_currentSession.Messages) { message };
        var updatedSession = _currentSession with { Messages = newMsgs.ToImmutableList() };
        
        await StateContainer.SetStateAsync(updatedSession);
    }

    private async Task TriggerPrune()
    {
        if (_currentSession is null) return;
        
        var pruned = await HistoryManager.PruneHistory(_currentSession, 500); // 500 token limit
        await StateContainer.SetStateAsync(pruned);
        
        // Notify other parts of the app (e.g., a toast or dashboard)
        EventService.NotifyPruned();
    }

    public void Dispose() => _subscription?.Dispose();
}
