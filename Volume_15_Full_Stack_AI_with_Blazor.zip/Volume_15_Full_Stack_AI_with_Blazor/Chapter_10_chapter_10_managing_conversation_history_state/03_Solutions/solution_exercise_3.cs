
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

using System.Collections.Concurrent;
using System.Text.RegularExpressions;

namespace ConversationManager.Services;

public class ConversationHistoryManager
{
    private readonly SemaphoreSlim _lock = new(1, 1);

    // 1. Prune History with "Smart" Priority Logic
    public async Task<ChatSession> PruneHistory(ChatSession session, int maxTokenCount)
    {
        await _lock.WaitAsync();
        try
        {
            // Heuristic: 1 token ~= 4 chars
            int currentTokens = session.Messages.Sum(m => m.Length) / 4;

            if (currentTokens <= maxTokenCount) return session;

            var messages = new List<string>(session.Messages);
            
            // Define importance keywords
            var importantKeywords = new[] { "requirements", "code", "urgent", "fix" };

            // 1. Identify non-important indices
            var nonImportantIndices = new List<int>();
            for (int i = 0; i < messages.Count; i++)
            {
                bool isImportant = importantKeywords.Any(k => messages[i].Contains(k, StringComparison.OrdinalIgnoreCase));
                if (!isImportant)
                {
                    nonImportantIndices.Add(i);
                }
            }

            // 2. Delete oldest non-important messages first
            // We iterate backwards to maintain index integrity during removal
            foreach (var index in nonImportantIndices.OrderByDescending(i => i))
            {
                if (currentTokens <= maxTokenCount) break;

                var removedMessage = messages[index];
                currentTokens -= removedMessage.Length / 4;
                messages.RemoveAt(index);
            }

            // 3. If still over limit, remove oldest important messages
            while (currentTokens > maxTokenCount && messages.Count > 0)
            {
                var removedMessage = messages[0];
                currentTokens -= removedMessage.Length / 4;
                messages.RemoveAt(0);
            }

            return session with { Messages = messages };
        }
        finally
        {
            _lock.Release();
        }
    }

    // 2. Simulate AI Summarization
    public async Task<string> SummarizeHistory(ChatSession session)
    {
        // Simulate network latency
        await Task.Delay(500);

        if (session.Messages.Count == 0) return "Empty conversation.";

        // Mock Logic: Summarize by taking first and last messages
        string firstMsg = session.Messages.First();
        string lastMsg = session.Messages.Last();

        // Simple keyword extraction for "mock" summary
        var keywords = Regex.Matches(string.Join(" ", session.Messages), @"\b(\w{5,})\b")
                            .Select(m => m.Value)
                            .Distinct()
                            .Take(5);

        return $"Summary of '{session.Title}': Started with '{firstMsg.Substring(0, Math.Min(20, firstMsg.Length))}...' " +
               $"and concluded with '{lastMsg.Substring(0, Math.Min(20, lastMsg.Length))}...'. " +
               $"Key topics: {string.Join(", ", keywords)}.";
    }
}
