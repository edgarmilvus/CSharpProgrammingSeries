
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using System.Text.Json;
using Microsoft.AspNetCore.Components;

// 1. Domain Model: Represents a single message in the conversation
public record ChatMessage
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public required string Role { get; init; } // "User" or "Assistant"
    public required string Content { get; init; }
    public DateTime Timestamp { get; init; } = DateTime.UtcNow;
}

// 2. State Container: Manages the conversation state and notifies subscribers of changes
public class ConversationHistoryService
{
    private readonly List<ChatMessage> _messages = new();
    private readonly IJSRuntime? _jsRuntime; // Optional: For LocalStorage persistence

    // Event to notify Blazor components that the state has changed
    public event Action? OnChange;

    // Constructor accepting IJSRuntime for persistence capability
    public ConversationHistoryService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    // Public property to expose messages immutably to consumers
    public IReadOnlyList<ChatMessage> Messages => _messages;

    // Adds a message and triggers the notification
    public async Task AddMessageAsync(string role, string content)
    {
        var message = new ChatMessage { Role = role, Content = content };
        _messages.Add(message);

        // Persist to browser storage immediately
        if (_jsRuntime != null)
        {
            await PersistToStorageAsync();
        }

        NotifyStateChanged();
    }

    // Clears the history
    public async Task ClearHistoryAsync()
    {
        _messages.Clear();
        
        if (_jsRuntime != null)
        {
            await _jsRuntime.InvokeVoidAsync("localStorage.removeItem", "chatHistory");
        }

        NotifyStateChanged();
    }

    // Loads history from browser storage on initialization
    public async Task LoadHistoryAsync()
    {
        if (_jsRuntime == null) return;

        try
        {
            var json = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", "chatHistory");
            if (!string.IsNullOrEmpty(json))
            {
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var storedMessages = JsonSerializer.Deserialize<List<ChatMessage>>(json, options);
                
                if (storedMessages != null)
                {
                    _messages.Clear();
                    _messages.AddRange(storedMessages);
                    NotifyStateChanged();
                }
            }
        }
        catch (Exception ex)
        {
            // Handle storage errors (e.g., quota exceeded, disabled cookies)
            Console.WriteLine($"Error loading history: {ex.Message}");
        }
    }

    // Helper to persist state to LocalStorage
    private async Task PersistToStorageAsync()
    {
        if (_jsRuntime == null) return;

        var json = JsonSerializer.Serialize(_messages);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", "chatHistory", json);
    }

    // Invokes the event handler to trigger UI updates
    private void NotifyStateChanged() => OnChange?.Invoke();
}

// 3. UI Component: Displays the history and interacts with the service
@page "/chat"
@inject ConversationHistoryService HistoryService
@implements IDisposable

<h3>Conversation History</h3>

<div class="chat-container">
    @foreach (var msg in HistoryService.Messages)
    {
        <div class="message @msg.Role.ToLower()">
            <strong>@msg.Role:</strong> @msg.Content
        </div>
    }
</div>

<div class="controls">
    <button @onclick="AddUserMessage">Simulate User Message</button>
    <button @onclick="AddAssistantMessage">Simulate Assistant Reply</button>
    <button @onclick="ClearHistory" class="btn-danger">Clear History</button>
</div>

@code {
    protected override async Task OnInitializedAsync()
    {
        // Subscribe to changes
        HistoryService.OnChange += StateHasChanged;
        
        // Load existing history from browser storage
        await HistoryService.LoadHistoryAsync();
    }

    private async Task AddUserMessage()
    {
        await HistoryService.AddMessageAsync("User", "Hello, how do I manage state in Blazor?");
    }

    private async Task AddAssistantMessage()
    {
        await HistoryService.AddMessageAsync("Assistant", "You should use a State Container pattern.");
    }

    private async Task ClearHistory()
    {
        await HistoryService.ClearHistoryAsync();
    }

    public void Dispose()
    {
        // Always unsubscribe to prevent memory leaks
        HistoryService.OnChange -= StateHasChanged;
    }
}

<style>
    .chat-container { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; max-height: 300px; overflow-y: auto; }
    .message { margin: 5px 0; padding: 5px; border-radius: 4px; }
    .user { background-color: #e3f2fd; text-align: right; }
    .assistant { background-color: #f5f5f5; }
    .controls button { margin-right: 5px; }
    .btn-danger { background-color: #ff4444; color: white; border: none; padding: 5px 10px; cursor: pointer; }
</style>
