
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

    using Microsoft.JSInterop;

    public class WakeLockService : IAsyncDisposable
    {
        private readonly IJSRuntime _jsRuntime;
        private IJSObjectReference? _module;
        private IJSObjectReference? _currentLockHandle;

        public WakeLockService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        private async Task<IJSObjectReference> GetModule()
        {
            if (_module == null)
            {
                _module = await _jsRuntime.InvokeAsync<IJSObjectReference>(
                    "import", "./js/wakeLock.js");
            }
            return _module;
        }

        public async Task<bool> RequestLockAsync()
        {
            var module = await GetModule();
            // We expect a JS object back containing the lock handle
            var result = await module.InvokeAsync<LockResult>("requestWakeLock");
            
            if (result.Success && result.LockHandle != null)
            {
                _currentLockHandle = result.LockHandle;
                return true;
            }
            return false;
        }

        public async Task<bool> ReleaseLockAsync()
        {
            var module = await GetModule();
            var released = await module.InvokeAsync<bool>("releaseWakeLock");
            if (released)
            {
                _currentLockHandle = null;
            }
            return released;
        }

        public async ValueTask DisposeAsync()
        {
            if (_currentLockHandle != null)
            {
                await _currentLockHandle.DisposeAsync();
            }
            if (_module != null)
            {
                await _module.DisposeAsync();
            }
        }

        // Helper class for deserializing JS result
        private class LockResult
        {
            public bool Success { get; set; }
            public IJSObjectReference? LockHandle { get; set; }
            public string? Error { get; set; }
        }
    }
    