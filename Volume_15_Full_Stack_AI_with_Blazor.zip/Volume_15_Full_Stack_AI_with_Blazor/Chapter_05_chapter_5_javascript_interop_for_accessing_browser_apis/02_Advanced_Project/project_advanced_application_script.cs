
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Threading.Tasks;
using System.Text;

namespace BlazorCopilotJSInterop
{
    /// <summary>
    /// Real-World Problem: Building a "Smart Clipboard & Data Persistence" Copilot.
    /// 
    /// In a modern Blazor WASM AI Copilot application, users often need to:
    /// 1. Capture text snippets from the web (Copy).
    /// 2. Store these snippets locally for a session or indefinitely (Local Storage).
    /// 3. Retrieve and process them later (Paste/Analyze).
    /// 
    /// Since Blazor WebAssembly runs in a sandbox, it cannot directly access the 
    /// OS Clipboard or Browser Local Storage via standard .NET libraries. 
    /// We must use JavaScript Interop (IJSRuntime) to bridge this gap.
    /// 
    /// This Console Application simulates the logic flow of a Blazor Component 
    /// handling these operations, abstracting the "JS Interop" calls into a mock service.
    /// </summary>
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("--- Smart Clipboard & Persistence Copilot Simulation ---");
            Console.WriteLine("Simulating Blazor WASM JS Interop for Clipboard and Local Storage.\n");

            // 1. Initialize the Service (Simulating Dependency Injection in Blazor)
            var browserInteropService = new BrowserInteropService();

            // 2. Scenario: User copies a snippet of text from the web
            string sourceText = "AI Copilot Idea: Use JS Interop to bridge .NET and Browser APIs.";
            Console.WriteLine($"[User Action] Copied text: \"{sourceText}\"");

            // 3. Operation: Write to Clipboard (Requires JS)
            // In a real Blazor app, this calls IJSRuntime.InvokeVoidAsync("navigator.clipboard.writeText")
            await browserInteropService.WriteToClipboardAsync(sourceText);

            // 4. Operation: Persist to Local Storage (Requires JS)
            // In a real Blazor app, this calls IJSRuntime.InvokeVoidAsync("localStorage.setItem")
            // We simulate a unique ID for the stored item.
            string storageKey = $"snippet_{DateTime.Now:yyyyMMdd_HHmmss}";
            await browserInteropService.SaveToLocalStorageAsync(storageKey, sourceText);

            // 5. Operation: Read from Local Storage (Requires JS)
            // Retrieving the data to verify persistence.
            Console.WriteLine($"\n[System] Retrieving stored data for key: {storageKey}");
            string retrievedText = await browserInteropService.GetFromLocalStorageAsync(storageKey);

            // 6. Operation: Read from Clipboard (Requires JS)
            // Simulating a paste operation.
            string clipboardContent = await browserInteropService.ReadFromClipboardAsync();

            // 7. Logic: Compare Retrieved Data vs Clipboard Data
            // Basic validation logic (No LINQ/Lambdas used, per constraints)
            ValidateDataIntegrity(retrievedText, clipboardContent, sourceText);

            Console.WriteLine("\n--- Simulation Complete ---");
        }

        /// <summary>
        /// Validates if the stored data matches the source and clipboard data.
        /// Uses basic control flow (if/else) rather than LINQ or complex expressions.
        /// </summary>
        static void ValidateDataIntegrity(string storedData, string clipboardData, string originalData)
        {
            Console.WriteLine("\n[Validation] Checking data integrity...");

            if (storedData == originalData)
            {
                Console.WriteLine("  [PASS] Local Storage retrieval matches original source.");
            }
            else
            {
                Console.WriteLine("  [FAIL] Local Storage data mismatch.");
            }

            if (clipboardData == originalData)
            {
                Console.WriteLine("  [PASS] Clipboard retrieval matches original source.");
            }
            else
            {
                Console.WriteLine("  [FAIL] Clipboard data mismatch.");
            }

            // Simulating a simple AI Copilot suggestion based on data match
            if (storedData == clipboardData && clipboardData == originalData)
            {
                Console.WriteLine("  [Copilot Suggestion] Data integrity verified. Ready for semantic analysis.");
            }
        }
    }

    /// <summary>
    /// Service class simulating a Blazor Component's interaction with IJSRuntime.
    /// In a real Blazor app, this class would inject IJSRuntime:
    /// private readonly IJSRuntime _jsRuntime;
    /// </summary>
    public class BrowserInteropService
    {
        // Mocking the asynchronous nature of JS Interop
        private readonly Random _random = new Random();

        public BrowserInteropService() { }

        /// <summary>
        /// Simulates: await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", text);
        /// </summary>
        public async Task WriteToClipboardAsync(string text)
        {
            // Simulate network/JS delay
            await Task.Delay(100); 
            Console.WriteLine($"  [JS Interop] Called 'navigator.clipboard.writeText' with length: {text.Length}");
            // In reality, the browser handles the clipboard write here.
        }

        /// <summary>
        /// Simulates: await JSRuntime.InvokeVoidAsync("localStorage.setItem", key, value);
        /// </summary>
        public async Task SaveToLocalStorageAsync(string key, string value)
        {
            await Task.Delay(50);
            Console.WriteLine($"  [JS Interop] Called 'localStorage.setItem' for key: '{key}'");
            // In reality, the browser persists this to IndexedDB or similar.
        }

        /// <summary>
        /// Simulates: await JSRuntime.InvokeAsync<string>("localStorage.getItem", key);
        /// </summary>
        public async Task<string> GetFromLocalStorageAsync(string key)
        {
            await Task.Delay(50);
            Console.WriteLine($"  [JS Interop] Called 'localStorage.getItem' for key: '{key}'");
            // Returning the value to simulate successful retrieval.
            return "AI Copilot Idea: Use JS Interop to bridge .NET and Browser APIs."; 
        }

        /// <summary>
        /// Simulates: await JSRuntime.InvokeAsync<string>("navigator.clipboard.readText");
        /// </summary>
        public async Task<string> ReadFromClipboardAsync()
        {
            await Task.Delay(50);
            Console.WriteLine("  [JS Interop] Called 'navigator.clipboard.readText'");
            // Returning the value to simulate successful read.
            return "AI Copilot Idea: Use JS Interop to bridge .NET and Browser APIs.";
        }
    }
}
