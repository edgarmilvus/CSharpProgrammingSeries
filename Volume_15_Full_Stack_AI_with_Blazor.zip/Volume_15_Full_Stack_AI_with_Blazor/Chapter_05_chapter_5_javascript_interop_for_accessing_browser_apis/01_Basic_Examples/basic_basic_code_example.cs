
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/clipboard-demo"
@using System.Text.Json
@inject IJSRuntime JS

<h3>AI Copilot Clipboard Helper</h3>

<div class="card p-3">
    <div class="mb-2">
        <label class="form-label">Enter text to copy (e.g., AI Response):</label>
        <textarea @bind="inputText" class="form-control" rows="3"></textarea>
    </div>
    
    <div class="btn-group">
        <button class="btn btn-primary" @onclick="CopyToClipboardAsync">Copy Text</button>
        <button class="btn btn-secondary" @onclick="ReadClipboardAsync">Read Clipboard</button>
    </div>

    @if (!string.IsNullOrEmpty(statusMessage))
    {
        <div class="alert alert-info mt-3">@statusMessage</div>
    }
</div>

@code {
    private string? inputText;
    private string? statusMessage;
    private IJSObjectReference? clipboardModule;

    // 1. Initialize the JS Module
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            try
            {
                // Import the JavaScript file as a module
                clipboardModule = await JS.InvokeAsync<IJSObjectReference>(
                    "import", "./js/clipboardModule.js");
            }
            catch (Exception ex)
            {
                statusMessage = $"Error loading JS module: {ex.Message}";
                StateHasChanged();
            }
        }
    }

    // 2. Invoke 'writeText' method from JavaScript
    private async Task CopyToClipboardAsync()
    {
        if (clipboardModule is null || string.IsNullOrEmpty(inputText)) return;

        try
        {
            // We pass the raw string; the runtime handles marshaling
            await clipboardModule.InvokeVoidAsync("writeText", inputText);
            statusMessage = "Text copied to clipboard successfully!";
        }
        catch (JSException jsEx)
        {
            statusMessage = $"JS Error: {jsEx.Message}";
        }
        catch (Exception ex)
        {
            statusMessage = $"Error: {ex.Message}";
        }
        
        StateHasChanged();
    }

    // 3. Invoke 'readText' method and handle the Promise
    private async Task ReadClipboardAsync()
    {
        if (clipboardModule is null) return;

        try
        {
            // The JS method returns a Promise<string>. 
            // IJSRuntime automatically awaits this and returns the string to C#.
            string clipboardContent = await clipboardModule.InvokeAsync<string>("readText");
            
            if (!string.IsNullOrEmpty(clipboardContent))
            {
                statusMessage = $"Clipboard contains: {clipboardContent}";
                inputText = clipboardContent; // Update the UI
            }
            else
            {
                statusMessage = "Clipboard is empty or permission denied.";
            }
        }
        catch (JSException jsEx)
        {
            // Browsers often block clipboard access if not in a secure context (HTTPS) 
            // or without explicit user interaction (like a click event).
            statusMessage = $"Permission Denied or Error: {jsEx.Message}";
        }
        finally
        {
            StateHasChanged();
        }
    }

    // 4. Clean up resources
    public async ValueTask DisposeAsync()
    {
        if (clipboardModule is not null)
        {
            await clipboardModule.DisposeAsync();
        }
    }
}
