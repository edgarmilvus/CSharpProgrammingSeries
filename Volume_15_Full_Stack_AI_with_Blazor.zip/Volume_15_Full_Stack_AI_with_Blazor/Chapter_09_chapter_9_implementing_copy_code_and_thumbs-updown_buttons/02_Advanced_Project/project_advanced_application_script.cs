
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Chapter9_AdvancedApplicationScript
{
    // ==========================================
    // 1. DATA MODELS
    // ==========================================
    // Represents a code snippet with an ID, content, and feedback counters.
    // In a real Blazor WASM app, this would be a shared model between client and server.
    public class CodeSnippet
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string CodeContent { get; set; }
        public int UpVotes { get; set; }
        public int DownVotes { get; set; }
        public bool HasUserVoted { get; set; } // Tracks local state to prevent multiple votes
    }

    // ==========================================
    // 2. MOCK BACKEND SERVICE
    // ==========================================
    // Simulates a persistent backend (API) that stores feedback.
    // In a real scenario, this would involve HTTP calls to a REST API.
    public class FeedbackService
    {
        // Simulating a database with a simple in-memory list
        private List<CodeSnippet> _snippets;

        public FeedbackService()
        {
            InitializeData();
        }

        private void InitializeData()
        {
            _snippets = new List<CodeSnippet>
            {
                new CodeSnippet
                {
                    Id = 1,
                    Title = "Blazor JS Interop Basic",
                    CodeContent = "await JSRuntime.InvokeVoidAsync(\"console.log\", \"Hello World\");",
                    UpVotes = 0,
                    DownVotes = 0
                },
                new CodeSnippet
                {
                    Id = 2,
                    Title = "Blazor Component Lifecycle",
                    CodeContent = "protected override void OnInitialized() { /* Logic */ }",
                    UpVotes = 0,
                    DownVotes = 0
                }
            };
        }

        // Simulates an API call to persist the vote
        public async Task<bool> SubmitVoteAsync(int snippetId, bool isUpVote)
        {
            Console.WriteLine($"[Backend API] Processing vote for Snippet ID {snippetId}...");
            
            // Simulate network latency
            await Task.Delay(500); 

            var snippet = FindSnippetById(snippetId);
            if (snippet == null || snippet.HasUserVoted) return false;

            if (isUpVote)
                snippet.UpVotes++;
            else
                snippet.DownVotes++;

            snippet.HasUserVoted = true; // Lock the vote for this session
            return true;
        }

        // Helper to retrieve data
        public List<CodeSnippet> GetSnippets() => _snippets;
        
        public CodeSnippet GetSnippet(int id) => FindSnippetById(id);

        private CodeSnippet FindSnippetById(int id)
        {
            foreach (var s in _snippets)
            {
                if (s.Id == id) return s;
            }
            return null;
        }
    }

    // ==========================================
    // 3. JAVASCRIPT INTEROP SIMULATION
    // ==========================================
    // In Blazor WASM, we use IJSRuntime. Here we simulate the browser's clipboard API.
    // This class abstracts the browser-specific logic required for copying text.
    public class ClipboardService
    {
        // Simulates: await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", text);
        public async Task CopyTextToClipboardAsync(string text)
        {
            Console.WriteLine("\n[JS Interop] Calling navigator.clipboard.writeText...");
            
            // In a real browser environment, this is an asynchronous operation.
            await Task.Delay(200); // Simulate JS execution time

            // We simulate the browser copying mechanism by setting a static variable
            // or simply printing to console, as a console app cannot access the system clipboard
            // without external libraries or P/Invoke.
            Console.WriteLine($"[JS Interop] SUCCESS: '{text}' copied to system clipboard.");
        }
    }

    // ==========================================
    // 4. MAIN APPLICATION LOGIC (CONSOLE UI)
    // ==========================================
    class Program
    {
        static async Task Main(string[] args)
        {
            // Initialize Services (Dependency Injection simulation)
            var feedbackService = new FeedbackService();
            var clipboardService = new ClipboardService();

            Console.WriteLine("=== Chapter 9: Interactive Copilot Simulation ===");
            Console.WriteLine("Simulating Blazor WASM User Interaction Logic\n");

            bool running = true;
            while (running)
            {
                DisplayMenu(feedbackService);
                Console.Write("\nEnter Command (1-3, 4 to Exit): ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        await HandleViewSnippets(feedbackService, clipboardService);
                        break;
                    case "2":
                        await HandleVote(feedbackService);
                        break;
                    case "3":
                        await HandleCopyCode(feedbackService, clipboardService);
                        break;
                    case "4":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid selection.");
                        break;
                }
                Console.WriteLine("\n" + new string('-', 40) + "\n");
            }
        }

        // ---------------------------------------------------------
        // LOGIC BLOCK 1: Displaying Content
        // ---------------------------------------------------------
        static void DisplayMenu(FeedbackService service)
        {
            var snippets = service.GetSnippets();
            Console.WriteLine("Available Code Snippets:");
            Console.WriteLine("ID | Title");
            Console.WriteLine("---|----------------------");
            
            // Basic loop to iterate through the collection
            foreach (var snippet in snippets)
            {
                string voteStatus = snippet.HasUserVoted ? " (Voted)" : "";
                Console.WriteLine($"{snippet.Id}  | {snippet.Title}{voteStatus}");
            }
            Console.WriteLine("\nActions:");
            Console.WriteLine("1. View Details & Copy Code");
            Console.WriteLine("2. Submit Thumbs Up/Down Vote");
            Console.WriteLine("3. Copy Code (Direct)");
            Console.WriteLine("4. Exit");
        }

        // ---------------------------------------------------------
        // LOGIC BLOCK 2: Handling User Votes (Thumbs Up/Down)
        // ---------------------------------------------------------
        static async Task HandleVote(FeedbackService service)
        {
            Console.Write("Enter Snippet ID to vote: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Invalid ID format.");
                return;
            }

            var snippet = service.GetSnippet(id);
            if (snippet == null)
            {
                Console.WriteLine("Snippet not found.");
                return;
            }

            Console.WriteLine($"Current Stats: Up: {snippet.UpVotes} | Down: {snippet.DownVotes}");
            Console.Write("Vote (1 for Up, 2 for Down): ");
            string voteInput = Console.ReadLine();

            bool isUpVote = voteInput == "1";
            bool success = false;

            // State Management: Check local state before calling backend
            if (snippet.HasUserVoted)
            {
                Console.WriteLine("Error: You have already voted on this snippet in this session.");
                return;
            }

            // Simulating the async backend call
            try 
            {
                success = await service.SubmitVoteAsync(id, isUpVote);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Backend Error: {ex.Message}");
            }

            if (success)
            {
                string emoji = isUpVote ? "👍" : "👎";
                Console.WriteLine($"Vote Submitted Successfully! {emoji}");
                Console.WriteLine($"New Stats: Up: {snippet.UpVotes} | Down: {snippet.DownVotes}");
            }
            else
            {
                Console.WriteLine("Vote failed. Please try again.");
            }
        }

        // ---------------------------------------------------------
        // LOGIC BLOCK 3: Handling Copy Code (JS Interop Simulation)
        // ---------------------------------------------------------
        static async Task HandleCopyCode(FeedbackService service, ClipboardService clipboard)
        {
            Console.Write("Enter Snippet ID to copy: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Invalid ID format.");
                return;
            }

            var snippet = service.GetSnippet(id);
            if (snippet == null)
            {
                Console.WriteLine("Snippet not found.");
                return;
            }

            // 1. Identify the specific code block
            string codeToCopy = snippet.CodeContent;

            // 2. Execute the browser API call via Interop
            try
            {
                await clipboard.CopyTextToClipboardAsync(codeToCopy);
                Console.WriteLine("Operation Complete: Code is now in your clipboard.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Clipboard Error: {ex.Message}");
            }
        }
        
        // ---------------------------------------------------------
        // LOGIC BLOCK 4: Combined View and Copy (Mimicking Component UI)
        // ---------------------------------------------------------
        static async Task HandleViewSnippets(FeedbackService service, ClipboardService clipboard)
        {
            Console.Write("Enter Snippet ID to view details: ");
            if (!int.TryParse(Console.ReadLine(), out int id)) return;

            var snippet = service.GetSnippet(id);
            if (snippet == null) { Console.WriteLine("Not found."); return; }

            // Render the "Component" view
            Console.WriteLine("\n--- COMPONENT VIEW ---");
            Console.WriteLine($"Title: {snippet.Title}");
            Console.WriteLine($"Code: {snippet.CodeContent}");
            Console.WriteLine($"Feedback: 👍 {snippet.UpVotes} | 👎 {snippet.DownVotes}");
            Console.WriteLine("----------------------");

            // Interactive Prompt
            Console.Write("Copy this code to clipboard? (y/n): ");
            if (Console.ReadLine()?.ToLower() == "y")
            {
                await clipboard.CopyTextToClipboardAsync(snippet.CodeContent);
            }
        }
    }
}
