
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

// ConversationContainer.razor
@using System.Collections.Generic

<div class="conversation-wrapper">
    <div class="controls">
        <h3>Session: @State.SessionId</h3>
        <button @onclick="ToggleBatchMode">
            Batch Mode: @(State.IsBatchMode ? "ON" : "OFF")
        </button>
    </div>

    <!-- Cascading the State object. IsFixed=true optimizes for immutable data. -->
    <CascadingValue Value="State" Name="ConversationContext" IsFixed="true">
        @foreach (var msg in Messages)
        {
            <MessageDisplay Message="@msg" />
        }
    </CascadingValue>
</div>

@code {
    public ConversationState State { get; set; } = new() { SessionId = Guid.NewGuid() };
    
    // Mock data
    private List<string> Messages { get; set; } = new() 
    { 
        "Message 1 Code", 
        "Message 2 Code", 
        "Message 3 Code" 
    };

    private void ToggleBatchMode()
    {
        State.IsBatchMode = !State.IsBatchMode;
        // In a real app, this would trigger a notification to children
    }
}

// MessageDisplay.razor
@inherits ComponentBase

<div class="message">
    <p>@Message</p>
    <InteractiveCodeBlock Index="@GetHashCode()" />
</div>

@code {
    [Parameter] public string Message { get; set; }
}

// InteractiveCodeBlock.razor
@inject IVoteService VoteService

<div class="code-block">
    <p>Code Block Index: @Index</p>
    <VoteButtons FeedbackId="FeedbackId" 
                 InitialUpVotes="0" 
                 InitialDownVotes="0" 
                 OnVoteChanged="HandleVoteChange" />
</div>

@code {
    [CascadingParameter(Name = "ConversationContext")]
    public ConversationState Context { get; set; }

    [Parameter] public int Index { get; set; }

    // Generate a deterministic ID based on context and index
    private Guid FeedbackId => Context != null 
        ? Guid.Parse(Context.SessionId.ToString().Substring(0, 8) + Index.ToString().PadLeft(16, '0')) 
        : Guid.NewGuid();

    private async Task HandleVoteChange(VoteState state)
    {
        // Interactive Challenge: Batch Vote Logic
        if (Context != null && Context.IsBatchMode)
        {
            // In a real scenario, we would use an EventAggregator or Service 
            // to notify the parent to update all other components.
            // Here, we simulate the action:
            Console.WriteLine($"Batch Mode Active: Vote applied to Block {Index} propagated to session {Context.SessionId}");
            
            // Example: Call a global service to update all items in this SessionId
            // await GlobalVoteService.ApplyBatchVote(Context.SessionId, state);
        }
    }
}
