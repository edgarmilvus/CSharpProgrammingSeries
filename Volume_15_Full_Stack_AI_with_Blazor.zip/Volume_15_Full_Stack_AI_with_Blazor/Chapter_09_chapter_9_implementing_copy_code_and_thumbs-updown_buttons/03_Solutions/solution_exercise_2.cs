
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// VoteButtons.razor
@inject IVoteService VoteService

<div class="vote-controls">
    <button class="vote-btn up @(_currentState.UserHasVotedUp ? "active" : "")" 
            @onclick="HandleUpVote" 
            @ondblclick="HandleDoubleClick">
        👍 <span>@_currentState.CurrentUpCount</span>
    </button>
    
    <button class="vote-btn down @(_currentState.UserHasVotedDown ? "active" : "")" 
            @onclick="HandleDownVote" 
            @ondblclick="HandleDoubleClick">
        👎 <span>@_currentState.CurrentDownCount</span>
    </button>
</div>

@if (!string.IsNullOrEmpty(_errorMessage))
{
    <div class="error-toast">@_errorMessage</div>
}

@code {
    [Parameter] public Guid FeedbackId { get; set; }
    [Parameter] public int InitialUpVotes { get; set; }
    [Parameter] public int InitialDownVotes { get; set; }
    [Parameter] public EventCallback<VoteState> OnVoteChanged { get; set; }

    // Internal state to track UI changes before server confirmation
    private VoteState _currentState = new();
    private VoteState _previousState = new(); // For rollback
    private string _errorMessage = string.Empty;
    private bool _isProcessing = false;

    protected override void OnInitialized()
    {
        _currentState.CurrentUpCount = InitialUpVotes;
        _currentState.CurrentDownCount = InitialDownVotes;
    }

    private async Task HandleUpVote() => await Vote(true);
    private async Task HandleDownVote() => await Vote(false);

    private async Task Vote(bool isUpVote)
    {
        if (_isProcessing) return;

        // 1. Optimistic Update
        _previousState = CloneState(_currentState);
        _errorMessage = string.Empty;

        if (isUpVote)
        {
            if (_currentState.UserHasVotedUp) return; // Already voted up
            _currentState.CurrentUpCount++;
            _currentState.UserHasVotedUp = true;
            
            // If was downvoted, remove downvote
            if (_currentState.UserHasVotedDown)
            {
                _currentState.CurrentDownCount--;
                _currentState.UserHasVotedDown = false;
            }
        }
        else
        {
            if (_currentState.UserHasVotedDown) return; // Already voted down
            _currentState.CurrentDownCount++;
            _currentState.UserHasVotedDown = true;

            // If was upvoted, remove upvote
            if (_currentState.UserHasVotedUp)
            {
                _currentState.CurrentUpCount--;
                _currentState.UserHasVotedUp = false;
            }
        }

        _isProcessing = true;
        StateHasChanged();

        try
        {
            // 2. API Call
            await VoteService.SubmitVoteAsync(FeedbackId, isUpVote);
            await OnVoteChanged.InvokeAsync(_currentState);
        }
        catch (Exception ex)
        {
            // 3. Rollback on failure
            _currentState = _previousState;
            _errorMessage = $"Vote failed: {ex.Message}. Reverting changes.";
        }
        finally
        {
            _isProcessing = false;
        }
    }

    // Interactive Challenge: Double Click to Reset
    private async Task HandleDoubleClick()
    {
        if (_isProcessing) return;

        _previousState = CloneState(_currentState);
        
        // Reset logic: remove current active vote
        bool wasUp = _currentState.UserHasVotedUp;
        bool wasDown = _currentState.UserHasVotedDown;

        if (wasUp) _currentState.CurrentUpCount--;
        if (wasDown) _currentState.CurrentDownCount--;
        
        _currentState.UserHasVotedUp = false;
        _currentState.UserHasVotedDown = false;

        _isProcessing = true;
        StateHasChanged();

        try
        {
            // Send withdrawal (false indicates generic vote removal or specific API logic)
            await VoteService.SubmitVoteAsync(FeedbackId, wasUp); 
            await OnVoteChanged.InvokeAsync(_currentState);
        }
        catch (Exception ex)
        {
            _currentState = _previousState;
            _errorMessage = $"Reset failed: {ex.Message}";
        }
        finally
        {
            _isProcessing = false;
        }
    }

    private VoteState CloneState(VoteState source) => new()
    {
        CurrentUpCount = source.CurrentUpCount,
        CurrentDownCount = source.CurrentDownCount,
        UserHasVotedUp = source.UserHasVotedUp,
        UserHasVotedDown = source.UserHasVotedDown
    };
}
