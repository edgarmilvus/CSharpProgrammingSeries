
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// CodeSnippet.razor
@page "/code-snippet"
@inject IJSRuntime JSRuntime
@implements IAsyncDisposable

<div class="code-container">
    <pre><code>@CodeContent</code></pre>
    <button class="copy-btn" @onclick="CopyCode" disabled="@_isProcessing">
        @_buttonText
    </button>
    
    @if (!string.IsNullOrEmpty(_statusMessage))
    {
        <div class="status-message @(_isSuccess ? "success" : "error")">
            @_statusMessage
        </div>
    }
</div>

@code {
    [Parameter] public string CodeContent { get; set; } = "Console.WriteLine(\"Hello World\");";
    
    private bool _isProcessing = false;
    private bool _isSuccess = false;
    private string _buttonText = "Copy";
    private string _statusMessage = string.Empty;
    private IJSObjectReference? _clipboardModule;
    private DotNetObjectReference<CodeSnippet>? _dotNetRef;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            try
            {
                // Import the JS module explicitly to avoid global scope pollution
                _clipboardModule = await JSRuntime.InvokeAsync<IJSObjectReference>(
                    "import", "./js/clipboardModule.js");
                
                _dotNetRef = DotNetObjectReference.Create(this);
            }
            catch (JSException ex)
            {
                Console.WriteLine($"JS Import Error: {ex.Message}");
            }
        }
    }

    private async Task CopyCode()
    {
        if (_isProcessing) return;

        _isProcessing = true;
        _statusMessage = string.Empty;
        
        try
        {
            // Invoke the JS function from the imported module
            bool success = await _clipboardModule!.InvokeAsync<bool>(
                "copyToClipboard", CodeContent);

            if (success)
            {
                _isSuccess = true;
                _buttonText = "Copied!";
                _statusMessage = "Code copied to clipboard.";
                
                // Reset UI after 2 seconds
                await Task.Delay(2000);
                _buttonText = "Copy";
                _statusMessage = string.Empty;
            }
            else
            {
                throw new JSException("Clipboard API not supported or denied.");
            }
        }
        catch (JSException ex)
        {
            _isSuccess = false;
            _statusMessage = $"Error: {ex.Message}. Check browser permissions.";
            Console.WriteLine($"Clipboard Error: {ex.Message}");
        }
        catch (JSDisconnectedException)
        {
            // Client disconnected, silently fail or log
            Console.WriteLine("Client disconnected during clipboard operation.");
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    // Interactive Challenge: Copy on Selection
    // This method is called from JS when text selection occurs
    [JSInvokable]
    public async Task OnTextSelected(string selectedText)
    {
        if (!string.IsNullOrWhiteSpace(selectedText))
        {
            // Trigger copy without button click
            await CopyCode();
            
            // Show subtle toast (reusing status message logic)
            _statusMessage = "Selection copied automatically.";
            StateHasChanged();
            
            await Task.Delay(2000);
            _statusMessage = string.Empty;
            StateHasChanged();
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_clipboardModule != null)
        {
            await _clipboardModule.DisposeAsync();
        }
        _dotNetRef?.Dispose();
    }
}
