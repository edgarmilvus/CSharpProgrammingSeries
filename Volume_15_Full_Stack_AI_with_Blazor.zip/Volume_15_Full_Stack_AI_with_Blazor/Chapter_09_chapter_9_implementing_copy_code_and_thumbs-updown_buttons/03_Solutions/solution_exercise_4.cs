
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// ScrollAwareCodeBlock.razor
@page "/scroll-block"
@inject IJSRuntime JSRuntime
@implements IAsyncDisposable

<div @ref="_containerRef" class="scroll-container" style="height: 200px; overflow-y: scroll; border: 1px solid #ccc;">
    <div style="height: 1000px; padding: 10px;">
        <p>Scroll inside this box...</p>
        <p>Current Position: @_scrollPosition</p>
        <p>Updates are throttled to 500ms via JS.</p>
    </div>
</div>

@code {
    private ElementReference _containerRef;
    private IJSObjectReference? _module;
    private DotNetObjectReference<ScrollAwareCodeBlock>? _dotNetRef;
    private int _scrollPosition;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            _dotNetRef = DotNetObjectReference.Create(this);
            
            // Import the module containing the throttled listener logic
            _module = await JSRuntime.InvokeAsync<IJSObjectReference>(
                "import", "./js/scrollModule.js");

            // Initialize the listener, passing the element reference and the .NET object
            await _module.InvokeVoidAsync("setupScrollListener", _containerRef, _dotNetRef);
        }
    }

    // This method is invoked from JavaScript
    [JSInvokable]
    public void OnScroll(int scrollPosition)
    {
        _scrollPosition = scrollPosition;
        // Note: In a real app, avoid StateHasChanged on every scroll event 
        // if JS is throttling, but here we update the UI to verify it works.
        StateHasChanged();
    }

    public async ValueTask DisposeAsync()
    {
        // 1. Remove the event listener from the DOM
        if (_module != null)
        {
            await _module.InvokeVoidAsync("disposeScrollListener", _containerRef);
            await _module.DisposeAsync();
        }

        // 2. Release the .NET object reference to allow Garbage Collection
        _dotNetRef?.Dispose();
    }
}
