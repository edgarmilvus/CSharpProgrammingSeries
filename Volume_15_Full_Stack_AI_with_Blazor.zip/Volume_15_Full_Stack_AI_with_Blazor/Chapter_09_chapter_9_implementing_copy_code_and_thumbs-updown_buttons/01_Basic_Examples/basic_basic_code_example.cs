
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/copy-demo"
@inject IJSRuntime JS

<div class="code-container">
    <pre><code>public string Greet(string name) => $"Hello, {name}!";</code></pre>
    <button @onclick="CopyCodeAsync" disabled="@_isCopying">
        @_buttonText
    </button>
</div>

@code {
    private bool _isCopying = false;
    private string _buttonText = "Copy Code";

    private async Task CopyCodeAsync()
    {
        // The code snippet to be copied
        const string codeToCopy = "public string Greet(string name) => \"Hello, {name}!\";";

        try
        {
            _isCopying = true; // 1. Prevent concurrent clicks
            _buttonText = "Copying...";

            // 2. Invoke the JavaScript 'navigator.clipboard.writeText' API
            await JS.InvokeVoidAsync("navigator.clipboard.writeText", codeToCopy);

            // 3. Provide immediate user feedback
            _buttonText = "Copied!";
            await Task.Delay(2000); // Wait 2 seconds
            _buttonText = "Copy Code";
        }
        catch (Exception ex)
        {
            // 4. Handle potential browser security errors (e.g., non-HTTPS context)
            Console.WriteLine($"Failed to copy: {ex.Message}");
            _buttonText = "Error (Check Console)";
        }
        finally
        {
            _isCopying = false; // 5. Re-enable the button
        }
    }
}
