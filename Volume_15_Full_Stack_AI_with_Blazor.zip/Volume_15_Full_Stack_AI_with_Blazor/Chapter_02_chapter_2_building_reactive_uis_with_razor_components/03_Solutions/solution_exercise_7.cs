
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.cs
// Description: Solution for Exercise 7
// ==========================================

@page "/complex-form"
@using Microsoft.AspNetCore.Components.Forms

<h3>Complex Registration Form</h3>

<div class="row">
    <div class="col-md-8">
        <EditForm Model="@Model" OnValidSubmit="@HandleValidSubmit" @ref="editFormRef">
            <DataAnnotationsValidator />
            
            <div class="card mb-3">
                <div class="card-body">
                    <!-- Basic Fields -->
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <InputText class="form-control" @bind-Value="Model.Username" />
                        <ValidationMessage For="@(() => Model.Username)" />
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <InputText class="form-control" @bind-Value="Model.Email" />
                        <ValidationMessage For="@(() => Model.Email)" />
                    </div>

                    <!-- Password Fields -->
                    <div class="row">
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <InputText type="password" class="form-control" @bind-Value="Model.Password" />
                                <ValidationMessage For="@(() => Model.Password)" />
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Confirm Password</label>
                                <InputText type="password" class="form-control" @bind-Value="Model.ConfirmPassword" />
                                <ValidationMessage For="@(() => Model.ConfirmPassword)" />
                            </div>
                        </div>
                    </div>

                    <!-- Subscription & Dates -->
                    <div class="row">
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Subscription Type</label>
                                <InputSelect class="form-control" @bind-Value="Model.SubscriptionType">
                                    <option value="Free">Free</option>
                                    <option value="Pro">Pro (1 Year)</option>
                                    <option value="Enterprise">Enterprise (5 Years)</option>
                                </InputSelect>
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Start Date</label>
                                <InputDate class="form-control" @bind-Value="Model.StartDate" />
                                <ValidationMessage For="@(() => Model.StartDate)" />
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">End Date (Calculated)</label>
                        <InputDate class="form-control" @bind-Value="Model.EndDate" />
                        <ValidationMessage For="@(() => Model.EndDate)" />
                        <small class="text-muted">Automatically calculated based on subscription.</small>
                    </div>

                    <button type="submit" class="btn btn-primary" disabled="@(!isFormValid)">Submit Registration</button>
                </div>
            </div>
        </EditForm>
    </div>
    <div class="col-md-4">
        <div class="alert alert-info">
            <h5>Form State</h5>
            <p>Is Valid: <strong>@(isFormValid ? "Yes" : "No")</strong></p>
            <p>Validation Messages: @validationCount</p>
        </div>
    </div>
</div>

@code {
    private RegistrationModel Model = new RegistrationModel();
    private EditForm? editFormRef;
    private EditContext? editContext;
    private bool isFormValid = false;
    private int validationCount = 0;

    protected override void OnInitialized()
    {
        // Initialize dates to avoid nulls
        Model.StartDate = DateTime.Today;
        Model.EndDate = DateTime.Today.AddYears(1); // Default
    }

    protected override void OnAfterRender(bool firstRender)
    {
        if (firstRender && editFormRef?.EditContext is not null)
        {
            editContext = editFormRef.EditContext;
            
            // Subscribe to validation events
            editContext.OnValidationRequested += HandleValidationRequested;
            editContext.OnFieldChanged += HandleFieldChanged;

            // Initial validation check
            UpdateFormState();
        }
    }

    private void HandleFieldChanged(object? sender, FieldChangedEventArgs e)
    {
        // 1. Dynamic Logic: Subscription Type Change
        if (e.FieldIdentifier.FieldName == nameof(RegistrationModel.SubscriptionType))
        {
            CalculateEndDate();
        }

        // 2. Update Form State (Button disabled state)
        UpdateFormState();
    }

    private void HandleValidationRequested(object? sender, ValidationRequestedEventArgs e)
    {
        UpdateFormState();
    }

    private void CalculateEndDate()
    {
        if (Model.StartDate.HasValue)
        {
            int yearsToAdd = 0;
            if (Model.SubscriptionType == "Pro") yearsToAdd = 1;
            else if (Model.SubscriptionType == "Enterprise") yearsToAdd = 5;

            if (yearsToAdd > 0)
            {
                Model.EndDate = Model.StartDate.Value.AddYears(yearsToAdd);
                
                // Trigger validation specifically for EndDate to clear/show errors immediately
                if (editContext != null)
                {
                    editContext.NotifyFieldChanged(editContext.Field(nameof(RegistrationModel.EndDate)));
                }
            }
        }
    }

    private void UpdateFormState()
    {
        if (editContext != null)
        {
            isFormValid = editContext.Validate();
            validationCount = editContext.GetValidationMessages().Count();
            StateHasChanged();
        }
    }

    private void HandleValidSubmit()
    {
        // Simulate form submission
        Console.WriteLine("Form Submitted Successfully");
    }

    public void Dispose()
    {
        if (editContext is not null)
        {
            editContext.OnValidationRequested -= HandleValidationRequested;
            editContext.OnFieldChanged -= HandleFieldChanged;
        }
    }
}
