
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

@page "/canvas-drawer"
@using Microsoft.JSInterop
@inject IJSRuntime JSRuntime

<h3>JS Interop Canvas Drawer</h3>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                Draw here (Mouse or Touch)
                <button class="btn btn-sm btn-danger float-end" @onclick="ClearCanvas">Clear</button>
            </div>
            <div class="card-body text-center">
                <!-- We use a div with a background color to simulate a canvas for simplicity in layout, 
                     but actually we render a real <canvas> element -->
                <canvas id="drawingCanvas" @ref="canvasRef" width="600" height="400" 
                        style="border: 1px solid #ccc; background-color: #f9f9f9; cursor: crosshair;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">Drawing Log</div>
            <div class="card-body" style="max-height: 350px; overflow-y: auto;">
                <ul class="list-group list-group-flush">
                    @foreach (var log in drawLogs)
                    {
                        <li class="list-group-item small">@log</li>
                    }
                </ul>
            </div>
        </div>
    </div>
</div>

@code {
    private ElementReference canvasRef;
    private DotNetObjectReference<CanvasDrawer>? dotNetObjectReference;
    private List<string> drawLogs = new List<string>();

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            dotNetObjectReference = DotNetObjectReference.Create(this);
            await JSRuntime.InvokeVoidAsync("initCanvas", dotNetObjectReference, canvasRef);
        }
    }

    [JSInvokable]
    public void UpdateLastCoordinate(int x, int y)
    {
        // We limit the log size to prevent memory issues in the UI
        if (drawLogs.Count > 50) drawLogs.RemoveAt(0);
        
        drawLogs.Add($"Drew at ({x}, {y}) at {DateTime.Now:HH:mm:ss}");
        
        // Note: We do not call StateHasChanged here for every pixel move 
        // to maintain high drawing performance. The UI log will update 
        // when the user stops drawing or interacts with other UI elements.
        // If we wanted real-time log updates, we would call StateHasChanged, 
        // but it might cause stuttering during fast drawing.
    }

    private async Task ClearCanvas()
    {
        drawLogs.Clear();
        await JSRuntime.InvokeVoidAsync("clearCanvas", canvasRef);
    }

    public void Dispose()
    {
        dotNetObjectReference?.Dispose();
    }
}
