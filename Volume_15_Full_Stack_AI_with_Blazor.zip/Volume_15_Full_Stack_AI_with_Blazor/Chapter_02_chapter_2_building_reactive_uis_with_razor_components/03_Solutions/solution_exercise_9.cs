
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.cs
// Description: Solution for Exercise 9
// ==========================================

@page "/virtualized-list"
@using Microsoft.AspNetCore.Components.Web.Virtualization
@inject IJSRuntime JSRuntime
@inject ProductService ProductService

<h3>Optimized Virtualized List</h3>

<div class="mb-3">
    <input type="text" class="form-control" placeholder="Filter products..." 
           @bind="filterText" @bind:event="oninput" @onkeyup="HandleFilterChange" />
</div>

<!-- Container with fixed height is REQUIRED for Virtualization -->
<div id="scrollContainer" style="height: 500px; overflow-y: auto; border: 1px solid #ddd; position: relative;">
    
    @if (products == null)
    {
        <div class="p-3 text-center">Loading data...</div>
    }
    else
    {
        <Virtualize Items="@products" Context="product" OverscanCount="10" TItem="Product">
            <div class="p-3 border-bottom" style="height: 50px; line-height: 30px;">
                <span class="badge bg-secondary">@product.Id</span>
                <strong>@product.Name</strong> - $@product.Price.ToString("F2")
            </div>
            
            <!-- Optional: Placeholder for loading state during scroll -->
            <Placeholder>
                <div class="p-3 border-bottom text-muted" style="height: 50px;">Loading...</div>
            </Placeholder>
        </Virtualize>
    }
</div>

@code {
    private List<Product>? products;
    private string filterText = "";
    private bool isFiltering = false;

    protected override async Task OnInitializedAsync()
    {
        // Initial load
        products = await ProductService.GetProductsAsync();
    }

    private async Task HandleFilterChange()
    {
        // Debounce could be added here, but for simplicity we trigger on KeyUp
        isFiltering = true;
        
        // Fetch filtered data
        products = await ProductService.GetProductsAsync(filterText);
        
        // Reset scroll position using JS Interop
        await JSRuntime.InvokeVoidAsync("scrollToTop", "scrollContainer");
        
        isFiltering = false;
    }

    // Note: We removed the standard OnParametersSetAsync logic here 
    // because we are managing the data source directly via the filter method.
}
