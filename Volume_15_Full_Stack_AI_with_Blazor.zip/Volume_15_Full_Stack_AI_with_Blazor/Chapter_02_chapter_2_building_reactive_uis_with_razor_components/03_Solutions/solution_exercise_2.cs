
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

@using Microsoft.AspNetCore.Components

<div class="container mt-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Theme Manager</h4>
            <button class="btn @GetToggleBtnClass()" @onclick="ToggleTheme">
                Switch to @(CurrentTheme == Theme.Light ? "Dark" : "Light")
            </button>
        </div>
        <div class="card-body">
            <p>Current Theme: <strong>@CurrentTheme</strong></p>
            
            <!-- Cascading the theme value down to children -->
            <CascadingValue Value="CurrentTheme" Name="AppTheme">
                <ThemedCard Title="Dashboard Panel">
                    <p>This card content is inside the first child.</p>
                    <ThemedButton Text="Action 1" />
                </ThemedCard>

                <ThemedCard Title="Settings Panel" class="mt-3">
                    <p>This is a nested grandchild scenario.</p>
                    <div class="mt-2">
                        <ThemedButton Text="Save Settings" />
                        <ThemedButton Text="Cancel" />
                    </div>
                </ThemedCard>
            </CascadingValue>
        </div>
    </div>
</div>

@code {
    public enum Theme { Light, Dark }
    
    public Theme CurrentTheme { get; private set; } = Theme.Light;

    private void ToggleTheme()
    {
        CurrentTheme = CurrentTheme == Theme.Light ? Theme.Dark : Theme.Light;
    }

    private string GetToggleBtnClass()
    {
        return CurrentTheme == Theme.Light ? "btn-dark" : "btn-light";
    }
}
