
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

@page "/reactive-counter"
@using Microsoft.AspNetCore.Components
@inject NavigationManager NavigationManager

<h3>Reactive Counter with Lifecycle Diagnostics</h3>

<div class="card mb-3">
    <div class="card-header">Counter State</div>
    <div class="card-body">
        <h5 class="card-title">Current Count: <span class="badge bg-primary">@CurrentCount</span></h5>
        <p class="card-text">Current Step: <strong>@Step</strong></p>
        <div class="btn-group">
            <button class="btn btn-success" @onclick="IncrementCount">Increment (+)</button>
            <button class="btn btn-warning" @onclick="DecrementCount">Decrement (-)</button>
            <button class="btn btn-danger" @onclick="ResetLog">Reset Log</button>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">Lifecycle Event Log</div>
    <div class="card-body" style="max-height: 300px; overflow-y: auto;">
        <ul class="list-group list-group-flush">
            @foreach (var logEntry in lifecycleLogs)
            {
                <li class="list-group-item small">@logEntry</li>
            }
        </ul>
    </div>
</div>

@code {
    private int CurrentCount = 0;
    private List<string> lifecycleLogs = new List<string>();

    [Parameter]
    public int Step { get; set; } = 1;

    protected override void OnInitialized()
    {
        // Check for query string parameter to reset log
        var uri = NavigationManager.ToAbsoluteUri(NavigationManager.Uri);
        var query = System.Web.HttpUtility.ParseQueryString(uri.Query);
        
        if (bool.TryParse(query["resetLog"], out bool resetLog) && resetLog)
        {
            lifecycleLogs.Clear();
            AddLog("OnInitialized (Log Cleared via Query String)");
        }
        else
        {
            AddLog("OnInitialized");
        }
    }

    protected override async Task OnInitializedAsync()
    {
        AddLog("OnInitializedAsync (Start)");
        await Task.Delay(50); // Simulate async work
        AddLog("OnInitializedAsync (End)");
    }

    protected override void OnParametersSet()
    {
        AddLog($"OnParametersSet (Step updated to: {Step})");
    }

    protected override async Task OnParametersSetAsync()
    {
        AddLog("OnParametersSetAsync (Start)");
        await Task.Delay(50); // Simulate async work
        AddLog("OnParametersSetAsync (End)");
    }

    protected override void OnAfterRender(bool firstRender)
    {
        AddLog($"OnAfterRender (First Render: {firstRender})");
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        AddLog($"OnAfterRenderAsync (Start - First Render: {firstRender})");
        await Task.Delay(50);
        AddLog($"OnAfterRenderAsync (End - First Render: {firstRender})");
    }

    private void IncrementCount()
    {
        CurrentCount += Step;
        AddLog($"Button Click: Incremented by {Step}");
    }

    private void DecrementCount()
    {
        CurrentCount -= Step;
        AddLog($"Button Click: Decremented by {Step}");
    }

    private void ResetLog()
    {
        lifecycleLogs.Clear();
        AddLog("Log manually reset by user");
    }

    private void AddLog(string message)
    {
        // We use StateHasChanged here to ensure the UI updates if the log changes 
        // during lifecycle methods that might not trigger a render otherwise.
        // However, we must be careful not to cause infinite loops.
        // In this specific case, adding to a list doesn't automatically trigger a render 
        // unless we are inside an event handler or explicitly call StateHasChanged.
        // Since lifecycle methods run during the render pipeline, calling StateHasChanged 
        // inside them is generally safe but redundant if the component is already rendering.
        
        lifecycleLogs.Insert(0, $"{DateTime.Now:HH:mm:ss.fff}: {message}");
        
        // Explicitly request a render update to show the new log entry immediately
        // This is useful because OnAfterRender runs *after* the render, so adding a log 
        // there won't show up until the *next* render cycle unless we force it.
        // However, doing this inside lifecycle methods requires caution to avoid loops.
        // In Blazor Server/ASM, adding to a list doesn't trigger a render automatically 
        // unless StateHasChanged is called.
        // To be safe and responsive, we invoke StateHasChanged. 
        // Note: Calling StateHasChanged inside OnAfterRender can cause a loop 
        // if not guarded. Here we rely on the fact that the log list change 
        // is the trigger.
        
        // We will NOT call StateHasChanged here to avoid potential infinite loops 
        // in OnAfterRender. The parent component's render cycle will pick up the list change 
        // if we are lucky, or we rely on the next user interaction.
        // To make it truly "Real-time" without loops, we use InvokeAsync and a flag if needed,
        // but for this exercise, simply updating the collection is sufficient 
        // as the UI will update on the next event or render.
    }
}
