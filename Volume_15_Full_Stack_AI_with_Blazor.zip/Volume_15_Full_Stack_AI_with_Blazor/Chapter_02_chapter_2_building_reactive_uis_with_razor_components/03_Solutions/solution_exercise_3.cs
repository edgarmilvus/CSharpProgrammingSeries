
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

@using Microsoft.AspNetCore.Components

<div class="@GetCardClass() card mb-3" style="transition: background-color 0.3s, color 0.3s;">
    <div class="card-header @GetHeaderClass()">
        @Title
    </div>
    <div class="card-body @GetBodyClass()">
        @ChildContent
    </div>
</div>

@code {
    [Parameter]
    public string Title { get; set; }

    [Parameter]
    public RenderFragment ChildContent { get; set; }

    [CascadingParameter(Name = "AppTheme")]
    public ThemeContainer.Theme CurrentTheme { get; set; }

    private string GetCardClass()
    {
        return CurrentTheme == ThemeContainer.Theme.Dark ? "bg-dark border-secondary" : "bg-light border";
    }

    private string GetHeaderClass()
    {
        return CurrentTheme == ThemeContainer.Theme.Dark ? "text-white bg-secondary" : "";
    }

    private string GetBodyClass()
    {
        return CurrentTheme == ThemeContainer.Theme.Dark ? "text-light" : "text-dark";
    }
}
