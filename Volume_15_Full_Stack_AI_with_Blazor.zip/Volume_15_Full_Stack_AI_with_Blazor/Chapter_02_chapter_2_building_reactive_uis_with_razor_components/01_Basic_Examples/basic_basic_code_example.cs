
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/reactive-form"
@using System.ComponentModel.DataAnnotations

<h3>Reactive Sign-up Form</h3>

<div class="form-group">
    <label for="username">Username:</label>
    <!-- 
      1. Data Binding: The 'value' attribute is bound to the C# property 'Username'.
         As the user types, the 'Username' property is updated immediately.
      2. Event Handling: The '@oninput' directive triggers the 'OnUsernameChanged' 
         method whenever the value of the input changes.
    -->
    <input id="username" 
           value="@Username" 
           @oninput="OnUsernameChanged" 
           class="form-control @(IsValid ? "is-valid" : "is-invalid")" />
    
    <!-- 
      3. Conditional Rendering: This validation message block only renders 
         if 'ValidationMessage' is not null or empty.
    -->
    @if (!string.IsNullOrEmpty(ValidationMessage))
    {
        <div class="invalid-feedback d-block">
            @ValidationMessage
        </div>
    }
</div>

<div class="mt-3">
    <p><strong>Current State:</strong> @Username</p>
    <p><strong>Is Valid:</strong> @IsValid</p>
</div>

@code {
    // 4. Component State: Properties decorated with [Parameter] are usually set 
    //    by parent components, but here we use standard properties to hold 
    //    the component's internal state.
    
    /// <summary>
    /// The current value of the username input field.
    /// </summary>
    private string Username { get; set; } = string.Empty;

    /// <summary>
    /// The validation message to display to the user.
    /// </summary>
    private string ValidationMessage { get; set; } = string.Empty;

    /// <summary>
    /// A flag indicating if the current input meets the validation criteria.
    /// </summary>
    private bool IsValid { get; set; } = false;

    /// <summary>
    /// Handles the 'oninput' event from the HTML input.
    /// </summary>
    /// <param name="e">The ChangeEventArgs containing the new value.</param>
    private void OnUsernameChanged(ChangeEventArgs e)
    {
        // 5. State Update: We update the component's state based on the UI event.
        Username = e.Value?.ToString() ?? string.Empty;

        // 6. Validation Logic: We run our business rules against the new state.
        ValidateUsername();

        // 7. Re-rendering: Blazor detects that state properties (Username, IsValid, 
        //    ValidationMessage) have changed and automatically triggers a 
        //    re-render of the component UI to reflect these changes.
    }

    /// <summary>
    /// Contains the business logic for validating the username.
    /// </summary>
    private void ValidateUsername()
    {
        // Reset state
        IsValid = false;
        ValidationMessage = string.Empty;

        // Check length
        if (string.IsNullOrWhiteSpace(Username))
        {
            ValidationMessage = "Username is required.";
            return;
        }

        if (Username.Length < 3)
        {
            ValidationMessage = "Username must be at least 3 characters long.";
            return;
        }

        // If all checks pass
        IsValid = true;
    }
}
