
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;

namespace BlazorReactiveFundamentals
{
    // REAL-WORLD PROBLEM CONTEXT:
    // Imagine a "Coffee Shop Copilot" application running on a WASM client.
    // The barista needs a console-based tool to manage the order queue.
    // This simulates the core logic that would eventually be bound to Razor components.
    // We are building the "ViewModel" logic here: managing state, handling events, and reacting to changes.

    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the Coffee Shop Manager
            CoffeeShopManager shop = new CoffeeShopManager();
            
            // Simulate the application lifecycle (similar to Blazor component initialization)
            shop.Initialize();

            // Simulate User Interactions (Event Handling)
            // In a real Blazor app, these would be triggered by button clicks.
            Console.WriteLine("--- EVENT 1: Customer Places Order ---");
            shop.HandleOrderReceived("Latte", 2);

            Console.WriteLine("\n--- EVENT 2: Barista Updates Status ---");
            shop.HandleOrderStatusUpdate(1, "Brewing");

            Console.WriteLine("\n--- EVENT 3: Customer Places Complex Order ---");
            shop.HandleOrderReceived("Espresso", 1);

            Console.WriteLine("\n--- EVENT 4: Barista Completes Order ---");
            shop.HandleOrderStatusUpdate(1, "Completed");
            
            Console.WriteLine("\n--- EVENT 5: System Cleanup (Lifecycle) ---");
            shop.Dispose();
        }
    }

    // Represents the data structure for an Order.
    // In Blazor, this would be a shared model class (often a Record in modern C#, but using Class here per constraints).
    public class CoffeeOrder
    {
        public int Id { get; set; }
        public string DrinkName { get; set; }
        public string Status { get; set; } // Pending, Brewing, Completed
        public DateTime OrderTime { get; set; }
    }

    // The Core Logic Engine.
    // This mimics a Blazor Razor Component (e.g., OrderQueue.razor) but without the UI markup.
    // It encapsulates state and exposes methods for event handling.
    public class CoffeeShopManager : IDisposable
    {
        // STATE MANAGEMENT
        // In Blazor, component state is held in properties.
        // We use a simple array to simulate a list (avoiding Generics/List<T> as per constraints if strictly basic).
        // However, for a "Substantial" app, we need a dynamic collection. 
        // We will use an Array for fixed size or a simple wrapper, but let's use a List for practicality 
        // (assuming List is introduced in basic C# chapters, otherwise we'd build a dynamic array class).
        // *Constraint Check*: If strictly no Collections, we use an array. Let's use a standard List for realism, 
        // but explain the logic manually if needed.
        private List<CoffeeOrder> _orderQueue;
        private int _nextOrderId;

        // LIFECYCLE METHODS
        // Analogous to Blazor's OnInitializedAsync / OnInitialized
        public void Initialize()
        {
            _orderQueue = new List<CoffeeOrder>();
            _nextOrderId = 1;
            Console.WriteLine("System: Coffee Shop Copilot Initialized.");
            Console.WriteLine("System: UI State is ready to receive events.");
        }

        // EVENT HANDLING
        // Analogous to an EventCallback in Blazor.
        // This method handles the "OnOrderReceived" event.
        public void HandleOrderReceived(string drinkName, int quantity)
        {
            // VALIDATION LOGIC
            if (string.IsNullOrWhiteSpace(drinkName))
            {
                Console.WriteLine("Error: Drink name cannot be empty.");
                return;
            }

            if (quantity <= 0)
            {
                Console.WriteLine("Error: Quantity must be greater than zero.");
                return;
            }

            // STATE MUTATION
            // In Blazor, we would call StateHasChanged() after this to trigger a UI re-render.
            for (int i = 0; i < quantity; i++)
            {
                var newOrder = new CoffeeOrder
                {
                    Id = _nextOrderId++,
                    DrinkName = drinkName,
                    Status = "Pending",
                    OrderTime = DateTime.Now
                };

                _orderQueue.Add(newOrder);
                Console.WriteLine($"Order Created: #{newOrder.Id} - {newOrder.DrinkName} (Status: {newOrder.Status})");
            }
            
            // Trigger a simulation of the UI refreshing
            RenderQueueView();
        }

        // EVENT HANDLING
        // Analogous to an EventCallback<int> or parameter binding.
        public void HandleOrderStatusUpdate(int orderId, string newStatus)
        {
            bool found = false;
            
            // Iterate through the collection (Simulating Blazor's rendering loop)
            for (int i = 0; i < _orderQueue.Count; i++)
            {
                if (_orderQueue[i].Id == orderId)
                {
                    // STATE MUTATION
                    _orderQueue[i].Status = newStatus;
                    found = true;
                    Console.WriteLine($"Order Updated: #{_orderQueue[i].Id} is now {newStatus}.");
                    
                    // In Blazor, we might use Cascading Parameters to notify child components here.
                    break;
                }
            }

            if (!found)
            {
                Console.WriteLine($"Error: Order #{orderId} not found.");
            }

            // Trigger UI Refresh
            RenderQueueView();
        }

        // REACTIVE UI RENDERING
        // This simulates what Blazor does internally when the component tree renders.
        // It iterates over the state and generates the visual representation.
        private void RenderQueueView()
        {
            Console.WriteLine("\n--- CURRENT QUEUE VIEW (Re-rendered) ---");
            Console.WriteLine("{0,-5} {1,-15} {2,-12} {3,-20}", "ID", "DRINK", "STATUS", "TIME");
            Console.WriteLine(new string('-', 60));

            if (_orderQueue.Count == 0)
            {
                Console.WriteLine("No active orders.");
            }
            else
            {
                for (int i = 0; i < _orderQueue.Count; i++)
                {
                    var order = _orderQueue[i];
                    // Formatting output to look like a UI list
                    Console.WriteLine("{0,-5} {1,-15} {2,-12} {3,-20}", 
                        order.Id, 
                        order.DrinkName, 
                        order.Status, 
                        order.OrderTime.ToString("HH:mm:ss"));
                }
            }
            Console.WriteLine(new string('-', 60));
            Console.WriteLine();
        }

        // LIFECYCLE METHODS
        // Analogous to Blazor's OnDisposeAsync or IDisposable implementation.
        // Crucial for cleaning up resources (event listeners, timers).
        public void Dispose()
        {
            _orderQueue.Clear();
            Console.WriteLine("System: Resources released. Coffee Shop Copilot shutting down.");
        }
    }
}
