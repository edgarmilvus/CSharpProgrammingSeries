
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/hello-code"
@using Microsoft.AspNetCore.Components

<div class="code-container">
    <div class="code-header">
        <span>C# Example</span>
    </div>
    <!-- 
      The @((MarkupString)...) syntax is critical here. 
      It tells Blazor to render the string as raw HTML rather than escaping it.
      This allows us to inject <pre> and <code> tags directly.
    -->
    <pre class="language-csharp"><code>@((MarkupString)_highlightedCode)</code></pre>
</div>

@code {
    // 1. The raw source code we want to display.
    // In a real app, this might come from an API or a file.
    private const string RawCode = @"
using System;

public class HelloWorld 
{
    public static void Main() 
    {
        Console.WriteLine(""Hello, Blazor WASM!"");
    }
}";

    // 2. A property to hold the HTML-escaped and formatted code.
    // We initialize it in OnInitialized to simulate the processing step.
    private string _highlightedCode = string.Empty;

    protected override void OnInitialized()
    {
        // 3. Simulate syntax highlighting logic.
        // In a real scenario, you would use a library like Markdig or PrismJS.
        // Here, we manually wrap keywords in <span> tags with CSS classes.
        _highlightedCode = HighlightSyntax(RawCode);
    }

    // 4. A naive syntax highlighter for demonstration purposes.
    // This uses simple string replacement to colorize C# keywords.
    private string HighlightSyntax(string code)
    {
        // First, HTML escape the code to prevent XSS and ensure tags render correctly.
        var escapedCode = System.Net.WebUtility.HtmlEncode(code);

        // Define a list of C# keywords to highlight.
        var keywords = new[] { "using", "public", "class", "static", "void", "return", "if", "else" };

        // Apply highlighting by wrapping keywords in span tags.
        foreach (var keyword in keywords)
        {
            // Regex is usually better, but for simple string replacement:
            escapedCode = escapedCode.Replace(
                $"{keyword} ", 
                $"<span class=\"keyword\">{keyword}</span> ");
            
            // Handle cases where the keyword is at the end of a line or followed by punctuation
            escapedCode = escapedCode.Replace(
                $"{keyword}<", 
                $"<span class=\"keyword\">{keyword}</span><");
        }

        // Replace newlines with <br> tags for display in the inline context if needed,
        // though <pre> usually handles whitespace. We keep newlines for <pre> usage.
        // However, to ensure the MarkupString renders line breaks correctly in the specific context
        // of the injected HTML, we might replace \n with <br> if not using strict <pre> behavior,
        // but <pre> preserves whitespace. Let's stick to preserving the structure.
        
        return escapedCode;
    }
}
