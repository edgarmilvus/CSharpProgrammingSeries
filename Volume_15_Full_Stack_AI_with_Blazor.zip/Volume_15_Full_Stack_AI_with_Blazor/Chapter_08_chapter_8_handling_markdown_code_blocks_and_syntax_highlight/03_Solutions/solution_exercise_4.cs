
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using Microsoft.AspNetCore.Components;
using Markdig;
using Markdig.Syntax;
using System.Collections.Generic;
using System.Linq;

public class VirtualizedMarkdownRenderer : ComponentBase
{
    [Parameter] public string Markdown { get; set; }
    
    // Estimate item sizes (in pixels) for Virtualize component
    private const int ParagraphSize = 50;
    private const int CodeBlockSize = 300;
    
    private List<MarkdownChunk> _chunks;
    private MarkdownPipeline _pipeline;

    protected override void OnParametersSet()
    {
        _pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();
        var ast = Markdown.Parse(Markdown, _pipeline);
        
        // Segment AST into chunks
        _chunks = SplitIntoChunks(ast, chunkSize: 5); 
    }

    private List<MarkdownChunk> SplitIntoChunks(MarkdownDocument ast, int chunkSize)
    {
        var chunks = new List<MarkdownChunk>();
        var currentChunk = new MarkdownChunk();
        
        foreach (var block in ast)
        {
            if (currentChunk.Nodes.Count >= chunkSize)
            {
                chunks.Add(currentChunk);
                currentChunk = new MarkdownChunk();
            }
            currentChunk.Nodes.Add(block);
            
            // Calculate approximate height for this chunk based on block type
            currentChunk.EstimatedHeight += block switch
            {
                ParagraphBlock => ParagraphSize,
                CodeBlock => CodeBlockSize,
                HeadingBlock => 60,
                _ => 40
            };
        }
        
        if (currentChunk.Nodes.Any()) chunks.Add(currentChunk);
        return chunks;
    }

    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        if (_chunks == null) return;

        builder.OpenComponent(0, typeof(Virtualize<MarkdownChunk>));
        builder.AddParameter(1, "Items", _chunks);
        builder.AddParameter(2, "ItemSize", 200f); // Default estimate
        
        // Inline template for the Virtualize component
        builder.AddParameter(3, "ChildContent", (RenderFragment<MarkdownChunk>)((chunk) => 
            (b2) => 
            {
                foreach (var node in chunk.Nodes)
                {
                    // Render individual nodes using the logic from Exercise 1
                    RenderNode(node, b2);
                }
            }));
        
        builder.CloseComponent();
    }

    private void RenderNode(Block node, RenderTreeBuilder builder)
    {
        // Simplified renderer for context
        if (node is CodeBlock code)
        {
            // Use LazyImage or LazyCode component here
            builder.OpenComponent<LazyCodeBlock>(0);
            builder.AddParameter(1, "Code", code.Lines.ToString());
            builder.CloseComponent();
        }
        else if (node is ParagraphBlock para)
        {
            builder.OpenElement(2, "p");
            builder.AddContent(3, para.Inline.ToString());
            builder.CloseElement();
        }
    }
}

public class MarkdownChunk
{
    public List<Block> Nodes { get; set; } = new();
    public float EstimatedHeight { get; set; }
}

// Lazy Loading Component for Images
public class LazyImage : ComponentBase
{
    [Parameter] public string Src { get; set; }
    [Parameter] public string Alt { get; set; }
    
    private bool _isVisible = false;
    private ElementReference _imgRef;

    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        // If not visible, render a placeholder with the same height
        if (!_isVisible)
        {
            builder.OpenElement(0, "div");
            builder.AddAttribute(1, "style", "height: 200px; background: #eee;");
            builder.CloseElement();
        }
        else
        {
            builder.OpenElement(2, "img");
            builder.AddAttribute(3, "src", Src);
            builder.AddAttribute(4, "alt", Alt);
            builder.AddAttribute(5, "loading", "lazy"); // Native browser lazy loading
            builder.CloseElement();
        }
    }
    
    // In a real scenario, use IntersectionObserver via JS Interop 
    // to set _isVisible to true when in viewport.
}
