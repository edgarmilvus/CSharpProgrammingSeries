
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Microsoft.AspNetCore.Components;
using Markdig;
using Markdig.Syntax;
using Markdig.Syntax.Inlines;
using System.Text;

// 1. Define Semantic Blazor Components
public class MarkdownParagraph : ComponentBase
{
    [Parameter] public RenderFragment ChildContent { get; set; }
    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        builder.OpenElement(0, "p");
        builder.AddAttribute(1, "class", "semantic-paragraph");
        builder.AddContent(2, ChildContent);
        builder.CloseElement();
    }
}

public class MarkdownHeader : ComponentBase
{
    [Parameter] public int Level { get; set; }
    [Parameter] public RenderFragment ChildContent { get; set; }
    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        var tagName = $"h{Level}";
        builder.OpenElement(0, tagName);
        builder.AddAttribute(1, "class", $"semantic-header level-{Level}");
        builder.AddContent(2, ChildContent);
        builder.CloseElement();
    }
}

public class MarkdownBold : ComponentBase
{
    [Parameter] public RenderFragment ChildContent { get; set; }
    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        builder.OpenElement(0, "strong");
        builder.AddContent(1, ChildContent);
        builder.CloseElement();
    }
}

// 2. Main Renderer Component
public class CustomMarkdownRenderer : ComponentBase
{
    [Parameter] public string Markdown { get; set; }

    private RenderFragment _renderedContent;

    protected override void OnParametersSet()
    {
        _renderedContent = builder =>
        {
            if (string.IsNullOrEmpty(Markdown)) return;

            var pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();
            var document = Markdown.Parse(Markdown, pipeline);

            foreach (var block in document)
            {
                RenderBlock(block, builder);
            }
        };
    }

    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        builder.AddContent(0, _renderedContent);
    }

    private void RenderBlock(Block block, RenderTreeBuilder builder)
    {
        switch (block)
        {
            case HeadingBlock h:
                builder.OpenComponent<MarkdownHeader>(0);
                builder.AddParameter(1, "Level", h.Level);
                builder.AddParameter(2, "ChildContent", (RenderFragment)(b2 =>
                {
                    RenderInline(h.Inline, b2);
                }));
                builder.CloseComponent();
                break;

            case ParagraphBlock p:
                builder.OpenComponent<MarkdownParagraph>(10);
                builder.AddParameter(11, "ChildContent", (RenderFragment)(b2 =>
                {
                    RenderInline(p.Inline, b2);
                }));
                builder.CloseComponent();
                break;
            
            // Add cases for ListBlock, CodeBlock, etc. as needed
        }
    }

    private void RenderInline(ContainerInline inline, RenderTreeBuilder builder)
    {
        foreach (var child in inline)
        {
            if (child is LiteralInline literal)
            {
                builder.AddContent(0, literal.ToString());
            }
            else if (child is EmphasisInline emphasis)
            {
                if (emphasis.DelimiterChar == '*')
                {
                    builder.OpenComponent<MarkdownBold>(1);
                    builder.AddParameter(2, "ChildContent", (RenderFragment)(b2 => 
                    {
                        RenderInline(emphasis, b2);
                    }));
                    builder.CloseComponent();
                }
            }
        }
    }
}
