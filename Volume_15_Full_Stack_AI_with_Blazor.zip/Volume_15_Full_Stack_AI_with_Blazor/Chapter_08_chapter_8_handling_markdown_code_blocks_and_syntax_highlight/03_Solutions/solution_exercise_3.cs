
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// 1. Theme Manager Service (Singleton)
public class ThemeManager
{
    public event Action<string> OnThemeChanged;
    public string CurrentTheme { get; private set; } = "light";

    public void SetTheme(string theme)
    {
        CurrentTheme = theme;
        OnThemeChanged?.Invoke(theme);
    }
}

// 2. Themed Code Block Component
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

public class ThemedCodeBlock : ComponentBase, IDisposable
{
    [Parameter] public string Code { get; set; }
    [Parameter] public string Language { get; set; }
    
    [Inject] private ThemeManager ThemeManager { get; set; }
    [Inject] private IJSRuntime JSRuntime { get; set; }

    private ElementReference _codeRef;
    private bool _shouldHighlight = false;

    protected override void OnInitialized()
    {
        ThemeManager.OnThemeChanged += HandleThemeChange;
    }

    protected override void OnAfterRender(bool firstRender)
    {
        if (firstRender || _shouldHighlight)
        {
            // Invoke JS to highlight the specific element
            // We use a module import for better performance
            JSRuntime.InvokeVoidAsync("highlightModule.highlightElement", 
                _codeRef, ThemeManager.CurrentTheme, Language);
            
            _shouldHighlight = false;
        }
    }

    private async void HandleThemeChange(string newTheme)
    {
        // If the theme changes, we need to re-run highlighting or just swap CSS classes
        // Swapping classes is faster, but highlighting ensures correct token colors
        _shouldHighlight = true;
        await InvokeAsync(StateHasChanged); // Notify Blazor to re-render
    }

    protected override void OnParametersSet()
    {
        // If code changes, we need to highlight again
        _shouldHighlight = true;
    }

    public void Dispose()
    {
        ThemeManager.OnThemeChanged -= HandleThemeChange;
    }
}
