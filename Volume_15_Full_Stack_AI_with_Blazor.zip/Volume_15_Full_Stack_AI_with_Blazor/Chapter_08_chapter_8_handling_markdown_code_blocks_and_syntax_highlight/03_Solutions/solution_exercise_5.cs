
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.cs
// Description: Solution for Exercise 5
// ==========================================

using Microsoft.AspNetCore.Components;
using System.Collections.ObjectModel;
using System.Text;

// 1. Data Models for Streaming Segments
public class StreamSegment
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public SegmentType Type { get; set; }
    public StringBuilder Content { get; set; } = new StringBuilder();
    public bool IsComplete { get; set; }
}

public enum SegmentType { Text, Code, List }

// 2. Main Copilot Component
public class StreamingCopilot : ComponentBase
{
    [Parameter] public string StreamContent { get; set; } // Incoming stream from AI

    private ObservableCollection<StreamSegment> _segments = new();
    private StreamSegment _currentSegment;
    private MarkdownPipeline _pipeline;

    protected override void OnInitialized()
    {
        _pipeline = new MarkdownPipelineBuilder().Build();
        // Initialize with a default text segment
        _currentSegment = new StreamSegment { Type = SegmentType.Text };
        _segments.Add(_currentSegment);
    }

    protected override void OnParametersSet()
    {
        if (string.IsNullOrEmpty(StreamContent)) return;

        // Incremental Parsing Logic
        // In a real streaming scenario, we compare the new chunk with previous state
        // Here we simulate processing the latest additions
        ProcessStreamChunk(StreamContent);
    }

    private void ProcessStreamChunk(string chunk)
    {
        // Heuristic parsing: Detect code block start/end
        if (chunk.Contains("