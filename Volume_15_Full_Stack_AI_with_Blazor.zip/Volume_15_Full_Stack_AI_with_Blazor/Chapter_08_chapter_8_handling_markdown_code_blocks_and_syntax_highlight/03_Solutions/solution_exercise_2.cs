
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using BlazorMonaco; // Assuming the BlazorMonaco package is installed

public class InteractiveCodeBlock : ComponentBase, IAsyncDisposable
{
    [Parameter] public string Code { get; set; }
    [Parameter] public string Language { get; set; }
    [Parameter] public EventCallback<string> OnCodeChanged { get; set; }
    
    [Inject] private IJSRuntime JSRuntime { get; set; }

    private MonacoEditor _editor;
    private StandaloneEditorConstructionOptions _editorOptions;
    private bool _isReadOnly = true;
    private DotNetObjectReference<InteractiveCodeBlock> _dotNetRef;

    protected override void OnInitialized()
    {
        _dotNetRef = DotNetObjectReference.Create(this);
    }

    protected override void OnParametersSet()
    {
        // Initialize editor options
        _editorOptions = new StandaloneEditorConstructionOptions
        {
            Language = Language,
            Value = Code,
            ReadOnly = _isReadOnly,
            Minimap = new EditorMinimapOptions { Enabled = false }, // Performance optimization
            AutomaticLayout = true,
            ScrollBeyondLastLine = false,
            // Virtualization is built into Monaco for large files
        };
    }

    // Handle the editor reference
    private async Task OnEditorInitialized(MonacoEditor editor)
    {
        _editor = editor;
        
        // For large files, we might want to validate length before setting
        if (Code.Length > 100000) 
        {
            // Truncate or warn user in a real scenario
        }
        
        await _editor.UpdateOptions(_editorOptions);
    }

    private async Task ToggleEditMode()
    {
        _isReadOnly = !_isReadOnly;
        if (_editor != null)
        {
            await _editor.UpdateOptions(new EditorUpdateOptions { ReadOnly = _isReadOnly });
        }
    }

    private async Task SaveChanges()
    {
        if (_editor != null)
        {
            var value = await _editor.GetValue();
            await OnCodeChanged.InvokeAsync(value);
            // Switch back to read-only after save
            _isReadOnly = true;
            await _editor.UpdateOptions(new EditorUpdateOptions { ReadOnly = true });
        }
    }

    // JS Interop setup (simplified for brevity, usually handled in a wrapper)
    // In a real implementation, you would inject the Monaco JS loader in index.html
    
    public async ValueTask DisposeAsync()
    {
        if (_editor != null)
        {
            await _editor.DisposeEditor();
        }
        _dotNetRef?.Dispose();
    }
}
