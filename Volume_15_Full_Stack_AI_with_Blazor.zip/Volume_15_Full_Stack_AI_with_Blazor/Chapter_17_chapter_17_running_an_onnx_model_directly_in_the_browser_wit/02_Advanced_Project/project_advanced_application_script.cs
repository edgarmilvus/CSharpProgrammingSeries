
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace BlazorCopilotOnnxConsole
{
    // Real-World Context:
    // In a Blazor WebAssembly Copilot application, we often need to perform lightweight 
    // client-side preprocessing of user input before sending it to a server or running 
    // a local ONNX model. This console application simulates the logic required to 
    // tokenize a sentence into numerical vectors (Tensors) compatible with an ONNX model.
    // This is a critical step in Natural Language Processing (NLP) pipelines where 
    // raw text is converted into a format the neural network understands.

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Blazor WASM ONNX Preprocessing Simulator ---");
            
            // 1. Define the vocabulary (Simulating a tokenizer dictionary)
            // In a real WASM app, this might be loaded from a JSON file or embedded resource.
            string[] vocabulary = new string[] {
                "<pad>", "<s>", "</s>", "<unk>", "the", "quick", "brown", "fox",
                "jumps", "over", "lazy", "dog", "hello", "world", "blazor", "wasm"
            };

            // 2. Define the input sentence (User input to the Copilot)
            string inputSentence = "hello blazor wasm";

            // 3. Process the input
            // We simulate the tokenization and padding logic required for ONNX models.
            int maxSequenceLength = 8; // Model expects fixed input size
            int[] tokenIds = TokenizeAndPad(inputSentence, vocabulary, maxSequenceLength);

            // 4. Output the resulting Tensor
            // In the browser, this array would be passed to the ONNX Runtime Web API.
            PrintTensor(tokenIds);

            Console.WriteLine("\n--- Simulation Complete ---");
        }

        // Method: TokenizeAndPad
        // Purpose: Converts a string sentence into a fixed-size integer array (Tensor).
        // This mimics the logic we would implement in a Blazor component before inference.
        static int[] TokenizeAndPad(string sentence, string[] vocab, int maxLength)
        {
            // Initialize the result array with the <pad> token ID (0)
            int[] result = new int[maxLength];
            for (int i = 0; i < maxLength; i++)
            {
                result[i] = 0; // <pad> token
            }

            // Split the sentence into words (simple whitespace tokenizer)
            // In a real NLP model, this would be a Byte-Pair Encoding (BPE) or WordPiece tokenizer.
            string[] words = sentence.Split(' ', StringSplitOptions.RemoveEmptyEntries);

            // Fill the array with token IDs
            int currentIdx = 0;
            
            // Add start token if required by model (simulated as index 1)
            if (currentIdx < maxLength)
            {
                result[currentIdx] = 1; // <s> token
                currentIdx++;
            }

            foreach (string word in words)
            {
                if (currentIdx >= maxLength - 1) break; // Leave room for end token

                // Lookup word in vocabulary
                int tokenID = -1;
                for (int v = 0; v < vocab.Length; v++)
                {
                    if (vocab[v] == word.ToLower())
                    {
                        tokenID = v;
                        break;
                    }
                }

                // If word not found, use <unk> token (index 3)
                if (tokenID == -1) tokenID = 3;

                result[currentIdx] = tokenID;
                currentIdx++;
            }

            // Add end token if required by model (simulated as index 2)
            if (currentIdx < maxLength)
            {
                result[currentIdx] = 2; // </s> token
            }

            return result;
        }

        // Method: PrintTensor
        // Purpose: Visualizes the numerical tensor data for debugging.
        static void PrintTensor(int[] tensor)
        {
            Console.WriteLine("Generated Input Tensor (Shape: [1, 8]):");
            Console.Write("[ ");
            for (int i = 0; i < tensor.Length; i++)
            {
                Console.Write(tensor[i]);
                if (i < tensor.Length - 1) Console.Write(", ");
            }
            Console.WriteLine(" ]");
        }
    }
}
