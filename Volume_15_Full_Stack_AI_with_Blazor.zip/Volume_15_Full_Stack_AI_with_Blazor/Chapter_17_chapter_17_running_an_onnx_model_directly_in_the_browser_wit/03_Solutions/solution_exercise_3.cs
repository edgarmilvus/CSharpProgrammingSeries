
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// DebouncedInput.razor.cs
using Microsoft.AspNetCore.Components;
using Microsoft.ML.OnnxRuntime;
using System.Threading;

public partial class DebouncedInput : IDisposable
{
    [Inject] private NavigationManager NavManager { get; set; } // Used to simulate model loading
    
    private string _userInput = "";
    private string _prediction = "Waiting for input...";
    private bool _isProcessing = false;
    
    // Debounce Timer
    private Timer? _debounceTimer;
    private readonly TimeSpan _debounceDelay = TimeSpan.FromMilliseconds(300);

    // State Management Record
    private record InferenceState(string Input, string Result);

    protected override void OnInitialized()
    {
        // Initialize timer with null callback (start disabled)
        _debounceTimer = new Timer(OnDebounceElapsed, null, Timeout.Infinite, Timeout.Infinite);
    }

    private void HandleInput(ChangeEventArgs e)
    {
        _userInput = e.Value?.ToString() ?? "";
        
        // Reset the timer on every keystroke
        // Change due time to 300ms from now
        _debounceTimer.Change(_debounceDelay, Timeout.InfiniteTimeSpan);
        
        // Visual feedback
        _prediction = "Thinking...";
    }

    private async void OnDebounceElapsed(object? state)
    {
        // This runs on a ThreadPool thread, not the UI thread
        if (string.IsNullOrWhiteSpace(_userInput)) return;

        _isProcessing = true;
        
        // Run inference off the UI thread
        await Task.Run(async () =>
        {
            // Simulate heavy inference work
            await Task.Delay(500); 
            
            // Update state (thread-safe via InvokeAsync)
            await InvokeAsync(() =>
            {
                _prediction = $"Predicted for: '{_userInput}'";
                _isProcessing = false;
                StateHasChanged();
            });
        });
    }

    public void Dispose()
    {
        _debounceTimer?.Dispose();
    }
}
