
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// WebcamInference.razor.cs
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System.Drawing; // Requires System.Drawing.Common or a compatible WASM alternative like SkiaSharp
using System.Drawing.Imaging;

public partial class WebcamInference
{
    [Inject] private IJSRuntime JS { get; set; }
    
    private ElementReference videoRef;
    private ElementReference canvasRef;
    private bool _isWebGLAvailable = false;
    private string? _predictionResult;
    private OrtSession? _session;

    protected override async Task OnInitializedAsync()
    {
        // 1. Initialize Model with WebGL Provider
        try
        {
            var sessionOptions = new SessionOptions();
            
            // Attempt to append WebGL Execution Provider
            // Note: This API is hypothetical as ONNX Runtime Web support in Blazor 
            // depends on the specific bindings available. In a pure JS context, 
            // it's configured via 'executionProviders: ['webgl']'.
            // Here we simulate the configuration intent.
            sessionOptions.AppendExecutionProviderWebGpu(); // Assuming WebGPU/WebGL binding
            
            // Fallback to CPU if WebGL fails (simulated logic)
            _isWebGLAvailable = true; 
            
            // Load model bytes (omitted for brevity, same as Ex 1)
            // _session = new OrtSession(..., sessionOptions);
        }
        catch
        {
            _isWebGLAvailable = false;
            // Re-initialize with CPU fallback
        }
    }

    private async Task CaptureAndPredict()
    {
        // 2. Capture Image via JS Interop
        // We draw the video frame to a canvas, get the ImageData, and process it.
        var imageData = await JS.InvokeAsync<byte[]>("captureFrame", videoRef, canvasRef, 28, 28);
        
        // 3. Image Preprocessing Pipeline
        var inputVector = PreprocessImage(imageData);

        // 4. Run Inference
        if (_session != null)
        {
            var inputTensor = new DenseTensor<float>(inputVector, new long[] { 1, 1, 28, 28 }); // NCHW format
            using var inputOrtValue = OrtValue.CreateFromTensor(inputTensor);
            
            // Run on background thread to avoid UI freeze during heavy processing
            await Task.Run(() => 
            {
                using var outputs = _session.Run(new List<OrtValue> { inputOrtValue });
                var output = outputs[0].AsTensor<float>().ToArray();
                var maxIndex = Array.IndexOf(output, output.Max());
                _predictionResult = maxIndex.ToString();
            });
        }
    }

    private float[] PreprocessImage(byte[] rgbaData)
    {
        // Manual grayscale and normalization
        // Input: RGBA byte array (4 bytes per pixel)
        // Output: Float array (28x28 flattened)
        
        var floatArray = new float[28 * 28];
        
        // Loop through pixels
        for (int i = 0; i < 28 * 28; i++)
        {
            int r = rgbaData[i * 4];
            int g = rgbaData[i * 4 + 1];
            int b = rgbaData[i * 4 + 2];
            
            // Grayscale conversion: 0.299R + 0.587G + 0.114B
            float gray = (0.299f * r + 0.587f * g + 0.114f * b) / 255.0f;
            
            // Normalization (MNIST usually expects 0-1 or -0.5 to 0.5)
            // Here we use 0-1
            floatArray[i] = gray;
        }
        
        return floatArray;
    }
}
