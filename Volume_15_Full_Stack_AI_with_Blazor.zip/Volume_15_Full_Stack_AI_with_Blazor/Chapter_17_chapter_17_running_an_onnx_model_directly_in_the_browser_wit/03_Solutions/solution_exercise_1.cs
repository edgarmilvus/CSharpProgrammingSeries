
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

// MnistInference.razor.cs (Code-behind)
using Microsoft.AspNetCore.Components;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System.Collections.Generic;
using System.Threading.Tasks;

public partial class MnistInference : IAsyncDisposable
{
    [Inject] public IJSRuntime JS { get; set; } // Required for WASM file loading

    private OrtSession? _session;
    private bool _isLoading = true;
    private string? _errorMessage;
    private float[]? _lastPrediction;

    // Hardcoded input vector (representing a specific digit for demonstration)
    // In a real scenario, this would come from user drawing or file upload.
    private readonly float[] _testInput = new float[784]; 

    protected override async Task OnInitializedAsync()
    {
        try
        {
            // 1. Load the model file from wwwroot
            // Note: In Blazor WASM, we cannot use System.IO.File directly. 
            // We must fetch the file via HTTP or embedded resources.
            using var stream = await JS.InvokeAsync<Stream>("getBinaryFile", "models/mnist.onnx");
            using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);
            var modelBytes = memoryStream.ToArray();

            // 2. Create Session Options and Environment
            // Using 'using' declarations for modern C# syntax
            using var sessionOptions = new SessionOptions();
            
            // 3. Initialize the Inference Session
            _session = new OrtSession(OrtEnvironment.Default, modelBytes, sessionOptions);
            
            _isLoading = false;
        }
        catch (Exception ex)
        {
            _errorMessage = $"Failed to load model: {ex.Message}";
            _isLoading = false;
        }
    }

    private async Task RunInference()
    {
        if (_session == null) return;

        try
        {
            // 4. Input Tensor Creation
            // Shape: [1, 784] (Batch size 1, 784 features)
            var inputTensor = new DenseTensor<float>(_testInput, new long[] { 1, 784 });
            
            // Wrap in OrtValue
            // Note: OrtValue.CreateFromTensor is the modern API for wrapping managed tensors
            using var inputOrtValue = OrtValue.CreateFromTensor(inputTensor);

            // 5. Inference Execution
            // We assume the input name is "input" or "input_1". 
            // In production, inspect the model metadata or use session.InputMetadata.Keys.
            var inputName = _session.InputMetadata.Keys.FirstOrDefault() ?? "input";
            
            using var runOptions = new RunOptions();
            using var outputs = _session.Run(runOptions, new List<OrtValue> { inputOrtValue }, 
                                           new[] { inputName }, 
                                           _session.OutputMetadata.Keys.ToArray());

            // 6. Output Extraction
            // The output is an OrtValue. We convert it to a managed array.
            var outputTensor = outputs[0].AsTensor<float>();
            _lastPrediction = outputTensor.ToArray();
        }
        catch (Exception ex)
        {
            _errorMessage = $"Inference failed: {ex.Message}";
        }
    }

    public async ValueTask DisposeAsync()
    {
        _session?.Dispose();
        // In WASM, explicit GC calls are sometimes needed for immediate cleanup
        await JS.InvokeVoidAsync("eval", "gc() && gc()"); 
    }
}
