
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.cs
// Description: Solution for Exercise 6
// ==========================================

// AdvancedCopilot.razor.cs
using Microsoft.AspNetCore.Components;
using Microsoft.ML.OnnxRuntime;
using System.Runtime.CompilerServices;

public partial class AdvancedCopilot : IAsyncDisposable
{
    [Inject] private IJSRuntime JS { get; set; }
    
    private string _inputText = "";
    private CancellationTokenSource? _cts;
    private List<Prediction> _predictions = new();

    // 1. Architecture Change: IAsyncEnumerable for streaming
    private async IAsyncEnumerable<Prediction> PredictStreamAsync(
        string input, 
        [EnumeratorCancellation] CancellationToken ct)
    {
        // 2. Token Streaming: Process in chunks (e.g., by sentence or token)
        // For this example, we split by space to simulate tokens/sentences
        var tokens = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        
        // Simulate loading a model (in reality, this would be injected)
        // using var session = ... 

        foreach (var token in tokens)
        {
            // Check for cancellation immediately
            ct.ThrowIfCancellationRequested();

            // Simulate inference latency
            await Task.Delay(100, ct); 

            // Simulate prediction result
            // In reality: Create tensor, session.Run(), parse output
            var result = new Prediction 
            { 
                Text = token, 
                Confidence = new Random().NextDouble() 
            };

            // 3. Yield Return: Stream result immediately
            yield return result;
        }
    }

    private async Task HandleInput(ChangeEventArgs e)
    {
        _inputText = e.Value?.ToString() ?? "";
        
        // 4. Cancellation Support: Cancel previous stream
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = new CancellationTokenSource();
        
        _predictions.Clear(); // Clear previous results
        
        try
        {
            // 5. UI Integration: Enumerate the async stream
            // We must capture the stream to a local list to display in the UI 
            // OR update the UI incrementally. 
            // Blazor's @foreach in Razor supports IAsyncEnumerable directly.
            
            // However, for the code-behind, we iterate to update the list:
            await foreach (var prediction in PredictStreamAsync(_inputText, _cts.Token))
            {
                _predictions.Add(prediction);
                StateHasChanged(); // Update UI after every chunk
            }
        }
        catch (OperationCanceledException)
        {
            // Expected when user types rapidly
        }
    }

    public async ValueTask DisposeAsync()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        await JS.InvokeVoidAsync("eval", "gc() && gc()");
    }

    public class Prediction
    {
        public string Text { get; set; } = "";
        public double Confidence { get; set; }
    }
}
