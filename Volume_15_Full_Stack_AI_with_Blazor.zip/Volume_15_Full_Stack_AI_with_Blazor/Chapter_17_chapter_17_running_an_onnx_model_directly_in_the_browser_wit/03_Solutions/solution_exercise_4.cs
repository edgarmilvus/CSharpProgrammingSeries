
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

// ModelManager.cs
using Microsoft.ML.OnnxRuntime;
using System.Collections.Concurrent;

public class ModelManager : IAsyncDisposable
{
    private readonly ConcurrentDictionary<string, OrtSession> _sessions = new();
    private OrtSession? _activeSession;
    private string? _activeModelName;

    // Load a model and make it active
    public async Task<string> SwitchModelAsync(string modelName, byte[] modelBytes)
    {
        // 1. Dispose previous session if switching
        if (_activeSession != null && _activeModelName != modelName)
        {
            await DisposeSessionAsync(_activeModelName);
        }

        // 2. Check if already loaded
        if (_sessions.TryGetValue(modelName, out var existingSession))
        {
            _activeSession = existingSession;
            _activeModelName = modelName;
            return $"Switched to existing model: {modelName}";
        }

        // 3. Load new model
        try
        {
            var sessionOptions = new SessionOptions();
            // Configure options...
            var newSession = new OrtSession(OrtEnvironment.Default, modelBytes, sessionOptions);
            
            _sessions[modelName] = newSession;
            _activeSession = newSession;
            _activeModelName = modelName;
            
            return $"Loaded new model: {modelName}";
        }
        catch (Exception ex)
        {
            return $"Error loading model: {ex.Message}";
        }
    }

    // Explicit disposal
    private async Task DisposeSessionAsync(string? modelName)
    {
        if (string.IsNullOrEmpty(modelName)) return;

        if (_sessions.TryRemove(modelName, out var session))
        {
            session.Dispose();
            
            // Force GC in WASM to release unmanaged memory immediately
            // This is specific to Blazor WASM where memory is limited
            await Task.Yield(); // Ensure we are off the UI thread
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    public OrtSession? GetActiveSession() => _activeSession;

    public async ValueTask DisposeAsync()
    {
        foreach (var session in _sessions.Values)
        {
            session.Dispose();
        }
        _sessions.Clear();
        
        // Final GC hint
        GC.Collect();
    }
}
