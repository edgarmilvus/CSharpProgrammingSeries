
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

@page "/onnx-hello-world"
@using Microsoft.JSInterop
@using System.Text.Json
@inject IJSRuntime JSRuntime

<PageTitle>ONNX Hello World</PageTitle>

<h3>ONNX Runtime Web in Blazor WASM</h3>

<div class="mb-3">
    <label class="form-label">Input Value (Float):</label>
    <input type="number" step="0.1" class="form-control" @bind="inputValue" />
</div>

<button class="btn btn-primary" @onclick="RunInference" disabled="@isProcessing">
    @if (isProcessing)
    {
        <span class="spinner-border spinner-border-sm"></span>
        <span> Processing...</span>
    }
    else
    {
        <span>Run Inference</span>
    }
</button>

@if (result != null)
{
    <div class="alert alert-success mt-3">
        <strong>Result:</strong> @result
    </div>
}

@if (!string.IsNullOrEmpty(errorMessage))
{
    <div class="alert alert-danger mt-3">
        <strong>Error:</strong> @errorMessage
    </div>
}

@code {
    private double inputValue = 1.0;
    private double? result;
    private string? errorMessage;
    private bool isProcessing = false;

    // Reference to the JavaScript module (defined below)
    private IJSObjectReference? jsModule;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            try
            {
                // Load the JavaScript module
                jsModule = await JSRuntime.InvokeAsync<IJSObjectReference>(
                    "import", "./js/onnx-hello-world.js");
            }
            catch (Exception ex)
            {
                errorMessage = $"Failed to load JS module: {ex.Message}";
            }
        }
    }

    private async Task RunInference()
    {
        if (jsModule == null) return;

        isProcessing = true;
        result = null;
        errorMessage = null;
        StateHasChanged();

        try
        {
            // 1. Prepare the input tensor data (C# Array)
            // For this example, we simulate a simple model: f(x) = x * 2
            // We wrap the scalar in an array for the tensor shape [1, 1]
            float[] inputData = new float[] { (float)inputValue };

            // 2. Serialize parameters for JS call
            var parameters = new
            {
                inputData = inputData,
                inputShape = new[] { 1, 1 } // Batch size 1, 1 feature
            };

            // 3. Invoke the JavaScript function to run inference
            // We expect a double back (the prediction)
            var responseJson = await jsModule.InvokeAsync<string>("runInference", parameters);

            // 4. Deserialize the result
            // In a real app, you might return a complex object. Here we return a double.
            var response = JsonSerializer.Deserialize<InferenceResponse>(responseJson);
            
            if (response != null && response.Success)
            {
                // Assuming the model output is a single float, mapped to double
                result = response.Output[0];
            }
            else
            {
                errorMessage = "Inference failed or returned no data.";
            }
        }
        catch (Exception ex)
        {
            errorMessage = $"Inference Error: {ex.Message}";
        }
        finally
        {
            isProcessing = false;
            StateHasChanged();
        }
    }

    // Helper class for deserializing the JS response
    public class InferenceResponse
    {
        public bool Success { get; set; }
        public float[]? Output { get; set; }
        public string? Error { get; set; }
    }
}
