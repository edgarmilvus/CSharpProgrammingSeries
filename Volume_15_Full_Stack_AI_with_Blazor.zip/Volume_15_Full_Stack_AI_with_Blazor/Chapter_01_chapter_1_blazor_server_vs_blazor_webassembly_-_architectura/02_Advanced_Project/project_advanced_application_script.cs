
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorAI_ArchitecturalTradeoffs
{
    // PROBLEM CONTEXT:
    // In a real-world AI Copilot application, we often need to route user requests
    // to different processing engines based on latency requirements and resource constraints.
    // This simulates the decision-making process between Blazor Server (processing on server)
    // and Blazor WebAssembly (processing on client).
    //
    // SCENARIO: An AI Assistant handles three types of tasks:
    // 1. "Quick Query": Simple text analysis (low latency, client-side suitable)
    // 2. "Deep Analysis": Complex pattern matching (high CPU, server-side suitable)
    // 3. "Secure Operation": API key validation (requires secure server environment)
    //
    // This console application simulates the architectural routing logic required
    // to manage these tasks efficiently, mimicking the trade-offs discussed in Chapter 1.

    class Program
    {
        // Entry point of the application
        static void Main(string[] args)
        {
            Console.WriteLine("=== AI Copilot Architectural Router v1.0 ===");
            Console.WriteLine("Simulating Blazor Server vs. WebAssembly Routing Logic\n");

            // Initialize the Request Queue
            // In a real Blazor app, this would be the SignalR hub queue (Server)
            // or the JS Interop queue (WASM).
            List<AIRequest> requestQueue = InitializeRequestQueue();

            // Initialize the Processing Engine
            // This abstracts the underlying hardware (Server CPU vs. Client Device CPU)
            AIProcessor engine = new AIProcessor();

            // Process the queue
            // We iterate through requests and decide the execution path
            for (int i = 0; i < requestQueue.Count; i++)
            {
                AIRequest currentRequest = requestQueue[i];
                
                Console.WriteLine($"\nProcessing Item #{i + 1}: '{currentRequest.RequestType}'");
                
                // The Routing Logic: Deciding where the AI model runs
                // This mimics the "Architectural Trade-off" decision in Blazor
                string executionResult = RouteAndProcessRequest(currentRequest, engine);
                
                Console.WriteLine($"   > Result: {executionResult}");
            }

            Console.WriteLine("\n=== Batch Processing Complete ===");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        // Helper method to populate initial data
        static List<AIRequest> InitializeRequestQueue()
        {
            List<AIRequest> queue = new List<AIRequest>();

            // Adding mixed request types to demonstrate routing logic
            queue.Add(new AIRequest("Quick Query", "Summarize text", Priority.Low));
            queue.Add(new AIRequest("Deep Analysis", "Calculate neural network weights", Priority.High));
            queue.Add(new AIRequest("Secure Operation", "Retrieve user financial data", Priority.High));
            queue.Add(new AIRequest("Quick Query", "Check grammar", Priority.Low));
            queue.Add(new AIRequest("Deep Analysis", "Image recognition processing", Priority.Medium));

            return queue;
        }

        // The Core Routing Logic
        // This method represents the architectural decision layer in Blazor
        static string RouteAndProcessRequest(AIRequest request, AIProcessor processor)
        {
            string resultMessage = "";

            // ARCHITECTURAL DECISION BLOCK 1: Security & Latency Check
            // In Blazor Server, sensitive data stays on the server.
            // In Blazor WASM, data is exposed unless encrypted/handled carefully.
            if (request.RequestType == "Secure Operation")
            {
                // Force execution on Server (Simulated)
                // Why? Because API keys and sensitive data should never be downloaded
                // to the client browser in a WASM app.
                resultMessage = processor.ExecuteOnServer(request);
            }
            // ARCHITECTURAL DECISION BLOCK 2: Computational Intensity
            // In Blazor WASM, heavy computation can freeze the UI thread.
            // In Blazor Server, the server has more power but network latency exists.
            else if (request.RequestType == "Deep Analysis")
            {
                // Heuristic: If priority is High, offload to Server to save client battery/resources
                if (request.PriorityLevel == Priority.High)
                {
                    resultMessage = processor.ExecuteOnServer(request);
                }
                else
                {
                    // Medium priority: Try client-side (WASM) to reduce server load
                    resultMessage = processor.ExecuteOnClient(request);
                }
            }
            // ARCHITECTURAL DECISION BLOCK 3: Lightweight Tasks
            // In Blazor WASM, instant UI feedback is possible without server round-trips.
            // In Blazor Server, every interaction incurs network latency.
            else if (request.RequestType == "Quick Query")
            {
                // Always route to Client (WASM) for low latency experience
                resultMessage = processor.ExecuteOnClient(request);
            }
            else
            {
                resultMessage = "Error: Unknown Request Type";
            }

            return resultMessage;
        }
    }

    // --- Domain Models ---

    // Enum representing Priority levels
    // Used to simulate decision heuristics
    public enum Priority
    {
        Low,
        Medium,
        High
    }

    // Represents an incoming AI request
    // In a real app, this would be a SignalR message or a WASM event argument
    public class AIRequest
    {
        public string RequestType { get; set; }
        public string Payload { get; set; }
        public Priority PriorityLevel { get; set; }

        public AIRequest(string type, string payload, Priority priority)
        {
            RequestType = type;
            Payload = payload;
            PriorityLevel = priority;
        }
    }

    // Simulates the Blazor Hosting Model Processing Engine
    public class AIProcessor
    {
        // Simulates Blazor Server Execution
        // Pros: Powerful CPU, Secure, Access to Server Resources
        // Cons: Network Latency, Server Load, State Management Complexity
        public string ExecuteOnServer(AIRequest request)
        {
            // Simulate processing delay (Network + Server CPU)
            SimulateDelay(500); 

            // In a real scenario, this would call an Azure AI Service or local model
            return $"[SERVER] Processed '{request.Payload}' securely. Latency: ~500ms.";
        }

        // Simulates Blazor WebAssembly Execution
        // Pros: No Network Latency for UI, Offline Capability, Reduced Server Cost
        // Cons: Limited Client Resources, Larger Download Size, Security Risks
        public string ExecuteOnClient(AIRequest request)
        {
            // Simulate processing delay (Client CPU - usually slower)
            SimulateDelay(200); 

            // In a real scenario, this would use ONNX Runtime or TensorFlow.js in WASM
            return $"[CLIENT] Processed '{request.Payload}' locally. Latency: ~200ms.";
        }

        // Helper to simulate realistic processing times
        private void SimulateDelay(int milliseconds)
        {
            System.Threading.Thread.Sleep(milliseconds);
        }
    }
}
