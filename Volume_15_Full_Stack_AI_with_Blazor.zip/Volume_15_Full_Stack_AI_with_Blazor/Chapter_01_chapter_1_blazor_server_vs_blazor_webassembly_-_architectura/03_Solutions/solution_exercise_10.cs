
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_10.cs
// Description: Solution for Exercise 10
// ==========================================

// File: Components/ArchitectureVisualizer.razor
@page "/architecture"
@using System.Text

<h3>Architecture Visualizer</h3>

<div class="mb-3">
    <label>Select Hosting Model:</label>
    <select @bind="SelectedModel" class="form-select">
        <option value="@HostingModel.BlazorServer">Blazor Server</option>
        <option value="@HostingModel.BlazorWebAssembly">Blazor WebAssembly</option>
        <option value="@HostingModel.BlazorHybrid">Blazor Hybrid (MAUI)</option>
    </select>
</div>

<h4>Generated Data Flow (Graphviz DOT)</h4>
<textarea class="form-control" rows="10" readonly>@GenerateDotGraph()</textarea>

<div class="mt-3">
    <p><em>Copy the code above into a Graphviz viewer (e.g., graphviz.org) to see the diagram.</em></p>
</div>

@code {
    public HostingModel SelectedModel { get; set; } = HostingModel.BlazorServer;

    private string GenerateDotGraph()
    {
        return SelectedModel switch
        {
            HostingModel.BlazorServer => GenerateServerFlow(),
            HostingModel.BlazorWebAssembly => GenerateWasmFlow(),
            HostingModel.BlazorHybrid => GenerateHybridFlow(),
            _ => "Invalid model selected."
        };
    }

    private string GenerateServerFlow()
    {
        return """
            digraph BlazorServer {
                rankdir=LR;
                node [shape=box, style=rounded];
                
                Client [label="Client Browser"];
                SignalR [label="SignalR Connection"];
                Server [label="Server (AI Logic)"];
                ExtAPI [label="External API"];

                Client -> SignalR [label="Prompt"];
                SignalR -> Server [label="Process"];
                Server -> ExtAPI [label="Secure Call"];
                ExtAPI -> Server [label="Response"];
                Server -> SignalR [label="Update"];
                SignalR -> Client [label="Render"];
            }
            """;
    }

    private string GenerateWasmFlow()
    {
        return """
            digraph BlazorWASM {
                rankdir=LR;
                node [shape=box, style=rounded];

                Client [label="Client Browser (WASM)"];
                ExtAPI [label="External API"];

                Client -> ExtAPI [label="HTTP Request (API Key Visible)"];
                ExtAPI -> Client [label="JSON Response"];
                Client -> Client [label="Render (WASM)"];
            }
            """;
    }

    private string GenerateHybridFlow()
    {
        return """
            digraph BlazorHybrid {
                rankdir=TB;
                node [shape=box, style=rounded];

                subgraph cluster_0 {
                    label = "Device Runtime";
                    style = dashed;
                    
                    WebView [label="Web View (Chromium/WebKit)"];
                    Native [label="Native OS APIs"];
                    LocalModel [label="Local ONNX Model"];

                    WebView -> Native [label="JS Interop / Bridge"];
                    Native -> LocalModel [label="Inference"];
                }

                Cloud [label="Cloud API (Optional)"];
                
                WebView -> Cloud [label="REST (If not local)"];
            }
            """;
    }

    public enum HostingModel
    {
        BlazorServer,
        BlazorWebAssembly,
        BlazorHybrid
    }
}
