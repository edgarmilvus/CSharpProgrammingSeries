
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.cs
// Description: Solution for Exercise 7
// ==========================================

// File: Shared/Components/SmartRouter.razor
@inject IServiceProvider ServiceProvider
@inject PerformanceMonitor Monitor

<h3>Smart Router</h3>

<div>
    <label>
        <input type="checkbox" @bind="IsHeavyComputation" />
        Use Heavy Computation (Server)
    </label>
</div>

<button @onclick="RunProcessing" disabled="@_isProcessing">Run AI Task</button>

@if (result != null)
{
    <div class="alert alert-info mt-2">@result</div>
}

<h4>Performance History (Last 5 Requests)</h4>
<div style="display: flex; gap: 5px; height: 50px; align-items: flex-end;">
    @foreach (var time in Monitor.GetTimings())
    {
        <div title="@time ms" style="width: 20px; background-color: @(time > 100 ? 'red' : 'green'); height: @(Math.Min(time, 100))px;"></div>
    }
</div>

@code {
    [Parameter] public bool IsHeavyComputation { get; set; }
    private string? result;
    private bool _isProcessing;

    private async Task RunProcessing()
    {
        _isProcessing = true;
        IAIProcessor processor;

        if (IsHeavyComputation)
        {
            // Resolve Server Processor (Simulated via DI)
            processor = new ServerAIProcessor(Monitor); 
        }
        else
        {
            // Resolve Client Processor
            processor = new ClientAIProcessor(Monitor);
        }

        result = await processor.ProcessPromptAsync("Analyze this AI prompt.");
        _isProcessing = false;
    }
}
