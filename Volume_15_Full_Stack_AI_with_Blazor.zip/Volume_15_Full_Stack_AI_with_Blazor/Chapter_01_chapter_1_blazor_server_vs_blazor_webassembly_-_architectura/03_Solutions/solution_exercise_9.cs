
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.cs
// Description: Solution for Exercise 9
// ==========================================

// File: Components/SecureKeyManager.razor
@page "/secure-key"
@inject ApiAuthService AuthService
@inject IJSRuntime JSRuntime

<h3>Secure Key Manager</h3>

@if (keyStatus == KeyState.Loading)
{
    <p>Fetching credentials...</p>
}
else if (keyStatus == KeyState.Loaded)
{
    <div class="alert alert-success">
        <strong>Status:</strong> Key Loaded (Masked)<br />
        <em>Note: In WASM, this key is visible in network tab and memory.</em>
    </div>

    <button class="btn btn-primary" @onclick="CallExternalService">Use Key (Simulate API Call)</button>
    <button class="btn btn-secondary" @onclick="RefreshKey">Refresh Key</button>
}
else
{
    <button class="btn btn-info" @onclick="LoadKey">Retrieve API Key</button>
}

@code {
    private KeyState keyStatus = KeyState.NotLoaded;
    private string? _apiKey;

    private async Task LoadKey()
    {
        keyStatus = KeyState.Loading;
        _apiKey = await AuthService.GetApiKeyAsync();
        keyStatus = KeyState.Loaded;
    }

    private async Task CallExternalService()
    {
        // Simulate using the key
        if (!string.IsNullOrEmpty(_apiKey))
        {
            await JSRuntime.InvokeVoidAsync("alert", $"API Call made with Key: [REDACTED]");
        }
    }

    private async Task RefreshKey()
    {
        AuthService.InvalidateCache();
        await LoadKey();
    }

    private enum KeyState { NotLoaded, Loading, Loaded }
}
