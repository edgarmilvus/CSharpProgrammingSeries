
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.cs
// Description: Solution for Exercise 3
// ==========================================

// File: Components/PromptSanitizer.razor
@page "/sanitizer"
@inject IJSRuntime JSRuntime
@using System.Text.RegularExpressions

<h3>Client-Side Prompt Sanitizer</h3>

<div class="mb-3">
    <label>Enter Text:</label>
    <InputText @bind-Value="inputText" class="form-control" />
</div>

<div class="mb-3">
    <button class="btn btn-warning" @onclick="SanitizeCSharp">Sanitize (C#)</button>
    <button class="btn btn-info" @onclick="SanitizeJS">Sanitize (JS Interop)</button>
</div>

<h4>Original:</h4>
<p>@inputText</p>

<h4>Sanitized Output:</h4>
<p style="color: green;">@sanitizedOutput</p>

@code {
    [Required] // Modern C# feature for dependency validation
    public string inputText { get; set; } = "My password is 1234 and my secret is hidden.";
    
    private string sanitizedOutput = string.Empty;
    private IJSObjectReference? module;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            // Load JS module for clean interop
            module = await JSRuntime.InvokeAsync<IJSObjectReference>(
                "import", "./js/sanitizer.js");
        }
    }

    private void SanitizeCSharp()
    {
        // Pattern matching for forbidden keywords
        var forbidden = new[] { "password", "secret" };
        sanitizedOutput = inputText;

        foreach (var word in forbidden)
        {
            // Regex replace with case insensitivity
            sanitizedOutput = Regex.Replace(sanitizedOutput, word, "***", RegexOptions.IgnoreCase);
        }
    }

    private async Task SanitizeJS()
    {
        if (module is not null)
        {
            sanitizedOutput = await module.InvokeAsync<string>("sanitizeInput", inputText);
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (module is not null)
        {
            await module.DisposeAsync();
        }
    }
}
