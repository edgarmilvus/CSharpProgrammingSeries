
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_8.cs
// Description: Solution for Exercise 8
// ==========================================

// File: Services/ApiAuthService.cs
using System.Collections.Concurrent;
using System.Net.Http.Json;

public class ApiAuthService
{
    private readonly HttpClient _http;
    private readonly ConcurrentDictionary<string, (DateTime Expiry, string Key)> _cache = new();
    private readonly TimeSpan _cacheDuration = TimeSpan.FromSeconds(30);

    public ApiAuthService(HttpClient http)
    {
        _http = http;
    }

    public async Task<string> GetApiKeyAsync()
    {
        string cacheKey = "ai_service_key";

        // Check Cache
        if (_cache.TryGetValue(cacheKey, out var cached) && DateTime.UtcNow < cached.Expiry)
        {
            return cached.Key;
        }

        // Simulate fetching from a secure backend endpoint
        // In a real app, this would be an endpoint requiring auth
        var response = await _http.GetFromJsonAsync<ApiConfig>("api/keys/ai-key");
        var key = response?.Key ?? "fallback-key";

        // Update Cache
        _cache[cacheKey] = (DateTime.UtcNow.Add(_cacheDuration), key);
        
        return key;
    }

    public void InvalidateCache()
    {
        _cache.Clear();
    }

    private class ApiConfig
    {
        public string Key { get; set; } = string.Empty;
    }
}
