
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

// File: Components/PromptCounter.razor
@page "/prompt-counter"
@inject PromptCounterService CounterService
@implements IAsyncDisposable

<h3>AI Prompt Counter (Server State)</h3>
<p>Current Count: <strong>@currentCount</strong></p>

<button class="btn btn-primary" @onclick="ManualIncrement">Submit Prompt (Manual)</button>
<p><em>Note: Counter auto-increments every 5 seconds.</em></p>

@code {
    private int currentCount;

    protected override void OnInitialized()
    {
        // Initialize with current server state
        currentCount = CounterService.Count;
        
        // Subscribe to real-time updates
        CounterService.Subscribe(async newCount =>
        {
            currentCount = newCount;
            await InvokeAsync(StateHasChanged);
        });
    }

    private async Task ManualIncrement()
    {
        await CounterService.IncrementAsync();
    }

    public async ValueTask DisposeAsync()
    {
        // Cleanup handled by service, but component disposal logic goes here
        await Task.CompletedTask;
    }
}
