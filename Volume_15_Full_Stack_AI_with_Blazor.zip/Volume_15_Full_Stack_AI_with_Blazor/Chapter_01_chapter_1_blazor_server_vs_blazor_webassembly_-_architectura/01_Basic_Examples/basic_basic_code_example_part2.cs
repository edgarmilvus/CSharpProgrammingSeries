
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.cs
// Description: Basic Code Example
// ==========================================

// File: Pages/WasmChat.razor
@page "/wasm-chat"
@using System.Threading.Tasks

<h3>Blazor WebAssembly Chat</h3>
<p><em>State and processing occur on the client (browser).</em></p>

<div style="border: 1px solid #ccc; padding: 10px; height: 300px; overflow-y: scroll;">
    @foreach (var msg in chatHistory)
    {
        <div><strong>@msg.Sender:</strong> @msg.Text</div>
    }
</div>

<div style="margin-top: 10px;">
    <input @bind="userInput" @bind:event="oninput" placeholder="Type a message..." />
    <button @onclick="SendMessageAsync">Send</button>
</div>

@code {
    // 1. State Management
    // This list lives in the browser's memory (RAM) within the WebAssembly runtime.
    private List<ChatMessage> chatHistory = new();
    private string userInput = "";

    // 2. Event Handling
    // When the user clicks "Send", this method executes IN THE BROWSER.
    private async Task SendMessageAsync()
    {
        if (string.IsNullOrWhiteSpace(userInput)) return;

        // 3. Client-Side Processing
        // Add user message to the client-side list.
        chatHistory.Add(new ChatMessage { Sender = "User", Text = userInput });

        // Simulate processing delay
        await Task.Delay(500);

        // The "AI" logic runs here.
        string aiResponse = $"Processed by Client: {userInput}";

        // 4. State Update
        chatHistory.Add(new ChatMessage { Sender = "AI", Text = aiResponse });

        userInput = "";
        // 5. UI Update
        // Blazor WASM detects the state change and re-renders the component 
        // entirely within the browser's DOM. No network round-trip is needed for the UI update.
    }

    public class ChatMessage
    {
        public string Sender { get; set; } = "";
        public string Text { get; set; } = "";
    }
}
