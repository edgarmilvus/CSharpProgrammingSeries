
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.cs
// Description: Basic Code Example
// ==========================================

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Threading.RateLimiting;
using System.Diagnostics;

// ---------------------------------------------------------
// REAL-WORLD CONTEXT
// ---------------------------------------------------------
// Imagine you are building a "Corporate Knowledge Copilot" using Blazor WASM. 
// This AI assistant answers employee questions based on sensitive internal documents.
// You have an OpenAI API key (or Azure OpenAI Key) that costs money and must be kept secret.
// If you put this key in the Blazor WASM client code, any user can extract it via browser dev tools,
// leading to potential abuse and financial loss.
//
// SOLUTION:
// We build a minimal ASP.NET Core server acting as a secure proxy. The Blazor WASM app sends
// requests to our server. The server holds the secret key securely (in memory for this demo,
// but typically Azure Key Vault) and forwards the request to the actual AI provider.
// ---------------------------------------------------------

var builder = WebApplication.CreateBuilder(args);

// 1. SERVICE REGISTRATION & CONFIGURATION
// ---------------------------------------------------------
// We register necessary services: 
// - Controllers (for the API endpoints)
// - Authorization services
// - Authentication (JWT Bearer) to ensure only logged-in users can access the proxy
// - Rate Limiting services to prevent abuse
builder.Services.AddControllers();
builder.Services.AddAuthorization();

// In a real scenario, store the API key in Azure Key Vault or User Secrets.
// For this self-contained example, we inject it via the configuration system.
// We simulate a secure storage retrieval here.
var aiApiKey = builder.Configuration["AI_API_KEY"] ?? "sk-TEST-KEY-FOR-DEMO-ONLY"; 

// Register the AI Service as a Singleton. 
// This service encapsulates the logic for calling the external AI provider.
builder.Services.AddSingleton<IAIService>(new ExternalAIService(aiApiKey));

// 2. AUTHENTICATION SETUP (Simulated for Demo)
// ---------------------------------------------------------
// In a real Blazor WASM app, you'd use Azure AD, IdentityServer, or Auth0.
// Here, we simulate a JWT validation to demonstrate how to lock down the endpoint.
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = "CopilotServer",
            ValidAudience = "CopilotClient",
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("ThisIsASecretKeyForDemoPurposesOnly123456")) // In production, use a proper key management strategy
        };
    });

// 3. RATE LIMITING CONFIGURATION
// ---------------------------------------------------------
// Prevent a single user from spamming the AI endpoint, which could rack up costs.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    
    options.AddPolicy("CopilotPolicy", context =>
    {
        // Identify user by NameIdentifier claim. If not authenticated, use IP address.
        var userId = context.User.FindFirstValue(ClaimTypes.NameIdentifier) 
                     ?? context.Connection.RemoteIpAddress?.ToString() 
                     ?? "anonymous";

        return RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: userId,
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10, // 10 requests
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            });
    });
});

var app = builder.Build();

// 4. MIDDLEWARE PIPELINE
// ---------------------------------------------------------
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter(); // Enforce the limits defined above

// Map the controllers
app.MapControllers();

// ---------------------------------------------------------
// SERVER-SIDE CONTROLLER (The Secure Proxy)
// ---------------------------------------------------------
// This is the core component. It receives the request from the WASM client.
// It validates the user, checks rate limits, and then calls the external AI API.
[ApiController]
[Route("api/[controller]")]
public class AIProxyController : ControllerBase
{
    private readonly IAIService _aiService;
    private readonly ILogger<AIProxyController> _logger;

    public AIProxyController(IAIService aiService, ILogger<AIProxyController> logger)
    {
        _aiService = aiService;
        _logger = logger;
    }

    [HttpPost("ask")]
    [Authorize] // Only authenticated users can access this
    [EnableRateLimiting("CopilotPolicy")] // Apply rate limiting
    public async Task<IActionResult> AskQuestion([FromBody] AIRequest request)
    {
        // Audit Logging: We know WHO asked WHAT and WHEN.
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        _logger.LogInformation("User {UserId} requested AI response for prompt: {Prompt}", userId, request.Prompt);

        if (string.IsNullOrWhiteSpace(request.Prompt))
        {
            return BadRequest("Prompt is required.");
        }

        try
        {
            // Call the secure internal service (which holds the secret key)
            var response = await _aiService.GetResponseAsync(request.Prompt);
            
            // Return the result to the client
            return Ok(new AIResponse { Answer = response });
        }
        catch (Exception ex)
        {
            // Never expose internal API errors or keys to the client
            _logger.LogError(ex, "Error processing AI request for user {UserId}", userId);
            return StatusCode(500, "An error occurred while processing your request.");
        }
    }
}

// ---------------------------------------------------------
// INTERNAL AI SERVICE (The Key Holder)
// ---------------------------------------------------------
// This interface and implementation hide the complexity of the external API.
// The API Key is stored in the constructor of this service.
public interface IAIService
{
    Task<string> GetResponseAsync(string prompt);
}

public class ExternalAIService : IAIService
{
    private readonly string _apiKey;
    private readonly HttpClient _httpClient;

    public ExternalAIService(string apiKey)
    {
        _apiKey = apiKey; // The secret is stored in memory here
        _httpClient = new HttpClient();
    }

    public async Task<string> GetResponseAsync(string prompt)
    {
        // Simulate a call to an external AI provider (e.g., OpenAI API)
        // In a real app, you would construct an HttpRequestMessage here.
        
        // SECURITY NOTE: The _apiKey is never sent to the client.
        // It is only used on the server to authenticate with the external provider.
        
        // Simulating network latency and processing
        await Task.Delay(100); 
        
        // Return a mock response
        return $"Secure AI processed: '{prompt}'. (Real key used: {_apiKey.Substring(0, 10)}...)";
    }
}

// ---------------------------------------------------------
// DATA MODELS
// ---------------------------------------------------------
public class AIRequest
{
    public string Prompt { get; set; } = string.Empty;
}

public class AIResponse
{
    public string Answer { get; set; } = string.Empty;
}

// ---------------------------------------------------------
// DIAGRAM: ARCHITECTURE FLOW
// ---------------------------------------------------------
/*


::: {style="text-align: center"}
![A user's prompt is encapsulated into an `AIRequest` object, sent to an AI service, and the resulting data is returned encapsulated within an `AIResponse` object.](images/b15_c13_s2_diag1.png){width=80% caption="A user's prompt is encapsulated into an `AIRequest` object, sent to an AI service, and the resulting data is returned encapsulated within an `AIResponse` object."}
:::


*/

// ---------------------------------------------------------
// EXECUTION
// ---------------------------------------------------------
app.Run();


// ---------------------------------------------------------
// DETAILED LINE-BY-LINE EXPLANATION
// ---------------------------------------------------------

// 1. `var builder = WebApplication.CreateBuilder(args);`
//    - Initializes a new instance of the WebApplication builder.
//    - This sets up the generic host, default configuration sources (appsettings.json, environment variables), and default services (logging, dependency injection).

// 2. `builder.Services.AddControllers();`
//    - Registers the services required for API controller functionality.
//    - This includes support for model binding, validation, and action result types.

// 3. `builder.Services.AddAuthorization();`
//    - Adds the authorization policy services to the DI container.
//    - This allows us to use the `[Authorize]` attribute on controllers or actions.

// 4. `var aiApiKey = builder.Configuration["AI_API_KEY"] ?? "sk-TEST-KEY...";`
//    - Retrieves the API key from configuration sources.
//    - In a production environment, you would inject `IConfiguration` into a service or use Azure Key Vault.
//    - The fallback value is for demonstration purposes only.

// 5. `builder.Services.AddSingleton<IAIService>(new ExternalAIService(aiApiKey));`
//    - Registers the `ExternalAIService` as a singleton.
//    - **Crucial Security Point:** The `aiApiKey` is passed to the constructor *once* at startup.
//    - The key is now encapsulated within this service instance in memory. It is not accessible via HTTP requests.

// 6. `builder.Services.AddAuthentication(...)`
//    - Configures the authentication scheme. We use `JwtBearerDefaults.AuthenticationScheme` which is standard for API authentication.
//    - The lambda expression configures the validation parameters for incoming JWT tokens.

// 7. `IssuerSigningKey = new SymmetricSecurityKey(...)`
//    - Defines the key used to sign and validate the JWT token.
//    - **Pitfall:** In production, this key must be a high-entropy random string stored securely (e.g., Azure Key Vault) and shared between the Auth provider and this API.

// 8. `builder.Services.AddRateLimiter(options => ...)`
//    - Configures the global rate limiting middleware.
//    - `GetFixedWindowLimiter`: Allows a specific number of requests (10) per time window (1 minute).
//    - `partitionKey`: Uses the User ID (ClaimTypes.NameIdentifier) to track limits per user. If the user is anonymous, it falls back to the IP address.

// 9. `app.UseAuthentication();` & `app.UseAuthorization();`
//    - These middleware components must be ordered correctly.
//    - `UseAuthentication` validates the token and populates the `User` object.
//    - `UseAuthorization` checks if the user has the required permissions (based on `[Authorize]` attributes).

// 10. `app.UseRateLimiter();`
//     - Enables the rate limiting policy defined in step 8. This should be placed after authentication if the limit is user-based.

// 11. `[Route("api/[controller]")]`
//     - Defines the route template. `[controller]` is replaced by the class name minus "Controller" (e.g., "AIProxy").
//     - The full route becomes `api/AIProxy`.

// 12. `[Authorize]`
//     - A security attribute. If a request lacks a valid JWT token, the server immediately returns a `401 Unauthorized` response.
//     - This prevents unauthenticated users from even reaching the logic inside `AskQuestion`.

// 13. `[EnableRateLimiting("CopilotPolicy")]`
//     - Applies the specific rate limiting policy defined in the startup configuration to this endpoint.

// 14. `var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);`
//     - Extracts the unique user identifier from the validated JWT token.
//     - This is used for audit logging. We know exactly who requested what.

// 15. `_aiService.GetResponseAsync(request.Prompt)`
//     - Calls the internal service. This is the **Data Access Layer** for the AI.
//     - The `_aiService` instance holds the secret key securely in memory.

// 16. `catch (Exception ex)`
//     - Catches any errors (e.g., network failure, invalid API key on the external provider).
//     - **Security Best Practice:** We log the full exception internally (`_logger.LogError`) but return a generic error message to the client.
//     - We never want to leak stack traces or internal configuration details to the public client.

// 17. `public class ExternalAIService : IAIService`
//     - This class acts as a wrapper around the external API.
//     - By isolating the API key here, we ensure it is never mixed with HTTP request handling logic, reducing the risk of accidental exposure.

// ---------------------------------------------------------
// COMMON PITFALLS
// ---------------------------------------------------------
// ### Common Pitfalls
//
// 1. **Exposing the Key in Client-Side Code:**
//    - **Mistake:** Storing the API key in a JavaScript file or Blazor WASM `appsettings.json`.
//    - **Consequence:** Anyone can view "View Source" or inspect Network traffic to steal the key.
//    - **Fix:** Always proxy requests through a server where the key resides.
//
// 2. **Logging Sensitive Data:**
//    - **Mistake:** Using `LogInformation($"Key: {apiKey}")` for debugging.
//    - **Consequence:** The API key ends up in log files (Azure App Service logs, Seq, etc.) which might be accessible to unauthorized personnel.
//    - **Fix:** Never log secrets. Log metadata (User ID, Timestamp, Request ID) instead.
//
// 3. **Insecure Rate Limiting:**
//    - **Mistake:** Rate limiting based only on IP address for authenticated endpoints.
//    - **Consequence:** A user behind a NAT (shared IP) gets blocked because of others' usage, or a malicious user can rotate IPs to bypass limits.
//    - **Fix:** Always prioritize User ID (from JWT claims) for rate limiting authenticated users.
//
// 4. **Storing Keys in Source Control:**
//    - **Mistake:** Hardcoding the key in the C# file or committing `appsettings.json` with real keys to Git.
//    - **Consequence:** The secret is permanently history in the repository.
//    - **Fix:** Use `.gitignore`, User Secrets for local dev, and Azure Key Vault/Environment Variables for production.
