
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_script.cs
// Description: Advanced Application Script
// ==========================================

using System;
using System.Collections.Generic;
using System.Text;

namespace SecureCopilotProxy
{
    // 1. The Problem Context:
    // A client-side Blazor WASM application needs to call a paid AI service (e.g., OpenAI).
    // Storing the API key in the WASM binary is insecure because it can be extracted by anyone.
    // Solution: The WASM app calls a local C# console application (acting as a secure proxy).
    // The proxy holds the real API key in memory (or secure storage) and forwards the request.
    // This console app simulates the server-side logic: Authentication, Rate Limiting, and Secure Forwarding.

    class Program
    {
        // In a real scenario, this key comes from Azure Key Vault or Environment Variables.
        // NEVER hardcode keys in source control. We simulate the "secure retrieval" here.
        private static readonly string SecurelyStoredApiKey = "sk-secure-backend-key-12345";

        // Simple in-memory storage for rate limiting.
        // Key: Client IP (simulated), Value: Timestamp of last request.
        // In production, use a distributed cache like Redis.
        private static Dictionary<string, DateTime> _rateLimitStore = new Dictionary<string, DateTime>();

        static void Main(string[] args)
        {
            Console.WriteLine("--- Secure Copilot Proxy Server Started ---");
            Console.WriteLine("Waiting for client requests...\n");

            // Simulate an incoming request loop
            SimulateClientRequests();

            Console.WriteLine("\n--- Proxy Server Stopped ---");
        }

        // Simulates multiple clients hitting the proxy
        static void SimulateClientRequests()
        {
            // Mock Client 1: Valid request
            ProcessRequest("192.168.1.50", "user-query-1", "sk-client-1");

            // Mock Client 2: Invalid API Key
            ProcessRequest("192.168.1.51", "user-query-2", "wrong-key");

            // Mock Client 1: Rate Limit Violation (Simulated by immediate second call)
            ProcessRequest("192.168.1.50", "user-query-3", "sk-client-1");

            // Mock Client 3: Valid request after delay
            System.Threading.Thread.Sleep(2000); // Simulate time passing
            ProcessRequest("192.168.1.52", "user-query-4", "sk-client-3");
        }

        // Core Logic: The Entry Point for the Proxy
        static void ProcessRequest(string clientIp, string userPrompt, string clientApiKey)
        {
            Console.WriteLine($"[INFO] Received request from {clientIp}: {userPrompt}");

            // STEP 1: Authentication
            // Verify the client is allowed to use this proxy.
            if (!AuthenticateClient(clientApiKey))
            {
                LogAudit("AUTH_FAILURE", clientIp, "Invalid API Key provided.");
                Console.WriteLine($"[ERROR] 401 Unauthorized for {clientIp}\n");
                return;
            }

            // STEP 2: Rate Limiting
            // Ensure the client isn't spamming the endpoint.
            if (!CheckRateLimit(clientIp))
            {
                LogAudit("RATE_LIMIT_HIT", clientIp, "Request throttled.");
                Console.WriteLine($"[WARN] 429 Too Many Requests for {clientIp}\n");
                return;
            }

            // STEP 3: Secure Forwarding
            // The proxy uses the SECURE backend key to call the AI service.
            // The client never sees this key.
            string aiResponse = ForwardToAiService(userPrompt);

            // STEP 4: Audit Logging
            // Record the transaction for security analysis.
            LogAudit("SUCCESS", clientIp, $"Response: {aiResponse}");

            Console.WriteLine($"[SUCCESS] Response sent to {clientIp}: {aiResponse}\n");
        }

        // Checks if the client key matches the pre-shared secret for this proxy
        static bool AuthenticateClient(string clientKey)
        {
            // In a real app, this would check a database or identity provider.
            // Here, we simulate a whitelist.
            string[] validClientKeys = { "sk-client-1", "sk-client-2", "sk-client-3" };

            foreach (string key in validClientKeys)
            {
                if (key == clientKey)
                {
                    return true;
                }
            }
            return false;
        }

        // Implements a sliding window rate limit (1 request per 1.5 seconds per IP)
        static bool CheckRateLimit(string clientIp)
        {
            DateTime now = DateTime.Now;
            DateTime lastRequestTime;

            if (_rateLimitStore.TryGetValue(clientIp, out lastRequestTime))
            {
                TimeSpan timeSinceLastRequest = now - lastRequestTime;
                
                // Allow request if more than 1.5 seconds have passed
                if (timeSinceLastRequest.TotalSeconds < 1.5)
                {
                    return false; // Too soon
                }
            }

            // Update the store with the current time
            _rateLimitStore[clientIp] = now;
            return true;
        }

        // Simulates the secure call to the external AI API
        static string ForwardToAiService(string prompt)
        {
            // CRITICAL: The SecurelyStoredApiKey is used here.
            // It is never exposed to the client (WASM).
            // We simulate the API call logic.
            if (string.IsNullOrEmpty(SecurelyStoredApiKey))
            {
                return "Error: Backend Key Missing";
            }

            // Simulate processing delay
            System.Threading.Thread.Sleep(100);

            // Return a mock AI response
            return "AI Generated Response for: " + prompt;
        }

        // Writes a standardized audit log entry
        static void LogAudit(string status, string ip, string details)
        {
            // In production, write to a secure file, database, or SIEM system.
            string logEntry = $"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} | {status} | IP: {ip} | Details: {details}";
            Console.WriteLine($"   [AUDIT] {logEntry}");
        }
    }
}
