
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.cs
// Description: Solution for Exercise 2
// ==========================================

using Azure.Identity;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);

// 1. Setup Azure Key Vault References (Simulated for Local Dev)
// In a real Azure environment, we would use DefaultAzureCredential which automatically
// uses Managed Identity when deployed, or local Azure CLI/VS credentials when developing.
var keyVaultUrl = builder.Configuration["KeyVaultUrl"];

if (!string.IsNullOrEmpty(keyVaultUrl))
{
    // Production/Real Azure Scenario
    builder.Configuration.AddAzureKeyVault(
        new Uri(keyVaultUrl),
        new DefaultAzureCredential());
}
else
{
    // 2. Local Development Simulation
    // Use User Secrets for local development to simulate Key Vault.
    // Run: dotnet user-secrets init
    // Run: dotnet user-secrets set "AiSettings:ApiKey" "sk-...-local-dev"
    builder.Configuration.AddUserSecrets<Program>();
}

// 3. Configure Options (Values are now pulled from Key Vault/User Secrets)
builder.Services.Configure<AiSettings>(builder.Configuration.GetSection("AiSettings"));

// ... (Rest of the setup from Exercise 1: HttpClient, CORS, etc.)

var app = builder.Build();

// ... (Middleware pipeline)

app.Run();

public class AiSettings
{
    // 4. Retrieve Secrets: The properties map to the Key Vault secret names
    // or User Secret keys (e.g., "AiSettings:ApiKey").
    public string ApiKey { get; set; } = string.Empty;
    public string Endpoint { get; set; } = string.Empty;
}
