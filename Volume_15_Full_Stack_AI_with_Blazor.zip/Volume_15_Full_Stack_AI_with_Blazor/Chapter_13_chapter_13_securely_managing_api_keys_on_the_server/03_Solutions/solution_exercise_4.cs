
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.cs
// Description: Solution for Exercise 4
// ==========================================

using System.Diagnostics;
using System.Net;
using System.Text.Json;
using AspNetCoreRateLimit;

var builder = WebApplication.CreateBuilder(args);

// 1. Rate Limiting Configuration
builder.Services.AddRateLimiter(options =>
{
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(context =>
    {
        // Identify user by IP (or User.Identity.Name if authenticated)
        var userId = context.User.Identity?.Name ?? context.Connection.RemoteIpAddress?.ToString();
        
        return RateLimitPartition.GetSlidingWindowLimiter(userId, _ => new SlidingWindowRateLimiterOptions
        {
            PermitLimit = 10, // 10 requests
            Window = TimeSpan.FromMinutes(1), // per minute
            SegmentsPerWindow = 2, // 2 segments for smoother sliding
            QueueLimit = 0
        });
    });

    // 4. Interactive Challenge: Custom 429 Response
    options.OnRejected = async (context, token) =>
    {
        context.HttpContext.Response.StatusCode = 429;
        context.HttpContext.Response.ContentType = "application/json";
        
        var retryAfter = context.HttpContext.Response.Headers.RetryAfter;
        
        await context.HttpContext.Response.WriteAsync(
            JsonSerializer.Serialize(new 
            { 
                error = "Too many requests. Please slow down.", 
                retryAfter = retryAfter 
            }), 
            cancellationToken: token);
    };
});

// 2. Audit Logging (Custom Middleware)
var app = builder.Build();

app.UseRateLimiter();

// 2. Audit Logging Middleware
app.Use(async (context, next) =>
{
    var stopwatch = Stopwatch.StartNew();
    var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();
    
    // Log Request
    var userId = context.User.Identity?.Name ?? "Anonymous";
    logger.LogInformation(
        "Request started: {Method} {Path} by {UserId}", 
        context.Request.Method, context.Request.Path, userId);

    try
    {
        await next.Invoke();
        stopwatch.Stop();

        // Log Response
        logger.LogInformation(
            "Request finished: {StatusCode} in {ElapsedMs}ms", 
            context.Response.StatusCode, stopwatch.ElapsedMilliseconds);
    }
    catch (Exception ex)
    {
        stopwatch.Stop();
        logger.LogError(ex, "Request failed after {ElapsedMs}ms", stopwatch.ElapsedMilliseconds);
        throw; // Re-throw to allow global error handling
    }
});

// 3. Protected Endpoint
app.MapPost("/api/ai/chat", [Authorize] async (/* dependencies */) =>
{
    // Simulate processing
    await Task.Delay(100);
    return Results.Ok(new { Result = "AI Response" });
}).RequireRateLimiting("global"); // Apply rate limiting policy

app.Run();
