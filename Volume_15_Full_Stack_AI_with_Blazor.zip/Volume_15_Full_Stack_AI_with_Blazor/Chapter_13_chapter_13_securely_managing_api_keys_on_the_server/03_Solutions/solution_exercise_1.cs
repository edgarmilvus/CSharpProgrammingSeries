
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/CSharpProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.cs
// Description: Solution for Exercise 1
// ==========================================

using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// 1. Configure Options Pattern for AiSettings
builder.Services.Configure<AiSettings>(builder.Configuration.GetSection("AiSettings"));

// 2. Register HttpClientFactory
builder.Services.AddHttpClient();

// 3. Configure CORS for Blazor WASM
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowBlazorWasm", policy =>
    {
        policy.WithOrigins("https://localhost:7000") // Default Blazor WASM port
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseCors("AllowBlazorWasm");

// 4. Define the Secure Proxy Endpoint
app.MapPost("/api/ai/chat", async (
    IHttpClientFactory httpClientFactory,
    IOptions<AiSettings> aiSettings,
    ILogger<Program> logger,
    AiRequest request) =>
{
    // Validate input
    if (string.IsNullOrWhiteSpace(request.Prompt))
    {
        return Results.BadRequest(new { error = "Prompt is required." });
    }

    try
    {
        // Create HttpClient using the factory
        var client = httpClientFactory.CreateClient();

        // Attach the secret key from secure configuration
        client.DefaultRequestHeaders.Authorization = 
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", aiSettings.Value.ApiKey);

        // Simulate forwarding to external AI service
        // In a real scenario, you would POST to aiSettings.Value.Endpoint
        var response = await client.PostAsJsonAsync(aiSettings.Value.Endpoint, request);

        if (response.IsSuccessStatusCode)
        {
            var result = await response.Content.ReadFromJsonAsync<AiResponse>();
            return Results.Ok(result);
        }
        else
        {
            // Log the failure internally but return a generic error
            logger.LogError("AI Service returned status {StatusCode}", response.StatusCode);
            return Results.StatusCode(500); // Internal Server Error
        }
    }
    catch (Exception ex)
    {
        // Catch network or serialization errors
        logger.LogError(ex, "Error proxying AI request.");
        // Return standardized error without leaking stack trace
        return Results.Json(new { error = "An internal error occurred processing your request." }, statusCode: 500);
    }
});

app.Run();

// Models
public record AiRequest(string Prompt);
public record AiResponse(string Result);

public class AiSettings
{
    public string ApiKey { get; set; } = string.Empty;
    public string Endpoint { get; set; } = "https://api.example.com/v1/chat"; // Default for simulation
}
